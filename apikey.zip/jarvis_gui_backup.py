import customtkinter as ctk
import datetime
import psutil
import os

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.title("J.A.R.V.I.S - ALPHA NEXTGEN ECLIPSE")
app.geometry("1400x800")

# ---------------- FUNCTIONS ----------------

def update_dashboard():

    clock.configure(
        text=datetime.datetime.now().strftime("%d-%b-%Y %I:%M:%S %p")
    )

    cpu.configure(
        text=f"CPU : {psutil.cpu_percent()}%"
    )

    ram.configure(
        text=f"RAM : {psutil.virtual_memory().percent}%"
    )

    app.after(1000, update_dashboard)


def start_day():

    try:
        os.system("start outlook")
    except:
        pass

    try:
        os.startfile(
            r"C:\Users\aranja14\AppData\Local\Microsoft\WindowsApps\ms-teams.exe"
        )
    except:
        pass

    try:
        os.system("start msedge")
    except:
        pass

    output.configure(
        text="✅ Work Environment Started"
    )


def execute():

    command = cmd_box.get().lower().strip()

    if command == "outlook":

        os.system("start outlook")

        output.configure(
            text="📧 Opening Outlook..."
        )

    elif command == "teams":

        os.startfile(
            r"C:\Users\aranja14\AppData\Local\Microsoft\WindowsApps\ms-teams.exe"
        )

        output.configure(
            text="💬 Opening Teams..."
        )

    elif command == "edge":

        os.system("start msedge")

        output.configure(
            text="🌐 Opening Edge..."
        )

    elif command == "excel":

        os.system("start excel")

        output.configure(
            text="📊 Opening Excel..."
        )

    elif command == "time":

        output.configure(
            text=datetime.datetime.now().strftime("%I:%M:%S %p")
        )

    else:

        output.configure(
            text=f"❌ Unknown Command : {command}"
        )

# ---------------- HEADER ----------------

title = ctk.CTkLabel(
    app,
    text="J.A.R.V.I.S",
    font=("Arial", 50, "bold"),
    text_color="#00D9FF"
)

title.pack(pady=(20, 5))

subtitle = ctk.CTkLabel(
    app,
    text="ALPHA NEXTGEN ECLIPSE",
    font=("Arial", 22)
)

subtitle.pack()

status = ctk.CTkLabel(
    app,
    text="AI CORE ONLINE",
    font=("Arial", 18, "bold"),
    text_color="#00FF99"
)

status.pack(pady=5)

# ---------------- MAIN AREA ----------------

main = ctk.CTkFrame(app)

main.pack(
    fill="both",
    expand=True,
    padx=15,
    pady=15
)

# ---------- LEFT ----------

left = ctk.CTkFrame(
    main,
    width=250
)

left.pack(
    side="left",
    fill="y",
    padx=10,
    pady=10
)

ctk.CTkLabel(
    left,
    text="SYSTEM",
    font=("Arial", 25, "bold")
).pack(pady=20)

cpu = ctk.CTkLabel(
    left,
    text="CPU"
)

cpu.pack(pady=10)

ram = ctk.CTkLabel(
    left,
    text="RAM"
)

ram.pack(pady=10)

clock = ctk.CTkLabel(
    left,
    text=""
)

clock.pack(pady=10)

# ---------- CENTER ----------

center = ctk.CTkFrame(main)

center.pack(
    side="left",
    fill="both",
    expand=True,
    padx=10
)

reactor = ctk.CTkLabel(
    center,
    text="""
           ◉

      ◉         ◉

           ◉

      ARC REACTOR

      AI CORE
       ONLINE
    """,
    font=("Consolas", 26),
    text_color="#00D9FF"
)

reactor.pack(pady=40)

cmd_box = ctk.CTkEntry(
    center,
    width=600,
    height=45,
    placeholder_text="Type : outlook / teams / excel / edge"
)

cmd_box.pack(pady=20)

ctk.CTkButton(
    center,
    text="EXECUTE",
    command=execute,
    width=250
).pack(pady=10)

ctk.CTkButton(
    center,
    text="START MY DAY",
    command=start_day,
    width=250,
    fg_color="green"
).pack(pady=10)

output = ctk.CTkLabel(
    center,
    text="SYSTEM READY...",
    font=("Arial", 18)
)

output.pack(pady=25)

# ---------- RIGHT ----------

right = ctk.CTkFrame(
    main,
    width=300
)

right.pack(
    side="right",
    fill="y",
    padx=10
)

ctk.CTkLabel(
    right,
    text="ACTIVE MODULES",
    font=("Arial", 24, "bold")
).pack(pady=20)

modules = [
    "OUTLOOK",
    "TEAMS",
    "EXCEL",
    "EDGE",
    "PCRL",
    "TRACKER",
    "INTRADIEM",
    "SHAREPOINT"
]

for module in modules:

    ctk.CTkLabel(
        right,
        text=f"● {module}",
        text_color="#00D9FF"
    ).pack(pady=5)

update_dashboard()

app.mainloop()