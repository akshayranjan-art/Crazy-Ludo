import os
import sys
import json
import time
import socket
import datetime
import subprocess
import webbrowser
import threading

try:
    import psutil
except ImportError:
    psutil = None

try:
    import webview
except ImportError:
    webview = None

try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "eclipse_data.json")
MEM_FILE = os.path.join(BASE, "jarvis_memory.json")
HTML_FILE = os.path.join(BASE, "jarvis_3d_hud.html")
TITLE = "ECLIPSE A.I. | OPTUM · Alpha NextGen | V2.6 FEMALE AI [MUTED]"

# Default Speaker OFF rahega jab tak aap 'voice on' na karein
VOICE_ENABLED = False

APP_MAP = {
    "outlook": ["outlook.exe", "ms-outlook:", "https://office.com"],
    "teams": ["msteams:", "ms-teams:", "ms-teams.exe", "https://microsoft.com"],
    "excel": ["excel.exe", "https://office.com"],
    "word": ["winword.exe", "https://office.com"],
    "powerpoint": ["powerpnt.exe"],
    "edge": ["msedge.exe", "microsoft-edge:https://bing.com"],
    "chrome": ["chrome.exe"],
    "explorer": ["explorer.exe"],
    "notepad": ["notepad.exe"],
    "calc": ["calc.exe"],
    "cmd": ["cmd.exe"],
    "onedrive": ["https://office.com"],
    "sharepoint": ["https://office.com"],
}

import asyncio
import edge_tts
import pygame

pygame.mixer.init()

def speak(text, force=False):
    """100% Offline Young Sweet Girl Voice (SSML High-Pitch + Fast-Rate Boost)"""
    if not text:
        return
    if not VOICE_ENABLED and not force:
        return

    clean = "".join(ch for ch in str(text) if ch.isalnum() or ch in " .,!?'-").strip()
    if not clean:
        return

    # SSML se pitch +35% aur speed +12% badhane par ekdum young sweet ladki ki aawaz aati hai
    ssml = (
        f'<speak version="1.0" xmlns="http://w3.org" xml:lang="en-US">'
        f'<voice gender="female" age="teen">'
        f'<prosody pitch="+35%" rate="+12%">{clean}</prosody>'
        f'</voice></speak>'
    )

    ps_script = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Gender -eq 'Female' } | Select-Object -First 1; "
        "if ($v) { $s.SelectVoice($v.VoiceInfo.Name) }; "
        f"$s.SpeakSsml('{ssml}');"
    )
    try:
        subprocess.Popen(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_script],
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform.startswith("win") else 0
        )
    except Exception:
        pass

    threading.Thread(target=_run, daemon=True).start()



def _open_one(target):
    if sys.platform.startswith("win"):
        os.startfile(target)
    elif target.startswith(("http://", "https://")):
        webbrowser.open(target)
    else:
        subprocess.Popen(["xdg-open", target])


class Api:
    def __init__(self):
        self._net_prev = None
        if psutil:
            try:
                psutil.cpu_percent(interval=None)
            except Exception:
                pass

    # 1. REAL SYSTEM VITALS
    def vitals(self):
        if not psutil:
            return None
        try:
            vm = psutil.virtual_memory()
            drive = os.environ.get("SystemDrive", "C:") + "\\" if sys.platform.startswith("win") else "/"
            du = psutil.disk_usage(drive)
            net = psutil.net_io_counters()
            now = time.time()
            down = up = 0
            if self._net_prev:
                t0, r0, s0 = self._net_prev
                dt = max(now - t0, 0.001)
                down = round((net.bytes_recv - r0) / 1024 / dt, 1)
                up = round((net.bytes_sent - s0) / 1024 / dt, 1)
            self._net_prev = (now, net.bytes_recv, net.bytes_sent)
            bat = 100
            plugged = True
            try:
                b = psutil.sensors_battery()
                if b:
                    bat = int(b.percent)
                    plugged = bool(b.power_plugged)
            except Exception:
                pass
            up_s = int(now - psutil.boot_time())
            return {
                "cpu": float(psutil.cpu_percent(interval=None)),
                "cores": psutil.cpu_count(logical=True) or 0,
                "ram": float(vm.percent),
                "ram_used": round(vm.used / 1024 ** 3, 1),
                "ram_total": round(vm.total / 1024 ** 3, 1),
                "disk": float(du.percent),
                "disk_free": round(du.free / 1024 ** 3, 1),
                "down": down,
                "up": up,
                "battery": bat,
                "plugged": plugged,
                "uptime": "%dh %02dm" % (up_s // 3600, up_s % 3600 // 60),
                "host": socket.gethostname().upper(),
            }
        except Exception:
            return None

    # 2. APP & WEB LINK LAUNCHER
    def launch(self, target):
        t = (target or "").strip()
        if not t:
            return {"ok": False, "err": "Empty link"}
        low = t.lower()
        label = t
        if low.startswith("app:"):
            key = low[4:].strip()
            label = key
            choices = APP_MAP.get(key, [key if key.endswith(".exe") else key + ".exe"])
        elif low in APP_MAP:
            label = low
            choices = APP_MAP[low]
        else:
            label = "requested module"
            choices = [t]

        last = ""
        for c in choices:
            try:
                _open_one(c)
                speak(f"Opening {label}, Akshay.")
                return {"ok": True}
            except Exception as e:
                last = str(e)
        return {"ok": False, "err": last}

    # 3. VOICE TOGGLE + SELF-LEARNING BRAIN + PERMANENT MEMORY VAULT
    def ask_ai(self, prompt):
        global VOICE_ENABLED
        q = (prompt or "").strip()
        low = q.lower()
        brain_file = os.path.join(BASE, "jarvis_brain.json")

        # Load Self-Learning Q&A Brain
        try:
            with open(brain_file, "r", encoding="utf-8") as f:
                brain = json.load(f)
        except Exception:
            brain = {
                "hi": "Hello Akshay! All Optum systems are online and ready.",
                "hello": "Greetings, Akshay. How can I assist you today?",
                "who are you": "I am Eclipse A.I., your personal tactical assistant."
            }

        # Load Permanent Notes List
        try:
            with open(MEM_FILE, "r", encoding="utf-8") as f:
                memories = json.load(f)
        except Exception:
            memories = []

        # A. VOICE ON / OFF CONTROL
        if low in ["voice on", "speaker on", "unmute", "speak on"]:
            VOICE_ENABLED = True
            speak("Voice module activated. Hello Akshay, I am online.", force=True)
            return "🔊 VOICE MODULE: ON (Female AI Voice Activated)"

        if low in ["voice off", "speaker off", "mute", "speak off"]:
            VOICE_ENABLED = False
            return "🔇 VOICE MODULE: OFF (Silent Text Mode Active)"

        # B. SELF-LEARNING Q&A (Format: learn: hi = Hello Boss!)
        if low.startswith(("learn:", "teach:", "sikho:")):
            data = q.split(":", 1)[1].strip()
            if "=" in data:
                trigger, reply = data.split("=", 1)
                t_key = trigger.strip().lower()
                r_val = reply.strip()
                if t_key and r_val:
                    brain[t_key] = r_val
                    with open(brain_file, "w", encoding="utf-8") as f:
                        json.dump(brain, f, ensure_ascii=False, indent=2)
                    speak("New response learned and saved permanently.")
                    return f"🧠 LEARNED PERMANENTLY: '{t_key}' ➜ '{r_val}'"
            return "⚠️ Format use karein: learn: hi = Hello Akshay, ready to work!"

        # C. SAVE PERMANENT NOTE/LIST ITEM (Format: remember: Check PCRL)
        if low.startswith(("remember:", "save:", "note:", "yaad rakh:")):
            item = q.split(":", 1)[1].strip()
            if item:
                timestamp = datetime.datetime.now().strftime("%d-%b-%Y %I:%M %p")
                memories.append({"time": timestamp, "text": item})
                with open(MEM_FILE, "w", encoding="utf-8") as f:
                    json.dump(memories, f, ensure_ascii=False, indent=2)
                speak(f"Saved at entry number {len(memories)}.")
                return f"📌 SAVED TO LIST [#{len(memories)}]: '{item}'"
            return "⚠️ Type what to save after ':' (e.g., remember: Check PCRL report)."

        # D. SHOW FULL SAVED LIST & BRAIN
        if low in ["list", "show list", "memory", "show memory", "brain list", "list dikha"]:
            out = ["🧠 ECLIPSE PERMANENT KNOWLEDGE & LIST:"]
            out.append("\n--- LEARNED Q&A (jarvis_brain.json) ---")
            for k, v in brain.items():
                out.append(f"  • '{k}' ➜ {v}")
            out.append("\n--- SAVED NOTES / LIST (jarvis_memory.json) ---")
            if not memories:
                out.append("  (No notes saved yet. Use 'remember: <note>')")
            else:
                for idx, m in enumerate(memories, 1):
                    out.append(f"  [{idx}] ({m['time']}) ➜ {m['text']}")
            speak("Displaying your permanent memory and learned responses.")
            return "\n".join(out)

        # E. SEARCH MEMORY
        if low.startswith(("find:", "search:", "dhoondh:")):
            word = q.split(":", 1)[1].strip().lower()
            found = [f"• [{idx}] ({m['time']}) {m['text']}" for idx, m in enumerate(memories, 1) if word in m["text"].lower()]
            if found:
                speak(f"Found {len(found)} matching records.")
                return f"🔍 SEARCH RESULTS FOR '{word.upper()}':\n" + "\n".join(found)
            speak("No matching records found.")
            return f"❌ No records found matching '{word}'."

        # F. DELETE NOTE OR Q&A (Format: forget: 1 or forget: hi)
        if low.startswith(("forget:", "delete:", "bhool ja:")):
            target = q.split(":", 1)[1].strip().lower()
            if target in brain:
                del brain[target]
                with open(brain_file, "w", encoding="utf-8") as f:
                    json.dump(brain, f, ensure_ascii=False, indent=2)
                speak("Learned response removed.")
                return f"🗑️ REMOVED LEARNED Q&A: '{target}'"
            try:
                num = int(target)
                removed = memories.pop(num - 1)
                with open(MEM_FILE, "w", encoding="utf-8") as f:
                    json.dump(memories, f, ensure_ascii=False, indent=2)
                speak(f"Note number {num} deleted.")
                return f"🗑️ DELETED NOTE #{num}: '{removed['text']}'"
            except Exception:
                return "⚠️ Specify note number or Q&A key to delete (e.g., forget: 1 or forget: hi)."

        # G. CHECK IF JARVIS KNOWS THE ANSWER
        if low in brain:
            ans = brain[low]
            speak(ans)
            return f"🤖 ECLIPSE: {ans}"

        for k, v in brain.items():
            if k in low:
                speak(v)
                return f"🤖 ECLIPSE: {v}"

        speak("I don't know that yet. You can teach me.")
        return f"❓ Unknown: '{q}'.learn: {QA} = your answer"

    # 4. JSON DATA STORE
    def load_store(self):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_store(self, text):
        try:
            data = json.loads(text)
            tmp = DATA_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, DATA_FILE)
            return True
        except Exception:
            return False

    def export_backup(self, text):
        name = "ECLIPSE_AI_Backup_%s.json" % datetime.datetime.now().strftime("%Y-%m-%d_%H%M")
        path = os.path.join(BASE, name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        speak("Backup exported.")
        return path

    def pick_backup(self):
        try:
            win = webview.windows[0]
            kind = getattr(getattr(webview, "FileDialog", None), "OPEN", None) or webview.OPEN_DIALOG
            res = win.create_file_dialog(kind, directory=BASE, file_types=("JSON files (*.json)",))
            if res:
                with open(res[0], "r", encoding="utf-8") as f:
                    return f.read()
        except Exception:
            pass
        return None


def main():
    if webview is None:
        webbrowser.open("file:///" + HTML_FILE.replace("\\", "/"))
        return

    api = Api()
    kwargs = dict(
        url=HTML_FILE,
        js_api=api,
        width=1500,
        height=920,
        min_size=(1100, 700),
        background_color="#03040f",
    )
    try:
        webview.create_window(TITLE, maximized=True, **kwargs)
    except TypeError:
        webview.create_window(TITLE, **kwargs)

    # Shuru mein chup rahega (VOICE_ENABLED = False)
    webview.start()


if __name__ == "__main__":
    main()
