import { AstraItem, PetItem, GiftItem } from '../types/game';

// The generated game assets
export const ASSETS = {
  trishul: '/src/assets/images/ludo_divine_astra_trishul_1790907057947.jpg',
  sudarshan: '/src/assets/images/ludo_divine_sudarshan_chakra_1790907073602.jpg',
  gada: '/src/assets/images/ludo_divine_hanuman_gada_1790907086573.jpg',
  hypercar: '/src/assets/images/ludo_luxury_hypercar_entry_1790907099845.jpg',
  dragonPet: '/src/assets/images/ludo_celestial_dragon_pet_1790907112994.jpg',
  logo: '/src/assets/images/ludo_play_3d_logo_1790926782901.jpg',
  playOnline: '/src/assets/images/ludo_play_online_icon_1790926840583.jpg',
  roomPawns: '/src/assets/images/ludo_room_pawns_icon_1790926857165.jpg',
  hostAnanya: '/src/assets/images/ludo_host_ananya_model_1790926876541.jpg',
};

// 1. Divine Astras with exact Bible and user-specified pricing!
export const ASTRA_ITEMS: AstraItem[] = [
  {
    id: 'trishul-aura',
    name: "Mahadev's Trishul Aura",
    hindiName: 'त्रिशूल तांडव प्रभामंडल',
    tier: 'Ultra Divine',
    element: 'Cosmic Fire & Lightning',
    permanentDiamondCost: 19999999, // 19,999,999 💎 permanent
    image: ASSETS.trishul,
    description: 'Empowers board with Nataraja cosmic Tandav lightning aura. Rolls summon thunder trails across all safe cells.',
    cinematicEffect: 'tandav',
    passiveBonus: '+25% Star Luck on rolls & +500 Fame per turn',
  },
  {
    id: 'gada-entry',
    name: "Hanuman's Golden Gada Entry",
    hindiName: 'श्री हनुमान गदा प्रहार',
    tier: 'Ultra Divine',
    element: 'Earth & Celestial Strength',
    permanentDiamondCost: 59999999, // 59,999,999 💎 permanent
    image: ASSETS.gada,
    description: 'Earth-shattering celestial Gada slam on VIP room entry. Spikes shockwaves into the 8 live seats with ruby particles.',
    cinematicEffect: 'gada-smash',
    passiveBonus: 'Permanent Golden Shockwave on Token Captures',
  },
  {
    id: 'sudarshan-entry',
    name: 'Sudarshan Chakra Supreme Entry',
    hindiName: 'सुदर्शन चक्र अनंत प्रविष्टि',
    tier: 'Apex Divine',
    element: 'Solar Om Singularity',
    permanentDiamondCost: 79999999999, // 79,999,999,999 💎 permanent
    image: ASSETS.sudarshan,
    description: 'The ultimate weapon of cosmic preservation. Blazing golden solar blades spin across the entire 3D arena with sacred Om resonance.',
    cinematicEffect: 'sudarshan-spin',
    passiveBonus: 'Apex Cosmic Title, Golden Nameplate & Unlimited Astral Glory',
  },
  {
    id: 'surya-rath',
    name: 'Surya Rath Radiant Chariot',
    hindiName: 'सूर्य रथ व कोदंड धनुष',
    tier: 'Vedic Astra',
    element: 'Solar Light',
    permanentDiamondCost: 3500000,
    image: ASSETS.sudarshan,
    description: 'Blinding 7-horse solar ray tracks illuminating the home stretch path.',
    cinematicEffect: 'solar-rath',
    passiveBonus: '+200 Coins for every token home run',
    isThirdEyeCollection: true,
  },
  {
    id: 'varun-vortex',
    name: 'Varun Astra Ocean Vortex',
    hindiName: 'वरुण अस्त्र जल चक्रव्यूह',
    tier: 'Vedic Astra',
    element: 'Oceanic Deluge',
    permanentDiamondCost: 3000000,
    image: ASSETS.sudarshan,
    description: 'Deep ocean currents sweep the board with safe water shield blessings.',
    cinematicEffect: 'solar-rath',
    passiveBonus: '+150 Coins on safe cell landings',
  },
  {
    id: 'vayu-gale',
    name: 'Vayu Astra Tempest Bow',
    hindiName: 'वायु अस्त्र पवन बाण',
    tier: 'Vedic Astra',
    element: 'Cosmic Wind',
    permanentDiamondCost: 2800000,
    image: ASSETS.sudarshan,
    description: 'Brisk celestial tailwinds propel tokens faster across the outer board.',
    cinematicEffect: 'solar-rath',
    passiveBonus: '+5% Movement speed aura',
  },
  {
    id: 'gandiva-dhanush',
    name: 'Gandiva Dhanush Arrow Volley',
    hindiName: 'गांडीव दिव्य धनुष बाण',
    tier: 'High Celestial',
    element: 'Celestial Archery',
    permanentDiamondCost: 4500000,
    image: ASSETS.trishul,
    description: 'Divine bow of Arjuna firing a relentless volley of energy arrows across board lanes.',
    cinematicEffect: 'solar-rath',
    passiveBonus: '+15% Safe path protection on long runs',
    isThirdEyeCollection: true,
  },
  {
    id: 'indra-vajra',
    name: "Indra's Vajra",
    hindiName: 'इंद्र वज्र विद्युत',
    tier: 'High Celestial',
    element: 'Plasma Storm',
    permanentDiamondCost: 5000000,
    image: ASSETS.trishul,
    description: 'Rain of heavenly plasma and celestial thunderstorm over the opponent path.',
    cinematicEffect: 'lightning-vajra',
    passiveBonus: '+10% chance to roll a 6 on turn 1',
    isThirdEyeCollection: true,
  },
  {
    id: 'yamraj-danda',
    name: 'Yama Danda Cosmic Judgment',
    hindiName: 'यमराज काल दंड',
    tier: 'High Celestial',
    element: 'Dark Fire',
    permanentDiamondCost: 6500000,
    image: ASSETS.gada,
    description: 'Inescapable rod of righteousness that strikes fear into opponents.',
    cinematicEffect: 'lightning-vajra',
    passiveBonus: '+300 Fame upon defeating opponent pawn',
  },
  {
    id: 'garuda-wings',
    name: 'Garuda Astral Flight',
    hindiName: 'गरुड़ दिव्य पंख',
    tier: 'High Celestial',
    element: 'Sky Sovereignty',
    permanentDiamondCost: 7500000,
    image: ASSETS.trishul,
    description: 'Golden winged aura radiating celestial flight blessing over home yard.',
    cinematicEffect: 'lightning-vajra',
    passiveBonus: '+12% Bonus Stars on victories',
  },
  {
    id: 'trishul-aura',
    name: "Mahadev's Trishul Aura",
    hindiName: 'त्रिशूल तांडव प्रभामंडल',
    tier: 'Ultra Divine',
    element: 'Cosmic Fire & Lightning',
    permanentDiamondCost: 19999999, // 19,999,999 💎 permanent
    image: ASSETS.trishul,
    description: 'Empowers board with Nataraja cosmic Tandav lightning aura. Rolls summon thunder trails across all safe cells.',
    cinematicEffect: 'tandav',
    passiveBonus: '+25% Star Luck on rolls & +500 Fame per turn',
    isThirdEyeCollection: true,
  },
  {
    id: 'gada-entry',
    name: "Hanuman's Golden Gada Entry",
    hindiName: 'श्री हनुमान गदा प्रहार',
    tier: 'Ultra Divine',
    element: 'Earth & Celestial Strength',
    permanentDiamondCost: 59999999, // 59,999,999 💎 permanent
    image: ASSETS.gada,
    description: 'Earth-shattering celestial Gada slam on VIP room entry. Spikes shockwaves and funny seat wobble into the 8 live seats with ruby particles.',
    cinematicEffect: 'gada-smash',
    passiveBonus: 'Permanent Golden Shockwave on Token Captures',
    isThirdEyeCollection: true,
  },
  {
    id: 'kaal-chakra-astra',
    name: 'Mahakaal Third Eye Blaze',
    hindiName: 'महाकाल त्रिनेत्र ज्वाला',
    tier: 'Ultra Divine',
    element: 'Pralaya Fire',
    permanentDiamondCost: 65000000,
    image: ASSETS.trishul,
    description: 'Incinerating beam of cosmic dissolution creating fiery footprints on every step.',
    cinematicEffect: 'tandav',
    passiveBonus: 'Increases capture shockwave radius by 200%',
    isThirdEyeCollection: true,
  },
  {
    id: 'sudarshan-entry',
    name: 'Sudarshan Chakra Supreme Entry',
    hindiName: 'सुदर्शन चक्र अनंत प्रविष्टि',
    tier: 'Apex Divine',
    element: 'Solar Om Singularity',
    permanentDiamondCost: 79999999999, // 79,999,999,999 💎 permanent
    image: ASSETS.sudarshan,
    description: 'The ultimate weapon of cosmic preservation. Blazing golden solar blades spin across the entire 3D arena with sacred Om resonance.',
    cinematicEffect: 'sudarshan-spin',
    passiveBonus: 'Apex Cosmic Title, Golden Nameplate & Unlimited Astral Glory',
    isThirdEyeCollection: true,
  },
  {
    id: 'brahmastra-apex',
    name: 'Brahmastra Universe Core',
    hindiName: 'ब्रह्मास्त्र महाशक्ति',
    tier: 'Apex Divine',
    element: 'Universal Creation',
    permanentDiamondCost: 9999999999,
    image: ASSETS.trishul,
    description: 'Summons cosmic creator rings of fire. Can temporarily hold a player from joining a particular board for 10 uses (safety-controlled).',
    cinematicEffect: 'brahmastra',
    passiveBonus: 'Temporary Board Hold (10 uses) & Triples VIP Diamond Drops',
    isThirdEyeCollection: true,
    temporaryBlockBoardUses: 10,
  },
  {
    id: 'pashupatastra-apex',
    name: 'Pashupatastra Universal Destiny',
    hindiName: 'पाशुपतास्त्र ब्रह्मांड चक्र',
    tier: 'Apex Divine',
    element: 'Primordial Void',
    permanentDiamondCost: 88888888888,
    image: ASSETS.sudarshan,
    description: 'The rarest weapon of total cosmic stillness. Future divine behavior configured dynamically by Admin.',
    cinematicEffect: 'sudarshan-spin',
    passiveBonus: 'Rarest Apex Weapon · Admin Configured Behavior',
    isThirdEyeCollection: true,
    adminConfig: 'Cosmic Singularity Void',
  },
];

// 2. The EXACT 30 Ultra-Rare Pets from Master Game Bible (Items 12 & 13)
// Rule: One small pet per seated player. Extremely rare. Not purchasable with diamonds.
// Rarity: Rare → Epic → Mythic → Ancient → Divine → ???
export const RARE_PETS: PetItem[] = [
  // 1–10
  {
    id: 'pet-celestial-dragon',
    numberIndex: 1,
    name: 'Celestial Dragon',
    species: 'Cosmic Wyrm',
    element: 'Aakash (Cosmic Sky)',
    rarity: 'Divine',
    icon: '🐉',
    image: ASSETS.dragonPet,
    unlockRequirement: '1,000 Ludo wins',
    level: 12,
    affection: 95,
    bonus: '+15% Diamond Drops on 6 rolls & Dragon Roar on Capture',
    unlocked: true,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-royal-eagle',
    numberIndex: 2,
    name: 'Royal Eagle',
    species: 'Golden Eagle',
    element: 'Vayu (Wind)',
    rarity: 'Ancient',
    icon: '🦅',
    image: ASSETS.dragonPet,
    unlockRequirement: '100 consecutive login days',
    level: 9,
    affection: 80,
    bonus: '+1 Extra Safe Step on Turn 1 & Wind Flight Trail',
    unlocked: true,
    behaviorState: 'walk',
  },
  {
    id: 'pet-golden-lion',
    numberIndex: 3,
    name: 'Golden Lion',
    species: 'Solar Beast',
    element: 'Agni (Fire)',
    rarity: 'Mythic',
    icon: '🦁',
    image: ASSETS.dragonPet,
    unlockRequirement: '100-win streak',
    level: 8,
    affection: 85,
    bonus: '+500 Fame on Token Capture & Solar Roar',
    unlocked: true,
    behaviorState: 'sit',
  },
  {
    id: 'pet-moon-wolf',
    numberIndex: 4,
    name: 'Moon Wolf',
    species: 'Lunar Lupus',
    element: 'Jal (Water/Moon)',
    rarity: 'Epic',
    icon: '🐺',
    image: ASSETS.dragonPet,
    unlockRequirement: 'midnight challenge',
    level: 5,
    affection: 70,
    bonus: 'Night Arena Moonlight Glow & Howl on 6 rolls',
    unlocked: true,
    behaviorState: 'walk',
  },
  {
    id: 'pet-phantom-fox',
    numberIndex: 5,
    name: 'Phantom Fox',
    species: 'Aurora Fox',
    element: 'Mystic Illusion',
    rarity: 'Rare',
    icon: '🦊',
    image: ASSETS.dragonPet,
    unlockRequirement: 'secret achievement',
    level: 4,
    affection: 50,
    bonus: 'Reveals Opponent Dice Probability with Spirit Mist',
    unlocked: false,
    behaviorState: 'sit',
  },
  {
    id: 'pet-divine-cobra',
    numberIndex: 6,
    name: 'Divine Cobra',
    species: 'Sheshnag Naga',
    element: 'Prithvi & Amrit',
    rarity: 'Mythic',
    icon: '🐍',
    image: ASSETS.dragonPet,
    unlockRequirement: '500 token cuts',
    level: 6,
    affection: 60,
    bonus: '+20% Luck against Red Tokens & Naga Venom Aura',
    unlocked: false,
    behaviorState: 'react',
  },
  {
    id: 'pet-cosmic-peacock',
    numberIndex: 7,
    name: 'Cosmic Peacock',
    species: 'Mayura Celestial',
    element: 'Shri Krishna Radiance',
    rarity: 'Ancient',
    icon: '🦚',
    image: ASSETS.dragonPet,
    unlockRequirement: '10,000 gameplay stars',
    level: 10,
    affection: 92,
    bonus: 'Summons Feather Orbit on Safe Cells',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-thunder-tiger',
    numberIndex: 8,
    name: 'Thunder Tiger',
    species: 'Vajra Bengal Tiger',
    element: 'Plasma Lightning',
    rarity: 'Mythic',
    icon: '🐯',
    image: ASSETS.dragonPet,
    unlockRequirement: '50 comeback wins',
    level: 7,
    affection: 75,
    bonus: 'Shockwave trail on 3 consecutive 6s',
    unlocked: false,
    behaviorState: 'react',
  },
  {
    id: 'pet-astral-horse',
    numberIndex: 9,
    name: 'Astral Horse',
    species: 'Ucchaihshravas Steed',
    element: 'Cosmic Speed',
    rarity: 'Ancient',
    icon: '🐎',
    image: ASSETS.dragonPet,
    unlockRequirement: '1,000 completed games',
    level: 9,
    affection: 88,
    bonus: '+10% Pawn galloping sprint speed',
    unlocked: false,
    behaviorState: 'walk',
  },
  {
    id: 'pet-ancient-elephant',
    numberIndex: 10,
    name: 'Ancient Elephant',
    species: 'Airavata Divine Tusker',
    element: 'Imperial Earth',
    rarity: 'Divine',
    icon: '🐘',
    image: ASSETS.dragonPet,
    unlockRequirement: '1-year anniversary + achievement',
    level: 15,
    affection: 98,
    bonus: 'Golden Bell Trumpet & Immunity to First Cut',
    unlocked: false,
    behaviorState: 'sit',
  },

  // 11–20
  {
    id: 'pet-galaxy-butterfly',
    numberIndex: 11,
    name: 'Galaxy Butterfly',
    species: 'Nebula Papilio',
    element: 'Starlight',
    rarity: 'Epic',
    icon: '🦋',
    image: ASSETS.dragonPet,
    unlockRequirement: '100 rare milestones',
    level: 5,
    affection: 70,
    bonus: 'Flutters around dice providing glitter chime',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-immortal-turtle',
    numberIndex: 12,
    name: 'Immortal Turtle',
    species: 'Kurma Avatar Shell',
    element: 'Oceanic Eternity',
    rarity: 'Ancient',
    icon: '🐢',
    image: ASSETS.dragonPet,
    unlockRequirement: '1,000 games with no abandon',
    level: 11,
    affection: 90,
    bonus: 'Turtle Shield blessing on home row',
    unlocked: false,
    behaviorState: 'sleep',
  },
  {
    id: 'pet-royal-parrot',
    numberIndex: 13,
    name: 'Royal Parrot',
    species: 'Kamaraja Shuka',
    element: 'Voice & Harmony',
    rarity: 'Mythic',
    icon: '🦜',
    image: ASSETS.dragonPet,
    unlockRequirement: '365-day social achievement',
    level: 8,
    affection: 82,
    bonus: 'Repeats host cheer phrases with festive chime',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-moon-deer',
    numberIndex: 14,
    name: 'Moon Deer',
    species: 'Golden Mirage Antelope',
    element: 'Forest Light',
    rarity: 'Rare',
    icon: '🦌',
    image: ASSETS.dragonPet,
    unlockRequirement: 'seasonal hidden final reward',
    level: 4,
    affection: 65,
    bonus: 'Leaves blooming flowers behind pawns',
    unlocked: false,
    behaviorState: 'walk',
  },
  {
    id: 'pet-mystic-panda',
    numberIndex: 15,
    name: 'Mystic Panda',
    species: 'Zen Harmony Bear',
    element: 'Bamboo Peace',
    rarity: 'Epic',
    icon: '🐼',
    image: ASSETS.dragonPet,
    unlockRequirement: 'friendship with 100 players',
    level: 6,
    affection: 78,
    bonus: 'Shares +20 Coins to room friends on match victory',
    unlocked: false,
    behaviorState: 'sit',
  },
  {
    id: 'pet-phoenix-bird',
    numberIndex: 16,
    name: 'Phoenix Bird',
    species: 'Garuda Rebirth Avian',
    element: 'Solar Resurrection',
    rarity: 'Mythic',
    icon: '🔥',
    image: ASSETS.dragonPet,
    unlockRequirement: 'huge comeback',
    level: 9,
    affection: 86,
    bonus: 'Wings of rebirth flame when 3 pawns are captured',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-void-dragon',
    numberIndex: 17,
    name: 'Void Dragon',
    species: 'Nether Drake',
    element: 'Pralaya Singularity',
    rarity: 'Ancient',
    icon: '🐲',
    image: ASSETS.dragonPet,
    unlockRequirement: 'extreme secret quest',
    level: 12,
    affection: 94,
    bonus: 'Dark nebula vortex on 6 rolls',
    unlocked: false,
    behaviorState: 'react',
  },
  {
    id: 'pet-celestial-unicorn',
    numberIndex: 18,
    name: 'Celestial Unicorn',
    species: 'Amrit Horn Steed',
    element: 'Purity Light',
    rarity: 'Divine',
    icon: '🦄',
    image: ASSETS.dragonPet,
    unlockRequirement: '10 ultra-rare achievements',
    level: 14,
    affection: 97,
    bonus: 'Rainbow horn beacon shields user from snake trap',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-abyss-octopus',
    numberIndex: 19,
    name: 'Abyss Octopus',
    species: 'Kraken Ink Mystic',
    element: 'Deep Abyssal',
    rarity: 'Epic',
    icon: '🐙',
    image: ASSETS.dragonPet,
    unlockRequirement: 'all mini-games mastery',
    level: 7,
    affection: 72,
    bonus: 'Ink bubble splash on opponent captures',
    unlocked: false,
    behaviorState: 'walk',
  },
  {
    id: 'pet-ocean-spirit',
    numberIndex: 20,
    name: 'Ocean Spirit',
    species: 'Varuna Siren Nymph',
    element: 'Tidal Grace',
    rarity: 'Ancient',
    icon: '🌊',
    image: ASSETS.dragonPet,
    unlockRequirement: 'long-term collection completion',
    level: 11,
    affection: 91,
    bonus: 'Aqua water lily ripples on safe stars',
    unlocked: false,
    behaviorState: 'sleep',
  },

  // 21–30
  {
    id: 'pet-golden-bee',
    numberIndex: 21,
    name: 'Golden Bee',
    species: 'Honey Nectar Drone',
    element: 'Solar Pollen',
    rarity: 'Rare',
    icon: '🐝',
    image: ASSETS.dragonPet,
    unlockRequirement: '1,000 daily missions',
    level: 4,
    affection: 60,
    bonus: '+5% Bonus XP on daily logins',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-lucky-moon-rabbit',
    numberIndex: 22,
    name: 'Lucky Moon Rabbit',
    species: 'Jade Lunar Bunny',
    element: 'Amrit Elixir',
    rarity: 'Epic',
    icon: '🐇',
    image: ASSETS.dragonPet,
    unlockRequirement: 'festival hidden achievement',
    level: 6,
    affection: 76,
    bonus: 'Lucky Moon Hop on dice throw',
    unlocked: false,
    behaviorState: 'walk',
  },
  {
    id: 'pet-shadow-cat',
    numberIndex: 23,
    name: 'Shadow Cat',
    species: 'Eclipse Panther Cub',
    element: 'Shadow Stealth',
    rarity: 'Rare',
    icon: '🐈‍⬛',
    image: ASSETS.dragonPet,
    unlockRequirement: 'secret sequence',
    level: 5,
    affection: 68,
    bonus: 'Silent paw steps with purple phantom paws',
    unlocked: false,
    behaviorState: 'sleep',
  },
  {
    id: 'pet-night-bat',
    numberIndex: 24,
    name: 'Night Bat',
    species: 'Vampiric Sonic Flutter',
    element: 'Midnight Echo',
    rarity: 'Rare',
    icon: '🦇',
    image: ASSETS.dragonPet,
    unlockRequirement: 'rare night event',
    level: 4,
    affection: 55,
    bonus: 'Sonar radar detects double roll patterns',
    unlocked: false,
    behaviorState: 'react',
  },
  {
    id: 'pet-ancient-serpent',
    numberIndex: 25,
    name: 'Ancient Serpent',
    species: 'Takshak Golden King',
    element: 'Primordial Coil',
    rarity: 'Mythic',
    icon: '🐉',
    image: ASSETS.dragonPet,
    unlockRequirement: 'all Astra categories',
    level: 10,
    affection: 89,
    bonus: 'Coils around Astra weapons on trigger',
    unlocked: false,
    behaviorState: 'sit',
  },
  {
    id: 'pet-royal-swan',
    numberIndex: 26,
    name: 'Royal Swan',
    species: 'Hamsa Sacred Avian',
    element: 'Saraswati Wisdom',
    rarity: 'Ancient',
    icon: '🦢',
    image: ASSETS.dragonPet,
    unlockRequirement: 'long-term friendship/couple',
    level: 11,
    affection: 93,
    bonus: 'Twin heart crest displayed over partner',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-fossil-titan',
    numberIndex: 27,
    name: 'Fossil Titan',
    species: 'Prehistoric Behemoth',
    element: 'Ancient Stone',
    rarity: 'Ancient',
    icon: '🦕',
    image: ASSETS.dragonPet,
    unlockRequirement: 'very old account milestone',
    level: 12,
    affection: 90,
    bonus: 'Ground tremor sound on heavy token capture',
    unlocked: false,
    behaviorState: 'walk',
  },
  {
    id: 'pet-guardian-hound',
    numberIndex: 28,
    name: 'Guardian Hound',
    species: 'Bhairava Faithful Dog',
    element: 'Righteous Valor',
    rarity: 'Mythic',
    icon: '🐕',
    image: ASSETS.dragonPet,
    unlockRequirement: 'exceptional positive community/safety achievement',
    level: 9,
    affection: 87,
    bonus: 'Fair Play Badge & Golden Shield bark on turn',
    unlocked: false,
    behaviorState: 'sit',
  },
  {
    id: 'pet-star-spirit',
    numberIndex: 29,
    name: 'Star Spirit',
    species: 'Astral Wisp Sovereign',
    element: 'Singularity Light',
    rarity: 'Divine',
    icon: '✨',
    image: ASSETS.dragonPet,
    unlockRequirement: '1,000 major achievements/ultra milestones',
    level: 16,
    affection: 99,
    bonus: 'Omni-celestial aura illuminating entire 3D arena',
    unlocked: false,
    behaviorState: 'celebrate',
  },
  {
    id: 'pet-divine-companion',
    numberIndex: 30,
    name: 'Divine Companion',
    species: 'Supreme Celestial Familiar',
    element: 'Omnipresent Transcendence',
    rarity: '???',
    icon: '👑',
    image: ASSETS.dragonPet,
    unlockRequirement: 'special lifetime achievement/event selected by admin',
    level: 20,
    affection: 100,
    bonus: 'Universal Omnipotence: Reacts to all Astras, owners & winners alike',
    unlocked: false,
    behaviorState: 'react',
  },
];

// ============================================================================
// SECTION 11: BALLOONS & THROWABLE SPLASH INTERACTION (Bible Item 11)
// 20+ variants, mud, pichkari-style effects, 2 diamonds cosmetic splash
// ============================================================================
export interface BalloonVariant {
  id: string;
  name: string;
  hindiName: string;
  icon: string;
  effectType: 'splash' | 'mud' | 'pichkari' | 'bomb' | 'confetti' | 'freeze' | 'slime';
  splashColor: string;
  splatDecal: string;
  diamondCost: 2;
  description: string;
}

export const BALLOON_VARIANTS: BalloonVariant[] = [
  { id: 'bal-water', name: 'Water Splash Balloon', hindiName: 'जल गुब्बारा', icon: '💧', effectType: 'splash', splashColor: '#06b6d4', splatDecal: '💧💦 Water Drizzle', diamondCost: 2, description: 'Throws a cool refreshing water splash that pops into cyan droplets.' },
  { id: 'bal-mud', name: 'Mud Splatter Balloon', hindiName: 'कीचड़ धमाका', icon: '🤎', effectType: 'mud', splashColor: '#78350f', splatDecal: '🟤 Messy Mud Splat', diamondCost: 2, description: 'Splashes comical thick brown mud decals across the target seat.' },
  { id: 'bal-pichkari', name: 'Holi Pichkari Jet', hindiName: 'पिचकारी फव्वारा', icon: '🔫', effectType: 'pichkari', splashColor: '#ec4899', splatDecal: '🌈 Gulal Rainbow Jet', diamondCost: 2, description: 'Streams a continuous high-pressure spray of vibrant gulal colors.' },
  { id: 'bal-bomb', name: 'Balloon Mega Bomb', hindiName: 'गुब्बारा बम', icon: '💣', effectType: 'bomb', splashColor: '#f97316', splatDecal: '💥 Smoke Explosion', diamondCost: 2, description: 'Heavy party blast that triggers screen micro-shake and confetti.' },
  { id: 'bal-gold', name: 'Golden Glitter Balloon', hindiName: 'स्वर्ण चमक', icon: '✨', effectType: 'splash', splashColor: '#f59e0b', splatDecal: '⭐ 24K Gold Dust', diamondCost: 2, description: 'Covers the recipient in shimmering 24K golden stardust.' },
  { id: 'bal-pink', name: 'Neon Rose Ink Balloon', hindiName: 'गुलाबी स्याही', icon: '🌸', effectType: 'splash', splashColor: '#f43f5e', splatDecal: '🌺 Rose Petal Ink', diamondCost: 2, description: 'Romantic burst of blooming floral crimson ink.' },
  { id: 'bal-slime', name: 'Alien Green Slime', hindiName: 'हरी स्लाइम', icon: '🟢', effectType: 'slime', splashColor: '#22c55e', splatDecal: '🧪 Sticky Toxic Slime', diamondCost: 2, description: 'Gooey alien slime with bubbly dripping animation.' },
  { id: 'bal-freeze', name: 'Ice Frost Balloon', hindiName: 'बर्फ़ीला गुब्बारा', icon: '❄️', effectType: 'freeze', splashColor: '#38bdf8', splatDecal: '🧊 Frost Crystal Decal', diamondCost: 2, description: 'Sub-zero freeze impact that coats target seat with ice frost.' },
  { id: 'bal-lava', name: 'Molten Lava Balloon', hindiName: 'ज्वालामुखी लावा', icon: '🌋', effectType: 'splash', splashColor: '#ef4444', splatDecal: '🔥 Ember Fire Spatter', diamondCost: 2, description: 'Fiery magma burst with sizzling smoke particles.' },
  { id: 'bal-confetti', name: 'Party Confetti Balloon', hindiName: 'उत्सव कंफेटी', icon: '🎊', effectType: 'confetti', splashColor: '#a855f7', splatDecal: '🎉 Celebration Ribbons', diamondCost: 2, description: 'Pops into a festive shower of holographic confetti ribbons.' },
  { id: 'bal-rainbow', name: 'Prism Rainbow Balloon', hindiName: 'इंद्रधनुष गुब्बारा', icon: '🌈', effectType: 'splash', splashColor: '#8b5cf6', splatDecal: '🎨 7-Color Splatter', diamondCost: 2, description: 'Multicolor rainbow explosion across the arena board.' },
  { id: 'bal-electric', name: 'Lightning Zap Balloon', hindiName: 'बिजली का झटका', icon: '⚡', effectType: 'splash', splashColor: '#eab308', splatDecal: '⚡ Plasma Arc Burst', diamondCost: 2, description: 'Crackles with playful electric sparks and thunder pops.' },
  { id: 'bal-heart', name: 'Love Romance Balloon', hindiName: 'प्रेम दिल गुब्बारा', icon: '💖', effectType: 'splash', splashColor: '#ec4899', splatDecal: '💕 Heart Floaties', diamondCost: 2, description: 'Floats glowing mini hearts over the targeted seated player.' },
  { id: 'bal-bubble', name: 'Soap Foam Balloon', hindiName: 'साबुन झाग', icon: '🫧', effectType: 'splash', splashColor: '#67e8f9', splatDecal: '🫧 Glossy Bubbles', diamondCost: 2, description: 'Erupts into hundred iridescent bubbles floating upwards.' },
  { id: 'bal-chai', name: 'Spilled Masala Chai', hindiName: 'मसाला चाय छींटा', icon: '☕', effectType: 'splash', splashColor: '#d97706', splatDecal: '☕ Warm Tea Splatter', diamondCost: 2, description: 'Friendly chai splat with fragrant steam trails.' },
  { id: 'bal-smoke', name: 'Purple Smoke Veil', hindiName: 'बैंगनी धुआं', icon: '💨', effectType: 'splash', splashColor: '#7c3aed', splatDecal: '🌫️ Mystic Fog Cloud', diamondCost: 2, description: 'Envelops the seat in a cool purple fog cloud.' },
  { id: 'bal-comet', name: 'Cosmic Comet Balloon', hindiName: 'धूमकेतु गुब्बारा', icon: '☄️', effectType: 'splash', splashColor: '#3b82f6', splatDecal: '🌌 Galaxy Dust Splash', diamondCost: 2, description: 'Deep space cosmic blast with orbiting asteroid dust.' },
  { id: 'bal-sun', name: 'Solar Ray Balloon', hindiName: 'सूर्य किरण गुब्बारा', icon: '☀️', effectType: 'splash', splashColor: '#fbbf24', splatDecal: '🔆 Solar Flare Flare', diamondCost: 2, description: 'Blinding cheerful sun flare explosion.' },
  { id: 'bal-emerald', name: 'Emerald Spark Balloon', hindiName: 'पन्ना रत्न चमक', icon: '💎', effectType: 'splash', splashColor: '#10b981', splatDecal: '💎 Gemstone Shards', diamondCost: 2, description: 'Scatters sparkling emerald crystal gemstones.' },
  { id: 'bal-midnight', name: 'Midnight Eclipse Balloon', hindiName: 'चंद्र ग्रहण गुब्बारा', icon: '🌙', effectType: 'splash', splashColor: '#1e1b4b', splatDecal: '✨ Starry Void Decal', diamondCost: 2, description: 'Dark starry nebula with crescent moon gleam.' },
  { id: 'bal-kohinoor', name: 'Kohinoor Sovereign Balloon', hindiName: 'कोहिनूर शाही गुब्बारा', icon: '👑', effectType: 'splash', splashColor: '#ffd700', splatDecal: '👑 Royal Crown Splash', diamondCost: 2, description: 'The sovereign monarch balloon with golden crown splash.' },
];

// ============================================================================
// SECTION 14: SOCIAL / COUPLE SYSTEM DATA (Bible Item 14)
// ============================================================================
export interface CoupleProfile {
  partnerId: string;
  partnerName: string;
  partnerAvatar: string;
  timeSpentMinutes: number;
  doubleHeartsBalance: number;
  weeklyAllowanceHearts: number;
  daysTogether: number;
  announcementStatus: string;
}

export const INITIAL_COUPLE_DATA: CoupleProfile = {
  partnerId: 'user-princess-balqis',
  partnerName: 'Princess Balqis',
  partnerAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=140&auto=format&fit=crop&q=80',
  timeSpentMinutes: 1420, // 23+ hours in Ludo together
  doubleHeartsBalance: 40,
  weeklyAllowanceHearts: 50, // Up to 50 hearts/week for birthday
  daysTogether: 48,
  announcementStatus: 'Weekly Couple Award: 10 Double-Hearts Ready to Grant!',
};


// 3. Luxury Live Room 3D Gifts (From screenshots: Bigo/Queen Ludo luxury gifts)
export const LUXURY_GIFTS: GiftItem[] = [
  { id: 'gift-rose', name: 'Golden Rose Bouquet', hindiName: 'स्वर्ण गुलाब', icon: '🌹', cost: 10, currency: 'diamonds', rarity: 'Common', bannerText: 'showered fragrant golden roses' },
  { id: 'gift-heart', name: 'Neon Finger Heart', hindiName: 'हार्ट लव', icon: '💖', cost: 99, currency: 'diamonds', rarity: 'Common', bannerText: 'sent pure heart love' },
  { id: 'gift-beer', name: 'Celebration Toast', hindiName: 'चीयर्स मग', icon: '🍺', cost: 10, currency: 'coins', rarity: 'Common', bannerText: 'raised a golden toast' },
  { id: 'gift-fireworks', name: 'Midnight Galaxy Fireworks', hindiName: 'आतिशबाज़ी', icon: '🎆', cost: 208, currency: 'diamonds', rarity: 'Popular', bannerText: 'ignited stellar fireworks' },
  { id: 'gift-luckybox', name: 'Imperial Lucky Magic Box', hindiName: 'जादुई संदूक', icon: '🎁', cost: 500, currency: 'diamonds', rarity: 'Popular', bannerText: 'unlocked an imperial lucky chest' },
  { id: 'gift-ring', name: 'Diamond Solitaire Crown Ring', hindiName: 'हीरे की अंगूठी', icon: '💍', cost: 666, currency: 'diamonds', rarity: 'Popular', bannerText: 'presented a royal diamond ring' },
  { id: 'gift-crown', name: 'Emerald Sovereign Crown', hindiName: 'शाही मुकुट', icon: '👑', cost: 888, currency: 'diamonds', rarity: 'Popular', bannerText: 'crowned the seat with royalty' },
  { id: 'gift-swan', name: 'Crystal Swan Lake', hindiName: 'श्वेत हंस', icon: '🦢', cost: 666, currency: 'diamonds', rarity: 'Popular', bannerText: 'summoned graceful crystal swans' },
  { id: 'gift-cannon', name: 'True Love Heart Cannon', hindiName: 'लव तोप', icon: '💝', cost: 1314, currency: 'diamonds', rarity: 'Popular', bannerText: 'fired true love heart confetti' },
  { id: 'gift-racing-car', name: 'Neon Bugatti Super Racing Car', hindiName: 'सुपर रेसिंग कार', icon: '🏎️', cost: 1500, currency: 'diamonds', rarity: 'Mega Supercar', bannerText: 'sped in with a Neon Bugatti' },
  { id: 'gift-hypercar-fleet', name: 'Hypercar Fleet Parade', hindiName: 'सुपरकार फ्लीट', icon: '🚘', cost: 1888, currency: 'diamonds', rarity: 'Mega Supercar', bannerText: 'dispatched a luxury hypercar fleet' },
  { id: 'gift-yacht', name: 'Monaco Royal Cruise Yacht', hindiName: 'लक्ज़री क्रूज़ यॉट', icon: '🛥️', cost: 2288, currency: 'diamonds', rarity: 'Luxury', bannerText: 'docked a private diamond yacht' },
  { id: 'gift-rocket', name: 'Starship Apollo Rocket', hindiName: 'स्पेस रॉकेट', icon: '🚀', cost: 2888, currency: 'diamonds', rarity: 'Luxury', bannerText: 'launched a starship into orbit' },
  { id: 'gift-jet', name: 'VIP Gulfstream Private Jet', hindiName: 'प्राइवेट जेट', icon: '✈️', cost: 9999, currency: 'diamonds', rarity: 'Luxury', bannerText: 'flew in on a private jet' },
  { id: 'gift-moon', name: 'Journey to the Moon Tour', hindiName: 'चांद की यात्रा', icon: '🌕', cost: 28888, currency: 'diamonds', rarity: 'Luxury', bannerText: 'arranged a journey to the moon' },
  { id: 'gift-lion-pride', name: 'Golden Lion & Cub Pride', hindiName: 'शेर राजसी दरबार', icon: '🦁', cost: 34000, currency: 'diamonds', rarity: 'Luxury', bannerText: 'unleashed the roar of golden lions' },
  { id: 'gift-temple-fortune', name: 'Temple of Endless Fortune', hindiName: 'भाग्य महल', icon: '🏛️', cost: 188888, currency: 'diamonds', rarity: 'Divine Supreme', bannerText: 'erected the golden Temple of Fortune' },
  { id: 'gift-sudarshan-blessing', name: "Sudarshan Divine Blessing", hindiName: 'सुदर्शन महावरदान', icon: '🌀', cost: 999999, currency: 'diamonds', rarity: 'Divine Supreme', bannerText: 'conferred the Sudarshan Divine Blessing' },
];

// 4. 14 Lokas & Sacred Cosmological Realms (from user screenshots!)
export const COSMIC_LOKAS = [
  { id: 1, name: 'Satya Loka (Brahmaloka)', desc: 'Realm of Truth, Pure Cosmic Consciousness & Lord Brahma', level: 'Highest Divine' },
  { id: 2, name: 'Tapa Loka', desc: 'Realm of severe austerity, Ascetics and immortal rishis', level: 'High Spiritual' },
  { id: 3, name: 'Jana Loka', desc: 'Realm of the mind-born sons of Brahma (Sanat Kumaras)', level: 'Pure Mind' },
  { id: 4, name: 'Mahar Loka', desc: 'Realm of saints, rishis like Bhrigu who survive cosmic kalpas', level: 'Luminous Wisdom' },
  { id: 5, name: 'Swarga Loka', desc: 'Heavenly paradise of Indra, Devatas, Amrit and celestial gardens', level: 'Celestial' },
  { id: 6, name: 'Bhuvar Loka', desc: 'Atmospheric realm of planets, stars and ethereal spirits', level: 'Planetary Astral' },
  { id: 7, name: 'Bhu Loka (Earth)', desc: 'Physical earthly reality, karma arena where Ludo is played', level: 'Physical Plane' },
  { id: 8, name: 'Atala Loka', desc: 'First netherworld governed by Bala with magical illusions', level: 'Netherworld I' },
  { id: 9, name: 'Vitala Loka', desc: 'Subterranean gold mines and golden river Hataki', level: 'Netherworld II' },
  { id: 10, name: 'Sutala Loka', desc: 'Blessed subterranean kingdom of King Mahabali protected by Vamana', level: 'Netherworld III' },
  { id: 11, name: 'Talatala Loka', desc: 'Domain of Maya Danava, master of sacred cosmic architecture', level: 'Netherworld IV' },
  { id: 12, name: 'Mahatala Loka', desc: 'Abode of hood serpent kings: Kuhaka, Takshak and Kaliya', level: 'Netherworld V' },
  { id: 13, name: 'Rasatala Loka', desc: 'Fortified strongholds of Daityas and Danavas', level: 'Netherworld VI' },
  { id: 14, name: 'Patala Loka (Nagaloka)', desc: 'Lowest realm crowned with jewel-hooded king Vasuki and Sheshanaga', level: 'Deepest Matrix' },
];

// 5. Dashavatara 10 Avatars of Vishnu (from screenshots)
export const DASHAVATARA = [
  { name: 'Matsya Avatar', form: 'Golden Horned Fish', symbol: '🌊', virtue: 'Protection from Deluge' },
  { name: 'Kurma Avatar', form: 'Cosmic Tortoise', symbol: '🐢', virtue: 'Support for Ocean Churning (Amrit)' },
  { name: 'Varaha Avatar', form: 'Divine Boar', symbol: '🐗', virtue: 'Lifting Earth from Depths' },
  { name: 'Narasimha Avatar', form: 'Half-Man Half-Lion', symbol: '🦁', virtue: 'Destroying Evil everywhere' },
  { name: 'Vamana Avatar', form: 'Young Brahmin Dwarf', symbol: '👣', virtue: 'Three steps measuring Universe' },
  { name: 'Parashurama Avatar', form: 'Axe-Bearing Warrior Rishi', symbol: '🪓', virtue: 'Justice & Righteous Power' },
  { name: 'Shri Rama Avatar', form: 'Maryada Purushottam with Kodanda', symbol: '🏹', virtue: 'Dharma & Nobility' },
  { name: 'Shri Krishna Avatar', form: 'Flute & Sudarshan Chakra Lord', symbol: '🪈', virtue: 'Supreme Wisdom & Leela' },
  { name: 'Buddha Avatar', form: 'Enlightened One beneath Bodhi Tree', symbol: '🧘', virtue: 'Compassion & Ahimsa' },
  { name: 'Kalki Avatar', form: 'White Winged Steed Warrior with Sword', symbol: '⚔️', virtue: 'Renewal of Golden Age (Satya Yuga)' },
];

// 6. Safe Cells and Path Constants
export const SAFE_CELL_INDICES = [0, 8, 13, 21, 26, 34, 39, 47];
export const PLAYER_START_CELLS = {
  red: 0,
  green: 13,
  yellow: 26,
  blue: 39,
};
export const PLAYER_HOME_TURNS = {
  red: 50,
  green: 11,
  yellow: 24,
  blue: 37,
};

// 7. Complete 20+ Selectable Animated Frames Catalogue (User explicit requirement!)
import { AvatarFrame, LiveRoom } from '../types/game';

export const AVATAR_FRAMES: AvatarFrame[] = [
  { id: 'gold-wings', name: 'Golden Archangel Wings', hindiName: 'स्वर्ण पंख', rarity: 'Legendary', description: 'Gilded divine wings with heavenly golden light particles', glowColor: '#FFD700', borderClass: 'frame-gold-wings', icon: '🪽', unlocked: true },
  { id: 'royal-crown', name: 'Imperial Koh-i-Noor Crown', hindiName: 'शाही कोहिनूर', rarity: 'Mythic', description: 'Bejeweled emperor crown adorned with glowing rubies', glowColor: '#E63946', borderClass: 'frame-royal-crown', icon: '👑', unlocked: true },
  { id: 'lion-crest', name: 'Lion of Ayodhya Crest', hindiName: 'सिंह गर्जना', rarity: 'Legendary', description: 'Golden roaring lion emblem with solar flame rays', glowColor: '#F59E0B', borderClass: 'frame-lion-crest', icon: '🦁', unlocked: true },
  { id: 'neon-heart', name: 'Cyber Neon Pulse Heart', hindiName: 'नियॉन लव', rarity: 'Rare', description: 'Electric magenta cardiac wave pulse with star sparkles', glowColor: '#F72585', borderClass: 'frame-neon-heart', icon: '💖', unlocked: true },
  { id: 'dragon-crest', name: 'Celestial Dragon Coils', hindiName: 'अमर ड्रैगन', rarity: 'Mythic', description: 'Sapphire dragon scales wrapping with blue lightning smoke', glowColor: '#3B82F6', borderClass: 'frame-dragon-crest', icon: '🐉', unlocked: true },
  { id: 'diamond-star', name: 'Cosmic Diamond Nebula', hindiName: 'हीरा सितारा', rarity: 'Epic', description: 'Prismatic crystal refractions of pure diamond starlight', glowColor: '#60A5FA', borderClass: 'frame-diamond-star', icon: '💎', unlocked: true },
  { id: 'purple-empress', name: 'Amethyst Empress Tiara', hindiName: 'बैंगनी रानी', rarity: 'Legendary', description: 'Velvet royal purple aura with swirling orchid petals', glowColor: '#A855F7', borderClass: 'frame-purple-empress', icon: '🔮', unlocked: true },
  { id: 'blue-angel', name: 'Seraphim Blue Angel Halo', hindiName: 'नील देवदूत', rarity: 'Epic', description: 'Celestial azure ring with descending holy feathers', glowColor: '#38BDF8', borderClass: 'frame-blue-angel', icon: '🕊️', unlocked: true },
  { id: 'cyber-dragon', name: 'Neo-Tokyo Cyber Mech Dragon', hindiName: 'साइबर ड्रैगन', rarity: 'Mythic', description: 'Futuristic cyan circuit lines with pulsing holographic horns', glowColor: '#00F2FE', borderClass: 'frame-cyber-dragon', icon: '⚡', unlocked: true },
  { id: 'phoenix-flame', name: 'Eternal Phoenix Inferno', hindiName: 'अग्नि फीनिक्स', rarity: 'Apex', description: 'Living immortal fire plumes with burning ember trails', glowColor: '#EF4444', borderClass: 'frame-phoenix-flame', icon: '🔥', unlocked: true },
  { id: 'divine-halo', name: 'Lord Shiva Tri-Netra Halo', hindiName: 'दिव्य त्रिनेत्र प्रभामंडल', rarity: 'Apex', description: 'Sacred third-eye aura with Om resonance and lunar crescent', glowColor: '#FDE047', borderClass: 'frame-divine-halo', icon: '🕉️', unlocked: true },
  { id: 'emerald-lotus', name: 'Padma Emerald Lotus', hindiName: 'पद्म कमल', rarity: 'Rare', description: 'Sacred blooming lotus petals with jade dew drops', glowColor: '#10B981', borderClass: 'frame-emerald-lotus', icon: '🪷', unlocked: true },
  { id: 'galaxy-swirl', name: 'Milky Way Galaxy Vortex', hindiName: 'आकाशगंगा भंवर', rarity: 'Epic', description: 'Rotating cosmic spiral with dwarf stars and nebula dust', glowColor: '#818CF8', borderClass: 'frame-galaxy-swirl', icon: '🌌', unlocked: true },
  { id: 'vip-crown', name: 'Sovereign VIP 10 Sovereign', hindiName: 'वीआईपी अधिपति', rarity: 'Legendary', description: 'Double-tier 24k sovereign crown with emerald center stones', glowColor: '#FBBF24', borderClass: 'frame-vip-crown', icon: '🎖️', unlocked: true },
  { id: 'royal-ruby', name: 'Crimson Blood Ruby Ring', hindiName: 'माणिक्य चक्र', rarity: 'Epic', description: 'Intense red laser gemstone cut with deep velvet glow', glowColor: '#DC2626', borderClass: 'frame-royal-ruby', icon: '♦️', unlocked: true },
  { id: 'diamond-aura', name: 'Billionaire Diamond Prism', hindiName: 'अरबपति हीरा', rarity: 'Mythic', description: 'Hyper-reflective diamond facets with rainbow sparkles', glowColor: '#E0E7FF', borderClass: 'frame-diamond-aura', icon: '💠', unlocked: true },
  { id: 'ocean-wave', name: 'Poseidon Ocean Crest', hindiName: 'सागर तरंग', rarity: 'Rare', description: 'Aquamarine cresting tidal wave with bioluminescent foam', glowColor: '#06B6D4', borderClass: 'frame-ocean-wave', icon: '🌊', unlocked: true },
  { id: 'sakura-blossom', name: 'Kyoto Imperial Sakura', hindiName: 'चेरी ब्लॉसम', rarity: 'Rare', description: 'Delicate pastel sakura blossoms with fluttering petals', glowColor: '#F472B6', borderClass: 'frame-sakura-blossom', icon: '🌸', unlocked: true },
  { id: 'golden-vajra', name: 'Indra Thunder Vajra Spike', hindiName: 'स्वर्ण वज्र', rarity: 'Legendary', description: 'Crackling lightning rods forged of celestial gold', glowColor: '#EAB308', borderClass: 'frame-golden-vajra', icon: '🔱', unlocked: true },
  { id: 'solar-flare', name: 'Surya 1000-Ray Solar Corona', hindiName: 'सूर्य महाप्रभा', rarity: 'Legendary', description: 'Nuclear fusion solar flares shooting golden plasma arcs', glowColor: '#F97316', borderClass: 'frame-solar-flare', icon: '☀️', unlocked: true },
  { id: 'nagraj-coils', name: 'Takshak Serpent Kundalini', hindiName: 'तक्षक नागराज', rarity: 'Mythic', description: 'Seven-hooded mystical serpent with glowing ruby eyes', glowColor: '#14B8A6', borderClass: 'frame-nagraj-coils', icon: '🐍', unlocked: true },
  { id: 'hyper-neon', name: 'Synthwave Hyper Glow', hindiName: 'हाइपर नियॉन', rarity: 'Epic', description: 'Dual-tone 80s arcade laser beam border with overdrive hue', glowColor: '#EC4899', borderClass: 'frame-hyper-neon', icon: '🕹️', unlocked: true },
];

// 8. Featured Live Rooms Directory (User explicit requirement!)
export const FEATURED_LIVE_ROOMS: LiveRoom[] = [
  {
    id: 'room-royal-penthouse',
    title: '👑 Royal Dubai Penthouse · Ludo Royale',
    hostName: 'VikingKing (VIP 10)',
    hostAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
    hostFrame: 'gold-wings',
    hostLevel: 58,
    occupantsCount: 8,
    maxSeats: 8,
    tags: ['Hot 4P', 'Astra Enabled', 'English/Hindi'],
    isLocked: false,
    theme: 'royal',
    currentActivity: '🎲 Live Ludo 4P Tournament · Round 3',
    bgGradient: 'from-amber-900/60 via-purple-950/80 to-slate-950',
    roomCover: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&auto=format&fit=crop&q=80',
    hotScore: 98450,
  },
  {
    id: 'room-mahadev-arena',
    title: '🕉️ Mahadev Trishul Battleground',
    hostName: 'Sovereign Aryan',
    hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    hostFrame: 'lion-crest',
    hostLevel: 70,
    occupantsCount: 7,
    maxSeats: 8,
    tags: ['Trishul Aura', 'High Stakes', 'Divine Gifts'],
    isLocked: false,
    theme: 'temple',
    currentActivity: '⚡ Tandav Lightning Match · 50M 💎 Pot',
    bgGradient: 'from-blue-950/70 via-indigo-950/80 to-black',
    roomCover: 'https://images.unsplash.com/photo-1545239351-ef35f43d514b?w=600&auto=format&fit=crop&q=80',
    hotScore: 84200,
  },
  {
    id: 'room-lovers-deck',
    title: '💖 Romance & Voice Lounge · Couples Play',
    hostName: 'Princess Balqis',
    hostAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
    hostFrame: 'purple-empress',
    hostLevel: 42,
    occupantsCount: 8,
    maxSeats: 8,
    tags: ['Co-Op 2v2', 'Gift Showers', 'Chill Music'],
    isLocked: false,
    theme: 'neon',
    currentActivity: '🌹 Rose Shower Party & 2v2 Team Match',
    bgGradient: 'from-pink-950/70 via-purple-950/80 to-slate-950',
    roomCover: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=600&auto=format&fit=crop&q=80',
    hotScore: 76300,
  },
  {
    id: 'room-cyber-tokyo',
    title: '⚡ Neo-Tokyo Cyber 6-Player High Rollers',
    hostName: 'Danisya Nag',
    hostAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
    hostFrame: 'neon-heart',
    hostLevel: 35,
    occupantsCount: 6,
    maxSeats: 8,
    tags: ['Speed Mode', 'Neon VFX', 'Voice On'],
    isLocked: false,
    theme: 'cyber',
    currentActivity: '🏎️ Bugatti Entry Rush · 30-sec Turns',
    bgGradient: 'from-cyan-950/70 via-violet-950/80 to-black',
    roomCover: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600&auto=format&fit=crop&q=80',
    hotScore: 65100,
  },
  {
    id: 'room-takshak-sanctum',
    title: '🐍 Takshak Secret Serpent Sanctum (VIP)',
    hostName: 'Indra Thunder',
    hostAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    hostFrame: 'nagraj-coils',
    hostLevel: 61,
    occupantsCount: 5,
    maxSeats: 8,
    tags: ['VIP Only', 'Pet Battles', 'High Stakes'],
    isLocked: true,
    theme: 'cosmic',
    currentActivity: '🐉 30 Rare Pets Showcase & Battle',
    bgGradient: 'from-emerald-950/70 via-slate-950 to-black',
    roomCover: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    hotScore: 59800,
  },
];

// 9. Daily Wheel Prize Segments
export const DAILY_WHEEL_SEGMENTS = [
  { label: '50,000 🪙', rewardType: 'coins', amount: 50000, color: '#F59E0B' },
  { label: '1,000 💎', rewardType: 'diamonds', amount: 1000, color: '#3B82F6' },
  { label: '100 ⭐', rewardType: 'stars', amount: 100, color: '#10B981' },
  { label: '5,000 💎', rewardType: 'diamonds', amount: 5000, color: '#8B5CF6' },
  { label: '100,000 🪙', rewardType: 'coins', amount: 100000, color: '#EC4899' },
  { label: '25,000 💎', rewardType: 'diamonds', amount: 25000, color: '#EF4444' },
  { label: '500 ⭐', rewardType: 'stars', amount: 500, color: '#06B6D4' },
  { label: 'JACKPOT 100K 💎', rewardType: 'diamonds', amount: 100000, color: '#FACC15' },
];

// ============================================================================
// GAME BIBLE PAGE 2 SPECIFICATION DATA
// ============================================================================

// 1. EXACT DIAMOND SHOP TIERS (Bible Item 8: ₹49 up to ₹19,999)
export interface DiamondShopTier {
  id: string;
  inrPrice: number;
  priceLabel: string;
  diamonds: number;
  bonusText: string;
  badge?: string;
  color: string;
  popular?: boolean;
}

export const EXACT_DIAMOND_SHOP_TIERS: DiamondShopTier[] = [
  { id: 'tier-49', inrPrice: 49, priceLabel: '₹49', diamonds: 250, bonusText: '+25 Free Coins', color: 'from-blue-600 to-indigo-600' },
  { id: 'tier-89', inrPrice: 89, priceLabel: '₹89', diamonds: 500, bonusText: '+1 Mini Crate', color: 'from-blue-600 to-cyan-600' },
  { id: 'tier-99', inrPrice: 99, priceLabel: '₹99', diamonds: 650, bonusText: '+50 Stars', color: 'from-teal-600 to-emerald-600', badge: 'STARTER' },
  { id: 'tier-149', inrPrice: 149, priceLabel: '₹149', diamonds: 1000, bonusText: '+100 Coins & Sparkle', color: 'from-cyan-600 to-blue-500' },
  { id: 'tier-199', inrPrice: 199, priceLabel: '₹199', diamonds: 1500, bonusText: '+500 Free Coins', color: 'from-indigo-600 to-purple-600', badge: 'POPULAR', popular: true },
  { id: 'tier-299', inrPrice: 299, priceLabel: '₹299', diamonds: 2500, bonusText: '+Lucky Sixer Badge', color: 'from-purple-600 to-fuchsia-600' },
  { id: 'tier-399', inrPrice: 399, priceLabel: '₹399', diamonds: 3600, bonusText: '+Fire Token Trail', color: 'from-pink-600 to-rose-600' },
  { id: 'tier-499', inrPrice: 499, priceLabel: '₹499', diamonds: 5000, bonusText: '+1 Rare Crate', color: 'from-rose-600 to-amber-600', badge: 'BEST VALUE', popular: true },
  { id: 'tier-9999', inrPrice: 9999, priceLabel: '₹9,999', diamonds: 50000, bonusText: '+Archangel Frame & VIP Status', color: 'from-amber-600 to-yellow-500', badge: 'VIP FAVORITE' },
  { id: 'tier-19999', inrPrice: 19999, priceLabel: '₹19,999', diamonds: 200000, bonusText: '+Bugatti Supercar Arrival', color: 'from-yellow-500 to-amber-400', badge: 'SOVEREIGN APEX' },
];

// 2. TEN COIN ECONOMY ITEMS (Bible Item 7: 10/20/30/40/50 Coins)
export interface CoinItem {
  id: string;
  name: string;
  hindiName: string;
  coinCost: 10 | 20 | 30 | 40 | 50;
  icon: string;
  category: string;
  description: string;
}

export const TEN_COIN_ITEMS: CoinItem[] = [
  { id: 'coin-10a', name: 'Chidiya Token Glow', hindiName: 'चिड़िया गोटी चमक', coinCost: 10, icon: '✨', category: 'Token FX', description: 'Surrounds your pawn with a soft golden glow on 6 rolls.' },
  { id: 'coin-10b', name: 'Chat Sparkle Particle', hindiName: 'चैट स्पार्कल कण', coinCost: 10, icon: '💫', category: 'Chat FX', description: 'Sends sparkling stars into the voice room chat feed.' },
  { id: 'coin-20a', name: 'Mini Heart Reaction', hindiName: 'छोटा दिल अभिवादन', coinCost: 20, icon: '💖', category: 'Live Reaction', description: 'Heart pulse burst directly above any active voice room seat.' },
  { id: 'coin-20b', name: 'Lucky Dice Roll Charm', hindiName: 'लकी डाइस आकर्षण', coinCost: 20, icon: '🎲', category: 'Dice Charm', description: 'Visual golden chime aura during your next 3 rolls.' },
  { id: 'coin-30a', name: 'Voice Room Chai Cup', hindiName: 'कुल्हड़ चाय गिफ्ट', coinCost: 30, icon: '☕', category: 'Social Cheer', description: 'Warm steaming chai reaction sent to the room host.' },
  { id: 'coin-30b', name: 'Party Whistle Horn', hindiName: 'पार्टी सीटी ध्वनि', coinCost: 30, icon: '🎺', category: 'Audio FX', description: 'Fun victory cheer sound heard by spectators.' },
  { id: 'coin-40a', name: 'Golden Rose Token', hindiName: 'स्वर्ण गुलाब भेंट', coinCost: 40, icon: '🌹', category: 'Token Gift', description: 'Drops a fragrant 3D blooming rose on opponent capture.' },
  { id: 'coin-40b', name: 'Rank XP Boost Scroll', hindiName: 'स्तर वृद्धि स्क्रोल', coinCost: 40, icon: '📜', category: 'Progression', description: 'Boosts 1,000-level XP gained in the next completed match.' },
  { id: 'coin-50a', name: 'Safe Cell Shield Stamp', hindiName: 'सुरक्षा चक्र मोहर', coinCost: 50, icon: '🛡️', category: 'Board Decor', description: 'Inscribes glowing protective runes on the 8 safe star cells.' },
  { id: 'coin-50b', name: 'Royal Emote Word Pack', hindiName: 'शाही शब्द संकलन', coinCost: 50, icon: '👑', category: 'Word Pack', description: 'Unlocks "Shabash!", "Jai Mahakal!", & "Khel Khatam!" emotes.' },
];

// 3. THE 12 COLLECTION UNIVERSE FAMILIES (Bible Item 10)
export interface CollectionFamily {
  id: string;
  name: string;
  hindiName: string;
  icon: string;
  source: string;
  specialUnlock: string;
  itemsCount: number;
  accentColor: string;
  description: string;
}

export const COLLECTION_FAMILIES: CollectionFamily[] = [
  {
    id: 'fam-stars',
    name: 'Stars Family',
    hindiName: 'नक्षत्र तारा परिवार',
    icon: '⭐',
    source: 'Competitive Matches & Daily Rewards',
    specialUnlock: '5,000 Stars → Signature Entry (User photo rotating into lobby as cinematic supercar entry!)',
    itemsCount: 12,
    accentColor: 'from-amber-400 to-yellow-500',
    description: 'Celestial star fragments accumulated through skillful Ludo play and high-rank finishes.',
  },
  {
    id: 'fam-hearts',
    name: 'Hearts Family',
    hindiName: 'हृदय परिवार (दिल)',
    icon: '💖',
    source: 'Heart-Earned Only (Gifts, Romance Rooms, Affection)',
    specialUnlock: 'Milestones: 1,000 • 5,000 • 10,000 • 50,000 • 100,000 Hearts',
    itemsCount: 10,
    accentColor: 'from-pink-500 to-rose-600',
    description: 'Strictly heart-earned (never purchased with diamonds/stars). Pure social bond representation.',
  },
  {
    id: 'fam-morepankh',
    name: 'More Pankh (Peacock Feathers)',
    hindiName: 'मोर पंख संकलन',
    icon: '🦚',
    source: 'Chess/Sudoku (+5 per win, max 10/day) & Spin Wheel',
    specialUnlock: '100 More Pankh → Shri Krishna Celestial Crown & Peacock Trail FX',
    itemsCount: 8,
    accentColor: 'from-emerald-500 to-teal-600',
    description: 'Divine peacock feathers symbolizing elegance and strategic mastery from mini-games.',
  },
  {
    id: 'fam-eggs',
    name: 'Mystic Eggs & Incubators',
    hindiName: 'दिव्य अंडे एवं हैचरी',
    icon: '🥚',
    source: 'Snake-bite saves, Diamond Deposits & Ladder ascents',
    specialUnlock: 'Snake/Ladder sources → Rare Glowing Holographic Name Tags & Mythic Pets',
    itemsCount: 9,
    accentColor: 'from-violet-500 to-purple-700',
    description: 'Rare eggs nurtured in temperature-controlled incubators to hatch legendary butterflies and dragons.',
  },
  {
    id: 'fam-butterflies',
    name: 'Butterflies Sanctuary',
    hindiName: 'तितली अभयारण्य (12 प्रजातियां)',
    icon: '🦋',
    source: 'Egg Hatchery, Garden of Lokas & Sanctuary Care',
    specialUnlock: 'Equipped butterfly flutters around 3D dice providing passive roll luck buffs!',
    itemsCount: 12,
    accentColor: 'from-cyan-400 to-blue-600',
    description: '12 mystical species from Morpho to Solar Empress that flutter over the live match board.',
  },
  {
    id: 'fam-fish',
    name: 'Oceanic Fish Collection',
    hindiName: 'मत्स्य जल संकलन',
    icon: '🐟',
    source: 'Varun Astra Vortex, Water Board Rivers & Angler Mini-Game',
    specialUnlock: '1,000 Fish → Exclusive Animated Bubble Chat Avatar & Coral Frame!',
    itemsCount: 15,
    accentColor: 'from-blue-500 to-cyan-400',
    description: 'Tropical neon fish swimming beneath the transparent glass panels of the Ludo arena.',
  },
  {
    id: 'fam-kiss',
    name: 'Kiss & Romance Themes',
    hindiName: 'प्रेम एवं चुंबन संकलन',
    icon: '💋',
    source: 'Wedding/Love/Monument Themes & Spin Discovery',
    specialUnlock: 'Taj Mahal Monument Theme & Flying Cupid Arrow Room Entry',
    itemsCount: 8,
    accentColor: 'from-red-500 to-pink-600',
    description: 'Celebrates love, romance voice lounges, and iconic couple milestones.',
  },
  {
    id: 'fam-double-hearts',
    name: 'Double Hearts & Caps',
    hindiName: 'युगल दिल एवं विशिष्ट कैप्स',
    icon: '💞',
    source: 'Duo 2v2 Wins & Reciprocal Heart Showers',
    specialUnlock: 'Special Cap + Further Bronze, Silver, Gold, Diamond Cap Awards!',
    itemsCount: 6,
    accentColor: 'from-fuchsia-500 to-purple-600',
    description: 'Exclusive wearable 3D royal caps crowned over player avatars in live rooms.',
  },
  {
    id: 'fam-balloons',
    name: 'Party Balloons Festival',
    hindiName: 'उत्सव गुब्बारे',
    icon: '🎈',
    source: 'Match Victories, Room Host Cheers & Sunday Tournaments',
    specialUnlock: '3D Balloon Bouquet floats across the screen on 6-6-6 rolls!',
    itemsCount: 10,
    accentColor: 'from-rose-400 to-amber-400',
    description: 'Glossy rubber celebratory balloons with realistic lighting and soft buoyant physics.',
  },
  {
    id: 'fam-vegetables-food',
    name: 'Harvest Vegetables & Royal Food',
    hindiName: 'शाही भोज एवं फल-सब्जियां',
    icon: '🥗',
    source: 'Farm Harvest Mini-Game, Daily Picnic Crate',
    specialUnlock: 'Royal Thali Table Feast Gift & 2x Pet Affection Feeding Energy',
    itemsCount: 14,
    accentColor: 'from-green-500 to-lime-500',
    description: 'Fresh organic vegetables, juicy fruits, and royal sweets to feed pets and cheer hosts.',
  },
  {
    id: 'fam-friends-band',
    name: 'Friends Band & Friendship Bands',
    hindiName: 'मित्रता बैंड एवं सहचर्य',
    icon: '🤝',
    source: 'Friend Rematches, Co-Op Clan Wars & Room Invites',
    specialUnlock: 'Duo Synergy Aura & Synchronized High-Five Avatar Emote',
    itemsCount: 8,
    accentColor: 'from-indigo-400 to-cyan-500',
    description: 'Woven friendship bracelets sealing immortal bonds between Ludo companions.',
  },
  {
    id: 'fam-love-birds',
    name: 'Love Birds Sanctuary',
    hindiName: 'प्रेम पक्षी (लव बर्ड्स)',
    icon: '🕊️',
    source: 'Voice Room Co-Host Loyalty & Romance Pass',
    specialUnlock: 'Twin Doves perched on avatar frame singing harmonious chimes on victory',
    itemsCount: 7,
    accentColor: 'from-teal-400 to-emerald-400',
    description: 'Affectionate feathered companions that roost together on the player podium.',
  },
];

// 4. HOT SEATS & PUBLIC ACTIVITY STATUS (Bible Item 6: 1★ to 10★ Rarity)
export interface HotSeatStatus {
  id: string;
  name: string;
  hindiName: string;
  icon: string;
  rarityStars: number;
  frameStyle: string;
  description: string;
}

export const HOT_SEAT_STATUSES: HotSeatStatus[] = [
  { id: 'seat-winner', name: 'Match Winner', hindiName: 'विजेता सम्राट', icon: '🏆', rarityStars: 3, frameStyle: 'border-amber-400 shadow-[0_0_15px_#f59e0b]', description: 'Won the most recent competitive Ludo match.' },
  { id: 'seat-topper', name: 'Leaderboard Topper', hindiName: 'रैंक शिखर', icon: '👑', rarityStars: 10, frameStyle: 'border-yellow-300 shadow-[0_0_25px_#facc15] animate-pulse', description: 'Holding #1 spot on the Daily or Weekly Board.' },
  { id: 'seat-hotboard', name: 'Hot Board Sensation', hindiName: 'हॉट बोर्ड सितारा', icon: '🔥', rarityStars: 5, frameStyle: 'border-orange-500 shadow-[0_0_18px_#f97316]', description: 'Captured 5+ enemy pawns in a single session.' },
  { id: 'seat-lottery', name: 'Jackpot Winner', hindiName: 'लॉटरी विजेता', icon: '🎰', rarityStars: 8, frameStyle: 'border-fuchsia-400 shadow-[0_0_20px_#e879f9]', description: 'Won the Grand Jackpot on the Daily Wheel.' },
  { id: 'seat-comeback', name: 'Comeback King', hindiName: 'वापसी वीर', icon: '⚡', rarityStars: 6, frameStyle: 'border-cyan-400 shadow-[0_0_18px_#22d3ee]', description: 'Recovered from 1 pawn remaining to win the game.' },
  { id: 'seat-gift', name: 'Top Gifter Titan', hindiName: 'दानवीर शिरोमणि', icon: '🎁', rarityStars: 9, frameStyle: 'border-purple-400 shadow-[0_0_22px_#c084fc]', description: 'Sent 100,000+ Diamonds in room gifts today.' },
  { id: 'seat-talk', name: 'Voice Star Talker', hindiName: 'वाणी महारथी', icon: '🎙️', rarityStars: 4, frameStyle: 'border-emerald-400 shadow-[0_0_15px_#34d399]', description: 'Active voice host with 50+ live listeners.' },
];

// 5. 1,000-LEVEL PROGRESSION & FAME BOARDS (Bible Item 9)
export interface LevelMilestone {
  level: number;
  title: string;
  hindiTitle: string;
  badge: string;
  rewardDiamonds: number;
  rewardCoins: number;
  perk: string;
}

export const LEVEL_1000_MILESTONES: LevelMilestone[] = [
  { level: 1, title: 'Novice Roller', hindiTitle: 'आरंभिक खिलाड़ी', badge: '🎲', rewardDiamonds: 50, rewardCoins: 1000, perk: 'Standard Wooden Dice' },
  { level: 10, title: 'Goti Starter', hindiTitle: 'गोटी साधक', badge: '⚔️', rewardDiamonds: 250, rewardCoins: 5000, perk: 'Bronze Frame & Quick Cheers' },
  { level: 50, title: 'Lucky Sixer', hindiTitle: 'लकी छक्का मास्टर', badge: '🎯', rewardDiamonds: 1000, rewardCoins: 25000, perk: 'Lucky Sixer Title & Green Plasma Dice' },
  { level: 100, title: 'Goti Killer', hindiTitle: 'गोटी संहारक', badge: '🩸', rewardDiamonds: 5000, rewardCoins: 100000, perk: 'Goti Killer Blood-Red Title & Impact Wave' },
  { level: 250, title: 'Diamond Mafia', hindiTitle: 'डायमंड माफिया', badge: '💎', rewardDiamonds: 20000, rewardCoins: 500000, perk: 'Diamond Mafia Title & Black Gold Dice' },
  { level: 500, title: 'Apex Sovereign', hindiTitle: 'परम अधिपति', badge: '👑', rewardDiamonds: 50000, rewardCoins: 2000000, perk: 'Golden Signature Entry & VIP 8 Seat Halo' },
  { level: 750, title: 'Cosmic Avatar', hindiTitle: 'ब्रह्मांडीय अवतार', badge: '🌌', rewardDiamonds: 100000, rewardCoins: 5000000, perk: 'Trishul Tandav Aura & Galaxy Safe Cells' },
  { level: 1000, title: 'Universal Legend', hindiTitle: 'सर्वकालिक अमर महानायक', badge: '✨', rewardDiamonds: 500000, rewardCoins: 25000000, perk: 'Eternal Golden Statue in Museum & 24K Halo' },
];

// 6. PUBLIC DISCOVERY SECTIONS (Bible Item 3)
export interface DiscoveryItem {
  id: string;
  category: 'Hot Today' | 'Trending on Board' | 'New This Week' | 'Rare Showcase' | 'Play & Earn' | 'Live Board' | 'Pet of the Day' | 'Mystery Unlock';
  title: string;
  subtitle: string;
  icon: string;
  badge: string;
  gradient: string;
  actionText: string;
  targetModal?: string;
}

export const PUBLIC_DISCOVERY_ITEMS: DiscoveryItem[] = [
  { id: 'disc-hot', category: 'Hot Today', title: 'Tandav Trishul 50M Battle', subtitle: 'Room #892 with 8 voice seats full & live gifts', icon: '🔥', badge: 'TRENDING', gradient: 'from-orange-600 to-red-600', actionText: 'JOIN ROOM', targetModal: 'rooms' },
  { id: 'disc-board', category: 'Trending on Board', title: '6-6-6 Triple Roll Frenzy', subtitle: 'Aryan captured 3 pawns in one turn!', icon: '📈', badge: 'VIRAL', gradient: 'from-amber-600 to-yellow-600', actionText: 'SPECTATE', targetModal: 'arena' },
  { id: 'disc-new', category: 'New This Week', title: '12 Mystic Butterfly Species', subtitle: 'Hatch eggs in the sanctuary to gain roll buffs', icon: '🦋', badge: 'NEW', gradient: 'from-cyan-600 to-blue-600', actionText: 'HATCH NOW', targetModal: 'butterfly' },
  { id: 'disc-rare', category: 'Rare Showcase', title: 'Sudarshan Chakra Apex Weapon', subtitle: '79.9B 💎 Cosmic Weapon with Solar Om spin', icon: '💎', badge: 'MYTHIC', gradient: 'from-purple-600 to-indigo-600', actionText: 'INSPECT', targetModal: 'astra' },
  { id: 'disc-earn', category: 'Play & Earn', title: 'Daily 40 Diamonds Ludo Cap', subtitle: 'Finish games & cut pawns to reach max payout', icon: '🪙', badge: 'EARN', gradient: 'from-emerald-600 to-teal-600', actionText: 'PLAY LUDO', targetModal: 'arena' },
  { id: 'disc-live', category: 'Live Board', title: 'Sunday Maha-Tournament', subtitle: '1,000 players competing for ₹50,000 in diamonds', icon: '🎲', badge: 'LIVE', gradient: 'from-rose-600 to-pink-600', actionText: 'REGISTER', targetModal: 'leaderboard' },
  { id: 'disc-pet', category: 'Pet of the Day', title: 'Celestial Azure Dragon', subtitle: 'Passive: +15% Star roll luck & flame trails', icon: '🐉', badge: 'FEATURED', gradient: 'from-blue-600 to-cyan-500', actionText: 'VIEW PET', targetModal: 'pets' },
  { id: 'disc-unlock', category: 'Mystery Unlock', title: 'Snake-Bite Mystic Egg', subtitle: 'Survived snake safe-zone to drop ancient egg', icon: '🗝️', badge: 'LUCKY', gradient: 'from-violet-600 to-fuchsia-600', actionText: 'CLAIM EGG', targetModal: 'butterfly' },
];

