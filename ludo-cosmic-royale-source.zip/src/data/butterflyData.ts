export interface ButterflyCompanion {
  id: string;
  name: string;
  hindiName: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Divine';
  element: string;
  glowColor: string;
  description: string;
  buffTitle: string;
  buffDescription: string;
  passivePerk: string;
  wingspan: string;
  unlocked: boolean;
  eggTier?: string;
  hatchTimeMinutes?: number;
}

export const BUTTERFLY_SPECIES: ButterflyCompanion[] = [
  {
    id: 'bf-emerald-aurora',
    name: 'Emerald Aurora Butterfly',
    hindiName: 'हरित ज्योति तितली',
    rarity: 'Rare',
    element: 'Nature & Wind',
    glowColor: '#10b981',
    description: 'Born from sacred Himalayan groves. Emits a soothing emerald luminescence.',
    buffTitle: 'Lucky Safe Step',
    buffDescription: '+15% chance to land safely on star squares during tense turns.',
    passivePerk: '+15% Safe Step Chance',
    wingspan: '14.2 cm',
    unlocked: true,
  },
  {
    id: 'bf-neelkanth-azure',
    name: 'Neelkanth Azure Monarch',
    hindiName: 'नीलकंठ स्वर्गीय तितली',
    rarity: 'Epic',
    element: 'Divine Water',
    glowColor: '#06b6d4',
    description: 'Carries the essence of Shiva’s Neelkanth serenity and cosmic blue sparks.',
    buffTitle: 'Dice Stability',
    buffDescription: 'Reduces the likelihood of rolling low consecutive dice values.',
    passivePerk: 'Prevents Consecutive Ones',
    wingspan: '18.5 cm',
    unlocked: true,
  },
  {
    id: 'bf-surya-gold',
    name: 'Suryavanshi Golden Swallowtail',
    hindiName: 'सूर्यवंशी स्वर्ण तितली',
    rarity: 'Legendary',
    element: 'Solar Light',
    glowColor: '#f59e0b',
    description: 'Bathed in solar radiation from Surya Lok. Shines like liquid molten gold.',
    buffTitle: 'Golden Fortune +20%',
    buffDescription: 'Increases token reward multiplier and boosts double-six frequency.',
    passivePerk: '+20% Gold & Double 6 Boost',
    wingspan: '22.0 cm',
    unlocked: true,
  },
  {
    id: 'bf-cosmic-void',
    name: 'Amrit Brahma Violet Monarch',
    hindiName: 'अमृत ब्रह्म तितली',
    rarity: 'Divine',
    element: 'Cosmic Ether',
    glowColor: '#a855f7',
    description: 'Transcends ordinary space-time, fluttering between earthly and divine realms.',
    buffTitle: 'Astra Haste',
    buffDescription: 'Reduces all divine Astra cooldowns by 3 seconds automatically.',
    passivePerk: '-3s Astra Cooldowns',
    wingspan: '26.8 cm',
    unlocked: true,
  },
  {
    id: 'bf-agni-ember',
    name: 'Agni Jwala Crimson Flutter',
    hindiName: 'अग्नि ज्वाला तितली',
    rarity: 'Epic',
    element: 'Sacred Flame',
    glowColor: '#ef4444',
    description: 'Blazes with the pure fury of Havana Agni, leaving fiery trails in flight.',
    buffTitle: 'Capture Rush',
    buffDescription: 'Grants 250 bonus coins whenever an opponent token is eliminated.',
    passivePerk: '+250 Coins per Capture',
    wingspan: '16.0 cm',
    unlocked: false,
  },
];
