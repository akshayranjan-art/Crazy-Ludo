export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export type AppView = 'lobby' | 'rooms' | 'arena' | 'map' | 'leaderboard' | 'store' | 'profile';

export type FrameStyleId =
  | 'gold-wings'
  | 'royal-crown'
  | 'lion-crest'
  | 'neon-heart'
  | 'dragon-crest'
  | 'diamond-star'
  | 'purple-empress'
  | 'blue-angel'
  | 'cyber-dragon'
  | 'phoenix-flame'
  | 'divine-halo'
  | 'emerald-lotus'
  | 'galaxy-swirl'
  | 'vip-crown'
  | 'royal-ruby'
  | 'diamond-aura'
  | 'ocean-wave'
  | 'sakura-blossom'
  | 'golden-vajra'
  | 'solar-flare'
  | 'nagraj-coils'
  | 'hyper-neon';

export interface AvatarFrame {
  id: FrameStyleId;
  name: string;
  hindiName?: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic' | 'Apex';
  description: string;
  glowColor: string;
  borderClass: string;
  icon: string;
  diamondPrice?: number;
  unlocked?: boolean;
}

export interface LiveRoom {
  id: string;
  title: string;
  hostName: string;
  hostAvatar: string;
  hostFrame: FrameStyleId;
  hostLevel: number;
  occupantsCount: number;
  maxSeats: number;
  tags: string[];
  isLocked: boolean;
  theme: 'royal' | 'cosmic' | 'neon' | 'temple' | 'cyber' | 'lounge';
  currentActivity: string;
  bgGradient: string;
  roomCover: string;
  hotScore: number;
}

export interface Token {
  id: number; // 0, 1, 2, 3
  color: PlayerColor;
  position: number; // -1 to -4: home base; 0 to 51: main path; 100 to 105: colored home path; 999: finished home
  stepCount: number; // 0 to 57 total steps needed to finish
}

export interface Player {
  id: string;
  name: string;
  color: PlayerColor;
  avatar: string;
  avatarFrame: string;
  isBot: boolean;
  tokens: Token[];
  hasFinished: boolean;
  rank?: number;
  level: number;
  title: string;
  winStreak?: number;
}

export type PetRarity = 'Rare' | 'Epic' | 'Mythic' | 'Ancient' | 'Divine' | '???';
export type PetBehaviorState = 'walk' | 'sit' | 'sleep' | 'celebrate' | 'react';

export interface Seat {
  id: number;
  playerName: string;
  avatar: string;
  frameStyle: FrameStyleId;
  isMuted: boolean;
  isSpeaking: boolean;
  volume: number; // 0 - 100
  level: number;
  title: string;
  coins: number;
  diamonds: number;
  isHotSeat?: boolean;
  petId?: string;
  petBehavior?: PetBehaviorState;
  equippedAstra?: string;
}

export interface AstraItem {
  id: string;
  name: string;
  hindiName: string;
  tier: 'Apex Divine' | 'Ultra Divine' | 'High Celestial' | 'Vedic Astra';
  element: string;
  permanentDiamondCost: number;
  image: string;
  description: string;
  cinematicEffect: 'tandav' | 'gada-smash' | 'sudarshan-spin' | 'lightning-vajra' | 'solar-rath' | 'brahmastra';
  passiveBonus: string;
  isThirdEyeCollection?: boolean;
  adminConfig?: string;
  temporaryBlockBoardUses?: number;
}

export type MiracleArrivalVariant =
  | 'dash-arrival'
  | 'royal-curtain'
  | 'shadow-curtain'
  | 'magic-pocket'
  | 'emergency-delivery'
  | 'funny-fall'
  | 'double-arrival'
  | 'pet-escort'
  | 'secret-arrival'
  | 'miracle-finale';

export interface Visual4DState {
  liquidNeonButtons: boolean;
  holographicDice: boolean;
  bioluminescentBoard: boolean;
  jellyTokens: boolean;
  victoryShockwaves: boolean;
  weatherArena: 'clear' | 'storm' | 'solar' | 'aurora';
  cinematicKillCam: boolean;
  soundReactiveBorders: boolean;
  zeroGravityLobby: boolean;
}

export interface PetItem {
  id: string;
  name: string;
  numberIndex: number; // 1 to 30
  species: string;
  element: string;
  rarity: PetRarity;
  image: string;
  unlockRequirement: string;
  level: number;
  affection: number;
  bonus: string;
  unlocked: boolean;
  behaviorState?: PetBehaviorState;
  icon?: string;
}

export interface GiftItem {
  id: string;
  name: string;
  hindiName?: string;
  icon: string;
  cost: number;
  currency: 'diamonds' | 'coins';
  rarity: 'Common' | 'Popular' | 'Luxury' | 'Mega Supercar' | 'Divine Supreme';
  bannerText: string;
}

export interface ChatMessage {
  id: string;
  sender: string;
  avatar: string;
  text: string;
  type: 'chat' | 'gift' | 'roll' | 'capture' | 'astra' | 'entry';
  timestamp: string;
  badge?: string;
}

