import React, { useState } from 'react';
import { X, Sparkles, Droplets, Zap, Eye, Wind, CloudRain, Sun, Disc3, ShieldAlert, Layers } from 'lucide-react';
import { Visual4DState } from '../types/game';
import { sound } from '../utils/soundEngine';
import {
  Icon4DWrapper,
  RealisticTrophyIcon,
  RealisticCrownIcon,
  RealisticDiamondIcon,
  RealisticCoinIcon,
  RealisticDiceIcon,
  RealisticTrishulIcon,
  RealisticGadaIcon,
  RealisticChakraIcon,
  RealisticDragonIcon,
  RealisticGiftIcon,
  RealisticShieldIcon,
  RealisticFlameIcon,
  RealisticBowArrowIcon,
  RealisticFluteIcon,
  RealisticArcadeTargetIcon,
  RealisticVIPMicIcon,
  RealisticCodexBookIcon,
  RealisticCoupleHeartsIcon,
  RealisticAndroidApkIcon,
} from './RealIcons';

interface NeonLiquidVisualsModalProps {
  isOpen: boolean;
  onClose: () => void;
  visuals: Visual4DState;
  onToggleVisual: (key: keyof Visual4DState, value?: any) => void;
}

export const NeonLiquidVisualsModal: React.FC<NeonLiquidVisualsModalProps> = ({
  isOpen,
  onClose,
  visuals,
  onToggleVisual,
}) => {
  const [activeTab, setActiveTab] = useState<'4d-icons' | 'fx'>('4d-icons');
  const [selectedTheme, setSelectedTheme] = useState<'cyberpunk' | 'gold' | 'cyan' | 'ruby' | 'emerald' | 'amethyst'>('cyberpunk');
  const [activePreviewIcon, setActivePreviewIcon] = useState<string>('Trishul');

  if (!isOpen) return null;

  const THEMES: { id: typeof selectedTheme; name: string; color: string; desc: string }[] = [
    { id: 'cyberpunk', name: 'Cyberpunk Neon', color: 'from-amber-400 to-cyan-400', desc: 'Gold glow + cyan volumetric reflection' },
    { id: 'gold', name: 'Royal Gold 24K', color: 'from-yellow-300 to-amber-500', desc: 'Pure 24K gold mirror sheen' },
    { id: 'cyan', name: 'Celestial Cyan', color: 'from-cyan-300 to-blue-500', desc: 'Diamond glass & cosmic starlight' },
    { id: 'ruby', name: 'Mythic Ruby', color: 'from-rose-400 to-red-600', desc: 'Liquid crimson plasma flame' },
    { id: 'emerald', name: 'Sacred Emerald', color: 'from-emerald-300 to-teal-500', desc: 'Jade dragon & serpent aura' },
    { id: 'amethyst', name: 'Imperial Violet', color: 'from-purple-300 to-indigo-500', desc: 'Cosmic codex & royal veil' },
  ];

  const SHOWCASE_ICONS = [
    { id: 'Trishul', name: 'Divine Trishul', component: <RealisticTrishulIcon size={36} />, category: 'Astra (Sec 10)' },
    { id: 'Gada', name: 'Hanuman Gada', component: <RealisticGadaIcon size={36} />, category: 'Astra (Sec 10)' },
    { id: 'Chakra', name: 'Sudarshan Chakra', component: <RealisticChakraIcon size={36} />, category: 'Astra (Sec 10)' },
    { id: 'Trophy', name: 'Golden Trophy', component: <RealisticTrophyIcon size={36} />, category: 'Podium (Sec 41)' },
    { id: 'Crown', name: 'Imperial Crown', component: <RealisticCrownIcon size={36} />, category: 'VIP (Sec 5)' },
    { id: 'Diamond', name: 'Crystal Diamond', component: <RealisticDiamondIcon size={36} />, category: 'Economy (Sec 8)' },
    { id: 'Coin', name: 'Rupee Medallion', component: <RealisticCoinIcon size={36} />, category: 'Daily (Sec 8)' },
    { id: 'Dice', name: 'Weighted 3D Dice', component: <RealisticDiceIcon size={36} />, category: 'Board (Sec 2)' },
    { id: 'Dragon', name: 'Celestial Dragon', component: <RealisticDragonIcon size={36} />, category: 'Pets (Sec 11)' },
    { id: 'Gift', name: 'Satin Ribbon Gift', component: <RealisticGiftIcon size={36} />, category: 'Social (Sec 6)' },
    { id: 'Shield', name: 'Titanium Shield', component: <RealisticShieldIcon size={36} />, category: 'Admin (Sec 25)' },
    { id: 'Flame', name: 'Liquid Fire Flame', component: <RealisticFlameIcon size={36} />, category: 'Hotseat (Sec 3)' },
    { id: 'Bow', name: 'Bow & Takshak Nag', component: <RealisticBowArrowIcon size={36} />, category: 'Mini-Games (Sec 16)' },
    { id: 'Flute', name: 'Krishna Flute', component: <RealisticFluteIcon size={36} />, category: 'Curtains (Sec 15)' },
    { id: 'Arcade', name: 'Bullseye Arcade', component: <RealisticArcadeTargetIcon size={36} />, category: 'Mini-Games (Sec 16)' },
    { id: 'Mic', name: '8-Seat VIP Mic', component: <RealisticVIPMicIcon size={36} />, category: 'Voice (Sec 5)' },
    { id: 'Codex', name: 'Cosmic Game Bible', component: <RealisticCodexBookIcon size={36} />, category: 'Bible (Sec 0-43)' },
    { id: 'Couple', name: 'Double Hearts', component: <RealisticCoupleHeartsIcon size={36} />, category: 'Couple (Sec 12)' },
    { id: 'Apk', name: 'Android 3D Capsule', component: <RealisticAndroidApkIcon size={36} />, category: 'Install' },
  ];

  const WEATHER_OPTIONS: { id: Visual4DState['weatherArena']; name: string; icon: string; desc: string }[] = [
    { id: 'clear', name: 'Cosmic Starlight', icon: '🌌', desc: 'Clear deep void with sparkling star dust' },
    { id: 'storm', name: 'Plasma Storm & Rain', icon: '⚡', desc: 'Divine Indra thunderstorm & electrical rain ripples' },
    { id: 'solar', name: 'Solar Flares', icon: '☀️', desc: 'Surya Lok intense golden flares and heatwaves' },
    { id: 'aurora', name: 'Bioluminescent Aurora', icon: '🌈', desc: 'Flowing neon curtains in turquoise & magenta' },
  ];

  const TOGGLES: {
    key: keyof Visual4DState;
    title: string;
    desc: string;
    icon: string;
  }[] = [
    {
      key: 'liquidNeonButtons',
      title: 'Liquid-Mercury Neon Buttons',
      desc: 'Fluid mercury border gradients with reactive ripple feedback on touch.',
      icon: '💧',
    },
    {
      key: 'holographicDice',
      title: 'Holographic 3D Dice',
      desc: 'Projects a luminous 3D matrix cube projection around physical dice.',
      icon: '🎲',
    },
    {
      key: 'bioluminescentBoard',
      title: 'Adaptive Bioluminescent Board',
      desc: 'Pulsating star nodes and glowing circuit tracks that adapt to turns.',
      icon: '✨',
    },
    {
      key: 'jellyTokens',
      title: 'Jelly Wobble Tokens',
      desc: 'Springy squash-and-stretch physical bounce on pawn hops and captures.',
      icon: '🍮',
    },
    {
      key: 'victoryShockwaves',
      title: 'Victory Radial Shockwaves',
      desc: 'Expands triple cosmic shockwave rings when completing a token or winning.',
      icon: '💥',
    },
    {
      key: 'cinematicKillCam',
      title: 'Cinematic Kill-Cam (Slow-Mo)',
      desc: 'Dynamic cinematic camera zoom and camera shake during pawn eliminations.',
      icon: '🎥',
    },
    {
      key: 'soundReactiveBorders',
      title: 'Sound-Reactive Borders',
      desc: 'Arena border shines brighter and pulses in real-time with Web Audio frequencies.',
      icon: '🔊',
    },
    {
      key: 'zeroGravityLobby',
      title: 'Zero-Gravity Lobby Atmosphere',
      desc: 'Subtle floating drift applied to cards, banners, and celestial elements.',
      icon: '🪐',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl overflow-hidden border-2 border-cyan-400/60 rounded-3xl bg-gradient-to-b from-[#06152b] via-[#050b17] to-black text-slate-100 shadow-[0_0_60px_rgba(6,182,212,0.3)] flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-cyan-900/60 via-blue-900/40 to-purple-900/40 border-b border-cyan-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Icon4DWrapper theme="cyan" tilt={false} className="w-12 h-12 rounded-2xl">
              <RealisticDiamondIcon size={28} />
            </Icon4DWrapper>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 to-indigo-300 font-cinzel">
                  4D & Volumetric Icons Studio
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-400/40">
                  Item 22
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Glassmorphism, 3D Rendered Depth, Specular Highlights & Cyberpunk Glow
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 p-3 bg-black/40 border-b border-white/5">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('4d-icons');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
              activeTab === '4d-icons'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.5)]'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Layers size={14} />
            <span>4D Volumetric Icons Showcase ({SHOWCASE_ICONS.length})</span>
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('fx');
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
              activeTab === 'fx'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.5)]'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles size={14} />
            <span>Weather & Physics FX ({TOGGLES.length})</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === '4d-icons' ? (
            <div className="space-y-4">
              {/* Theme Chooser Bar */}
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                    <span>✨</span> Select 4D Glassmorphism Theme
                  </h4>
                  <span className="text-[10px] text-slate-400">Tap to re-skin all 4D icons</span>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {THEMES.map((theme) => {
                    const isSelected = selectedTheme === theme.id;
                    return (
                      <button
                        key={theme.id}
                        onClick={() => {
                          sound.playClick();
                          setSelectedTheme(theme.id);
                        }}
                        className={`p-2 rounded-xl border text-center transition flex flex-col items-center gap-1 ${
                          isSelected
                            ? 'bg-white/15 border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.6)] scale-105'
                            : 'bg-white/5 border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${theme.color} shadow-sm`} />
                        <span className="text-[10px] font-bold text-white truncate max-w-full">{theme.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Design Standards Info Pill */}
              <div className="px-3.5 py-2 rounded-xl bg-purple-950/40 border border-purple-500/30 text-[11px] text-purple-200 flex items-center justify-between">
                <span>🎨 <strong>Industry Standard:</strong> Icons8 3D Fluency, Iconfinder Glass & UI8 3D Asset Fidelity</span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-purple-500/30 font-mono font-bold">Lossless SVG Vector</span>
              </div>

              {/* Grid of Interactive 4D Volumetric Icons */}
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3 pt-1">
                {SHOWCASE_ICONS.map((item) => {
                  const isInspecting = activePreviewIcon === item.id;
                  return (
                    <div
                      key={item.id}
                      onClick={() => {
                        sound.playClick();
                        setActivePreviewIcon(item.id);
                      }}
                      className="flex flex-col items-center cursor-pointer group"
                    >
                      <Icon4DWrapper
                        theme={selectedTheme}
                        className={`w-16 h-16 rounded-2xl flex items-center justify-center cursor-pointer transition-transform ${
                          isInspecting ? 'ring-2 ring-cyan-300 scale-110' : ''
                        }`}
                      >
                        {item.component}
                      </Icon4DWrapper>
                      <span className="text-[11px] font-bold text-white group-hover:text-cyan-300 mt-2 truncate max-w-[85px] text-center">
                        {item.name}
                      </span>
                      <span className="text-[8px] text-slate-400 truncate max-w-[85px] text-center font-mono">
                        {item.category}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Weather Arena Selector */}
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-2.5">
                <h4 className="text-xs font-black uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                  <span>🌦️</span> Dynamic Weather Arenas
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {WEATHER_OPTIONS.map((w) => {
                    const isSelected = visuals.weatherArena === w.id;
                    return (
                      <button
                        key={w.id}
                        onClick={() => {
                          sound.playClick();
                          onToggleVisual('weatherArena', w.id);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition ${
                          isSelected
                            ? 'bg-cyan-950/80 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                            : 'bg-black/40 border-white/10 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <span className="text-base">{w.icon}</span>
                          <span className="text-xs font-black text-white">{w.name}</span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 leading-snug">{w.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4D Toggles */}
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">
                  Visual & Physics FX ({TOGGLES.length})
                </h4>

                {TOGGLES.map((t) => {
                  const active = !!visuals[t.key];
                  return (
                    <div
                      key={t.key}
                      onClick={() => {
                        sound.playClick();
                        onToggleVisual(t.key);
                      }}
                      className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                        active
                          ? 'bg-slate-900/90 border-cyan-500/50 shadow-md'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 opacity-70'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{t.icon}</span>
                        <div>
                          <h5 className="text-xs font-black text-white">{t.title}</h5>
                          <p className="text-[10px] text-slate-400 max-w-[270px] sm:max-w-xs">{t.desc}</p>
                        </div>
                      </div>

                      <div
                        className={`w-11 h-6 rounded-full transition-colors p-1 flex items-center shrink-0 ${
                          active ? 'bg-cyan-500 justify-end' : 'bg-slate-800 justify-start'
                        }`}
                      >
                        <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
