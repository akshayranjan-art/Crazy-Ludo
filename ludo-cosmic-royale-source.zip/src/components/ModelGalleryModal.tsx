import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Heart,
  Crown,
  Lock,
  Volume2,
  Check,
  Flame,
  Send,
  Zap,
  Edit3,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

export interface ModelProfile {
  id: string;
  name: string;
  title: string;
  style: string;
  chilliCost: number;
  image: string;
  quote: string;
  dialogue: string;
  dialogue2: string;
  unlocked: boolean;
  dailyUses: number; // Max 10 uses/day per character (Bible Item 17)
}

export const GLAMOUR_MODELS: ModelProfile[] = [
  {
    id: 'model-balqis',
    name: 'Princess Balqis',
    title: 'Royal Mughal Royalty',
    style: 'Velvet Embroidered Lehenga & Emeralds',
    chilliCost: 0, // Free starter
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    quote: 'Hum aate hain toh mausam badal jata hai...',
    dialogue: 'Wah bete, moj kar di! Pura board mera hai! 😂👑',
    dialogue2: 'Aapki goti ka intezaar mere darbaar me ho raha tha! 🏰💃',
    unlocked: true,
    dailyUses: 0,
  },
  {
    id: 'model-aanya',
    name: 'Aanya Sharma',
    title: 'Banarasi Silk Queen',
    style: 'Crimson Crimson Gold Zari Saree',
    chilliCost: 20,
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    quote: 'Sari dunya ek taraf, mera pallu ek taraf.',
    dialogue: 'Hotel ka bill kaun bharega? Obviously haarne wala! 💸🏨',
    dialogue2: 'Banaras ki meethai aur mera 6 ka roll, dono lajawab! 🍬🎲',
    unlocked: true,
    dailyUses: 0,
  },
  {
    id: 'model-zoya',
    name: 'Zoya Khan',
    title: 'Cyberpunk Diva',
    style: 'Neon Holographic Trenchcoat & Bindi',
    chilliCost: 50,
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
    quote: 'Pixels, power, and pure attitude.',
    dialogue: 'Arre bhai, tumhare dice ko bhi sharam aa gayi! 🎲🙈',
    dialogue2: 'System hack kar diya, ab har roll mera 6 aayega! 💻⚡',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-meera',
    name: 'Meera Rajput',
    title: 'Rajasthani Royal Heritage',
    style: 'Kundan Choker & Saffron Poshaak',
    chilliCost: 80,
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&auto=format&fit=crop&q=80',
    quote: 'Hukum ka ikka hamesha mere paas rehta hai.',
    dialogue: 'Tokens bachalo apne, Meera aa chuki hai! ⚔️👸',
    dialogue2: 'Padharo mhare board par, haraane ka maza aayega! 🏰✨',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-tara',
    name: 'Tara D’Souza',
    title: 'Goan Coastal Siren',
    style: 'Boho Sunset Pearl Bikini & Shrug',
    chilliCost: 120,
    image: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&auto=format&fit=crop&q=80',
    quote: 'Warm breezes and killer dice rolls.',
    dialogue: 'Pani pilo bhai log, game bohot garam hone wala hai! 🌊🍹',
    dialogue2: 'Goa ke beaches jaisa cool mera attitude aur hot mera roll! 🏄‍♀️☀️',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-riya',
    name: 'Riya Sen',
    title: 'Kolkata Pujo Elegance',
    style: 'Lal-Paar White Silk Saree & Shakha Pola',
    chilliCost: 150,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
    quote: 'Dhaak beats when my token arrives.',
    dialogue: 'Kemon acho ludo master? Aaj harne ke liye taiyyar ho? 🥁✨',
    dialogue2: 'Roshogolla jaisa meetha mera swag, goti katne me teekha! 🍯🔥',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-natasha',
    name: 'Natasha Roman',
    title: 'Monaco High Roller',
    style: 'Black Velvet Slit Gown & Diamond Choker',
    chilliCost: 200,
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=400&auto=format&fit=crop&q=80',
    quote: 'Diamonds are forever, but my dice roll is lethal.',
    dialogue: 'Checkmate! Oh wait, wrong game... but you still lose! 💎🥂',
    dialogue2: 'Monaco casino me bhi itna thrill nahi jitna mere is turn me hai! 🎰👑',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-simran',
    name: 'Simran Kaur',
    title: 'Punjabi Patiala Grace',
    style: 'Phulkari Dupatta & Jhumkas',
    chilliCost: 250,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    quote: 'Chak de phatte, nap de killi!',
    dialogue: 'Balle balle! Token seedha ghar gaya! 🌾💃',
    dialogue2: 'Sherni di chal te Simran da dice, koi rokk nahi sakda! 🚜🔥',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-kiara',
    name: 'Kiara Varma',
    title: 'Temple Gold Devangana',
    style: 'Kanchipuram Temple Brocade & Kasu Mala',
    chilliCost: 350,
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    quote: 'Divine blessing with every single 6.',
    dialogue: 'Pranam dosto! Khushi se jeeto ya chup-chaap haar jao! 🪔🙏',
    dialogue2: 'Dev Mandir ki shanti aur mera pralay roll dono aamne-saamne! 🪷🕉️',
    unlocked: false,
    dailyUses: 0,
  },
  {
    id: 'model-maya',
    name: 'Maya Celestial',
    title: 'Cosmic Empress',
    style: 'Pure Starlight Gown & Diamond Crown',
    chilliCost: 500,
    image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
    quote: 'Ruling all 4 corners of the galaxy.',
    dialogue: '79 Billion Diamonds bhi kam hain mere aage! 🌌👑',
    dialogue2: 'Brahmaand ki rani aa gayi hai, board par jhuk jao! 🪐✨',
    unlocked: false,
    dailyUses: 0,
  },
];

interface ModelGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  userChillies: number;
  onSpendChillies: (amount: number) => void;
  onTriggerModelArrival: (model: ModelProfile) => void;
  isOwnerOrAdmin?: boolean;
}

export const ModelGalleryModal: React.FC<ModelGalleryModalProps> = ({
  isOpen,
  onClose,
  userChillies,
  onSpendChillies,
  onTriggerModelArrival,
  isOwnerOrAdmin = true,
}) => {
  const [models, setModels] = useState<ModelProfile[]>(GLAMOUR_MODELS);
  const [selectedModel, setSelectedModel] = useState<ModelProfile>(GLAMOUR_MODELS[0]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isEditingDialogue, setIsEditingDialogue] = useState(false);
  const [editLine1, setEditLine1] = useState(selectedModel.dialogue);
  const [editLine2, setEditLine2] = useState(selectedModel.dialogue2);

  if (!isOpen) return null;

  const handleUnlock = (m: ModelProfile) => {
    if (userChillies < m.chilliCost) {
      setToastMessage(`Need ${m.chilliCost - userChillies} more 🌶️ Red Chillies! Play Chilli Dot-Connect puzzle.`);
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }
    sound.playTrophy();
    confetti({ particleCount: 50, spread: 60 });
    onSpendChillies(m.chilliCost);
    setModels((prev) =>
      prev.map((item) => (item.id === m.id ? { ...item, unlocked: true } : item))
    );
    setSelectedModel((prev) => (prev.id === m.id ? { ...prev, unlocked: true } : prev));
  };

  const handleSaveDialogues = () => {
    sound.playClick();
    setModels((prev) =>
      prev.map((m) =>
        m.id === selectedModel.id ? { ...m, dialogue: editLine1, dialogue2: editLine2 } : m
      )
    );
    setSelectedModel((prev) => ({ ...prev, dialogue: editLine1, dialogue2: editLine2 }));
    setIsEditingDialogue(false);
    setToastMessage('Dialogues updated successfully by Admin!');
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleSendArrival = (m: ModelProfile) => {
    // Check 10 uses/day limit (Bible Item 17)
    if (!isOwnerOrAdmin && m.dailyUses >= 10) {
      setToastMessage('Daily limit reached (10/10 uses for this character). Resets tomorrow!');
      setTimeout(() => setToastMessage(null), 3500);
      return;
    }

    sound.playGrandVictory();
    // Increment daily usage
    setModels((prev) =>
      prev.map((item) => (item.id === m.id ? { ...item, dailyUses: item.dailyUses + 1 } : item))
    );
    onTriggerModelArrival(m);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl max-h-[92vh] flex flex-col glass-panel border-2 border-pink-500/40 rounded-3xl shadow-[0_0_50px_rgba(236,72,153,0.3)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-pink-500/20 bg-gradient-to-r from-pink-950/80 via-purple-950/80 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-pink-500/20 border border-pink-400 flex items-center justify-center text-xl shadow-[0_0_15px_#ec4899]">
              💃
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-pink-200 tracking-wide font-serif">
                  GLAMOUR CHARACTERS ATELIER
                </h2>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40">
                  Item 17
                </span>
              </div>
              <p className="text-[10px] text-slate-300">
                10–1,000 🌶️ Chilli Tiers · 5s Cinematic Reveal · 10s Funny Dialogue · Max 10 Uses/Day
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Chilli Balance Pill */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 shadow-inner">
              <span className="text-base">🌶️</span>
              <span className="text-xs font-black text-red-300 font-mono">{userChillies}</span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {toastMessage && (
          <div className="px-4 py-2 bg-amber-950/90 border-b border-amber-500/50 text-xs text-amber-200 font-bold flex items-center gap-2 animate-fade-in">
            <AlertCircle size={15} className="text-amber-400" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Selected Model Showcase */}
        <div className="p-4 bg-gradient-to-b from-purple-950/40 to-slate-950 border-b border-white/10 flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative w-28 h-36 rounded-2xl overflow-hidden border-2 border-pink-400 shadow-xl shrink-0">
            <img
              src={selectedModel.image}
              alt={selectedModel.name}
              className="w-full h-full object-cover"
            />
            {selectedModel.unlocked && (
              <span className="absolute top-1 right-1 px-1.5 py-0.5 rounded-md bg-emerald-500 text-[9px] font-black text-slate-950 flex items-center gap-0.5">
                <Check size={10} /> Active
              </span>
            )}
          </div>

          <div className="flex-1 space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-white font-serif">{selectedModel.name}</h3>
              <span className="text-[10px] text-pink-300 font-bold px-2 py-0.5 rounded-full bg-pink-500/10 border border-pink-500/30">
                {selectedModel.title}
              </span>
            </div>
            <p className="text-xs text-amber-300 font-semibold">{selectedModel.style}</p>
            <p className="text-[11px] text-slate-400 italic">"{selectedModel.quote}"</p>

            {/* Daily Uses Tracker (Bible Item 17) */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[10px] text-slate-300 font-bold">
                Daily Uses: <strong className="text-amber-300">{selectedModel.dailyUses}/10</strong>
              </span>
              {isOwnerOrAdmin && (
                <span className="text-[9px] text-emerald-400 font-black px-1.5 py-0.2 rounded bg-emerald-500/20 border border-emerald-500/40">
                  OWNER UNLIMITED PASS
                </span>
              )}
            </div>

            {/* Two Funny Lines & Admin Edit */}
            {!isEditingDialogue ? (
              <div className="mt-2 p-2 rounded-xl bg-black/60 border border-white/10 text-[11px] space-y-1">
                <p className="text-slate-200">
                  💬 <strong>Line 1:</strong> "{selectedModel.dialogue}"
                </p>
                <p className="text-slate-300">
                  💬 <strong>Line 2:</strong> "{selectedModel.dialogue2}"
                </p>
                <button
                  onClick={() => {
                    setEditLine1(selectedModel.dialogue);
                    setEditLine2(selectedModel.dialogue2);
                    setIsEditingDialogue(true);
                  }}
                  className="mt-1 text-[10px] text-pink-300 hover:text-pink-200 font-bold flex items-center gap-1"
                >
                  <Edit3 size={11} /> Admin Replace/Edit Dialogues
                </button>
              </div>
            ) : (
              <div className="mt-2 p-2 rounded-xl bg-black/80 border border-pink-500/50 space-y-2">
                <input
                  type="text"
                  value={editLine1}
                  onChange={(e) => setEditLine1(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                  placeholder="Funny Line 1"
                />
                <input
                  type="text"
                  value={editLine2}
                  onChange={(e) => setEditLine2(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white"
                  placeholder="Funny Line 2"
                />
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveDialogues}
                    className="px-3 py-1 bg-pink-500 text-slate-950 font-bold text-xs rounded"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setIsEditingDialogue(false)}
                    className="px-3 py-1 bg-slate-800 text-slate-300 font-bold text-xs rounded"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Action Button */}
            <div className="pt-2">
              {selectedModel.unlocked ? (
                <button
                  onClick={() => handleSendArrival(selectedModel)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-400 text-white font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition flex items-center gap-1.5"
                >
                  <Sparkles size={14} />
                  <span>Send Arrival onto Board (5s Reveal + 10s Meme)</span>
                </button>
              ) : (
                <button
                  onClick={() => handleUnlock(selectedModel)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-500 hover:from-red-500 text-white font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition flex items-center gap-1.5"
                >
                  <span>Unlock for {selectedModel.chilliCost} 🌶️ Chillies</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Models Grid */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            All Characters ({models.length})
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {models.map((m) => {
              const isSelected = selectedModel.id === m.id;
              return (
                <div
                  key={m.id}
                  onClick={() => {
                    sound.playClick();
                    setSelectedModel(m);
                  }}
                  className={`p-2.5 rounded-2xl border transition cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-pink-950/60 border-pink-400 shadow-md'
                      : m.unlocked
                      ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      : 'bg-slate-950/60 border-slate-900 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl overflow-hidden border border-white/10 shrink-0">
                      <img src={m.image} alt={m.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-black text-white truncate">{m.name}</p>
                      <p className="text-[10px] text-pink-300 truncate">{m.title}</p>
                    </div>
                  </div>

                  <div className="mt-2 pt-1 border-t border-white/5 flex items-center justify-between text-[10px]">
                    {m.unlocked ? (
                      <span className="text-emerald-400 font-bold">Unlocked</span>
                    ) : (
                      <span className="text-red-400 font-bold">{m.chilliCost} 🌶️</span>
                    )}
                    <span className="text-slate-400">{m.dailyUses}/10 uses</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
