import React from 'react';
import { X, BookOpen, ShieldCheck, Zap, Sparkles, ChevronRight, Crown } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface GameNiyamModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenButterflyModal: () => void;
  onOpenAstraModal: () => void;
}

export const GameNiyamModal: React.FC<GameNiyamModalProps> = ({
  isOpen,
  onClose,
  onOpenButterflyModal,
  onOpenAstraModal,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#140b25] via-[#0c0617] to-black text-slate-100 shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-purple-700/40 via-amber-700/30 to-slate-900 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-2xl shadow-lg border border-amber-300">
              📜
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-emerald-300">
                Ludo Royale Official Niyam
              </h3>
              <p className="text-xs text-slate-300">
                खेल के आधिकारिक नियम व निर्देश
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh] text-xs">
          {/* Rule 1 */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-amber-500/30 space-y-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-black">
              <Crown size={15} />
              <span>१. प्रारंभिक चाल (Starting Rule)</span>
            </div>
            <p className="text-slate-300">
              गोटी को घर से बाहर निकालने के लिए <strong>६ (Six)</strong> का पासा आना अनिवार्य है। ६ आने पर खिलाड़ी को एक अतिरिक्त पासा फेंकने का अवसर मिलता है।
            </p>
          </div>

          {/* Rule 2 */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-emerald-500/30 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-black">
              <ShieldCheck size={15} />
              <span>२. सुरक्षित स्थान (Safe Star Squares)</span>
            </div>
            <p className="text-slate-300">
              बोर्ड पर बने <strong>★ (स्टार)</strong> खाने सुरक्षित क्षेत्र हैं। यहाँ किसी भी खिलाड़ी की गोटी काटी नहीं जा सकती है।
            </p>
          </div>

          {/* Rule 3 */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-purple-500/30 space-y-1.5">
            <div className="flex items-center gap-2 text-purple-300 font-black">
              <Zap size={15} />
              <span>३. दिव्य अस्त्र (Divine Astras)</span>
            </div>
            <p className="text-slate-300">
              त्रिशूल, गदा और सुदर्शन चक्र जैसे अस्त्रों का उपयोग करके गेम में विशेष लाभ प्राप्त करें। अस्त्रों का कूलडाउन समाप्त होने पर इन्हें सक्रिय किया जा सकता है।
            </p>
          </div>

          {/* Navigation Action Buttons */}
          <div className="pt-2 grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                sound.playClick();
                onClose();
                onOpenAstraModal();
              }}
              className="py-2.5 rounded-xl bg-purple-600/40 hover:bg-purple-600/60 border border-purple-400/50 text-white font-bold flex items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <span>Explore Astras</span>
              <ChevronRight size={14} />
            </button>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
                onOpenButterflyModal();
              }}
              className="py-2.5 rounded-xl bg-emerald-600/40 hover:bg-emerald-600/60 border border-emerald-400/50 text-white font-bold flex items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <span>Butterflies</span>
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
