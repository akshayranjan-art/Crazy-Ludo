import React from 'react';
import { X, Heart, Sparkles, Users, Crown, Gift } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface CoupleSocialModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onAddHearts: (hearts: number) => void;
}

export const CoupleSocialModal: React.FC<CoupleSocialModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onAddHearts,
}) => {
  if (!isOpen) return null;

  const handleSendHeart = (amount: number) => {
    sound.playGrandVictory();
    confetti({ particleCount: 50, spread: 60 });
    onAddHearts(amount);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-rose-500/50 rounded-3xl bg-gradient-to-b from-[#220714] via-[#12050e] to-black text-slate-100 shadow-[0_0_50px_rgba(244,63,94,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-rose-700/40 via-pink-700/30 to-slate-900 border-b border-rose-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-2xl shadow-lg border border-rose-400">
              💖
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-rose-300 via-pink-200 to-amber-300">
                Couple & Social Sanctuary
              </h3>
              <p className="text-xs text-slate-300">
                Double hearts, CP rings, partner bonds & birthday gifts
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-300">Bond Level: Soulmates (LV. 8)</span>
              <span className="text-xs text-amber-300 font-bold">❤️ 2,450 Hearts</span>
            </div>
            <p className="text-xs text-slate-300">
              Send couple hearts and celebrate milestones with your special partner in game rooms!
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => handleSendHeart(10)}
                className="py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-400 text-white font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Heart size={14} fill="currentColor" />
                <span>+10 Double Hearts</span>
              </button>
              <button
                onClick={() => handleSendHeart(50)}
                className="py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-amber-500 hover:from-pink-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Gift size={14} />
                <span>+50 Birthday Hearts</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
