import React, { useState } from 'react';
import { LUXURY_GIFTS } from '../data/gameConstants';
import { GiftItem, Seat } from '../types/game';
import { X, Gift, Sparkles, Send, Check } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface GiftStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  seats: Seat[];
  targetSeat: Seat | null;
  userDiamonds: number;
  userCoins: number;
  onSendGift: (gift: GiftItem, recipient: Seat, quantity: number) => void;
}

export const GiftStoreModal: React.FC<GiftStoreModalProps> = ({
  isOpen,
  onClose,
  seats,
  targetSeat,
  userDiamonds,
  userCoins,
  onSendGift,
}) => {
  const [selectedRecipientId, setSelectedRecipientId] = useState<number>(targetSeat?.id || seats[0]?.id || 1);
  const [selectedGift, setSelectedGift] = useState<GiftItem>(LUXURY_GIFTS[0]);
  const [quantity, setQuantity] = useState<number>(1);
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'popular' | 'supercar' | 'luxury'>('all');

  if (!isOpen) return null;

  const currentRecipient = seats.find((s) => s.id === selectedRecipientId) || seats[0];
  const totalCost = selectedGift.cost * quantity;
  const hasEnoughFunds = selectedGift.currency === 'diamonds' ? userDiamonds >= totalCost : userCoins >= totalCost;

  const filteredGifts = LUXURY_GIFTS.filter((g) => {
    if (categoryFilter === 'popular') return g.rarity === 'Popular' || g.rarity === 'Common';
    if (categoryFilter === 'supercar') return g.rarity === 'Mega Supercar';
    if (categoryFilter === 'luxury') return g.rarity === 'Luxury' || g.rarity === 'Divine Supreme';
    return true;
  });

  const handleSend = () => {
    if (!hasEnoughFunds || !currentRecipient) return;
    sound.playGiftFanfare();
    onSendGift(selectedGift, currentRecipient, quantity);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-950 border-2 border-pink-500/50 rounded-3xl shadow-[0_0_60px_rgba(244,63,94,0.25)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-pink-500/20 bg-gradient-to-r from-pink-950/70 via-slate-900 to-purple-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-500/20 border border-pink-400 flex items-center justify-center text-xl shadow-[0_0_15px_#f43f5e]">
              🎁
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-pink-200 tracking-wide font-cinzel">
                  3D LIVE ROOM GIFT STORE
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 font-bold border border-pink-500/40">
                  INTERACTIVE BROADCAST
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Send interactive gifts with screen-wide effects and chat fanfare
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 text-xs font-mono font-bold">
              <span className="text-cyan-300">💎 {userDiamonds.toLocaleString()}</span>
              <span className="text-amber-300">🪙 {userCoins.toLocaleString()}</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Recipient Picker Banner */}
        <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between overflow-x-auto gap-2">
          <span className="text-xs text-slate-400 whitespace-nowrap font-medium">Send to Seat:</span>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {seats.map((seat) => {
              const isSelected = seat.id === selectedRecipientId;
              return (
                <button
                  key={seat.id}
                  onClick={() => setSelectedRecipientId(seat.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
                    isSelected
                      ? 'bg-pink-600 text-white border-pink-400 shadow-[0_0_10px_rgba(244,63,94,0.6)]'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <img src={seat.avatar} alt={seat.playerName} className="w-4 h-4 rounded-full" />
                  <span>#{seat.id} {seat.playerName}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="px-4 pt-3 flex gap-2">
          {[
            { id: 'all', label: 'All Gifts (28+)' },
            { id: 'popular', label: 'Popular & Rings' },
            { id: 'supercar', label: 'Supercars & Fleet' },
            { id: 'luxury', label: 'Ultra Luxury & Divine' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCategoryFilter(tab.id as typeof categoryFilter)}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                categoryFilter === tab.id
                  ? 'bg-pink-500/20 text-pink-300 border border-pink-500/50'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Gift Grid */}
        <div className="flex-1 overflow-y-auto p-4 grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
          {filteredGifts.map((gift) => {
            const isSelected = selectedGift.id === gift.id;
            return (
              <div
                key={gift.id}
                onClick={() => {
                  setSelectedGift(gift);
                  sound.playTokenHop(2);
                }}
                className={`relative rounded-2xl p-2.5 flex flex-col items-center text-center cursor-pointer border transition-all ${
                  isSelected
                    ? 'bg-gradient-to-b from-pink-950/80 to-slate-900 border-pink-400 shadow-[0_0_20px_rgba(244,63,94,0.4)] scale-105'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="text-3xl mb-1.5 filter drop-shadow-md">
                  {gift.icon}
                </div>
                <span className="text-[11px] font-bold text-slate-100 truncate w-full">
                  {gift.name}
                </span>
                <span className="text-[9px] text-pink-400/90 font-medium">
                  {gift.hindiName}
                </span>

                <div className="mt-1 flex items-center gap-1 font-mono text-[11px] font-bold text-amber-300">
                  <span>{gift.currency === 'diamonds' ? '💎' : '🪙'}</span>
                  <span>{gift.cost.toLocaleString()}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer / Send Action Bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
          {/* Selected Gift Summary */}
          <div className="flex items-center gap-3">
            <span className="text-2xl">{selectedGift.icon}</span>
            <div>
              <p className="text-xs font-bold text-slate-100">
                {selectedGift.name} <span className="text-pink-400">({selectedGift.hindiName})</span>
              </p>
              <p className="text-[10px] text-slate-400">
                Recipient: <span className="text-amber-300 font-semibold">{currentRecipient?.playerName}</span>
              </p>
            </div>
          </div>

          {/* Quantity multipliers */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
            {[1, 10, 66, 188, 1314].map((q) => (
              <button
                key={q}
                onClick={() => setQuantity(q)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                  quantity === q ? 'bg-pink-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                x{q}
              </button>
            ))}
          </div>

          {/* Send Button */}
          <button
            onClick={handleSend}
            disabled={!hasEnoughFunds}
            className={`px-6 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all active:scale-95 ${
              hasEnoughFunds
                ? 'bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 text-white hover:brightness-110 shadow-pink-500/25'
                : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>Send ({selectedGift.currency === 'diamonds' ? '💎' : '🪙'} {totalCost.toLocaleString()})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
