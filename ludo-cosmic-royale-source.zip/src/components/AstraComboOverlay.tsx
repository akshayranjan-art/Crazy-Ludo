import React, { useEffect } from 'react';
import { Sparkles, Zap, Flame, Crown, X } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface AstraComboOverlayProps {
  comboName: string;
  comboCount: number;
  comboDescription: string;
  petReactionEmoji?: string;
  onFinish: () => void;
}

export const AstraComboOverlay: React.FC<AstraComboOverlayProps> = ({
  comboName,
  comboCount,
  comboDescription,
  petReactionEmoji = '🐉',
  onFinish,
}) => {
  useEffect(() => {
    sound.playGrandVictory();
    confetti({ particleCount: 80, spread: 70 });

    const timer = setTimeout(() => {
      onFinish();
    }, 4500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      {/* Top Right Close Button */}
      <button
        onClick={() => {
          sound.playClick();
          onFinish();
        }}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 z-50 p-2.5 rounded-full bg-slate-900/90 hover:bg-red-950/90 border-2 border-amber-400 hover:border-red-400 text-amber-300 hover:text-white transition shadow-lg active:scale-95 flex items-center gap-1 cursor-pointer"
        title="Close Astra Combo Screen"
        aria-label="Close Screen"
      >
        <span className="text-[11px] font-black uppercase tracking-wider hidden sm:inline">Close</span>
        <X size={18} />
      </button>

      <div className="relative flex flex-col items-center text-center max-w-sm w-full p-6 rounded-3xl bg-gradient-to-b from-[#2a0e4a]/95 via-[#18082e]/95 to-black/95 border-3 border-amber-400 shadow-[0_0_60px_rgba(245,158,11,0.6)] animate-bounce">
        {/* Glow ambient halo */}
        <div className="absolute -inset-2 bg-gradient-to-r from-amber-500/30 via-purple-600/30 to-rose-500/30 rounded-3xl blur-xl" />

        {/* Combo Counter Badge */}
        <div className="relative z-10 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg flex items-center gap-1.5 -mt-8 mb-2">
          <Crown size={16} />
          <span>COMBO x{comboCount} TRIGGERED!</span>
        </div>

        {/* In-Card Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onFinish();
          }}
          className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-slate-800/80 hover:bg-red-900/80 text-slate-300 hover:text-white transition cursor-pointer"
          title="Dismiss Combo"
        >
          <X size={16} />
        </button>

        <h3 className="relative z-10 text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-100 to-amber-400 font-cinzel">
          {comboName}
        </h3>

        <p className="relative z-10 text-xs font-semibold text-slate-200 mt-2 px-2">
          {comboDescription}
        </p>

        {/* Pet Reaction Animation */}
        <div className="relative z-10 mt-4 flex items-center justify-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border-2 border-amber-400 flex items-center justify-center text-3xl shadow-inner animate-pulse">
            {petReactionEmoji}
          </div>
          <div className="text-left text-[11px] text-amber-300 font-bold bg-black/60 px-3 py-1.5 rounded-xl border border-white/10">
            <p>🐾 Pet is Cheering!</p>
            <p className="text-slate-400 font-normal">Cosmetic reaction sequence</p>
          </div>
        </div>

        <span className="relative z-10 text-[10px] text-slate-400 mt-3 uppercase tracking-widest font-black">
          Zero Gameplay Damage · Pure Spectacle
        </span>
      </div>
    </div>
  );
};
