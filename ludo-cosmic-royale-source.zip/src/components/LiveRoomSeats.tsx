import React from 'react';
import { Seat } from '../types/game';
import { Mic, MicOff, Flame, Gift, Sparkles } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { RARE_PETS } from '../data/gameConstants';

interface LiveRoomSeatsProps {
  seats: Seat[];
  currentUserId: number;
  onSeatClick: (seat: Seat) => void;
  onSendGiftClick: (seat: Seat) => void;
  onToggleMic: (seatId: number) => void;
  onOpenBalloons?: (seat: Seat) => void;
}

export const LiveRoomSeats: React.FC<LiveRoomSeatsProps> = ({
  seats,
  currentUserId,
  onSeatClick,
  onSendGiftClick,
  onToggleMic,
  onOpenBalloons,
}) => {
  return (
    <div className="w-full glass-panel rounded-3xl border border-amber-500/20 p-3 sm:p-4 shadow-2xl">
      {/* Live Room Header Bar */}
      <div className="flex items-center justify-between pb-2 mb-3 border-b border-white/10 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping inline-block" />
            LIVE STAGE · 8 SEATS
          </div>
          <span className="text-slate-400 hidden sm:inline">4.8K Watching</span>
        </div>

        <div className="flex items-center gap-3 text-slate-300">
          <div className="flex items-center gap-1 text-amber-400 font-semibold">
            <Flame className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
            <span className="hidden sm:inline">Hot Seat Arena</span>
          </div>
          <span className="text-[11px] text-emerald-400 font-bold">● High Fidelity Audio</span>
        </div>
      </div>

      {/* 8 Seat Grid */}
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 sm:gap-3">
        {seats.map((seat, index) => {
          const isCurrentUser = seat.id === currentUserId;
          const frameClass = `frame-${seat.frameStyle}`;

          // One small pet per seated player (Bible Item 12)
          const assignedPet = RARE_PETS[index % RARE_PETS.length];
          const petBehavior = seat.petBehavior || (index % 4 === 0 ? 'celebrate' : index % 3 === 0 ? 'walk' : 'sit');

          return (
            <div
              key={seat.id}
              className="relative flex flex-col items-center group cursor-pointer"
              onClick={() => onSeatClick(seat)}
            >
              {/* Seat Avatar Container with Frame */}
              <div className="relative w-14 h-14 sm:w-16 sm:h-16 flex items-center justify-center p-1">
                {/* Visual Animated Frame applied directly */}
                <div
                  className={`w-full h-full rounded-full overflow-hidden bg-slate-900 ${frameClass} transition-transform group-hover:scale-105`}
                >
                  <img
                    src={seat.avatar}
                    alt={seat.playerName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Hot Seat Badge */}
                {seat.isHotSeat && (
                  <div className="absolute -top-1 -left-1 z-20 px-1.5 py-0.2 bg-gradient-to-r from-amber-500 to-rose-600 rounded-full text-[8px] font-black text-white shadow-md flex items-center gap-0.5">
                    <Sparkles className="w-2 h-2" />
                    <span>#1</span>
                  </div>
                )}

                {/* Seated Small Companion Pet (Bible Item 12: One pet per seated player) */}
                <div
                  className="absolute -bottom-1 -left-1 z-20 px-1 py-0.2 rounded-full bg-slate-950/90 border border-emerald-400 text-[10px] shadow-md flex items-center gap-0.5 hover:scale-125 transition cursor-help"
                  title={`${assignedPet.name} (${assignedPet.rarity}) · State: ${petBehavior}`}
                >
                  <span>{assignedPet.icon || '🐉'}</span>
                  <span className="text-[7px] text-emerald-300 font-bold uppercase">
                    {petBehavior === 'celebrate' ? '🎉' : petBehavior === 'sleep' ? '💤' : petBehavior === 'walk' ? '🐾' : '🧘'}
                  </span>
                </div>

                {/* Mic Status Icon */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isCurrentUser) {
                      onToggleMic(seat.id);
                    } else {
                      sound.playMicBeep(false);
                    }
                  }}
                  className={`absolute -bottom-1 -right-1 z-20 w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px] shadow-md transition-all ${
                    seat.isMuted
                      ? 'bg-slate-700 border border-slate-500'
                      : 'bg-emerald-500 border border-emerald-300 animate-pulse'
                  }`}
                  title={isCurrentUser ? 'Click to Toggle Mic' : 'Seat Mic'}
                >
                  {seat.isMuted ? (
                    <MicOff className="w-2.5 h-2.5 text-slate-300" />
                  ) : (
                    <Mic className="w-2.5 h-2.5 text-white" />
                  )}
                </button>

                {/* Speaking Wave Equalizer Overlay */}
                {seat.isSpeaking && (
                  <div className="absolute -top-2 right-1 z-20 flex gap-0.5 items-end h-3">
                    <div className="w-0.5 h-2 bg-emerald-400 rounded-full voice-wave-bar" />
                    <div className="w-0.5 h-3.5 bg-emerald-400 rounded-full voice-wave-bar" />
                    <div className="w-0.5 h-2 bg-emerald-400 rounded-full voice-wave-bar" />
                  </div>
                )}
              </div>

              {/* Player Name & Tag */}
              <div className="mt-1.5 text-center w-full px-0.5">
                <p className="text-[11px] font-bold text-slate-200 truncate max-w-[75px]">
                  {seat.playerName}
                </p>
                <div className="text-[9px] text-amber-400/90 font-medium truncate max-w-[75px]">
                  {seat.title}
                </div>
              </div>

              {/* Action Buttons: Gift & Balloon Splash (2💎) */}
              <div className="flex items-center gap-1 mt-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onSendGiftClick(seat);
                  }}
                  className="px-1.5 py-0.5 rounded-full bg-white/5 hover:bg-amber-500/20 text-slate-300 hover:text-amber-300 text-[9px] flex items-center gap-0.5 font-semibold transition border border-white/5 hover:border-amber-500/30 active:scale-95"
                  title={`Send Gift to ${seat.playerName}`}
                >
                  <Gift className="w-2.5 h-2.5 text-amber-400" />
                  <span>Gift</span>
                </button>

                {onOpenBalloons && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenBalloons(seat);
                    }}
                    className="px-1.5 py-0.5 rounded-full bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-[9px] flex items-center gap-0.5 font-semibold transition border border-rose-500/20 active:scale-95"
                    title={`Throw Balloon/Mud/Pichkari at ${seat.playerName} (2 💎)`}
                  >
                    <span>🎈</span>
                    <span>2💎</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

