import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      errorMessage: error?.message || 'Unknown runtime error',
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Ludo Royale uncaught runtime error:', error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#070510] text-slate-100 flex flex-col items-center justify-center p-6 text-center select-none">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-3xl shadow-[0_0_30px_rgba(245,158,11,0.3)] mb-4">
            🎲
          </div>
          <h1 className="text-2xl font-black text-amber-300 mb-2">
            Ludo Cosmic Royale 3D
          </h1>
          <p className="text-sm text-slate-300 max-w-sm mb-6 leading-relaxed">
            The game encountered a momentary pause. Tap below to reload the cosmic arena.
          </p>
          <button
            onClick={this.handleReload}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-sm uppercase tracking-wider shadow-lg active:scale-95 transition cursor-pointer"
          >
            Reload Game 🔄
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
