import React, { useState, useEffect } from 'react';
import { Sparkles, Shield, User, X } from 'lucide-react';
import { MiracleArrivalVariant } from '../types/game';

interface MiracleArrivalOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  senderName: string;
  targetName: string;
  targetAvatar: string;
  dialogue?: string;
  tinyName?: string;
  tinyIcon?: string;
  variant?: MiracleArrivalVariant;
  privacyMode?: 'avatar-only' | 'approved-photo' | 'private';
}

const FUNNY_DIALOGUES = [
  'Wah bete, moj kar di! 😂',
  'Hotel ka bill kaun bharega? 🏨💸',
  'Aaj toh pura board mera hai! 👑',
  'Arre bhai, dice ko bhi sharam aa gayi! 🎲🙈',
  'Bhai, thodi practice karke aana tha! 🤣',
  'Itna serious kyun ho? Relax karo! 🌸',
];

export const MiracleArrivalOverlay: React.FC<MiracleArrivalOverlayProps> = ({
  isOpen,
  onClose,
  senderName,
  targetName,
  targetAvatar,
  dialogue,
  tinyName = 'Bal Gopal',
  tinyIcon = '🪈',
  variant = 'royal-curtain',
  privacyMode = 'avatar-only',
}) => {
  // Silent: Bible rule specifies Miracle Arrival has NO sound.
  // Timing: 5 seconds photo/curtain reveal, 10 seconds dialogue.
  const [stage, setStage] = useState<'sprinting' | 'curtain-opening' | 'reveal' | 'finished'>('sprinting');
  const [selectedDialogue, setSelectedDialogue] = useState(
    dialogue || FUNNY_DIALOGUES[Math.floor(Math.random() * FUNNY_DIALOGUES.length)]
  );
  const [countdown, setCountdown] = useState(10);

  useEffect(() => {
    if (!isOpen) {
      setStage('sprinting');
      setCountdown(10);
      return;
    }

    // Stage 1: Sprint across board to target seat (2 seconds)
    const sprintTimer = setTimeout(() => {
      setStage('reveal');
    }, 2000);

    // 10-second countdown for dialogue
    const interval = setInterval(() => {
      setCountdown((c) => Math.max(0, c - 1));
    }, 1000);

    // Stage 2: Closes theatre curtain and tiny disappears after 10s
    const closeTimer = setTimeout(() => {
      setStage('finished');
      setTimeout(onClose, 600);
    }, 10500);

    return () => {
      clearTimeout(sprintTimer);
      clearTimeout(closeTimer);
      clearInterval(interval);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Dim ambient theater lighting */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-xs transition-opacity duration-700" />

      {/* Top Right Close Button */}
      <button
        onClick={onClose}
        className="pointer-events-auto absolute top-4 right-4 sm:top-6 sm:right-6 z-50 p-2.5 rounded-full bg-slate-900/90 hover:bg-red-950/90 border-2 border-amber-400 hover:border-red-400 text-amber-300 hover:text-white transition shadow-lg active:scale-95 flex items-center gap-1 cursor-pointer"
        title="Close Miracle Arrival"
        aria-label="Close Screen"
      >
        <span className="text-[11px] font-black uppercase tracking-wider hidden sm:inline">Close</span>
        <X size={18} />
      </button>

      {/* Silent Indicator Badge */}
      <div className="absolute top-14 px-3 py-1 rounded-full bg-slate-900/90 border border-amber-400/50 text-[10px] text-amber-300 font-bold shadow-md flex items-center gap-1 z-30 pointer-events-none">
        <span>🤫</span>
        <span>Silent Miracle Arrival (Item 20 · Theatre Reveal)</span>
        <span className="text-slate-400">· {countdown}s</span>
      </div>

      {/* 1. SPRINTING TINY CHARACTER STAGE */}
      {stage === 'sprinting' && (
        <div className="absolute z-20 flex flex-col items-center animate-[bounce_0.35s_infinite] transition-all duration-[2000ms] ease-out left-10 transform translate-x-[40vw]">
          <div className="relative">
            <div className="text-5xl filter drop-shadow-[0_0_15px_rgba(255,215,0,0.9)] animate-pulse">
              {tinyIcon}
            </div>
            <span className="absolute -top-1 -right-1 text-xs">✨</span>
          </div>
          <span className="mt-1 px-2.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black tracking-wider uppercase shadow-md">
            {tinyName} Sprinting ({variant})
          </span>
        </div>
      )}

      {/* 2. THEATRE CURTAIN REVEAL STAGE */}
      {stage === 'reveal' && (
        <div className="relative z-30 pointer-events-auto flex flex-col items-center max-w-xs w-full animate-fade-in">
          {/* Header pill */}
          <div className="mb-2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-800 to-amber-600 border border-amber-300 text-center shadow-lg flex items-center gap-1.5">
            <span className="text-sm">{tinyIcon}</span>
            <span className="text-[10px] font-black text-amber-200 uppercase tracking-widest font-cinzel">
              {variant.replace('-', ' ')}
            </span>
          </div>

          {/* Mini Theatre Velvet Stage */}
          <div className="relative w-48 h-52 rounded-3xl overflow-hidden border-3 border-amber-400 bg-gradient-to-b from-[#250d3a] via-[#120722] to-slate-950 p-3 shadow-[0_0_40px_rgba(245,158,11,0.6)] flex flex-col items-center justify-center">
            {/* Golden spotlight beam from above */}
            <div className="absolute -top-10 w-32 h-44 bg-gradient-to-b from-amber-300/35 via-yellow-200/15 to-transparent blur-md pointer-events-none" />

            {/* Target Avatar / Approved Portrait (5s Reveal) */}
            <div className="relative z-10 w-24 h-24 rounded-full overflow-hidden border-3 border-amber-300 shadow-2xl bg-slate-900 animate-pulse flex items-center justify-center">
              {privacyMode === 'private' ? (
                <div className="w-full h-full bg-gradient-to-br from-amber-900 to-slate-950 flex flex-col items-center justify-center text-amber-300">
                  <span className="text-3xl">🎭</span>
                  <span className="text-[8px] font-black uppercase tracking-wider mt-1">Veiled</span>
                </div>
              ) : (
                <img
                  src={targetAvatar}
                  alt={targetName}
                  className="w-full h-full object-cover"
                />
              )}
            </div>

            <p className="relative z-10 text-xs font-black text-amber-300 mt-2 truncate max-w-[140px]">
              {targetName}
            </p>
            <p className="relative z-10 text-[9px] text-purple-200 font-semibold">
              Presented by {senderName}
            </p>

            {/* Red Velvet Theatrical Pelmets & Curtains */}
            <div className="absolute top-0 left-0 bottom-0 w-5 bg-gradient-to-r from-red-800 to-red-950 border-r-2 border-amber-400/80 shadow-md" />
            <div className="absolute top-0 right-0 bottom-0 w-5 bg-gradient-to-l from-red-800 to-red-950 border-l-2 border-amber-400/80 shadow-md" />
            <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-b from-amber-500 to-amber-700 border-b border-amber-300 shadow-sm" />
          </div>

          {/* 10-Second Funny Meme Dialogue Speech Bubble */}
          <div className="mt-3 relative w-full p-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-300 text-slate-950 font-black text-center shadow-2xl border-2 border-white animate-bounce">
            <p className="text-xs leading-snug tracking-wide">
              "{selectedDialogue}"
            </p>
            {/* Bubble arrow pointing upwards */}
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[8px] border-b-amber-400" />
          </div>

          {/* Tiny Character Standing Proud */}
          <div className="mt-2 flex items-center gap-1.5 text-xs text-amber-300 font-bold bg-black/60 px-3 py-1 rounded-full border border-white/10">
            <span>{tinyIcon}</span>
            <span>{tinyName} departs as curtain closes...</span>
          </div>
        </div>
      )}
    </div>
  );
};
