import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  Coins,
  Sparkles,
  Terminal,
  Award,
  Crown,
  KeyRound,
  Calendar,
  Gift,
  Lock,
  Eye,
  Ghost,
  Trophy,
  Users,
  CheckSquare,
  Square,
  Tag,
  AlertTriangle,
  Flame,
  Globe,
  Settings,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { authService, PlayerUser, OWNER_USER } from '../utils/authService';
import confetti from 'canvas-confetti';

interface AdminCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDiamonds: (amount: number) => void;
  onAddCoins: (amount: number) => void;
  onSetForcedDice: (val: number | null) => void;
  forcedDiceVal: number | null;
  onTriggerEntryTest: (type: 'hypercar' | 'sudarshan' | 'gada' | 'trishul' | 'signature-photo' | 'cyber-dragon') => void;
  boardTheme: string;
  onChangeBoardTheme: (theme: any) => void;
  botSpeed: 'fast' | 'normal' | 'slow';
  onChangeBotSpeed: (speed: 'fast' | 'normal' | 'slow') => void;
  isGhostMode?: boolean;
  onToggleGhostMode?: () => void;
  onTriggerMiracleArrival?: () => void;
  onTriggerTakshakNag?: () => void;
  onTriggerVictoryTest?: () => void;
}

type AdminTab =
  | 'overview'
  | 'users-auth'
  | 'weekly-ops'
  | 'promo-codes'
  | 'event-engine'
  | 'safety-moderation'
  | 'idea-families'
  | 'year-end-awards'
  | 'production-checklist';

interface PromoCode {
  code: string;
  rewardDiamonds: number;
  rewardCoins: number;
  rewardItem?: string;
  isActive: boolean;
  usedCount: number;
}

interface EventEngineRule {
  id: string;
  name: string;
  targetGame: string;
  reward: string;
  amount: number;
  eligibleGroup: string;
  startDate: string;
  endDate: string;
  usageLimit: number;
  enabled: boolean;
}

export const AdminCenterModal: React.FC<AdminCenterModalProps> = ({
  isOpen,
  onClose,
  onAddDiamonds,
  onAddCoins,
  onSetForcedDice,
  forcedDiceVal,
  onTriggerEntryTest,
  boardTheme,
  onChangeBoardTheme,
  botSpeed,
  onChangeBotSpeed,
  isGhostMode = false,
  onToggleGhostMode,
  onTriggerMiracleArrival,
  onTriggerTakshakNag,
  onTriggerVictoryTest,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Audit Logs (Bible Item 26)
  const [adminLog, setAdminLog] = useState<string[]>([
    'System init: Authenticated as Sovereign Owner (ID 777777 - akvikings05@gmail.com).',
    'RBAC enforcement active: Privileged moderation logging enabled.',
    'Astra Universe rules loaded: Sudarshan 79.9B, Gada 59.9M, Trishul 19.9M.',
  ]);

  // Weekly Operation Checkboxes (Bible Item 26)
  const [weeklyOps, setWeeklyOps] = useState<Record<string, boolean>>({
    users: true,
    rewards: true,
    diamonds: true,
    stars: true,
    gifts: true,
    collections: true,
    astra: true,
    pets: true,
    minigames: true,
    messages: true,
    prices: true,
    events: true,
    eligibility: true,
  });

  // Promo Codes (Bible Item 27)
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([
    { code: 'VIKING777', rewardDiamonds: 5000, rewardCoins: 1000000, rewardItem: 'Owner Blessing Badge', isActive: true, usedCount: 142 },
    { code: 'DIWALI2026', rewardDiamonds: 2500, rewardCoins: 500000, rewardItem: 'Golden Diya Frame', isActive: true, usedCount: 890 },
    { code: 'LUDOROYALE', rewardDiamonds: 1000, rewardCoins: 250000, rewardItem: 'Egg Hunter Tag', isActive: true, usedCount: 420 },
    { code: 'TAKSHAKNAG', rewardDiamonds: 3000, rewardCoins: 750000, rewardItem: 'Nag Cosmetic Trail', isActive: true, usedCount: 65 },
  ]);
  const [newPromoCode, setNewPromoCode] = useState('');
  const [newPromoDiamonds, setNewPromoDiamonds] = useState(1000);

  // Event Engine Rules (Bible Item 28)
  const [events, setEvents] = useState<EventEngineRule[]>([
    {
      id: 'ev-1',
      name: 'Sunday Grand Astra Tournament',
      targetGame: '3D Ludo Arena',
      reward: 'Diamonds & Apex Astra Shards',
      amount: 50000,
      eligibleGroup: 'Level 10+ Players',
      startDate: '2026-10-10',
      endDate: '2026-10-12',
      usageLimit: 3,
      enabled: true,
    },
    {
      id: 'ev-2',
      name: 'Weekly Egg Hatching Blitz',
      targetGame: 'Snake & Ladder & Hatchery',
      reward: 'Cosmic Butterfly Eggs',
      amount: 5,
      eligibleGroup: 'All Verified Users (100002+)',
      startDate: '2026-10-05',
      endDate: '2026-10-11',
      usageLimit: 10,
      enabled: true,
    },
    {
      id: 'ev-3',
      name: 'Chilli Dot-Connect Fashion Carnival',
      targetGame: 'Dot Connect (200 Lvls)',
      reward: 'Red Chillies 🌶️ x100',
      amount: 100,
      eligibleGroup: 'All Players',
      startDate: '2026-10-01',
      endDate: '2026-10-31',
      usageLimit: 20,
      enabled: true,
    },
  ]);

  // Safety & Moderation Settings (Bible Item 29)
  const [roomLockActive, setRoomLockActive] = useState(false);
  const [privateChatEnabled, setPrivateChatEnabled] = useState(true);
  const [brahmastraSafetyHoldLimit, setBrahmastraSafetyHoldLimit] = useState(10);
  const [privacyPolicyMode, setPrivacyPolicyMode] = useState<'avatar-only' | 'approved-photo' | 'private'>('avatar-only');

  // Pashupatastra Apex Admin Dynamic Config (Bible Item 18)
  const [pashupatastraBehavior, setPashupatastraBehavior] = useState('Cosmic Singularity Void & Galaxy Rings');

  // Year-End Award Categories (Bible Item 39)
  const [selectedAwardCategory, setSelectedAwardCategory] = useState<string>('Player of the Year');

  if (!isOpen) return null;

  const logAction = (msg: string) => {
    setAdminLog((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 15)]);
    sound.playSafeCell();
  };

  const handleToggleWeeklyOp = (key: string) => {
    setWeeklyOps((prev) => {
      const updated = { ...prev, [key]: !prev[key] };
      logAction(`Weekly Op checkbox toggled: ${key} = ${updated[key]}`);
      return updated;
    });
  };

  const handleAddPromoCode = () => {
    if (!newPromoCode.trim()) return;
    const clean = newPromoCode.trim().toUpperCase();
    setPromoCodes((prev) => [
      { code: clean, rewardDiamonds: newPromoDiamonds, rewardCoins: newPromoDiamonds * 50, isActive: true, usedCount: 0 },
      ...prev,
    ]);
    logAction(`Created new Promo Code: ${clean} (${newPromoDiamonds} 💎)`);
    setNewPromoCode('');
    sound.playGrandVictory();
  };

  const allRegisteredUsers = authService.getAllUsers();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[94vh] flex flex-col bg-slate-950 border-2 border-red-500/60 rounded-3xl shadow-[0_0_70px_rgba(239,68,68,0.35)] overflow-hidden">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between p-3 sm:p-4 border-b border-red-500/20 bg-gradient-to-r from-red-950/80 via-slate-900 to-amber-950/80 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/20 border border-red-400 flex items-center justify-center text-xl shadow-[0_0_15px_#ef4444]">
              🛡️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-red-200 tracking-wide font-cinzel">
                  SOVEREIGN COMMAND CENTER
                </h2>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 font-bold border border-red-500/40">
                  BIBLE 23–39
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Verified Owner: <strong className="text-amber-300">akvikings05@gmail.com (ID #777777)</strong> · User IDs from #100002+
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs (Points 26–39) */}
        <div className="flex items-center gap-1.5 px-3 py-2 border-b border-slate-800 overflow-x-auto bg-slate-900/60 scrollbar-none text-xs">
          {[
            { id: 'overview', label: '1. Overview & Economy', icon: '💎' },
            { id: 'users-auth', label: '2. User Accounts & IDs (26)', icon: '👥' },
            { id: 'weekly-ops', label: '3. Weekly Ops (26)', icon: '☑️' },
            { id: 'promo-codes', label: '4. Promo Codes (27)', icon: '🎟️' },
            { id: 'event-engine', label: '5. Event Engine (28)', icon: '⚡' },
            { id: 'safety-moderation', label: '6. Safety & RBAC (29)', icon: '🛡️' },
            { id: 'idea-families', label: '7. 7 Idea Families (32-38)', icon: '💡' },
            { id: 'year-end-awards', label: '8. Year-End Awards (39)', icon: '🏆' },
            { id: 'production-checklist', label: '9. Production & Build Order (40-43)', icon: '✨' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                setActiveTab(tab.id as AdminTab);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition border ${
                activeTab === tab.id
                  ? 'bg-red-500 text-white border-red-400 shadow-[0_0_12px_rgba(239,68,68,0.5)]'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4">
          {/* TAB 1: OVERVIEW & ECONOMY */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              {/* Sovereign Owner Credentials Box */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/60 to-slate-900 border-2 border-amber-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center text-2xl font-black shadow-[0_0_15px_#f59e0b]">
                    👑
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black text-amber-200 font-cinzel">
                        Sovereign Owner Identity
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black">
                        ID: #777777
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">
                      Verified Owner Email: <strong>akvikings05@gmail.com</strong>
                    </p>
                    <p className="text-[11px] text-amber-300/80">
                      Permanent Super Admin & Owner access with unrestricted controls.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onAddDiamonds(100000000000);
                      logAction('Granted +100 Billion Diamonds (Sudarshan Fund).');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 text-white font-black text-xs uppercase shadow-md transition active:scale-95"
                  >
                    +100B 💎 Diamonds
                  </button>
                  <button
                    onClick={() => {
                      onAddCoins(100000000);
                      logAction('Granted +100 Million Coins.');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase shadow-md transition active:scale-95"
                  >
                    +100M 🪙 Coins
                  </button>
                </div>
              </div>

              {/* Force Dice Section */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-bold text-emerald-300 font-cinzel">
                    <Zap className="w-4 h-4 text-emerald-400" />
                    <span>Force Dice Roll Value</span>
                  </div>
                  {forcedDiceVal && (
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-bold border border-emerald-500/40">
                      Fixed to {forcedDiceVal}
                    </span>
                  )}
                </div>
                <div className="flex gap-2 pt-1">
                  {[1, 2, 3, 4, 5, 6].map((num) => (
                    <button
                      key={num}
                      onClick={() => {
                        onSetForcedDice(forcedDiceVal === num ? null : num);
                        logAction(`Dice forced to: ${num}`);
                      }}
                      className={`w-9 h-9 rounded-xl font-black text-xs transition-all border ${
                        forcedDiceVal === num
                          ? 'bg-emerald-500 text-slate-950 border-emerald-300 shadow-[0_0_10px_#10b981]'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-emerald-500'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                  {forcedDiceVal && (
                    <button
                      onClick={() => {
                        onSetForcedDice(null);
                        logAction('Dice unforced (standard random)');
                      }}
                      className="px-3 py-1 rounded-xl bg-red-950 border border-red-500/40 text-red-300 text-xs font-bold"
                    >
                      Clear Force
                    </button>
                  )}
                </div>
              </div>

              {/* Signature Photo & Vehicles Test (Bible Item 21) */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/40 space-y-2">
                <h4 className="text-xs font-black text-amber-300 flex items-center gap-1.5 uppercase tracking-wider font-cinzel">
                  <span>⭐</span> Vehicle & Signature Photo Entries (Bible Item 21)
                </h4>
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => {
                      onTriggerEntryTest('signature-photo');
                      logAction('Simulated 5,000 Star Signature Photo Cinematic Lobby Entry.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
                  >
                    ⭐ 5,000 Star Signature Photo Entry
                  </button>
                  <button
                    onClick={() => {
                      onTriggerEntryTest('cyber-dragon');
                      logAction('Simulated Cyber-Dragon Celestial Arrival.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs uppercase shadow-md active:scale-95 transition"
                  >
                    🐉 Cyber-Dragon Entry
                  </button>
                  <button
                    onClick={() => {
                      onTriggerEntryTest('hypercar');
                      logAction('Simulated Bugatti Hypercar VIP Arrival.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/40 font-black text-xs uppercase shadow-md active:scale-95 transition"
                  >
                    🏎️ Hypercar
                  </button>
                  <button
                    onClick={() => {
                      onTriggerEntryTest('sudarshan');
                      logAction('Simulated 79 Billion 💎 Sudarshan Entry.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 font-black text-xs uppercase shadow-md active:scale-95 transition"
                  >
                    ☀️ Sudarshan 79B
                  </button>
                  <button
                    onClick={() => {
                      onTriggerEntryTest('gada');
                      logAction('Simulated 59 Million 💎 Gada Entry.');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-500/40 font-black text-xs uppercase shadow-md active:scale-95 transition"
                  >
                    🚩 Hanuman Gada 59M
                  </button>
                  <button
                    onClick={() => {
                      if (onTriggerVictoryTest) {
                        onTriggerVictoryTest();
                        logAction('Triggered 3D Victory Ceremony: Tiered Podium, Fireworks & Spotlights.');
                        onClose();
                      }
                    }}
                    className="col-span-full px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase shadow-lg shadow-amber-500/20 active:scale-95 transition flex items-center justify-center gap-2"
                  >
                    🏆 Test 3D Victory Ceremony (Tiered Podium, Spotlights & Fireworks)
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: USER ACCOUNTS & IDS (BIBLE ITEM 26) */}
          {activeTab === 'users-auth' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-white font-cinzel">
                    User Accounts & Unique Sequential ID Registry
                  </h4>
                  <p className="text-xs text-slate-400">
                    Owner: #777777 (akvikings05@gmail.com) · All registered users start from #100002 sequentially.
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-amber-300 bg-amber-500/20 px-2.5 py-1 rounded-full border border-amber-400/40">
                  Total Users: {allRegisteredUsers.length}
                </span>
              </div>

              {/* Users Table */}
              <div className="rounded-2xl border border-slate-800 overflow-hidden bg-slate-900/60">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-700">
                    <tr>
                      <th className="p-3">Player ID</th>
                      <th className="p-3">User & Email</th>
                      <th className="p-3">Role</th>
                      <th className="p-3">Tag (Item 25)</th>
                      <th className="p-3">Diamonds</th>
                      <th className="p-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {allRegisteredUsers.map((u) => (
                      <tr key={u.id} className="hover:bg-white/5 transition">
                        <td className="p-3 font-mono font-bold text-amber-400">
                          #{u.id}
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <img src={u.avatar} alt={u.name} className="w-6 h-6 rounded-full object-cover" />
                            <div>
                              <p className="font-bold text-white">{u.name}</p>
                              <p className="text-[10px] text-slate-400">{u.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            u.role === 'owner'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-slate-800 text-slate-300'
                          }`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="p-3 text-cyan-300 font-bold">
                          {u.tag}
                        </td>
                        <td className="p-3 font-mono text-emerald-400">
                          💎 {u.diamonds.toLocaleString()}
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">
                            Active
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: WEEKLY OPS CHECKBOXES (BIBLE ITEM 26) */}
          {activeTab === 'weekly-ops' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="text-sm font-black text-white font-cinzel">
                  Weekly Operation Controls (Tick / Checkbox Style)
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Bible Item 26: Prior default configuration persists automatically if no new configuration is submitted.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.entries(weeklyOps).map(([key, enabled]) => (
                  <button
                    key={key}
                    onClick={() => handleToggleWeeklyOp(key)}
                    className={`p-3 rounded-2xl border transition flex items-center justify-between text-left ${
                      enabled
                        ? 'bg-slate-900/90 border-emerald-500/60 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                        : 'bg-slate-950 border-slate-800 opacity-60'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-black uppercase tracking-wider text-white">
                        {key} Module
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {enabled ? 'Active this cycle' : 'Paused / Frozen'}
                      </p>
                    </div>
                    {enabled ? (
                      <CheckSquare size={20} className="text-emerald-400" />
                    ) : (
                      <Square size={20} className="text-slate-600" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PROMO CODES ENGINE (BIBLE ITEM 27) */}
          {activeTab === 'promo-codes' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-black text-white font-cinzel">
                    Festival & Special Promo Codes Engine
                  </h4>
                  <p className="text-xs text-slate-400">
                    Bible Item 27: One-time per user, not reusable/hackable. Redemption enabled/disabled by admin.
                  </p>
                </div>
              </div>

              {/* Add New Promo Code Form */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/30 flex flex-wrap items-center gap-3">
                <input
                  type="text"
                  placeholder="NEW PROMO CODE (e.g. DIWALI777)"
                  value={newPromoCode}
                  onChange={(e) => setNewPromoCode(e.target.value)}
                  className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs font-mono font-bold uppercase focus:outline-hidden"
                />
                <input
                  type="number"
                  placeholder="Diamond Value"
                  value={newPromoDiamonds}
                  onChange={(e) => setNewPromoDiamonds(parseInt(e.target.value, 10) || 0)}
                  className="px-3 py-2 w-32 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono font-bold focus:outline-hidden"
                />
                <button
                  onClick={handleAddPromoCode}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
                >
                  Create Code
                </button>
              </div>

              {/* Codes List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {promoCodes.map((pc) => (
                  <div
                    key={pc.code}
                    className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-black text-amber-300">
                          {pc.code}
                        </span>
                        <span className={`text-[9px] px-2 py-0.2 rounded-full font-bold ${
                          pc.isActive ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
                        }`}>
                          {pc.isActive ? 'Active' : 'Disabled'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1">
                        💎 +{pc.rewardDiamonds.toLocaleString()} Diamonds · 🪙 +{pc.rewardCoins.toLocaleString()} Coins
                      </p>
                      <p className="text-[10px] text-slate-400">
                        Redemptions: {pc.usedCount} players
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setPromoCodes((prev) =>
                          prev.map((c) => (c.code === pc.code ? { ...c, isActive: !c.isActive } : c))
                        );
                        logAction(`Toggled Promo Code: ${pc.code}`);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                    >
                      {pc.isActive ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: EVENT ENGINE (BIBLE ITEM 28) */}
          {activeTab === 'event-engine' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="text-sm font-black text-white font-cinzel">
                  Event & Quest Engine (Dynamic Assignment)
                </h4>
                <p className="text-xs text-slate-400">
                  Bible Item 28: Admin can attach rewards/items to any game, activity, quest or date window.
                </p>
              </div>

              <div className="space-y-3">
                {events.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-sm font-black text-white">{ev.name}</h5>
                        <span className={`text-[10px] px-2 py-0.2 rounded-full font-bold ${
                          ev.enabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {ev.enabled ? 'Active Event' : 'Paused'}
                        </span>
                      </div>
                      <p className="text-xs text-amber-300 font-bold mt-1">
                        🎯 Game: {ev.targetGame} · Reward: {ev.reward} (x{ev.amount})
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Group: {ev.eligibleGroup} · Duration: {ev.startDate} to {ev.endDate} · Limit: {ev.usageLimit} uses
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setEvents((prev) =>
                          prev.map((e) => (e.id === ev.id ? { ...e, enabled: !e.enabled } : e))
                        );
                        logAction(`Event rule ${ev.name} toggled.`);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        ev.enabled ? 'bg-red-950 border border-red-500/40 text-red-300' : 'bg-emerald-600 text-white'
                      }`}
                    >
                      {ev.enabled ? 'Pause Event' : 'Activate Event'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: SAFETY & MODERATION (BIBLE ITEM 29) */}
          {activeTab === 'safety-moderation' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="text-sm font-black text-white font-cinzel">
                  Safety, RBAC & Moderation Systems
                </h4>
                <p className="text-xs text-slate-400">
                  Bible Item 29: Block/report tools, room locks, Brahmastra board safety limits (10 uses), and privacy modes.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Real Mode vs Ghost Mode */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white uppercase tracking-wider">
                      Admin Ghost Mode
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      isGhostMode ? 'bg-purple-500 text-white' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {isGhostMode ? 'Ghost Active' : 'Real Mode'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Inspect live audio rooms without disturbing players. Locked-room privileged access is audit-logged.
                  </p>
                  {onToggleGhostMode && (
                    <button
                      onClick={() => {
                        onToggleGhostMode();
                        logAction(`Admin mode toggled: ${!isGhostMode ? 'Ghost Mode' : 'Real Mode'}`);
                      }}
                      className="w-full py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition"
                    >
                      {isGhostMode ? 'Switch to Real Mode' : 'Enable Ghost Mode'}
                    </button>
                  )}
                </div>

                {/* Brahmastra Board Hold Limit */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white uppercase tracking-wider">
                      Brahmastra Safety Limit
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold border border-rose-500/40">
                      {brahmastraSafetyHoldLimit} Uses Max
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Non-permanent safety mechanic: stops player from joining a particular board for 10 uses, NOT a whole game ban.
                  </p>
                  <button
                    onClick={() => {
                      logAction('Verified Brahmastra safety limit rules: 10 uses hold active.');
                      sound.playSafeCell();
                    }}
                    className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
                  >
                    Verify Safety Constraints
                  </button>
                </div>

                {/* Privacy Modes */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-xs font-black text-white uppercase tracking-wider">
                    Privacy Policy Enforcement
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Approved avatar/photo only · Private mode suppresses public reveal.
                  </p>
                  <div className="flex gap-1.5 pt-1">
                    {(['avatar-only', 'approved-photo', 'private'] as const).map((m) => (
                      <button
                        key={m}
                        onClick={() => {
                          setPrivacyPolicyMode(m);
                          logAction(`Privacy policy set to: ${m}`);
                        }}
                        className={`flex-1 py-1.5 rounded-xl text-[10px] font-black uppercase transition ${
                          privacyPolicyMode === m
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {m.replace('-', ' ')}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dynamic Pashupatastra Config (Bible Item 18) */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                  <span className="text-xs font-black text-white uppercase tracking-wider">
                    Pashupatastra Apex Config (Item 18)
                  </span>
                  <p className="text-[11px] text-slate-400">
                    Rarest weapon behavior dynamically selected by admin.
                  </p>
                  <select
                    value={pashupatastraBehavior}
                    onChange={(e) => {
                      setPashupatastraBehavior(e.target.value);
                      logAction(`Pashupatastra behavior updated to: ${e.target.value}`);
                    }}
                    className="w-full p-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-bold"
                  >
                    <option value="Cosmic Singularity Void & Galaxy Rings">Cosmic Singularity Void & Galaxy Rings</option>
                    <option value="Primordial Time Freeze (Board Stillness)">Primordial Time Freeze (Board Stillness)</option>
                    <option value="Universal Starlight Rebirth">Universal Starlight Rebirth</option>
                    <option value="Destiny Void Cleansing">Destiny Void Cleansing</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: 7 IDEA FAMILIES (BIBLE ITEMS 32 TO 38) */}
          {activeTab === 'idea-families' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800">
                <h4 className="text-sm font-black text-white font-cinzel">
                  The 7 Idea Families & Final 10 World Concepts (Items 32–38)
                </h4>
                <p className="text-xs text-slate-400">
                  Comprehensive creative repository spanning board life, comedy, Astra powers, pets, discoveries and the living world.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {/* 32. Board-Life Family (20) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-amber-500/30 space-y-1.5">
                  <h5 className="font-black text-amber-300 flex items-center gap-1 font-cinzel">
                    <span>⚡</span> 32. Board-Life Idea Family (20)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Earthquake, royal gate, pet parade, lucky sky, token crown, danger zone, hot-seat flame, comeback storm, royal carpet, drone camera, golden dice, token laugh, victory meteor, board spotlight, pet high-five, confetti tunnel, magic bridge, throne seat, moonlight board, treasure chest.
                  </p>
                </div>

                {/* 33. Comedy Family (20) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-pink-500/30 space-y-1.5">
                  <h5 className="font-black text-pink-300 flex items-center gap-1 font-cinzel">
                    <span>😂</span> 33. Comedy Idea Family (20)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Goti slip, pet hide, fake sleep, chicken chase, duck parade, banana peel, funny hammer, laugh bomb, mirror taunt, pet steal, sleepy dice, angry dice, goti taxi, rickshaw, pet umbrella, flying chappal, mini chef, pet dance battle, laughing board, Oho reaction.
                  </p>
                </div>

                {/* 34. Astra / Power Family (20) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-purple-500/30 space-y-1.5">
                  <h5 className="font-black text-purple-300 flex items-center gap-1 font-cinzel">
                    <span>🔱</span> 34. Astra & Power Family (20)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Trishul Tandav, Vajra rain, Gada bounce, Dhanush arrow trail, Chakra spin, Astra Museum, kill-cam, triple combo, pet+Astra reaction, counter, combo meter, mega combo, roulette, temple entry, divine aura, shadow, lightning footprint, weapon showcase, victory seal, collector crown.
                  </p>
                </div>

                {/* 35. Pet Idea Family (15) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-1.5">
                  <h5 className="font-black text-emerald-300 flex items-center gap-1 font-cinzel">
                    <span>🐉</span> 35. Pet Idea Family (15)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Mood, birthday, costume, shadow, rescue, dragon breath, phoenix flyover, eagle landing, wolf howl, elephant trumpet, treasure hunt, sleep corner, twin reaction, collector wall, secret pet.
                  </p>
                </div>

                {/* 36. Competition Family (15) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-1.5">
                  <h5 className="font-black text-cyan-300 flex items-center gap-1 font-cinzel">
                    <span>🏆</span> 36. Competition Idea Family (15)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Hot-seat crown, fastest player, comeback king/queen, lucky sixer, cut master, pet collector, Astra master, social star, gift magnet (spending hidden), talk king/queen, board boss, underdog, weekly challenger, record breaker, Hall of Legends.
                  </p>
                </div>

                {/* 37. Mind-Blowing Discovery Family (10) */}
                <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-yellow-500/30 space-y-1.5">
                  <h5 className="font-black text-yellow-300 flex items-center gap-1 font-cinzel">
                    <span>🪐</span> 37. Mind-Blowing Discoveries (10)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Board portal, mini cinema, world change, time freeze, reverse replay, crowd reaction, royal newspaper, secret combination, mystery door, chaos button combining unlocked cosmetic effects.
                  </p>
                </div>

                {/* 38. Final 10 World Ideas */}
                <div className="col-span-1 md:col-span-2 p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-indigo-950/60 border border-purple-500/40 space-y-1.5">
                  <h5 className="font-black text-purple-200 flex items-center gap-1 font-cinzel">
                    <span>🌌</span> 38. Final 10 World Ideas (Living Ecosystem)
                  </h5>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    1. Living Board (Sunset → night → moonlight → sunrise) · 2. Board Remembers You · 3. 5-Second Movie Moments · 4. Impossible Mirror · 5. Secret World · 6. Collection Fusion · 7. Player Museum Showroom · 8. Live What-Just-Happened Replay · 9. Mystery Hunt · 10. 3D World Map connecting all realms.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: YEAR-END AWARDS CEREMONY (BIBLE ITEM 39) */}
          {activeTab === 'year-end-awards' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/70 via-purple-950/60 to-slate-900 border-2 border-amber-500/50 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center text-slate-950 text-2xl font-black shadow-[0_0_20px_#f59e0b]">
                    🏆
                  </div>
                  <div>
                    <h4 className="text-base font-black text-amber-200 font-cinzel">
                      Official 2026 Year-End Awards Ceremony
                    </h4>
                    <p className="text-xs text-slate-300">
                      Bible Item 39: 12 Legendary honor categories with 3D trophy, cinematic announcement & Hall of Fame entry!
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    sound.playGrandVictory();
                    confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
                    logAction(`Simulated Year-End Award presentation for: ${selectedAwardCategory}`);
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition"
                >
                  Simulate Award Ceremony
                </button>
              </div>

              {/* 12 Award Categories Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                {[
                  'Player of the Year',
                  'Ludo Master',
                  'Comeback King/Queen',
                  'Cut Master',
                  'Pet Collector',
                  'Astra Master',
                  'Balloon Hunter',
                  'Puzzle Master',
                  'Social Star',
                  'Gift Champion',
                  'Achievement Legend',
                  'Collection King/Queen',
                ].map((category) => (
                  <button
                    key={category}
                    onClick={() => {
                      sound.playClick();
                      setSelectedAwardCategory(category);
                    }}
                    className={`p-3 rounded-2xl border text-center transition ${
                      selectedAwardCategory === category
                        ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)] text-amber-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="text-2xl block mb-1">🏅</span>
                    <span className="text-xs font-black">{category}</span>
                  </button>
                ))}
              </div>

              {/* Compliance Notice for Cash Concepts (Bible Item 39) */}
              <div className="p-3 rounded-2xl bg-slate-900 border border-amber-500/30 text-xs text-slate-300 flex items-start gap-2">
                <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
                <p>
                  <strong>Legal Compliance Review Note (Bible Item 39):</strong> The discussed ₹500/₹1,000/₹2,000/₹4,000/₹5,000/₹9,999 yearly rewards and ₹50,000+ spender tier concept should only be activated after applicable legal, payment and promotional compliance review.
                </p>
              </div>
            </div>
          )}

          {/* TAB 9: PRODUCTION CHECKLIST & BUILD ORDER (Items 40-43) */}
          {activeTab === 'production-checklist' && (
            <div className="space-y-4">
              {/* Item 40: Core UX Rules */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-amber-300">40. Core UX Architecture</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                    VERIFIED ENFORCED
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <span className="font-bold text-amber-200">🎓 Tutorial</span>
                    <p className="text-[11px] text-slate-300">Can be watched or skipped at any moment with 1 click.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <span className="font-bold text-cyan-200">⚡ Fast Reveals</span>
                    <p className="text-[11px] text-slate-300">Most reveals last seconds (5s/10s), not minutes.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <span className="font-bold text-pink-200">🔒 Privacy</span>
                    <p className="text-[11px] text-slate-300">Public status for Top Gifters, private spending balances.</p>
                  </div>
                </div>
              </div>

              {/* Item 41: Visual Production Checklist */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-cyan-300">41. Visual Production Checklist</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold border border-cyan-500/30">
                    QUALITY PILLARS
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-cyan-300">Assets:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Model, material, texture, shadow, animation, LOD rendering.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-amber-300">6 Animation States:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Idle, Entry, Interaction, Reaction, Victory, Exit.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-indigo-300">Camera:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Normal gameplay plus short cinematic kill & victory cameras.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-pink-300">Audio:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Appropriate SFX; Miracle Arrival specifically remains SILENT.</p>
                  </div>
                  <div className="col-span-1 sm:col-span-2 p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-emerald-300">Readability:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Tokens, dice numbers and board pathways stay clear above effects.</p>
                  </div>
                </div>
              </div>

              {/* Item 42: Build Order (5 Phases) */}
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-indigo-300">42. 5-Phase Build Order Audit</h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                    PHASES 1–5 ACTIVE
                  </span>
                </div>
                <div className="space-y-1.5 text-xs">
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">Phase 1: Core Engine & Identity</span>
                      <p className="text-[10px] text-slate-400">Core Ludo, Auth (777777 / 100002+), Profiles, Rooms, Audio.</p>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">✓ Complete</span>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">Phase 2: Collections & Admin</span>
                      <p className="text-[10px] text-slate-400">12 Collections, 30 Pets, Levels, Frames, Sovereign Admin Center.</p>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">✓ Complete</span>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">Phase 3: Mini-Games & Astras</span>
                      <p className="text-[10px] text-slate-400">Carrom, Bow & Arrow (Takshak), Dot Connect (Chilli), Silent Flute.</p>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">✓ Complete</span>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">Phase 4: World Map & Living Board</span>
                      <p className="text-[10px] text-slate-400">3D World Map, Museum, Mystery Hunt, Day/Night Lighting.</p>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">✓ Complete</span>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">Phase 5: Performance, Moderation & Live-Ops</span>
                      <p className="text-[10px] text-slate-400">Promo codes, Event engine, RBAC audit logs, legal compliance.</p>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">✓ Complete</span>
                  </div>
                </div>
              </div>

              {/* Item 43: Final Product Promise */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-amber-950/60 border border-amber-500/40 space-y-2">
                <h3 className="text-sm font-black text-amber-200 font-cinzel">43. Final Product Promise</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-amber-300">Identity:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Social multiplayer Ludo universe with a premium 3D world.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-cyan-300">Discovery:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Deep mechanics revealed progressively through joyful play.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-emerald-300">Collections:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Rare items and Astras feel earned and visibly celebrated.</p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                    <strong className="text-pink-300">Visuals:</strong>
                    <p className="text-[11px] text-slate-300 mt-0.5">Rich, realistic, alive — never paper-like or flat.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Audit Logs Console at Bottom of Admin Center */}
          <div className="p-3 rounded-2xl bg-black/80 border border-slate-800 space-y-1.5 font-mono text-[11px]">
            <div className="flex items-center gap-1.5 text-slate-400 font-bold border-b border-white/5 pb-1">
              <Terminal size={13} className="text-emerald-400" />
              <span>Sovereign Audit Log Stream (Item 26)</span>
            </div>
            <div className="space-y-0.5 text-emerald-400/90 max-h-24 overflow-y-auto">
              {adminLog.map((log, idx) => (
                <p key={idx} className="truncate">
                  {log}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
