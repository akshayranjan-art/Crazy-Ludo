import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { sound } from '../utils/soundEngine';

export interface ActiveImpact {
  id: string;
  type: 'tomato' | 'bomb' | 'rose' | 'water' | 'punch' | 'egg' | 'trophy' | 'taunt';
  emoji?: string;
  tauntText?: string;
  senderName: string;
  x?: number; // percentage (0 - 100)
  y?: number; // percentage (0 - 100)
}

interface ReactionImpactOverlayProps {
  impacts: ActiveImpact[];
  onRemoveImpact: (id: string) => void;
}

export const ReactionImpactOverlay: React.FC<ReactionImpactOverlayProps> = ({
  impacts,
  onRemoveImpact,
}) => {
  useEffect(() => {
    impacts.forEach((impact) => {
      const timer = setTimeout(() => {
        onRemoveImpact(impact.id);
      }, 2500);
      return () => clearTimeout(timer);
    });
  }, [impacts, onRemoveImpact]);

  if (impacts.length === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-40 overflow-hidden">
      {/* Quick Dismiss Button */}
      <button
        onClick={() => impacts.forEach((i) => onRemoveImpact(i.id))}
        className="pointer-events-auto absolute top-20 right-4 z-50 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-red-950/90 border border-amber-400 text-amber-300 hover:text-white transition shadow-lg active:scale-95 flex items-center gap-1 cursor-pointer"
        title="Clear Screen Reactions"
      >
        <span className="text-[10px] font-bold hidden sm:inline">Clear</span>
        <X size={14} />
      </button>

      {impacts.map((imp) => {
        const posX = imp.x ?? 50;
        const posY = imp.y ?? 45;

        return (
          <div
            key={imp.id}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center animate-bounce-in"
            style={{ left: `${posX}%`, top: `${posY}%` }}
          >
            {/* Sender Badge */}
            <div className="px-2.5 py-0.5 rounded-full bg-black/80 border border-amber-400/50 text-[10px] font-bold text-amber-300 mb-1 shadow-lg flex items-center gap-1">
              <span>{imp.senderName}</span>
              <span>threw</span>
            </div>

            {/* Impact Visuals */}
            {imp.type === 'tomato' && (
              <div className="relative flex items-center justify-center animate-ping-once">
                <span className="text-7xl drop-shadow-[0_10px_20px_rgba(239,68,68,0.8)] filter">
                  🍅
                </span>
                <div className="absolute inset-0 w-24 h-24 bg-red-600/40 rounded-full blur-xl animate-pulse" />
                <div className="absolute -bottom-6 flex gap-1 text-red-500 font-black text-xs uppercase tracking-widest bg-red-950/80 px-2 py-0.5 rounded border border-red-500/50">
                  SPLAAAAT!
                </div>
              </div>
            )}

            {imp.type === 'bomb' && (
              <div className="relative flex items-center justify-center">
                <span className="text-8xl drop-shadow-[0_10px_30px_rgba(249,115,22,0.9)] animate-scale-up">
                  💥
                </span>
                <div className="absolute inset-0 w-32 h-32 bg-amber-500/40 rounded-full blur-2xl animate-ping" />
                <div className="absolute -bottom-6 font-black text-xs uppercase tracking-widest text-amber-300 bg-amber-950/80 px-2.5 py-0.5 rounded border border-amber-400/50">
                  BOOOOOOM!
                </div>
              </div>
            )}

            {imp.type === 'rose' && (
              <div className="relative flex flex-col items-center">
                <span className="text-7xl drop-shadow-[0_10px_25px_rgba(244,63,94,0.8)] animate-pulse">
                  🌹
                </span>
                <div className="flex gap-2 mt-1">
                  <span className="text-xl animate-bounce">💖</span>
                  <span className="text-xl animate-bounce delay-100">✨</span>
                  <span className="text-xl animate-bounce delay-200">🌹</span>
                </div>
              </div>
            )}

            {imp.type === 'water' && (
              <div className="relative flex items-center justify-center">
                <span className="text-7xl drop-shadow-[0_10px_25px_rgba(6,182,212,0.8)] animate-scale-up">
                  🌊
                </span>
                <div className="absolute -bottom-4 font-black text-xs text-cyan-200 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-400/50">
                  SPLASH!
                </div>
              </div>
            )}

            {imp.type === 'punch' && (
              <div className="relative flex items-center justify-center">
                <span className="text-7xl drop-shadow-[0_10px_25px_rgba(220,38,38,0.8)] animate-bounce">
                  🥊
                </span>
                <div className="absolute -top-6 font-black text-sm text-yellow-300 bg-red-950/90 px-3 py-1 rounded-full border-2 border-yellow-400 rotate-[-12deg] shadow-xl">
                  POW! 💥
                </div>
              </div>
            )}

            {imp.type === 'egg' && (
              <div className="relative flex items-center justify-center">
                <span className="text-7xl drop-shadow-[0_10px_25px_rgba(234,179,8,0.8)] animate-pulse">
                  🍳
                </span>
                <div className="absolute -bottom-4 font-bold text-xs text-yellow-200 bg-yellow-950/80 px-2 py-0.5 rounded border border-yellow-400/50">
                  EGG SMASH!
                </div>
              </div>
            )}

            {imp.type === 'trophy' && (
              <div className="relative flex flex-col items-center">
                <span className="text-7xl drop-shadow-[0_10px_30px_rgba(250,204,21,0.9)] animate-bounce">
                  🏆
                </span>
                <div className="text-sm font-black text-amber-300 mt-1 bg-amber-950/80 px-3 py-0.5 rounded-full border border-amber-400">
                  CHAMPION FLEX! 👑
                </div>
              </div>
            )}

            {imp.type === 'taunt' && (
              <div className="relative bg-gradient-to-r from-purple-900 to-indigo-950 border-2 border-yellow-400 px-5 py-3 rounded-2xl shadow-[0_0_30px_rgba(168,85,247,0.8)] flex items-center gap-2 animate-bounce">
                <span className="text-2xl">🗣️</span>
                <span className="text-base font-black text-yellow-300 tracking-wide font-cinzel">
                  "{imp.tauntText}"
                </span>
                {/* Speech Bubble Arrow */}
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-indigo-950 border-b-2 border-r-2 border-yellow-400 rotate-45" />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
