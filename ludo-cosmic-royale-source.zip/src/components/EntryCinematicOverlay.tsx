import React, { useEffect } from 'react';
import { ASSETS } from '../data/gameConstants';
import { Sparkles, Trophy, Star, Crown, X } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

export type EntryCinematicType =
  | 'hypercar'
  | 'sudarshan'
  | 'gada'
  | 'trishul'
  | 'flute'
  | 'signature-photo'
  | 'cyber-dragon'
  | null;

interface EntryCinematicOverlayProps {
  entryType: EntryCinematicType;
  playerName: string;
  title: string;
  playerAvatar?: string;
  onFinish: () => void;
}

export const EntryCinematicOverlay: React.FC<EntryCinematicOverlayProps> = ({
  entryType,
  playerName,
  title,
  playerAvatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
  onFinish,
}) => {
  useEffect(() => {
    if (!entryType) return;

    if (entryType === 'hypercar') {
      sound.playGiftFanfare();
    } else if (entryType === 'sudarshan') {
      sound.playSudarshanChakra();
    } else if (entryType === 'gada') {
      sound.playGadaSmash();
    } else if (entryType === 'trishul') {
      sound.playTrishulTandav();
    } else if (entryType === 'signature-photo') {
      sound.playGrandVictory();
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
    } else if (entryType === 'cyber-dragon') {
      sound.playTrishulThunder();
    }

    const timer = setTimeout(() => {
      onFinish();
    }, 4500);

    return () => clearTimeout(timer);
  }, [entryType, onFinish]);

  if (!entryType) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md animate-fade-in p-4">
      {/* Top Right Close 'X' Button */}
      <button
        onClick={() => {
          sound.playClick();
          onFinish();
        }}
        className="absolute top-4 right-4 sm:top-6 sm:right-6 z-50 p-2.5 sm:p-3 rounded-full bg-slate-900/90 hover:bg-red-950/90 border-2 border-amber-400/80 hover:border-red-400 text-amber-300 hover:text-white transition-all shadow-[0_0_25px_rgba(245,158,11,0.5)] active:scale-95 flex items-center gap-1.5 cursor-pointer group"
        title="Close Astra / Cinematic Screen"
        aria-label="Close Screen"
      >
        <span className="text-[11px] font-black uppercase tracking-wider hidden sm:inline text-amber-200 group-hover:text-white">
          Close
        </span>
        <X size={20} className="stroke-[2.5]" />
      </button>

      {/* 1. Neon Bugatti Hypercar Arrival */}
      {entryType === 'hypercar' && (
        <div className="relative flex flex-col items-center animate-[zoomIn_0.6s_ease-out]">
          <div className="relative w-[340px] sm:w-[500px] h-64 sm:h-72 rounded-3xl overflow-hidden border-2 border-cyan-400 shadow-[0_0_80px_rgba(6,182,212,0.8)]">
            <img
              src={ASSETS.hypercar}
              alt="Bugatti Arrival"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover animate-pulse"
            />
            {/* Speed lines */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent flex flex-col justify-end p-4">
              <div className="flex items-center gap-2">
                <span className="text-2xl animate-bounce">🏎️</span>
                <span className="text-xs uppercase tracking-widest font-black text-cyan-300">
                  HYPERCAR VIP ARRIVAL (Item 21)
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 text-center">
            <h2 className="text-2xl font-black text-white tracking-wider drop-shadow-[0_0_15px_#38bdf8] font-cinzel">
              {playerName}
            </h2>
            <p className="text-sm font-bold text-amber-300 tracking-widest uppercase">
              {title}
            </p>
          </div>
        </div>
      )}

      {/* 2. Signature Photo-Based Entry (Item 21: 5,000 Stars Unlock) */}
      {entryType === 'signature-photo' && (
        <div className="relative flex flex-col items-center animate-[zoomIn_0.5s_ease-out]">
          {/* Top Star Banner */}
          <div className="mb-4 px-5 py-1.5 rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-slate-950 font-black text-xs uppercase tracking-widest border-2 border-white shadow-[0_0_30px_#f59e0b] flex items-center gap-2 animate-bounce">
            <Star size={16} className="fill-slate-950" />
            <span>5,000 STARS SIGNATURE LOBBY ENTRY (Item 21)</span>
            <Star size={16} className="fill-slate-950" />
          </div>

          {/* Golden Rotating Photo Frame with Spotlight */}
          <div className="relative w-56 h-56 sm:w-64 sm:h-64 rounded-full p-2 bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-600 shadow-[0_0_90px_rgba(245,158,11,0.9)] animate-pulse flex items-center justify-center">
            <div className="w-full h-full rounded-full overflow-hidden border-4 border-slate-950 bg-black">
              <img
                src={playerAvatar}
                alt={playerName}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Crown on top */}
            <div className="absolute -top-6 text-4xl animate-bounce filter drop-shadow-[0_0_15px_#f59e0b]">
              👑
            </div>
          </div>

          <div className="mt-5 text-center">
            <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-100 to-amber-400 tracking-wider font-cinzel">
              {playerName}
            </h2>
            <p className="text-sm font-bold text-amber-300 tracking-widest uppercase mt-1">
              {title} · Royal Grand Entrance
            </p>
          </div>
        </div>
      )}

      {/* 3. Cyber-Dragon Arrival (Item 21) */}
      {entryType === 'cyber-dragon' && (
        <div className="relative flex flex-col items-center animate-[zoomIn_0.5s_ease-out]">
          <div className="relative w-[340px] sm:w-[480px] h-64 sm:h-72 rounded-3xl overflow-hidden border-3 border-cyan-400 shadow-[0_0_100px_rgba(6,182,212,0.9)] bg-gradient-to-b from-indigo-950 via-slate-950 to-black flex items-center justify-center">
            <div className="text-8xl sm:text-9xl animate-pulse filter drop-shadow-[0_0_40px_#06b6d4]">
              🐉⚡
            </div>
            {/* Overlay banner */}
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between px-3 py-1.5 rounded-xl bg-black/70 border border-cyan-400/50">
              <span className="text-[10px] font-black uppercase tracking-widest text-cyan-300">
                CYBER-DRAGON CELESTIAL ARRIVAL
              </span>
              <span className="text-xs">⚡🔥</span>
            </div>
          </div>

          <div className="mt-4 text-center">
            <h2 className="text-2xl font-black text-cyan-300 tracking-wider font-cinzel">
              {playerName}
            </h2>
            <p className="text-sm font-bold text-amber-300 tracking-widest uppercase mt-0.5">
              Riding the Neon Cyber-Dragon into Battle
            </p>
          </div>
        </div>
      )}

      {/* 4. Sudarshan Chakra Entry */}
      {entryType === 'sudarshan' && (
        <div className="relative flex flex-col items-center animate-[spinScale_0.8s_ease-out]">
          <div className="relative w-72 h-72 sm:w-80 sm:h-80 rounded-full overflow-hidden border-4 border-amber-400 shadow-[0_0_120px_#f59e0b] bg-black">
            <img
              src={ASSETS.sudarshan}
              alt="Sudarshan Chakra"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover animate-[spin_5s_linear_infinite]"
            />
          </div>

          <div className="mt-5 text-center">
            <h2 className="text-3xl font-black text-amber-300 tracking-wider drop-shadow-[0_0_20px_#fbbf24] font-cinzel">
              ॐ SUDARSHAN SUPREME BLESSING ॐ
            </h2>
            <p className="text-sm font-bold text-slate-100 uppercase tracking-widest mt-1">
              {playerName} enters the arena with 79 Billion 💎 Cosmic Aura
            </p>
          </div>
        </div>
      )}

      {/* 5. Hanuman Gada Smash */}
      {entryType === 'gada' && (
        <div className="relative flex flex-col items-center animate-[bounce_0.8s_ease-out]">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl overflow-hidden border-4 border-rose-500 shadow-[0_0_100px_#ef4444] bg-black">
            <img
              src={ASSETS.gada}
              alt="Hanuman Gada"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="mt-5 text-center">
            <h2 className="text-2xl font-black text-rose-400 tracking-wider font-cinzel">
              🚩 HANUMAN GADA CELESTIAL STRIKE 🚩
            </h2>
            <p className="text-sm font-bold text-amber-300 uppercase tracking-widest mt-1">
              {playerName} unleashes 59 Million 💎 Earth-Shattering Presence
            </p>
          </div>
        </div>
      )}

      {/* 6. Shiva Trishul Tandav */}
      {entryType === 'trishul' && (
        <div className="relative flex flex-col items-center">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl overflow-hidden border-4 border-cyan-400 shadow-[0_0_100px_#06b6d4] bg-black">
            <img
              src={ASSETS.trishul}
              alt="Shiva Trishul"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="mt-5 text-center">
            <h2 className="text-2xl font-black text-cyan-300 tracking-wider font-cinzel">
              🔱 NATARAJA TANDAV AURA ACTIVATED 🔱
            </h2>
            <p className="text-sm font-bold text-slate-200 uppercase tracking-widest mt-1">
              {playerName} summons celestial lightning storms across all safe cells
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
