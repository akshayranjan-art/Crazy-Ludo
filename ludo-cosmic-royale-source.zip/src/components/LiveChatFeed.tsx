import React, { useState } from 'react';
import { ChatMessage } from '../types/game';
import { Send, Mic, MicOff, Volume2, Sparkles } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface LiveChatFeedProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  isMicOn: boolean;
  onToggleMic: () => void;
  voiceEffect: string;
  onChangeVoiceEffect: (effect: string) => void;
}

export const LiveChatFeed: React.FC<LiveChatFeedProps> = ({
  messages,
  onSendMessage,
  isMicOn,
  onToggleMic,
  voiceEffect,
  onChangeVoiceEffect,
}) => {
  const [inputText, setInputText] = useState('');

  const handleSend = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    sound.playTokenHop(0);
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const quickPhrases = [
    'Om Namah Shivay! 🔱',
    'Rolling for a 6! 🎲',
    'Gada Smash incoming! 🪓',
    'Awesome token cut! 💥',
    'Sudarshan Chakra blessings! 🌀',
  ];

  return (
    <div className="flex flex-col h-full bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 p-3 shadow-xl">
      {/* Live Voice HUD */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleMic}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm ${
              isMicOn
                ? 'bg-emerald-500 text-slate-950 font-black animate-pulse'
                : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
            }`}
          >
            {isMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
            <span>{isMicOn ? 'Voice Active' : 'Mic Muted'}</span>
          </button>

          {isMicOn && (
            <div className="flex items-center gap-0.5">
              <span className="w-1 h-3 bg-emerald-400 animate-pulse rounded-full" />
              <span className="w-1 h-4 bg-emerald-400 animate-[bounce_0.6s_infinite] rounded-full" />
              <span className="w-1 h-2 bg-emerald-400 animate-pulse rounded-full" />
            </div>
          )}
        </div>

        {/* Voice Modulator Presets */}
        <select
          value={voiceEffect}
          onChange={(e) => {
            onChangeVoiceEffect(e.target.value);
            sound.playSafeCell();
          }}
          className="bg-slate-950 text-slate-300 text-[11px] font-semibold px-2 py-1 rounded-lg border border-slate-700 focus:outline-none focus:border-amber-400"
        >
          <option value="normal">🎙️ Natural Voice</option>
          <option value="divine">✨ Divine Echo</option>
          <option value="deep">🦁 Deep Lion King</option>
          <option value="robot">🤖 Cyber Android</option>
        </select>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 min-h-[160px] max-h-[220px]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`text-xs p-1.5 rounded-xl transition-all ${
              msg.type === 'gift'
                ? 'bg-gradient-to-r from-pink-950/60 to-purple-950/60 border border-pink-500/30'
                : msg.type === 'astra'
                ? 'bg-gradient-to-r from-amber-950/60 to-cyan-950/60 border border-amber-500/30'
                : msg.type === 'capture'
                ? 'bg-rose-950/40 border border-rose-500/20'
                : 'bg-slate-950/50'
            }`}
          >
            <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
              <span className="font-bold text-amber-400 flex items-center gap-1">
                {msg.sender}
                {msg.badge && (
                  <span className="px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] border border-amber-500/40 font-mono">
                    {msg.badge}
                  </span>
                )}
              </span>
              <span className="text-slate-500">{msg.timestamp}</span>
            </div>
            <p className="text-slate-200 text-[11px] break-words">
              {msg.text}
            </p>
          </div>
        ))}
      </div>

      {/* Quick Phrases */}
      <div className="flex items-center gap-1.5 py-1.5 overflow-x-auto">
        {quickPhrases.map((phrase, i) => (
          <button
            key={i}
            onClick={() => onSendMessage(phrase)}
            className="px-2 py-0.5 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[10px] font-medium whitespace-nowrap transition-colors border border-slate-700/60"
          >
            {phrase}
          </button>
        ))}
      </div>

      {/* Input bar */}
      <form onSubmit={handleSend} className="flex gap-1.5 pt-1">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Send a live message to the room..."
          className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-400"
        />
        <button
          type="submit"
          className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center transition-colors shadow-sm"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
