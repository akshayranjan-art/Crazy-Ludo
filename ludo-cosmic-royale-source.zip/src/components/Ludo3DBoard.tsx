import React, { useState } from 'react';
import { Player, Token, PlayerColor, Visual4DState } from '../types/game';
import { SAFE_CELL_INDICES } from '../data/gameConstants';
import { Eye, Mic, MicOff, Flame, Crown, Shield, Maximize2, Minimize2, Sparkles, Palette, Droplets, X } from 'lucide-react';
import { sound } from '../utils/soundEngine';

export interface Ludo3DBoardProps {
  players: Player[];
  activeColor: PlayerColor;
  diceValue: number | null;
  canRoll: boolean;
  selectableTokenIds: number[];
  onSelectToken: (token: Token) => void;
  activeAstraEffect: string | null;
  onDismissAstraEffect?: () => void;
  boardTheme?: 'royal-purple' | 'cosmic-gold' | 'cyber-neon' | 'shiva-temple';
  onChangeTheme?: (theme: 'royal-purple' | 'cosmic-gold' | 'cyber-neon' | 'shiva-temple') => void;
  onDiceRoll?: () => void;
  isRollingDice?: boolean;
  isImmersionMode?: boolean;
  onToggleImmersion?: () => void;
  onThrowAtPlayer?: (playerColor: PlayerColor) => void;
  isEarthquakeActive?: boolean;
  isShieldActive?: boolean;
  visual4D?: Visual4DState;
  onOpenVisualsModal?: () => void;
}

// Special Bonus Cells on the main 52-tile track (Matching Hapi Ludo & Queen Ludo mechanics)
const BONUS_CELLS: Record<number, { icon: string; label: string; color: string; desc: string }> = {
  4: { icon: '🌹', label: 'Rose', color: 'text-rose-400', desc: 'Rose Blossom Safe' },
  6: { icon: '🪙', label: '+100K', color: 'text-amber-300 font-black text-[8px]', desc: '+100K Bonus Coin' },
  16: { icon: '💣', label: 'Bomb', color: 'text-amber-500', desc: 'Cosmic Bomb Blast' },
  18: { icon: '🚀', label: 'Warp', color: 'text-cyan-400', desc: 'Hyper Rocket Boost' },
  20: { icon: '🪙', label: '+100K', color: 'text-amber-300 font-black text-[8px]', desc: '+100K Bonus Coin' },
  28: { icon: '🎲', label: 'Lucky 6', color: 'text-yellow-400', desc: 'Lucky Bonus Roll' },
  30: { icon: '🌹', label: 'Rose', color: 'text-rose-400', desc: 'Rose Blossom Safe' },
  32: { icon: '🪙', label: '+100K', color: 'text-amber-300 font-black text-[8px]', desc: '+100K Bonus Coin' },
  42: { icon: '💣', label: 'Bomb', color: 'text-amber-500', desc: 'Cosmic Bomb Blast' },
  44: { icon: '🚀', label: 'Warp', color: 'text-cyan-400', desc: 'Hyper Rocket Boost' },
  46: { icon: '🪙', label: '+100K', color: 'text-amber-300 font-black text-[8px]', desc: '+100K Bonus Coin' },
};

// Track corner directional arrows showing path flow
const TURN_ARROWS: Record<number, string> = {
  5: '⬇️',
  11: '➡️',
  18: '➡️',
  24: '⬇️',
  31: '⬅️',
  37: '⬇️',
  44: '⬅️',
  50: '⬆️',
};

// Theme presets for the board
interface BoardThemeConfig {
  id: 'royal-purple' | 'cosmic-gold' | 'cyber-neon' | 'shiva-temple';
  name: string;
  icon: string;
  outerBorder: string;
  frameBg: string;
  gridBg: string;
  safeCellBg: string;
  safeCellBorder: string;
  safeCellGlow: string;
  cellBg: string;
  cellBorder: string;
  accentGlow: string;
  matGradient: string;
  centerBg: string;
}

const THEME_STYLES: Record<string, BoardThemeConfig> = {
  'cosmic-gold': {
    id: 'cosmic-gold',
    name: '24K Dubai Gold',
    icon: '👑',
    outerBorder: 'border-amber-400 shadow-[0_0_60px_rgba(251,191,36,0.6),0_25px_60px_rgba(0,0,0,0.95)]',
    frameBg: 'bg-gradient-to-b from-[#2d1b06] via-[#120a03] to-[#251504]',
    gridBg: 'bg-[#09060f]',
    safeCellBg: 'bg-gradient-to-br from-amber-950 via-yellow-900 to-amber-900',
    safeCellBorder: 'border-amber-400',
    safeCellGlow: 'shadow-[0_0_15px_rgba(251,191,36,0.7)]',
    cellBg: 'bg-slate-900/95',
    cellBorder: 'border-amber-500/25',
    accentGlow: 'from-amber-500/30 via-yellow-500/10 to-transparent',
    matGradient: 'from-amber-600/25 via-purple-900/20 to-amber-500/25',
    centerBg: 'bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900',
  },
  'royal-purple': {
    id: 'royal-purple',
    name: 'Empress Velvet',
    icon: '💎',
    outerBorder: 'border-purple-400 shadow-[0_0_60px_rgba(168,85,247,0.6),0_25px_60px_rgba(0,0,0,0.95)]',
    frameBg: 'bg-gradient-to-b from-[#20052e] via-[#0e0216] to-[#1a0426]',
    gridBg: 'bg-[#08020e]',
    safeCellBg: 'bg-gradient-to-br from-purple-950 via-fuchsia-950 to-purple-900',
    safeCellBorder: 'border-purple-400',
    safeCellGlow: 'shadow-[0_0_15px_rgba(168,85,247,0.7)]',
    cellBg: 'bg-purple-950/45',
    cellBorder: 'border-purple-500/30',
    accentGlow: 'from-purple-500/30 via-fuchsia-500/10 to-transparent',
    matGradient: 'from-purple-600/25 via-pink-900/20 to-purple-700/25',
    centerBg: 'bg-gradient-to-br from-purple-950 via-slate-950 to-indigo-950',
  },
  'shiva-temple': {
    id: 'shiva-temple',
    name: 'Kailash Mandir',
    icon: '🔱',
    outerBorder: 'border-orange-400 shadow-[0_0_60px_rgba(249,115,22,0.6),0_25px_60px_rgba(0,0,0,0.95)]',
    frameBg: 'bg-gradient-to-b from-[#2a1306] via-[#100602] to-[#200d04]',
    gridBg: 'bg-[#0c0502]',
    safeCellBg: 'bg-gradient-to-br from-orange-950 via-amber-950 to-orange-900',
    safeCellBorder: 'border-orange-400',
    safeCellGlow: 'shadow-[0_0_15px_rgba(249,115,22,0.7)]',
    cellBg: 'bg-slate-900/95',
    cellBorder: 'border-orange-500/30',
    accentGlow: 'from-orange-500/30 via-amber-500/10 to-transparent',
    matGradient: 'from-orange-600/25 via-red-900/20 to-amber-600/25',
    centerBg: 'bg-gradient-to-br from-stone-950 via-orange-950 to-slate-950',
  },
  'cyber-neon': {
    id: 'cyber-neon',
    name: 'Tokyo Cyberpunk',
    icon: '⚡',
    outerBorder: 'border-cyan-400 shadow-[0_0_60px_rgba(6,182,212,0.6),0_25px_60px_rgba(0,0,0,0.95)]',
    frameBg: 'bg-gradient-to-b from-[#031d28] via-[#020d14] to-[#041722]',
    gridBg: 'bg-[#02090e]',
    safeCellBg: 'bg-gradient-to-br from-cyan-950 via-sky-900 to-cyan-900',
    safeCellBorder: 'border-cyan-400',
    safeCellGlow: 'shadow-[0_0_15px_rgba(6,182,212,0.7)]',
    cellBg: 'bg-cyan-950/45',
    cellBorder: 'border-cyan-500/30',
    accentGlow: 'from-cyan-500/30 via-sky-500/10 to-transparent',
    matGradient: 'from-cyan-600/25 via-blue-900/20 to-fuchsia-600/25',
    centerBg: 'bg-gradient-to-br from-slate-950 via-cyan-950 to-blue-950',
  },
};

export const Ludo3DBoard: React.FC<Ludo3DBoardProps> = ({
  players,
  activeColor,
  selectableTokenIds,
  onSelectToken,
  activeAstraEffect,
  onDismissAstraEffect,
  boardTheme = 'cosmic-gold',
  onChangeTheme,
  onDiceRoll,
  canRoll,
  isRollingDice,
  isImmersionMode = false,
  onToggleImmersion,
  onThrowAtPlayer,
  isEarthquakeActive = false,
  isShieldActive = false,
  visual4D,
  onOpenVisualsModal,
}) => {
  const [cameraMode, setCameraMode] = useState<'3d-iso' | 'top-down' | 'cinematic'>('3d-iso');
  const [isThemePickerOpen, setIsThemePickerOpen] = useState(false);

  const currentTheme = THEME_STYLES[boardTheme] || THEME_STYLES['cosmic-gold'];

  // Camera perspective transformation
  const getCameraTransform = () => {
    switch (cameraMode) {
      case '3d-iso':
        return 'perspective(1200px) rotateX(24deg) scale(0.97)';
      case 'cinematic':
        return 'perspective(950px) rotateX(34deg) rotateY(-5deg) scale(0.95)';
      case 'top-down':
      default:
        return 'none';
    }
  };

  // Color mappings with rich jewel palette
  const colorMap: Record<PlayerColor, {
    primary: string;
    bg: string;
    border: string;
    glow: string;
    name: string;
    text: string;
    badgeBg: string;
    tokenGradient: string;
    tokenEmoji: string;
  }> = {
    red: {
      primary: '#ef4444',
      bg: 'bg-red-600',
      border: 'border-red-500',
      glow: 'shadow-[0_0_15px_#ef4444]',
      name: 'Red',
      text: 'text-red-400',
      badgeBg: 'bg-red-500/20 text-red-300 border-red-500/40',
      tokenGradient: 'from-red-500 via-rose-600 to-red-800',
      tokenEmoji: '👑',
    },
    green: {
      primary: '#10b981',
      bg: 'bg-emerald-600',
      border: 'border-emerald-500',
      glow: 'shadow-[0_0_15px_#10b981]',
      name: 'Green',
      text: 'text-emerald-400',
      badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      tokenGradient: 'from-emerald-400 via-emerald-600 to-teal-800',
      tokenEmoji: '💎',
    },
    yellow: {
      primary: '#f59e0b',
      bg: 'bg-amber-500',
      border: 'border-amber-400',
      glow: 'shadow-[0_0_15px_#f59e0b]',
      name: 'Yellow',
      text: 'text-amber-300',
      badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      tokenGradient: 'from-yellow-300 via-amber-500 to-amber-700',
      tokenEmoji: '🦁',
    },
    blue: {
      primary: '#3b82f6',
      bg: 'bg-blue-600',
      border: 'border-blue-500',
      glow: 'shadow-[0_0_15px_#3b82f6]',
      name: 'Blue',
      text: 'text-blue-400',
      badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
      tokenGradient: 'from-cyan-400 via-blue-600 to-indigo-800',
      tokenEmoji: '🌊',
    },
  };

  // Base coordinates for tokens in Home Base (-1 to -4)
  const getBaseTokenCoords = (tokenIdx: number): { top: string; left: string } => {
    const offsets = [
      { top: '30%', left: '30%' },
      { top: '30%', left: '70%' },
      { top: '70%', left: '30%' },
      { top: '70%', left: '70%' },
    ];
    return offsets[tokenIdx % 4];
  };

  // Check tokens on given main path cell
  const getTokensOnCell = (pathIdx: number) => {
    const matched: { player: Player; token: Token }[] = [];
    players.forEach((p) => {
      p.tokens.forEach((t) => {
        if (t.position === pathIdx) {
          matched.push({ player: p, token: t });
        }
      });
    });
    return matched;
  };

  // Check tokens on home run step
  const getTokensOnHomeRun = (color: PlayerColor, step: number) => {
    const matched: { player: Player; token: Token }[] = [];
    const p = players.find((pl) => pl.color === color);
    if (p) {
      p.tokens.forEach((t) => {
        if (t.position === 100 + step) {
          matched.push({ player: p, token: t });
        }
      });
    }
    return matched;
  };

  // Check tokens finished in central home
  const getTokensInFinishedHome = () => {
    const matched: { player: Player; token: Token }[] = [];
    players.forEach((p) => {
      p.tokens.forEach((t) => {
        if (t.position === 999) {
          matched.push({ player: p, token: t });
        }
      });
    });
    return matched;
  };

  // Render 3D Sculpted Gem Pawn
  const renderTokenPawn = (token: Token, player: Player, isSelectable: boolean) => {
    const theme = colorMap[player.color];
    return (
      <div
        key={`${player.id}-${token.id}`}
        onClick={(e) => {
          e.stopPropagation();
          if (isSelectable) {
            sound.playTokenHop(token.stepCount);
            onSelectToken(token);
          }
        }}
        className={`relative z-20 flex items-center justify-center transition-all duration-200 select-none ${
          isSelectable
            ? 'cursor-pointer scale-125 animate-bounce'
            : 'cursor-default'
        }`}
        title={`${player.name} Token #${token.id + 1} (${
          isSelectable ? 'CLICK TO MOVE!' : 'Waiting on board'
        })`}
      >
        {/* Pulsing Sunburst Halo if Selectable */}
        {isSelectable && (
          <div className="absolute -inset-2.5 rounded-full bg-amber-400 blur-sm opacity-90 animate-ping pointer-events-none" />
        )}

        {/* Indra Vajra Plasma Shield Aura */}
        {player.color === 'red' && isShieldActive && (
          <div className="absolute -inset-2 rounded-full border-2 border-purple-400 bg-purple-500/25 animate-pulse shadow-[0_0_12px_#c084fc] pointer-events-none flex items-center justify-center">
            <span className="absolute -top-3 text-[10px] animate-bounce">🛡️</span>
          </div>
        )}

        {/* 3D Pawn Body with Specular Highlight and Golden Bevel (Jelly Token support) */}
        <div
          className={`w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-gradient-to-b ${theme.tokenGradient} border-2 border-white/95 flex items-center justify-center font-black text-white transition-all ${theme.glow} ${
            visual4D?.jellyTokens ? 'hover:scale-135 active:scale-75 active:scale-y-125 transition-transform duration-150 ease-out' : ''
          }`}
          style={{
            boxShadow: `0 6px 14px rgba(0,0,0,0.85), 0 0 16px ${theme.primary}, inset 0 2px 4px rgba(255,255,255,0.8)`,
          }}
        >
          {/* 3D Pawn Golden Emblem / Facet */}
          <span className="text-[10px] sm:text-[11px] drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            {theme.tokenEmoji}
          </span>
        </div>
      </div>
    );
  };

  // Corner in-game player card helper (Hapi Ludo & Queen Ludo style)
  const renderCornerPlayer = (color: PlayerColor, align: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right') => {
    const player = players.find((p) => p.color === color) || {
      id: color,
      name: color.toUpperCase(),
      color,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      avatarFrame: 'frame-gold-wings',
      level: 45,
      isBot: color !== 'red',
      hasFinished: false,
      title: 'Royale Player',
      tokens: [],
    };

    const isCurrentTurn = activeColor === color;
    const theme = colorMap[color];

    return (
      <div
        className={`relative flex items-center gap-2 p-1.5 sm:p-2.5 rounded-2xl transition-all duration-300 ${
          isCurrentTurn
            ? 'bg-gradient-to-r from-amber-500/35 via-slate-900/95 to-amber-500/25 border-2 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.7)] scale-105 z-30'
            : 'bg-slate-950/85 border border-white/15 hover:border-white/30 backdrop-blur-md'
        } ${align.includes('right') ? 'flex-row-reverse text-right' : 'text-left'}`}
      >
        {/* Avatar with Royal Frame & Pulsing Turn Beacon */}
        <div className="relative">
          {/* Animated Golden Ring on Active Turn */}
          {isCurrentTurn && (
            <div className="absolute -inset-1 rounded-full border-2 border-amber-400 border-dashed animate-[spin_4s_linear_infinite] shadow-[0_0_12px_#f59e0b]" />
          )}

          <div
            className={`w-9 h-9 sm:w-12 sm:h-12 rounded-full overflow-hidden bg-slate-800 ${player.avatarFrame} shadow-md`}
          >
            <img
              src={player.avatar}
              alt={player.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Live Mic badge */}
          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center shadow">
            <Mic size={9} className={isCurrentTurn ? 'text-emerald-400 animate-pulse' : 'text-slate-400'} />
          </div>
        </div>

        {/* Player Name, Level & Turn Status */}
        <div className="min-w-0">
          <div className="flex items-center gap-1">
            <span
              className={`text-xs font-black truncate max-w-[85px] sm:max-w-[110px] ${
                isCurrentTurn ? 'text-amber-300 drop-shadow-[0_1px_4px_rgba(245,158,11,0.8)]' : 'text-white'
              }`}
            >
              {player.name}
            </span>
          </div>

          <div className="flex items-center gap-1 mt-0.5">
            <span className="text-[9px] px-1 py-0.2 rounded bg-slate-800 text-slate-300 font-mono border border-slate-700">
              Lv.{player.level}
            </span>

            {isCurrentTurn ? (
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black animate-pulse shadow-[0_0_8px_#f59e0b]">
                ROLL 🎲
              </span>
            ) : (
              <span className={`text-[9px] font-bold capitalize ${theme.text}`}>
                {theme.name}
              </span>
            )}
          </div>
        </div>

        {/* Quick Throw reaction at this corner player (Hapi Ludo style) */}
        {onThrowAtPlayer && color !== 'red' && (
          <button
            onClick={() => onThrowAtPlayer(color)}
            title={`Throw reaction at ${player.name}`}
            className="p-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-[10px] border border-slate-600 transition-transform active:scale-90"
          >
            🎯
          </button>
        )}
      </div>
    );
  };

  return (
    <div className={`flex flex-col items-center w-full select-none transition-all ${isImmersionMode ? 'max-w-[720px]' : 'max-w-[640px]'}`}>
      {/* 1. VIEWPORT CAMERA, THEMES & FULL BOARD CONTROLS */}
      <div className="flex flex-wrap items-center justify-between w-full mb-2 px-1 gap-2 text-xs">
        {/* Camera Selector */}
        <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-full border border-slate-700 shadow-md">
          <Eye className="w-3.5 h-3.5 text-amber-400 ml-1.5" />
          {(['3d-iso', 'cinematic', 'top-down'] as const).map((cam) => (
            <button
              key={cam}
              onClick={() => {
                sound.playClick();
                setCameraMode(cam);
              }}
              className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] sm:text-[11px] transition-colors ${
                cameraMode === cam
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cam === '3d-iso' ? '3D Arena' : cam === 'cinematic' ? 'Cinematic' : '2D Classic'}
            </button>
          ))}
        </div>

        {/* Board Theme Picker & Full Board Toggle */}
        <div className="flex items-center gap-1.5">
          {/* Theme Dropdown / Button */}
          {onChangeTheme && (
            <div className="relative">
              <button
                onClick={() => {
                  sound.playClick();
                  setIsThemePickerOpen(!isThemePickerOpen);
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 text-[11px] font-bold text-amber-300 shadow-sm transition-all"
                title="Change Ludo Board Theme"
              >
                <span>{currentTheme.icon}</span>
                <span className="hidden sm:inline">{currentTheme.name}</span>
                <Palette size={12} className="text-amber-400" />
              </button>

              {isThemePickerOpen && (
                <div className="absolute right-0 top-full mt-1.5 z-50 w-44 rounded-2xl bg-slate-950/95 border border-amber-500/40 p-1.5 shadow-2xl backdrop-blur-xl animate-fadeIn space-y-1">
                  <p className="text-[10px] text-slate-400 px-2 font-bold uppercase tracking-wider">
                    Select Board Theme
                  </p>
                  {Object.values(THEME_STYLES).map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        sound.playClick();
                        onChangeTheme(t.id);
                        setIsThemePickerOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                        boardTheme === t.id
                          ? 'bg-amber-500 text-slate-950 font-black'
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        <span>{t.icon}</span>
                        <span>{t.name}</span>
                      </span>
                      {boardTheme === t.id && <span>✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Full Screen Immersion Toggle */}
          {onToggleImmersion && (
            <button
              onClick={() => {
                sound.playClick();
                onToggleImmersion();
              }}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full border text-[11px] font-bold transition-all shadow-sm ${
                isImmersionMode
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-[0_0_15px_#f59e0b]'
                  : 'bg-slate-900/90 text-slate-300 hover:text-white border-slate-700'
              }`}
              title={isImmersionMode ? 'Exit Full Board View' : 'Full Board View (Maximum Stage Presence)'}
            >
              {isImmersionMode ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
              <span className="hidden sm:inline">
                {isImmersionMode ? 'Normal View' : 'Full Board Focus'}
              </span>
            </button>
          )}

          {/* 4D Neon-Liquid FX Button (Bible Item 22) */}
          {onOpenVisualsModal && (
            <button
              onClick={() => {
                sound.playClick();
                onOpenVisualsModal();
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-cyan-600/40 via-blue-600/30 to-purple-600/40 border border-cyan-400/50 text-[11px] font-black text-cyan-200 hover:border-cyan-300 transition-all shadow-sm active:scale-95"
              title="Configure 4D & Neon-Liquid Visuals (Holographic Dice, Jelly Tokens, Weather Arenas)"
            >
              <Sparkles size={12} className="text-cyan-300 animate-pulse" />
              <span>4D FX</span>
              {visual4D?.weatherArena && visual4D.weatherArena !== 'clear' && (
                <span className="text-[10px]">
                  {visual4D.weatherArena === 'storm' ? '⚡' : visual4D.weatherArena === 'solar' ? '☀️' : '🌈'}
                </span>
              )}
            </button>
          )}

          {/* Turn indicator */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 px-2.5 py-1 rounded-full border border-amber-500/30">
            <span className="text-slate-400 text-[10px] hidden xs:inline">Turn:</span>
            <span className={`font-black text-xs uppercase flex items-center gap-1 ${colorMap[activeColor].text}`}>
              <span className={`w-2 h-2 rounded-full ${colorMap[activeColor].bg} animate-pulse shadow-[0_0_8px]`} />
              {colorMap[activeColor].name}
            </span>
          </div>
        </div>
      </div>

      {/* 2. TOP IN-GAME PLAYER CORNERS (Hapi Ludo & Queen Ludo style) */}
      <div className="w-full grid grid-cols-2 gap-2 mb-2 px-1">
        {renderCornerPlayer('red', 'top-left')}
        {renderCornerPlayer('green', 'top-right')}
      </div>

      {/* 3. THE 3D LUDO ARENA BOARD CONTAINER */}
      <div
        className="relative transition-all duration-700 ease-out origin-center w-full flex justify-center"
        style={{
          transform: getCameraTransform(),
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Living Ambient Radiant Backlight (Queen Ludo style) */}
        <div className={`absolute -inset-6 rounded-3xl bg-gradient-to-tr ${currentTheme.matGradient} blur-3xl -z-10`} />

        {/* Dynamic Weather Arena FX Overlays (Item 22) */}
        {visual4D?.weatherArena === 'storm' && (
          <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden rounded-3xl">
            <div className="absolute inset-0 bg-blue-900/15 animate-[pulse_2s_infinite]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-400/20 via-transparent to-transparent opacity-70" />
            <div className="absolute top-2 left-6 text-2xl animate-bounce">⚡</div>
            <div className="absolute top-4 right-10 text-2xl animate-pulse">⚡</div>
          </div>
        )}

        {visual4D?.weatherArena === 'solar' && (
          <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden rounded-3xl">
            <div className="absolute inset-0 bg-amber-500/10 animate-pulse" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-yellow-400/25 via-amber-600/10 to-transparent" />
          </div>
        )}

        {visual4D?.weatherArena === 'aurora' && (
          <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden rounded-3xl">
            <div className="absolute inset-0 bg-gradient-to-r from-teal-500/15 via-purple-600/15 to-pink-500/15 animate-[pulse_3s_infinite]" />
          </div>
        )}

        {/* Outer Royal Golden Double Beveled Rim */}
        <div
          className={`relative w-[96vw] aspect-square rounded-3xl p-2 sm:p-3 transition-all duration-500 ${currentTheme.frameBg} border-[5px] sm:border-[6px] ${currentTheme.outerBorder} ${
            isEarthquakeActive ? 'animate-[bounce_0.1s_infinite] shadow-[0_0_80px_rgba(239,68,68,0.9)] scale-[1.02]' : ''
          } ${
            isImmersionMode
              ? 'max-w-[680px] sm:w-[620px] sm:h-[620px] md:w-[660px] md:h-[660px] lg:w-[680px] lg:h-[680px]'
              : 'max-w-[440px] sm:w-[500px] sm:h-[500px] md:w-[560px] md:h-[560px] lg:w-[600px] lg:h-[600px]'
          }`}
        >
          {/* Ornate Gilded Corner Gemstone Medallions */}
          <div className="absolute -top-3 -left-3 text-xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)] z-20 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 border-2 border-white shadow-[0_0_15px_#f59e0b]">
            <span className="text-sm">🔴</span>
          </div>
          <div className="absolute -top-3 -right-3 text-xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)] z-20 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 border-2 border-white shadow-[0_0_15px_#f59e0b]">
            <span className="text-sm">🟢</span>
          </div>
          <div className="absolute -bottom-3 -left-3 text-xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)] z-20 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 border-2 border-white shadow-[0_0_15px_#f59e0b]">
            <span className="text-sm">🔵</span>
          </div>
          <div className="absolute -bottom-3 -right-3 text-xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)] z-20 flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-amber-700 border-2 border-white shadow-[0_0_15px_#f59e0b]">
            <span className="text-sm">🟡</span>
          </div>

          {/* 15x15 Standard Ludo Board Grid with Velvet Depth */}
          <div className={`w-full h-full ${currentTheme.gridBg} rounded-2xl border-2 border-amber-500/50 p-1 sm:p-1.5 grid grid-cols-15 grid-rows-15 gap-0.5 sm:gap-1 overflow-hidden shadow-inner`}>
            
            {/* ===================== 1. RED BASE (Top Left: row 1-6, col 1-6) ===================== */}
            <div className="col-span-6 row-span-6 rounded-xl bg-gradient-to-br from-rose-950 via-red-900 to-red-800 border-2 border-red-500/80 p-1.5 sm:p-2.5 shadow-[inset_0_4px_16px_rgba(0,0,0,0.85)] relative flex flex-col items-center justify-between">
              <div className="flex items-center justify-between w-full text-[10px] sm:text-xs font-black text-red-100">
                <span className="tracking-wider flex items-center gap-1 drop-shadow">
                  <span>🔴</span> RED PALACE
                </span>
                <span className="text-[8px] sm:text-[9px] px-1.5 py-0.5 rounded bg-red-950/90 border border-red-500/50 text-red-300 font-bold">
                  Safe Yard
                </span>
              </div>

              {/* Red Base 4 Sunken Token Sockets */}
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-2xl bg-black/60 border border-red-500/50 shadow-inner flex items-center justify-center">
                {/* 4 Empty Socket Well Rings */}
                {[0, 1, 2, 3].map((idx) => {
                  const pos = getBaseTokenCoords(idx);
                  return (
                    <div
                      key={`socket-red-${idx}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-red-500/35 bg-red-950/50 shadow-[inset_0_2px_8px_rgba(0,0,0,0.85)] flex items-center justify-center text-red-400/30 text-xs"
                      style={{ top: pos.top, left: pos.left }}
                    >
                      👑
                    </div>
                  );
                })}

                {/* Occupied Tokens in Base */}
                {players
                  .find((p) => p.color === 'red')
                  ?.tokens.map((token, idx) => {
                    if (token.position >= 0) return null;
                    const isSelectable = selectableTokenIds.includes(token.id) && activeColor === 'red';
                    const pos = getBaseTokenCoords(idx);
                    return (
                      <div
                        key={token.id}
                        className="absolute -translate-x-1/2 -translate-y-1/2"
                        style={{ top: pos.top, left: pos.left }}
                      >
                        {renderTokenPawn(token, players.find((p) => p.color === 'red')!, isSelectable)}
                      </div>
                    );
                  })}
              </div>

              <div className="text-[9px] sm:text-[10px] text-red-300 font-bold bg-red-950/70 px-2 py-0.5 rounded-full border border-red-500/40 shadow-sm">
                Roll 6 to Deploy
              </div>
            </div>

            {/* ===================== TOP DIVIDER / GREEN PATH (Cols 7-9, Rows 1-6) ===================== */}
            <div className="col-span-3 row-span-6 grid grid-cols-3 grid-rows-6 gap-0.5 sm:gap-1">
              {Array.from({ length: 18 }).map((_, i) => {
                const row = Math.floor(i / 3) + 1;
                const col = (i % 3) + 7;

                // Home run track (Col 8, rows 2..6)
                const isGreenHomeRun = col === 8 && row >= 2 && row <= 6;
                const homeRunStep = row - 2;

                let pathIdx: number | null = null;
                if (col === 7) {
                  pathIdx = 10 - (row - 1); // 10..5
                } else if (col === 8 && row === 1) {
                  pathIdx = 11;
                } else if (col === 9) {
                  if (row === 1) pathIdx = 12;
                  else if (row === 2) pathIdx = 13; // Green start (Safe)
                  else pathIdx = 14 + (row - 3); // 14..17
                }

                const isSafe = pathIdx !== null && SAFE_CELL_INDICES.includes(pathIdx);
                const bonus = pathIdx !== null ? BONUS_CELLS[pathIdx] : null;
                const turnArrow = pathIdx !== null ? TURN_ARROWS[pathIdx] : null;
                const tokensOnCell = pathIdx !== null
                  ? getTokensOnCell(pathIdx)
                  : isGreenHomeRun
                  ? getTokensOnHomeRun('green', homeRunStep)
                  : [];

                return (
                  <div
                    key={`top-${i}`}
                    className={`relative rounded-[4px] sm:rounded-[6px] flex items-center justify-center transition-all ${
                      isGreenHomeRun
                        ? 'bg-gradient-to-b from-emerald-400 via-emerald-600 to-emerald-800 border border-emerald-300 text-white font-black shadow-sm'
                        : isSafe
                        ? `${currentTheme.safeCellBg} ${currentTheme.safeCellBorder} ${currentTheme.safeCellGlow} border-2`
                        : `${currentTheme.cellBg} ${currentTheme.cellBorder} border`
                    }`}
                  >
                    {/* Safe Cell Shield Icon */}
                    {isSafe && (
                      <span className="text-amber-300 text-[10px] sm:text-xs drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] animate-pulse">
                        🛡️
                      </span>
                    )}

                    {/* Bonus Cell Icon */}
                    {!isSafe && bonus && (
                      <span className={`text-[10px] sm:text-xs ${bonus.color} drop-shadow`}>
                        {bonus.icon}
                      </span>
                    )}

                    {/* Turn Direction Arrow */}
                    {!isSafe && !bonus && turnArrow && (
                      <span className="text-[8px] sm:text-[9px] text-slate-500 opacity-60">
                        {turnArrow}
                      </span>
                    )}

                    {/* Green Home Run Step Indicator */}
                    {isGreenHomeRun && (
                      <span className="text-[9px] sm:text-[10px] font-black text-white drop-shadow">
                        {homeRunStep + 1}
                      </span>
                    )}

                    {/* Tokens on this cell */}
                    {tokensOnCell.map(({ token, player }) =>
                      renderTokenPawn(
                        token,
                        player,
                        selectableTokenIds.includes(token.id) && activeColor === player.color
                      )
                    )}
                  </div>
                );
              })}
            </div>

            {/* ===================== 2. GREEN BASE (Top Right: row 1-6, col 10-15) ===================== */}
            <div className="col-span-6 row-span-6 rounded-xl bg-gradient-to-bl from-teal-950 via-emerald-900 to-emerald-800 border-2 border-emerald-500/80 p-1.5 sm:p-2.5 shadow-[inset_0_4px_16px_rgba(0,0,0,0.85)] relative flex flex-col items-center justify-between">
              <div className="flex items-center justify-between w-full text-[10px] sm:text-xs font-black text-emerald-100">
                <span className="tracking-wider flex items-center gap-1 drop-shadow">
                  <span>🟢</span> GREEN PALACE
                </span>
                <span className="text-[8px] sm:text-[9px] px-1.5 py-0.5 rounded bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 font-bold">
                  Safe Yard
                </span>
              </div>

              {/* Green Base 4 Sunken Token Sockets */}
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-2xl bg-black/60 border border-emerald-500/50 shadow-inner flex items-center justify-center">
                {[0, 1, 2, 3].map((idx) => {
                  const pos = getBaseTokenCoords(idx);
                  return (
                    <div
                      key={`socket-green-${idx}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-emerald-500/35 bg-emerald-950/50 shadow-[inset_0_2px_8px_rgba(0,0,0,0.85)] flex items-center justify-center text-emerald-400/30 text-xs"
                      style={{ top: pos.top, left: pos.left }}
                    >
                      💎
                    </div>
                  );
                })}

                {players
                  .find((p) => p.color === 'green')
                  ?.tokens.map((token, idx) => {
                    if (token.position >= 0) return null;
                    const isSelectable = selectableTokenIds.includes(token.id) && activeColor === 'green';
                    const pos = getBaseTokenCoords(idx);
                    return (
                      <div
                        key={token.id}
                        className="absolute -translate-x-1/2 -translate-y-1/2"
                        style={{ top: pos.top, left: pos.left }}
                      >
                        {renderTokenPawn(token, players.find((p) => p.color === 'green')!, isSelectable)}
                      </div>
                    );
                  })}
              </div>

              <div className="text-[9px] sm:text-[10px] text-emerald-300 font-bold bg-emerald-950/70 px-2 py-0.5 rounded-full border border-emerald-500/40 shadow-sm">
                Roll 6 to Deploy
              </div>
            </div>

            {/* ===================== LEFT PATH GRID (Rows 7-9, Cols 1-6) ===================== */}
            <div className="col-span-6 row-span-3 grid grid-cols-6 grid-rows-3 gap-0.5 sm:gap-1">
              {Array.from({ length: 18 }).map((_, i) => {
                const row = Math.floor(i / 6) + 7;
                const col = (i % 6) + 1;

                const isRedHomeRun = row === 8 && col >= 2 && col <= 6;
                const homeRunStep = col - 2;

                let pathIdx: number | null = null;
                if (row === 7) {
                  if (col === 1) pathIdx = 51;
                  else if (col === 2) pathIdx = 0; // Red start (Safe)
                  else pathIdx = 1 + (col - 3); // 1..4
                } else if (row === 8 && col === 1) {
                  pathIdx = 50;
                } else if (row === 9) {
                  pathIdx = 49 - (col - 1); // 49..44
                }

                const isSafe = pathIdx !== null && SAFE_CELL_INDICES.includes(pathIdx);
                const bonus = pathIdx !== null ? BONUS_CELLS[pathIdx] : null;
                const turnArrow = pathIdx !== null ? TURN_ARROWS[pathIdx] : null;
                const tokensOnCell = pathIdx !== null
                  ? getTokensOnCell(pathIdx)
                  : isRedHomeRun
                  ? getTokensOnHomeRun('red', homeRunStep)
                  : [];

                return (
                  <div
                    key={`left-${i}`}
                    className={`relative rounded-[4px] sm:rounded-[6px] flex items-center justify-center transition-all ${
                      isRedHomeRun
                        ? 'bg-gradient-to-r from-red-500 via-rose-600 to-red-800 border border-red-300 text-white font-black shadow-sm'
                        : isSafe
                        ? `${currentTheme.safeCellBg} ${currentTheme.safeCellBorder} ${currentTheme.safeCellGlow} border-2`
                        : `${currentTheme.cellBg} ${currentTheme.cellBorder} border`
                    }`}
                  >
                    {isSafe && (
                      <span className="text-amber-300 text-[10px] sm:text-xs drop-shadow animate-pulse">
                        🛡️
                      </span>
                    )}

                    {!isSafe && bonus && (
                      <span className={`text-[10px] sm:text-xs ${bonus.color} drop-shadow`}>
                        {bonus.icon}
                      </span>
                    )}

                    {!isSafe && !bonus && turnArrow && (
                      <span className="text-[8px] sm:text-[9px] text-slate-500 opacity-60">
                        {turnArrow}
                      </span>
                    )}

                    {isRedHomeRun && (
                      <span className="text-[9px] sm:text-[10px] font-black text-white drop-shadow">
                        {homeRunStep + 1}
                      </span>
                    )}

                    {tokensOnCell.map(({ token, player }) =>
                      renderTokenPawn(
                        token,
                        player,
                        selectableTokenIds.includes(token.id) && activeColor === player.color
                      )
                    )}
                  </div>
                );
              })}
            </div>

            {/* ===================== CENTER SANCTUM (HOME OF TRIUMPH) ===================== */}
            <div className={`col-span-3 row-span-3 relative rounded-xl ${currentTheme.centerBg} border-2 border-amber-400 shadow-2xl flex items-center justify-center overflow-hidden`}>
              {/* 4 Converging Jewel Triangles with High-Gloss Facets */}
              <div className="absolute top-0 left-0 w-full h-1/2 bg-red-600/35 clip-triangle-top border-b border-white/20" />
              <div className="absolute top-0 right-0 h-full w-1/2 bg-emerald-600/35 clip-triangle-right border-l border-white/20" />
              <div className="absolute bottom-0 right-0 w-full h-1/2 bg-amber-500/35 clip-triangle-bottom border-t border-white/20" />
              <div className="absolute bottom-0 left-0 h-full w-1/2 bg-blue-600/35 clip-triangle-left border-r border-white/20" />

              {/* Rotating Divine Ray Halo */}
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-400/20 via-transparent to-amber-300/20 animate-[spin_12s_linear_infinite] pointer-events-none" />

              {/* Elevated 3D Golden Lotus Crown Medallion */}
              <div className="relative z-10 flex flex-col items-center justify-center p-1 sm:p-2 rounded-full bg-slate-950/90 border border-amber-400 shadow-[0_0_20px_#f59e0b]">
                <span className="text-lg sm:text-2xl font-black text-amber-300 drop-shadow-[0_0_12px_rgba(245,158,11,1)] animate-pulse">
                  ॐ
                </span>
                <span className="text-[7px] sm:text-[9px] font-black text-amber-200 tracking-widest uppercase">
                  HOME
                </span>
              </div>

              {/* Finished Tokens Celebratory Stack */}
              <div className="absolute inset-0 flex flex-wrap items-center justify-center gap-1 p-1 z-20 pointer-events-none">
                {getTokensInFinishedHome().map(({ token, player }) => (
                  <div key={`fin-${player.id}-${token.id}`} className="scale-75 animate-bounce">
                    {renderTokenPawn(token, player, false)}
                  </div>
                ))}
              </div>
            </div>

            {/* ===================== RIGHT PATH GRID (Rows 7-9, Cols 10-15) ===================== */}
            <div className="col-span-6 row-span-3 grid grid-cols-6 grid-rows-3 gap-0.5 sm:gap-1">
              {Array.from({ length: 18 }).map((_, i) => {
                const row = Math.floor(i / 6) + 7;
                const col = (i % 6) + 10;

                const isYellowHomeRun = row === 8 && col >= 10 && col <= 14;
                const homeRunStep = 14 - col;

                let pathIdx: number | null = null;
                if (row === 7) {
                  if (col === 10) pathIdx = 18;
                  else pathIdx = 19 + (col - 11); // 19..23
                } else if (row === 8 && col === 15) {
                  pathIdx = 24;
                } else if (row === 9) {
                  if (col === 15) pathIdx = 25;
                  else if (col === 14) pathIdx = 26; // Yellow Start (Safe)
                  else pathIdx = 27 + (13 - col); // 27..30
                }

                const isSafe = pathIdx !== null && SAFE_CELL_INDICES.includes(pathIdx);
                const bonus = pathIdx !== null ? BONUS_CELLS[pathIdx] : null;
                const turnArrow = pathIdx !== null ? TURN_ARROWS[pathIdx] : null;
                const tokensOnCell = pathIdx !== null
                  ? getTokensOnCell(pathIdx)
                  : isYellowHomeRun
                  ? getTokensOnHomeRun('yellow', homeRunStep)
                  : [];

                return (
                  <div
                    key={`right-${i}`}
                    className={`relative rounded-[4px] sm:rounded-[6px] flex items-center justify-center transition-all ${
                      isYellowHomeRun
                        ? 'bg-gradient-to-l from-amber-300 via-amber-500 to-yellow-600 border border-amber-200 text-slate-950 font-black shadow-sm'
                        : isSafe
                        ? `${currentTheme.safeCellBg} ${currentTheme.safeCellBorder} ${currentTheme.safeCellGlow} border-2`
                        : `${currentTheme.cellBg} ${currentTheme.cellBorder} border`
                    }`}
                  >
                    {isSafe && (
                      <span className="text-amber-300 text-[10px] sm:text-xs drop-shadow animate-pulse">
                        🛡️
                      </span>
                    )}

                    {!isSafe && bonus && (
                      <span className={`text-[10px] sm:text-xs ${bonus.color} drop-shadow`}>
                        {bonus.icon}
                      </span>
                    )}

                    {!isSafe && !bonus && turnArrow && (
                      <span className="text-[8px] sm:text-[9px] text-slate-500 opacity-60">
                        {turnArrow}
                      </span>
                    )}

                    {isYellowHomeRun && (
                      <span className="text-[9px] sm:text-[10px] font-black text-slate-950 drop-shadow">
                        {homeRunStep + 1}
                      </span>
                    )}

                    {tokensOnCell.map(({ token, player }) =>
                      renderTokenPawn(
                        token,
                        player,
                        selectableTokenIds.includes(token.id) && activeColor === player.color
                      )
                    )}
                  </div>
                );
              })}
            </div>

            {/* ===================== 4. BLUE BASE (Bottom Left: row 10-15, col 1-6) ===================== */}
            <div className="col-span-6 row-span-6 rounded-xl bg-gradient-to-tr from-blue-950 via-blue-900 to-blue-800 border-2 border-blue-500/80 p-1.5 sm:p-2.5 shadow-[inset_0_4px_16px_rgba(0,0,0,0.85)] relative flex flex-col items-center justify-between">
              <div className="flex items-center justify-between w-full text-[10px] sm:text-xs font-black text-blue-100">
                <span className="tracking-wider flex items-center gap-1 drop-shadow">
                  <span>🔵</span> BLUE PALACE
                </span>
                <span className="text-[8px] sm:text-[9px] px-1.5 py-0.5 rounded bg-blue-950/90 border border-blue-500/50 text-blue-300 font-bold">
                  Safe Yard
                </span>
              </div>

              {/* Blue Base 4 Sunken Token Sockets */}
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-2xl bg-black/60 border border-blue-500/50 shadow-inner flex items-center justify-center">
                {[0, 1, 2, 3].map((idx) => {
                  const pos = getBaseTokenCoords(idx);
                  return (
                    <div
                      key={`socket-blue-${idx}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-blue-500/35 bg-blue-950/50 shadow-[inset_0_2px_8px_rgba(0,0,0,0.85)] flex items-center justify-center text-blue-400/30 text-xs"
                      style={{ top: pos.top, left: pos.left }}
                    >
                      🌊
                    </div>
                  );
                })}

                {players
                  .find((p) => p.color === 'blue')
                  ?.tokens.map((token, idx) => {
                    if (token.position >= 0) return null;
                    const isSelectable = selectableTokenIds.includes(token.id) && activeColor === 'blue';
                    const pos = getBaseTokenCoords(idx);
                    return (
                      <div
                        key={token.id}
                        className="absolute -translate-x-1/2 -translate-y-1/2"
                        style={{ top: pos.top, left: pos.left }}
                      >
                        {renderTokenPawn(token, players.find((p) => p.color === 'blue')!, isSelectable)}
                      </div>
                    );
                  })}
              </div>

              <div className="text-[9px] sm:text-[10px] text-blue-300 font-bold bg-blue-950/70 px-2 py-0.5 rounded-full border border-blue-500/40 shadow-sm">
                Roll 6 to Deploy
              </div>
            </div>

            {/* ===================== BOTTOM DIVIDER / BLUE PATH (Cols 7-9, Rows 10-15) ===================== */}
            <div className="col-span-3 row-span-6 grid grid-cols-3 grid-rows-6 gap-0.5 sm:gap-1">
              {Array.from({ length: 18 }).map((_, i) => {
                const row = Math.floor(i / 3) + 10;
                const col = (i % 3) + 7;

                const isBlueHomeRun = col === 8 && row >= 10 && row <= 14;
                const homeRunStep = 14 - row;

                let pathIdx: number | null = null;
                if (col === 7) {
                  if (row === 15) pathIdx = 38;
                  else if (row === 14) pathIdx = 39; // Blue start (Safe)
                  else pathIdx = 40 + (13 - row); // 40..43
                } else if (col === 8 && row === 15) {
                  pathIdx = 37;
                } else if (col === 9) {
                  pathIdx = 36 - (15 - row); // 36..31
                }

                const isSafe = pathIdx !== null && SAFE_CELL_INDICES.includes(pathIdx);
                const bonus = pathIdx !== null ? BONUS_CELLS[pathIdx] : null;
                const turnArrow = pathIdx !== null ? TURN_ARROWS[pathIdx] : null;
                const tokensOnCell = pathIdx !== null
                  ? getTokensOnCell(pathIdx)
                  : isBlueHomeRun
                  ? getTokensOnHomeRun('blue', homeRunStep)
                  : [];

                return (
                  <div
                    key={`bottom-${i}`}
                    className={`relative rounded-[4px] sm:rounded-[6px] flex items-center justify-center transition-all ${
                      isBlueHomeRun
                        ? 'bg-gradient-to-t from-blue-400 via-blue-600 to-indigo-800 border border-blue-300 text-white font-black shadow-sm'
                        : isSafe
                        ? `${currentTheme.safeCellBg} ${currentTheme.safeCellBorder} ${currentTheme.safeCellGlow} border-2`
                        : `${currentTheme.cellBg} ${currentTheme.cellBorder} border`
                    }`}
                  >
                    {isSafe && (
                      <span className="text-amber-300 text-[10px] sm:text-xs drop-shadow animate-pulse">
                        🛡️
                      </span>
                    )}

                    {!isSafe && bonus && (
                      <span className={`text-[10px] sm:text-xs ${bonus.color} drop-shadow`}>
                        {bonus.icon}
                      </span>
                    )}

                    {!isSafe && !bonus && turnArrow && (
                      <span className="text-[8px] sm:text-[9px] text-slate-500 opacity-60">
                        {turnArrow}
                      </span>
                    )}

                    {isBlueHomeRun && (
                      <span className="text-[9px] sm:text-[10px] font-black text-white drop-shadow">
                        {homeRunStep + 1}
                      </span>
                    )}

                    {tokensOnCell.map(({ token, player }) =>
                      renderTokenPawn(
                        token,
                        player,
                        selectableTokenIds.includes(token.id) && activeColor === player.color
                      )
                    )}
                  </div>
                );
              })}
            </div>

            {/* ===================== 3. YELLOW BASE (Bottom Right: row 10-15, col 10-15) ===================== */}
            <div className="col-span-6 row-span-6 rounded-xl bg-gradient-to-tl from-amber-950 via-amber-900 to-yellow-800 border-2 border-amber-500/80 p-1.5 sm:p-2.5 shadow-[inset_0_4px_16px_rgba(0,0,0,0.85)] relative flex flex-col items-center justify-between">
              <div className="flex items-center justify-between w-full text-[10px] sm:text-xs font-black text-amber-100">
                <span className="tracking-wider flex items-center gap-1 drop-shadow">
                  <span>🟡</span> YELLOW PALACE
                </span>
                <span className="text-[8px] sm:text-[9px] px-1.5 py-0.5 rounded bg-amber-950/90 border border-amber-500/50 text-amber-300 font-bold">
                  Safe Yard
                </span>
              </div>

              {/* Yellow Base 4 Sunken Token Sockets */}
              <div className="relative w-28 h-28 sm:w-36 sm:h-36 md:w-40 md:h-40 rounded-2xl bg-black/60 border border-amber-500/50 shadow-inner flex items-center justify-center">
                {[0, 1, 2, 3].map((idx) => {
                  const pos = getBaseTokenCoords(idx);
                  return (
                    <div
                      key={`socket-yellow-${idx}`}
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-amber-500/35 bg-amber-950/50 shadow-[inset_0_2px_8px_rgba(0,0,0,0.85)] flex items-center justify-center text-amber-400/30 text-xs"
                      style={{ top: pos.top, left: pos.left }}
                    >
                      🦁
                    </div>
                  );
                })}

                {players
                  .find((p) => p.color === 'yellow')
                  ?.tokens.map((token, idx) => {
                    if (token.position >= 0) return null;
                    const isSelectable = selectableTokenIds.includes(token.id) && activeColor === 'yellow';
                    const pos = getBaseTokenCoords(idx);
                    return (
                      <div
                        key={token.id}
                        className="absolute -translate-x-1/2 -translate-y-1/2"
                        style={{ top: pos.top, left: pos.left }}
                      >
                        {renderTokenPawn(token, players.find((p) => p.color === 'yellow')!, isSelectable)}
                      </div>
                    );
                  })}
              </div>

              <div className="text-[9px] sm:text-[10px] text-amber-300 font-bold bg-amber-950/70 px-2 py-0.5 rounded-full border border-amber-500/40 shadow-sm">
                Roll 6 to Deploy
              </div>
            </div>
          </div>

          {/* ===================== ACTIVE ASTRA BOARD OVERLAY FX ===================== */}
          {activeAstraEffect && (
            <div className="absolute inset-0 z-30 flex items-center justify-center overflow-hidden rounded-3xl pointer-events-none">
              {/* Dismiss X button for Board Astra FX */}
              {onDismissAstraEffect && (
                <button
                  onClick={() => {
                    sound.playClick();
                    onDismissAstraEffect();
                  }}
                  className="pointer-events-auto absolute top-3 right-3 z-40 px-3 py-1.5 rounded-full bg-slate-950/90 hover:bg-red-950/90 border-2 border-amber-400 hover:border-red-400 text-amber-300 hover:text-white text-[11px] font-black tracking-wider uppercase flex items-center gap-1.5 shadow-[0_0_15px_rgba(245,158,11,0.5)] active:scale-95 transition cursor-pointer"
                  title="Dismiss Astra Board FX"
                  aria-label="Close Screen"
                >
                  <span>Close Astra</span>
                  <X size={15} />
                </button>
              )}

              {activeAstraEffect === 'tandav' && (
                <div className="w-full h-full bg-cyan-500/25 backdrop-invert-0 animate-pulse flex items-center justify-center">
                  <div className="w-72 h-72 sm:w-88 sm:h-88 rounded-full border-4 border-cyan-400 shadow-[0_0_80px_#06b6d4] animate-spin" />
                  <span className="absolute text-5xl sm:text-6xl animate-bounce">🔱</span>
                </div>
              )}

              {activeAstraEffect === 'sudarshan-spin' && (
                <div className="w-full h-full bg-amber-500/30 flex items-center justify-center">
                  <div className="w-80 h-80 sm:w-96 sm:h-96 rounded-full border-8 border-amber-400 border-dashed animate-[spin_2s_linear_infinite] shadow-[0_0_100px_#f59e0b]" />
                  <span className="absolute text-6xl text-amber-300 animate-pulse">🌀</span>
                </div>
              )}

              {activeAstraEffect === 'gada-smash' && (
                <div className="w-full h-full bg-rose-600/35 flex items-center justify-center animate-[ping_0.5s_ease-out]">
                  <div className="w-96 h-96 rounded-full border-4 border-red-500 shadow-[0_0_120px_#ef4444]" />
                  <span className="absolute text-6xl">🔨</span>
                </div>
              )}

              {activeAstraEffect === 'lightning-vajra' && (
                <div className="w-full h-full bg-purple-600/30 flex items-center justify-center animate-pulse">
                  <div className="w-80 h-80 rounded-full border-4 border-purple-400 shadow-[0_0_100px_#a855f7]" />
                  <span className="absolute text-6xl animate-bounce">⚡</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 4. BOTTOM IN-GAME PLAYER CORNERS (Hapi Ludo & Queen Ludo style) */}
      <div className="w-full grid grid-cols-2 gap-2 mt-2 px-1">
        {renderCornerPlayer('blue', 'bottom-left')}
        {renderCornerPlayer('yellow', 'bottom-right')}
      </div>
    </div>
  );
};
