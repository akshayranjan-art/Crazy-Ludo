import React, { useState } from 'react';
import { COSMIC_LOKAS, DASHAVATARA } from '../data/gameConstants';
import { X, Sparkles, BookOpen, Compass, Shield, Award } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface CosmicCodexModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimBlessing: (coins: number, diamonds: number) => void;
  hasClaimedBlessing: boolean;
}

export const CosmicCodexModal: React.FC<CosmicCodexModalProps> = ({
  isOpen,
  onClose,
  onClaimBlessing,
  hasClaimedBlessing,
}) => {
  const [activeTab, setActiveTab] = useState<'lokas' | 'dashavatara' | 'zodiac' | 'creatures'>('lokas');

  if (!isOpen) return null;

  const handleClaim = () => {
    sound.playSafeCell();
    onClaimBlessing(50000, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-950 border-2 border-indigo-500/50 rounded-3xl shadow-[0_0_60px_rgba(99,102,241,0.25)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-indigo-500/20 bg-gradient-to-r from-indigo-950/70 via-slate-900 to-purple-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400 flex items-center justify-center text-xl shadow-[0_0_15px_#6366f1]">
              🌌
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-indigo-200 tracking-wide font-cinzel">
                  COSMIC CODEX & 14 LOKAS
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/40">
                  SACRED UNIVERSE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Explore the 14 cosmological dimensions, Dashavatara, and zodiac crystals
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-4 py-2 border-b border-slate-800 flex gap-2 overflow-x-auto bg-slate-900/50">
          {[
            { id: 'lokas', label: '14 Lokas (Realms)', icon: '🪐' },
            { id: 'dashavatara', label: '10 Dashavatara', icon: '🪷' },
            { id: 'zodiac', label: '12 Zodiac & Gems', icon: '💎' },
            { id: 'creatures', label: '12 Month Mythic Rides', icon: '🐉' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as typeof activeTab);
                sound.playTokenHop(0);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white border-indigo-400 shadow-[0_0_10px_rgba(99,102,241,0.5)]'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'lokas' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 text-xs text-slate-300 flex items-center justify-between">
                <span>The 14 Lokas bridge from the supreme Brahmaloka down to Patala Loka.</span>
                {!hasClaimedBlessing && (
                  <button
                    onClick={handleClaim}
                    className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md transition-colors"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Claim Codex Blessing (+50K Coins)</span>
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {COSMIC_LOKAS.map((loka) => (
                  <div
                    key={loka.id}
                    className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 transition-all flex items-start gap-3"
                  >
                    <div className="w-8 h-8 rounded-xl bg-indigo-900/60 border border-indigo-400/40 flex items-center justify-center font-mono font-bold text-amber-300 text-xs flex-shrink-0">
                      #{loka.id}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-100 font-cinzel">
                        {loka.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {loka.desc}
                      </p>
                      <span className="inline-block mt-1 text-[9px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30 font-semibold">
                        {loka.level}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'dashavatara' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {DASHAVATARA.map((ava, idx) => (
                <div
                  key={ava.name}
                  className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition-all flex items-center gap-3.5"
                >
                  <div className="text-3xl p-2 rounded-xl bg-amber-500/10 border border-amber-400/30 flex-shrink-0">
                    {ava.symbol}
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-amber-400">Avatar #{idx + 1}</span>
                    <h4 className="text-sm font-bold text-slate-100 font-cinzel">
                      {ava.name}
                    </h4>
                    <p className="text-xs text-slate-300 font-medium">{ava.form}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Power: {ava.virtue}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'zodiac' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {[
                { sign: 'Aries (मेष)', stone: 'Garnet', power: 'Fire Bravery', icon: '♈' },
                { sign: 'Taurus (वृषभ)', stone: 'Rose Quartz', power: 'Abundance', icon: '♉' },
                { sign: 'Gemini (मिथुन)', stone: 'Citrine', power: 'Intellect', icon: '♊' },
                { sign: 'Cancer (कर्क)', stone: 'Moonstone', power: 'Intuition', icon: '♋' },
                { sign: 'Leo (सिंह)', stone: "Tiger's Eye", power: 'Solar Royalty', icon: '♌' },
                { sign: 'Virgo (कन्या)', stone: 'Aventurine', power: 'Healing Harmony', icon: '♍' },
                { sign: 'Libra (तुला)', stone: 'Lapis Lazuli', power: 'Truth & Justice', icon: '♎' },
                { sign: 'Scorpio (वृश्चिक)', stone: 'Obsidian', power: 'Deep Mysteries', icon: '♏' },
                { sign: 'Sagittarius (धनु)', stone: 'Amethyst', power: 'Celestial Aim', icon: '♐' },
                { sign: 'Capricorn (मकर)', stone: 'Onyx', power: 'Endurance', icon: '♑' },
                { sign: 'Aquarius (कुंभ)', stone: 'Quartz', power: 'Cosmic Vision', icon: '♒' },
                { sign: 'Pisces (मीन)', stone: 'Aquamarine', power: 'Ocean Grace', icon: '♓' },
              ].map((z) => (
                <div key={z.sign} className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-center flex flex-col items-center">
                  <span className="text-2xl mb-1">{z.icon}</span>
                  <span className="text-xs font-bold text-slate-200">{z.sign}</span>
                  <span className="text-[11px] text-amber-400 font-semibold">{z.stone}</span>
                  <span className="text-[10px] text-slate-400 mt-1">{z.power}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'creatures' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {[
                { month: 'January', ride: 'Ice Dragon', icon: '🐉', power: 'Frost Aura' },
                { month: 'February', ride: 'Crystal Carriage', icon: '🛷', power: 'Diamond Sheen' },
                { month: 'March', ride: 'Sky Whale', icon: '🐋', power: 'Celestial Song' },
                { month: 'April', ride: 'Elven Longboat', icon: '⛵', power: 'Forest Drift' },
                { month: 'May', ride: 'Phoenix', icon: '🦅', power: 'Solar Fire' },
                { month: 'June', ride: 'Unicorn', icon: '🦄', power: 'Purity Shield' },
                { month: 'July', ride: 'Floating Castle', icon: '🏰', power: 'Citadel Grace' },
                { month: 'August', ride: 'Shadow Steed', icon: '🐎', power: 'Night Speed' },
                { month: 'September', ride: 'Steampunk Airship', icon: '🛸', power: 'Steam Wings' },
                { month: 'October', ride: 'Pumpkin Coach', icon: '🎃', power: 'Moon Magic' },
                { month: 'November', ride: 'Griffin', icon: '🦅', power: 'Gryphon Strike' },
                { month: 'December', ride: 'Sleigh of Stars', icon: '✨', power: 'Starlight Trail' },
              ].map((m) => (
                <div key={m.month} className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-center flex flex-col items-center">
                  <span className="text-2xl mb-1">{m.icon}</span>
                  <span className="text-[10px] text-indigo-400 font-bold uppercase">{m.month}</span>
                  <span className="text-xs font-bold text-slate-200">{m.ride}</span>
                  <span className="text-[10px] text-amber-400 mt-0.5">{m.power}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
