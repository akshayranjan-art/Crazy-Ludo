import React, { useState } from 'react';
import { X, Sparkles, Flame, Shield, Zap, Check } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface DiceForgeModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onDeductCoins: (amt: number) => void;
  onDeductDiamonds: (amt: number) => void;
}

export const DiceForgeModal: React.FC<DiceForgeModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onDeductCoins,
  onDeductDiamonds,
}) => {
  const [activeSkin, setActiveSkin] = useState('gold');
  const [isForging, setIsForging] = useState(false);

  if (!isOpen) return null;

  const DICE_SKINS = [
    { id: 'gold', name: 'Golden Surya Dice', desc: 'Crafted with cosmic solar rays', cost: 100, color: 'from-amber-400 to-yellow-600' },
    { id: 'neon', name: 'Cyber Neon Cube', desc: 'Electrified matrix pulse effect', cost: 150, color: 'from-cyan-400 to-blue-600' },
    { id: 'ruby', name: 'Agni Ruby Core', desc: 'Blazing embers on every bounce', cost: 200, color: 'from-red-500 to-rose-700' },
    { id: 'void', name: 'Amrit Void Crystal', desc: 'Celestial dark matter glow', cost: 300, color: 'from-purple-500 to-indigo-700' },
  ];

  const handleForge = (skin: typeof DICE_SKINS[0]) => {
    if (userDiamonds < skin.cost) {
      sound.playError();
      return;
    }
    sound.playFanfare();
    onDeductDiamonds(skin.cost);
    setIsForging(true);
    setTimeout(() => {
      setIsForging(false);
      setActiveSkin(skin.id);
      confetti({ particleCount: 50, spread: 50 });
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#1c1205] via-[#0e0717] to-black text-slate-100 shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600/40 via-orange-600/30 to-slate-900 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-2xl shadow-lg border border-amber-300">
              🎲
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-300">
                Celestial 3D Dice Forge
              </h3>
              <p className="text-xs text-slate-300">
                Forge magical skins and trail effects
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-3 overflow-y-auto max-h-[75vh]">
          {DICE_SKINS.map((skin) => {
            const isEquipped = activeSkin === skin.id;
            return (
              <div
                key={skin.id}
                className="p-3.5 rounded-2xl bg-slate-900/70 border border-amber-500/20 flex items-center justify-between hover:border-amber-400/50 transition"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${skin.color} flex items-center justify-center text-2xl shadow-lg border border-white/20`}>
                    🎲
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white">{skin.name}</h4>
                    <p className="text-[11px] text-slate-400">{skin.desc}</p>
                    <span className="text-[11px] text-amber-300 font-bold">{skin.cost} 💎</span>
                  </div>
                </div>

                <button
                  onClick={() => handleForge(skin)}
                  disabled={isForging || isEquipped}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-black uppercase tracking-wider transition ${
                    isEquipped
                      ? 'bg-emerald-500 text-slate-950 cursor-default flex items-center gap-1'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95 cursor-pointer'
                  }`}
                >
                  {isEquipped ? <><Check size={12} /> Equipped</> : 'Forge & Equip'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
