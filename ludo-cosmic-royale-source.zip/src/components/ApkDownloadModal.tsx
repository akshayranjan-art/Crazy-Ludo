import React, { useState, useEffect } from 'react';
import {
  X,
  Smartphone,
  Download,
  Copy,
  Check,
  ExternalLink,
  Sparkles,
  QrCode,
  ShieldCheck,
  Zap,
  Archive,
  FolderDown,
  FileCode,
  Package,
  Layers,
  Info,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface ApkDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<ApkDownloadModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'zip' | 'web2app'>('zip');
  const [copiedLink, setCopiedLink] = useState<'app' | 'buildZip' | 'sourceZip' | null>(null);
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [showQrCode, setShowQrCode] = useState(false);
  const [showInstallGuideToast, setShowInstallGuideToast] = useState(false);

  // Active dev container URL
  const APP_URL = 'https://ais-dev-g4k6wbsgsqg2cd4xxapbft-499782633579.asia-southeast1.run.app';
  const BUILD_ZIP_URL = `${APP_URL}/ludo-cosmic-royale-web-build.zip`;
  const SOURCE_ZIP_URL = `${APP_URL}/ludo-cosmic-royale-source.zip`;
  const PWABUILDER_URL = `https://www.pwabuilder.com?url=${encodeURIComponent(APP_URL)}`;
  const QR_CODE_URL = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(APP_URL)}`;

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleCopy = (text: string, type: 'app' | 'buildZip' | 'sourceZip') => {
    sound.playClick();
    navigator.clipboard.writeText(text);
    setCopiedLink(type);
    confetti({ particleCount: 35, spread: 50 });
    setTimeout(() => setCopiedLink(null), 3000);
  };

  const handleDownload = (filename: string) => {
    sound.playFanfare();
    confetti({ particleCount: 60, spread: 70 });
    const a = document.createElement('a');
    a.href = `/${filename}`;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleInstallPWA = async () => {
    if (installPrompt) {
      sound.playFanfare();
      installPrompt.prompt();
      const choiceResult = await installPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        confetti({ particleCount: 100, spread: 80 });
      }
      setInstallPrompt(null);
    } else {
      handleCopy(APP_URL, 'app');
      setShowInstallGuideToast(true);
      setTimeout(() => setShowInstallGuideToast(false), 6000);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#140b25] via-[#0c0617] to-black text-slate-100 shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600/30 via-purple-700/30 to-emerald-600/30 border-b border-amber-500/30 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 flex items-center justify-center text-2xl shadow-lg border border-amber-300 text-slate-950 font-black">
              📦
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-emerald-400">
                  ZIP Download & APK Center
                </h3>
              </div>
              <p className="text-xs text-slate-300">
                Direct ZIP files for Web2App, Website 2 APK, offline use & live link
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white cursor-pointer"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="p-2 bg-black/50 border-b border-white/10 flex gap-2 shrink-0 px-4">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('zip');
            }}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer ${
              activeTab === 'zip'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Archive size={15} />
            <span>📦 Download ZIP Files (Offline / APK)</span>
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('web2app');
            }}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition cursor-pointer ${
              activeTab === 'web2app'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md'
                : 'bg-white/5 text-slate-300 hover:bg-white/10'
            }`}
          >
            <Smartphone size={15} />
            <span>🌐 Web2App Live URL & WebAPK</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto">
          {activeTab === 'zip' ? (
            /* ============================================================== */
            /* TAB 1: ZIP FILE DOWNLOADS (Requested by user)                 */
            /* ============================================================== */
            <div className="space-y-4">
              {/* PRIMARY ZIP: Production Web Build (Ready for Web2App ZIP Mode) */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-950 border-2 border-amber-400 shadow-[0_0_30px_rgba(245,158,11,0.25)] space-y-3.5 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 shadow">
                    ⭐ RECOMMENDED FOR WEB2APP & OFFLINE APK
                  </span>
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <ShieldCheck size={14} /> Ready (2.6 MB)
                  </span>
                </div>

                <div>
                  <h4 className="text-lg font-black text-amber-200 flex items-center gap-2">
                    <Package size={20} className="text-amber-400" />
                    <span>Offline Web Build ZIP (Ready to Convert)</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    Is ZIP ke andar complete compiled HTML, CSS, JS, 3D Board, audio sounds aur icons hain. Web2App ya Website 2 APK me is ZIP ko daal kar <strong>100% Offline APK</strong> ban sakti hai jo bina kisi internet/server ke phone me seedha chalegi!
                  </p>
                </div>

                {/* Direct 1-Click Download Button */}
                <div className="space-y-2 pt-1">
                  <button
                    onClick={() => handleDownload('ludo-cosmic-royale-web-build.zip')}
                    className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-[0_0_25px_rgba(245,158,11,0.5)] active:scale-95 transition cursor-pointer"
                  >
                    <Download size={20} className="stroke-[2.5]" />
                    <span>Download Web Build ZIP (2.6 MB)</span>
                  </button>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      readOnly
                      value={BUILD_ZIP_URL}
                      className="w-full bg-black/80 border border-amber-500/40 rounded-xl px-3 py-2 text-[11px] font-mono text-amber-300 select-all focus:outline-none"
                    />
                    <button
                      onClick={() => handleCopy(BUILD_ZIP_URL, 'buildZip')}
                      className={`px-3 py-2 rounded-xl text-xs font-bold shrink-0 transition cursor-pointer ${
                        copiedLink === 'buildZip'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-white/10 hover:bg-white/20 text-slate-200'
                      }`}
                    >
                      {copiedLink === 'buildZip' ? 'Copied!' : 'Copy Direct URL'}
                    </button>
                  </div>
                </div>

                {/* What's Inside details */}
                <div className="p-3 rounded-xl bg-black/50 border border-amber-500/20 text-[11px] text-slate-300 space-y-1">
                  <div className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Layers size={13} />
                    <span>Is ZIP me kya hai:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-300 pl-1">
                    <li><strong className="text-white">index.html</strong> (Relative paths configured for WebView & offline)</li>
                    <li><strong className="text-white">assets/</strong> (Minified 3D Game Engine + CSS)</li>
                    <li><strong className="text-white">manifest.json + sw.js</strong> (PWA offline service worker)</li>
                    <li><strong className="text-white">icon-192.jpg & icon-512.jpg</strong> (App icons ready for APK)</li>
                  </ul>
                </div>
              </div>

              {/* SECONDARY ZIP: Full Project Source Code (React + Vite + TypeScript) */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-slate-900 to-slate-950 border border-indigo-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                    FOR DEVELOPERS / VS CODE
                  </span>
                  <span className="text-xs text-indigo-300 font-bold">14.8 MB</span>
                </div>

                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <FileCode size={18} className="text-indigo-400" />
                    <span>Full React Project Source Code ZIP</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Poora source code (src, components, package.json, vite.config.ts). Isko VS Code me open karein, ya Android Studio / Capacitor me daal kar native APK compile karein.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownload('ludo-cosmic-royale-source.zip')}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition cursor-pointer shadow"
                  >
                    <FolderDown size={16} />
                    <span>Download Source Code (14.8 MB)</span>
                  </button>

                  <button
                    onClick={() => handleCopy(SOURCE_ZIP_URL, 'sourceZip')}
                    className={`px-3 py-2.5 rounded-xl text-xs font-bold shrink-0 transition cursor-pointer ${
                      copiedLink === 'sourceZip'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-white/10 hover:bg-white/20 text-slate-200'
                    }`}
                  >
                    {copiedLink === 'sourceZip' ? 'Copied!' : 'Copy URL'}
                  </button>
                </div>
              </div>

              {/* How to use ZIP Guide */}
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs space-y-1.5">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <Info size={15} />
                  <span>💡 ZIP File se APK Kaise Banayein (Guide):</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] pl-1 leading-relaxed">
                  <li>Upar se <strong className="text-yellow-300">Offline Web Build ZIP</strong> download karein.</li>
                  <li><strong>Web2App</strong> app ya <strong>Website 2 APK Builder</strong> open karein.</li>
                  <li>Wahan URL ke bajaye <strong>"Local HTML Website / ZIP File"</strong> option select karein.</li>
                  <li>Download ki hui ZIP file chunein aur <strong>"Build APK"</strong> dabayein.</li>
                  <li>APK install karein — bina kisi server error ke game phone me turant chalega!</li>
                </ol>
              </div>
            </div>
          ) : (
            /* ============================================================== */
            /* TAB 2: WEB2APP LIVE URL & DIRECT WEBAPK                        */
            /* ============================================================== */
            <div className="space-y-4">
              {/* Web2App Live URL */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 via-slate-900 to-slate-950 border border-emerald-400/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black">
                    LIVE SYNC URL
                  </span>
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <ShieldCheck size={13} /> Active
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-black text-emerald-200">
                    Live Web2App URL (Auto-Updates)
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Agar aap chahte hain ki AI Studio ke changes bina APK re-install kiye sync hon:
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={APP_URL}
                    className="w-full bg-black/80 border border-emerald-500/40 rounded-xl px-3 py-2.5 text-xs font-mono text-emerald-300 select-all focus:outline-none"
                  />
                  <button
                    onClick={() => handleCopy(APP_URL, 'app')}
                    className={`px-4 py-2.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition shrink-0 cursor-pointer ${
                      copiedLink === 'app'
                        ? 'bg-emerald-500 text-slate-950'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                    }`}
                  >
                    {copiedLink === 'app' ? <Check size={15} /> : <Copy size={15} />}
                    <span>{copiedLink === 'app' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* QR Code Toggle */}
                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => setShowQrCode(!showQrCode)}
                    className="text-xs text-emerald-300 hover:text-emerald-200 flex items-center gap-1.5 underline cursor-pointer"
                  >
                    <QrCode size={14} />
                    <span>{showQrCode ? 'Hide QR Code' : 'Scan QR Code with Phone'}</span>
                  </button>
                </div>

                {showQrCode && (
                  <div className="p-3 bg-white/5 border border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2">
                    <div className="p-2 bg-white rounded-xl shadow-lg">
                      <img
                        src={QR_CODE_URL}
                        alt="Ludo App QR Code"
                        className="w-36 h-36 object-contain"
                      />
                    </div>
                    <p className="text-[11px] text-slate-300 text-center">
                      Phone camera se scan karke direct live preview kholein
                    </p>
                  </div>
                )}
              </div>

              {/* Direct Android 1-Click Install */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-950/50 via-slate-900 to-slate-950 border border-teal-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-400/30">
                    DIRECT INSTALL (WEBAPK)
                  </span>
                  <span className="text-xs text-amber-300 font-bold flex items-center gap-1">
                    <Zap size={12} /> 1-Click
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Smartphone size={17} className="text-teal-400" />
                    <span>Install Directly on Android Phone</span>
                  </h4>
                  <p className="text-xs text-slate-300 mt-1">
                    Bina kisi converter ke direct phone ke home screen aur app drawer me native app ki tarah install karein:
                  </p>
                </div>

                <button
                  onClick={handleInstallPWA}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow cursor-pointer active:scale-95 transition"
                >
                  <Download size={16} />
                  <span>{installPrompt ? 'Install App on Phone Now' : 'Install / Add to Home Screen'}</span>
                </button>

                {showInstallGuideToast && (
                  <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-400 text-[11px] text-emerald-200 animate-fade-in">
                    <strong className="text-white">Chrome me kholein:</strong> 3-dots (⋮) par tap karke <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> select karein.
                  </div>
                )}
              </div>

              {/* PWABuilder Signed APK */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/40 via-slate-900 to-slate-950 border border-purple-500/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/30">
                    MICROSOFT PWABUILDER
                  </span>
                  <span className="text-xs text-purple-300 font-bold">Standalone .APK</span>
                </div>

                <p className="text-xs text-slate-300">
                  Microsoft PWABuilder tool se signed `.apk` file generate karein:
                </p>

                <a
                  href={PWABUILDER_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => sound.playClick()}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow active:scale-95 transition cursor-pointer"
                >
                  <span>Build .APK with PWABuilder</span>
                  <ExternalLink size={14} />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

