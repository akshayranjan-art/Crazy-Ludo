import React, { useState } from 'react';
import { RARE_PETS } from '../data/gameConstants';
import { PetItem, PetRarity, PetBehaviorState } from '../types/game';
import { X, Heart, Sparkles, Utensils, Award, Check, Shield, Flame, Activity } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface PetUniverseModalProps {
  isOpen: boolean;
  onClose: () => void;
  pets: PetItem[];
  equippedPetId: string | null;
  onEquipPet: (pet: PetItem) => void;
  onFeedPet: (petId: string) => void;
}

export const PetUniverseModal: React.FC<PetUniverseModalProps> = ({
  isOpen,
  onClose,
  pets,
  equippedPetId,
  onEquipPet,
  onFeedPet,
}) => {
  const [selectedPet, setSelectedPet] = useState<PetItem>(pets[0] || RARE_PETS[0]);
  const [selectedRarity, setSelectedRarity] = useState<string>('All');
  const [activeBehavior, setActiveBehavior] = useState<PetBehaviorState>('sit');
  const [petDialogue, setPetDialogue] = useState<string>('Ready to accompany you to the live 8-player room!');
  const [showHeartBurst, setShowHeartBurst] = useState(false);

  if (!isOpen) return null;

  const currentPet = pets.find((p) => p.id === selectedPet.id) || selectedPet;
  const isEquipped = equippedPetId === currentPet.id;

  const filteredPets =
    selectedRarity === 'All'
      ? pets
      : pets.filter((p) => p.rarity === selectedRarity);

  const handleFeed = () => {
    sound.playTokenHop(2);
    setShowHeartBurst(true);
    setTimeout(() => setShowHeartBurst(false), 900);
    onFeedPet(currentPet.id);

    const dialogues = [
      'Yummy! Affection increased! May your next roll be a 6! ✨',
      'Purrr! My divine scales shine brighter for your victory! 🐉',
      'Delicious stardust berry! Ready to roar on token capture! 🌟',
      'Thanks Master! Your Ludo safe cells are blessed! 🛡️',
    ];
    setPetDialogue(dialogues[Math.floor(Math.random() * dialogues.length)]);
  };

  const handleSetBehavior = (behavior: PetBehaviorState) => {
    setActiveBehavior(behavior);
    sound.playClick();
    if (behavior === 'celebrate') {
      confetti({ particleCount: 35, spread: 50 });
      setPetDialogue('Yay! Celebrating your rolls with stardust fireworks! 🎉');
    } else if (behavior === 'sleep') {
      setPetDialogue('Zzz... Peacefully resting beside your avatar frame... 💤');
    } else if (behavior === 'walk') {
      setPetDialogue('Trotting gracefully around your player corner! 🐾');
    } else if (behavior === 'react') {
      sound.playFanfare();
      setPetDialogue('RAWR! Ready to bow and roar upon Astra weapon cast! ⚡');
    } else {
      setPetDialogue('Sitting regally beside your dice cup! 🧘');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl max-h-[94vh] flex flex-col bg-slate-950 border-2 border-emerald-500/50 rounded-3xl shadow-[0_0_60px_rgba(16,185,129,0.25)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-emerald-500/20 bg-gradient-to-r from-emerald-950/80 via-slate-900 to-indigo-950/80">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-2xl shadow-[0_0_15px_#10b981]">
              🐉
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-emerald-200 tracking-wide font-cinzel">
                  30 ULTRA-RARE PET COMPANIONS
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-black border border-emerald-500/40">
                  BIBLE ITEMS 12 & 13
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Rule: <strong>One pet per seated player</strong> • Extremely rare • <strong>Not purchasable with diamonds</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Rarity Progression Filter Bar (Rare → Epic → Mythic → Ancient → Divine → ???) */}
        <div className="flex items-center gap-1.5 p-2 bg-slate-900/80 border-b border-slate-800 overflow-x-auto scrollbar-none">
          {['All', 'Rare', 'Epic', 'Mythic', 'Ancient', 'Divine', '???'].map((rarity) => (
            <button
              key={rarity}
              onClick={() => {
                sound.playClick();
                setSelectedRarity(rarity);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                selectedRarity === rarity
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black shadow-md'
                  : 'bg-slate-800/60 text-slate-400 hover:text-white'
              }`}
            >
              {rarity === 'All' ? 'All 30 Pets' : `${rarity} Rarity`}
            </button>
          ))}
        </div>

        {/* Content: Left List & Right Active Showcase */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12">
          
          {/* Pet Selection Grid (Cols 1-7) */}
          <div className="md:col-span-7 p-4 overflow-y-auto border-r border-slate-800/80 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {filteredPets.map((pet) => {
                const isSelected = selectedPet.id === pet.id;
                const isItemEquipped = equippedPetId === pet.id;

                return (
                  <div
                    key={pet.id}
                    onClick={() => {
                      setSelectedPet(pet);
                      sound.playTokenHop(1);
                    }}
                    className={`relative rounded-2xl p-2.5 flex flex-col items-center text-center cursor-pointer border transition-all ${
                      isSelected
                        ? 'bg-gradient-to-b from-emerald-950/80 to-slate-900 border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)] scale-[1.02]'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {/* Index badge */}
                    <div className="absolute top-1.5 left-1.5 px-1.5 py-0.2 rounded bg-black/60 text-[9px] font-black text-amber-300">
                      #{pet.numberIndex || 1}
                    </div>

                    {isItemEquipped && (
                      <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-[10px] font-black z-10">
                        <Check className="w-3 h-3" />
                      </div>
                    )}

                    <div className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl mb-1.5 bg-black/60 border border-emerald-500/30">
                      {pet.icon || '🐉'}
                    </div>

                    <span className="text-xs font-bold text-slate-100 truncate w-full">
                      {pet.name}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400">
                      {pet.rarity}
                    </span>
                    <span className="text-[8px] text-slate-400 truncate w-full mt-0.5">
                      {pet.unlockRequirement}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Active Pet Spotlight (Cols 8-12) */}
          <div className="md:col-span-5 p-5 flex flex-col justify-between bg-slate-950/90 relative overflow-y-auto">
            {/* Heart burst animation on feed */}
            {showHeartBurst && (
              <div className="absolute inset-0 z-30 pointer-events-none flex items-center justify-center">
                <span className="text-6xl animate-ping text-rose-500">💖</span>
              </div>
            )}

            <div>
              {/* Pet Large Showcase */}
              <div className="relative w-28 h-28 mx-auto rounded-3xl overflow-hidden border-2 border-emerald-400/70 shadow-[0_0_35px_rgba(16,185,129,0.4)] mb-3 bg-gradient-to-br from-emerald-950 to-slate-950 flex items-center justify-center">
                <span className="text-5xl">{currentPet.icon || '🐉'}</span>
                <div className="absolute bottom-1.5 left-1.5 px-2 py-0.5 rounded-full bg-black/70 text-[9px] font-bold text-emerald-300 border border-emerald-500/40">
                  {currentPet.element}
                </div>
              </div>

              {/* Title & Stats */}
              <div className="text-center mb-2">
                <div className="flex items-center justify-center gap-1.5">
                  <h3 className="text-base font-black text-slate-100 font-cinzel">
                    #{currentPet.numberIndex || 1} {currentPet.name}
                  </h3>
                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-yellow-300 font-black border border-amber-500/40">
                    {currentPet.rarity}
                  </span>
                </div>
                <p className="text-xs text-emerald-400 font-semibold mt-0.5">
                  {currentPet.species}
                </p>
              </div>

              {/* Behavior Selector (Walk, sit, sleep, celebrate, react to astra) */}
              <div className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 mb-3 space-y-1.5">
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block">
                  Pet Behavior State (Bible Item 12):
                </span>
                <div className="grid grid-cols-5 gap-1">
                  {[
                    { id: 'walk', label: '🐾 Walk' },
                    { id: 'sit', label: '🧘 Sit' },
                    { id: 'sleep', label: '💤 Sleep' },
                    { id: 'celebrate', label: '🎉 Cheer' },
                    { id: 'react', label: '⚡ React' },
                  ].map((b) => (
                    <button
                      key={b.id}
                      onClick={() => handleSetBehavior(b.id as PetBehaviorState)}
                      className={`py-1 rounded-lg text-[9px] font-bold transition ${
                        activeBehavior === b.id
                          ? 'bg-emerald-500 text-slate-950 font-black shadow-sm'
                          : 'bg-slate-950 text-slate-400 hover:text-white'
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Speech bubble dialogue */}
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-300 italic mb-3 text-center">
                "{petDialogue}"
              </div>

              {/* Affection & Unlock */}
              <div className="space-y-2 mb-3">
                <div className="flex justify-between text-xs text-slate-400 font-medium">
                  <span className="flex items-center gap-1 text-rose-400">
                    <Heart className="w-3.5 h-3.5 fill-rose-500" /> Affection
                  </span>
                  <span className="font-mono text-slate-200">{currentPet.affection}/100</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-amber-400 rounded-full transition-all duration-500"
                    style={{ width: `${currentPet.affection}%` }}
                  />
                </div>

                <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/20 text-[11px] text-slate-300">
                  <span className="font-bold text-emerald-400">Unlock Milestone: </span>
                  {currentPet.unlockRequirement}
                </div>
                
                <div className="text-[10px] text-amber-300 font-semibold">
                  Passive Bonus: {currentPet.bonus}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={handleFeed}
                className="flex-1 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <Utensils className="w-3.5 h-3.5" />
                <span>Feed Treat</span>
              </button>

              <button
                onClick={() => onEquipPet(currentPet)}
                disabled={!currentPet.unlocked}
                className={`flex-1 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md ${
                  !currentPet.unlocked
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : isEquipped
                    ? 'bg-emerald-500 text-slate-950 font-black'
                    : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isEquipped ? 'Active Seat Pet' : 'Equip to Seat'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
