import React from 'react';

interface ModalFadeWrapperProps {
  isClosing: boolean;
  children: React.ReactNode;
}

/**
 * High-performance wrapper that applies a smooth 'fade-out' exit animation
 * (opacity fade-out, subtle scale down, blur filter & pointer-events disabled)
 * when a modal or overlay is dismissed via close buttons or Escape key.
 */
export const ModalFadeWrapper: React.FC<ModalFadeWrapperProps> = ({
  isClosing,
  children,
}) => {
  if (!isClosing) {
    return <>{children}</>;
  }

  return (
    <div className="fixed inset-0 z-[70] pointer-events-none animate-modal-exit">
      {children}
    </div>
  );
};
