import React from 'react';
import {
  X,
  Sparkles,
  Zap,
  Gift,
  Gamepad2,
  BookOpen,
  Box,
  ShieldCheck,
  Award,
  Crown,
  Volume2,
  Share2,
  Users,
  Compass,
  Layers,
  HeartHandshake,
  Flame,
  KeyRound,
  ChevronRight,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import {
  RealisticAndroidApkIcon,
  RealisticCrownIcon,
  RealisticCodexBookIcon,
  RealisticTrishulIcon,
  RealisticDragonIcon,
  RealisticDiceIcon,
  RealisticArcadeTargetIcon,
  RealisticFluteIcon,
  RealisticDiamondIcon,
  RealisticGiftIcon,
  RealisticShieldIcon,
  RealisticCoupleHeartsIcon,
} from './RealIcons';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenModal: (modal: 'astra' | 'pets' | 'gifts' | 'codex' | 'minigames' | 'crates' | 'admin' | 'models' | 'private-room' | 'pass' | 'collections' | 'apk' | 'butterfly' | 'rules' | 'streak' | 'forge' | 'clan' | 'bible' | 'balloons' | 'couple' | 'flute' | 'visuals' | 'auth' | 'tutorial' | 'missions') => void;
  onNavigate: (view: 'lobby' | 'rooms' | 'arena' | 'map' | 'leaderboard' | 'store' | 'profile') => void;
  onOpenMuseum?: () => void;
  isAudioMuted: boolean;
  onToggleAudio: () => void;
}

export const SideDrawer: React.FC<SideDrawerProps> = ({
  isOpen,
  onClose,
  onOpenModal,
  onNavigate,
  onOpenMuseum,
  isAudioMuted,
  onToggleAudio,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-fade-in">
      {/* Background click to close */}
      <div className="flex-1" onClick={onClose} />

      {/* Drawer content */}
      <div className="relative w-full max-w-sm h-full overflow-y-auto glass-panel border-l border-amber-500/20 p-5 flex flex-col justify-between shadow-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-gradient-to-tr from-purple-600 to-amber-500 text-white text-lg">
                ✨
              </span>
              <div>
                <h3 className="font-serif font-bold text-lg text-gold-gradient">
                  Cosmic Universe
                </h3>
                <p className="text-xs text-slate-400">Master 700+ Feature Hub</p>
              </div>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>

          {/* Quick Categories */}
          <div className="mt-5 space-y-4">
            {/* Install Android APK Banner */}
            <button
              onClick={() => {
                sound.playFanfare();
                onOpenModal('apk');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-emerald-600/40 via-teal-700/40 to-emerald-600/40 border border-emerald-400/60 shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center justify-between text-left group hover:scale-[1.02] active:scale-95 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center p-1 shadow-md border border-amber-300 text-lg">
                  📦
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-amber-300 group-hover:text-yellow-200">
                      Download ZIP & APK
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 font-black">
                      OFFLINE
                    </span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">Web2App ZIP (2.6MB) + Source Code</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-emerald-400" />
            </button>

            {/* Featured Season Pass Banner */}
            <button
              onClick={() => {
                sound.playGrandVictory();
                onOpenModal('pass');
                onClose();
              }}
              className="w-full p-3 rounded-2xl bg-gradient-to-r from-amber-600/40 via-purple-700/40 to-amber-600/40 border-2 border-amber-400/60 shadow-[0_0_20px_rgba(245,158,11,0.3)] flex items-center justify-between text-left group hover:scale-[1.02] active:scale-95 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center p-1 shadow-md border border-amber-300">
                  <RealisticCrownIcon size={26} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-amber-300 group-hover:text-yellow-200">
                      Season 1 Cosmic Pass
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black">
                      LV. 4
                    </span>
                  </div>
                  <p className="text-[10px] text-amber-200/80">Quests & 8 Tiers of Rewards</p>
                </div>
              </div>
              <Sparkles size={16} className="text-amber-300 group-hover:rotate-45 transition-transform" />
            </button>

            {/* Ludo Master Game Bible (Page 2 Reference) Banner */}
            <button
              onClick={() => {
                sound.playGrandVictory();
                onOpenModal('bible');
                onClose();
              }}
              className="w-full p-3 rounded-2xl bg-gradient-to-r from-amber-950/80 via-purple-950/70 to-slate-900 border-2 border-amber-400/60 flex items-center justify-between text-left group hover:border-yellow-300 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_20px_rgba(245,158,11,0.25)] animate-pulse"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center p-1 border border-amber-200 shadow-md">
                  <RealisticCodexBookIcon size={26} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-amber-200 group-hover:text-yellow-100">
                      Game Bible (Page 2)
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black">
                      10 PILLARS
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-300">Concept Bible, 12 Collections, 40💎 Cap & Shop</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-amber-400 group-hover:translate-x-1 transition" />
            </button>

            {/* Grand Collections Vault Banner */}
            <button
              onClick={() => {
                sound.playGrandVictory();
                onOpenModal('collections');
                onClose();
              }}
              className="w-full p-3 rounded-2xl bg-gradient-to-r from-purple-900/50 via-slate-900 to-amber-950/50 border border-amber-500/40 flex items-center justify-between text-left group hover:border-amber-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-black/50 flex items-center justify-center text-2xl border border-amber-500/30">
                  🏛️
                </div>
                <div>
                  <p className="text-xs font-black text-white group-hover:text-amber-300">
                    Grand Collections Vault
                  </p>
                  <p className="text-[10px] text-slate-400">14 Astras · 30 Pets · Hypercars · Dice</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-amber-400" />
            </button>

            {/* Mystic Butterfly Egg & Hatchery Banner */}
            <button
              onClick={() => {
                sound.playFanfare();
                onOpenModal('butterfly');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border border-emerald-500/40 flex items-center justify-between text-left group hover:border-emerald-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-xl border border-emerald-400 shadow-[0_0_12px_#10b981]">
                  🦋
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-emerald-300 group-hover:text-teal-200">
                      Butterfly Egg Hatchery
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 font-black">
                      NEW
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Incubate eggs, 12 butterflies & board perks</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-emerald-400" />
            </button>

            {/* Official Game Niyam (Rules) Banner */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenModal('rules');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-yellow-950/60 border border-amber-500/40 flex items-center justify-between text-left group hover:border-amber-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-xl border border-amber-400 shadow-[0_0_12px_#f59e0b]">
                  📜
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-amber-300 group-hover:text-yellow-200">
                      Game Niyam (खेल के नियम)
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black">
                      RULES
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">लूडो, अस्त्र, अंडा हैचिंग और लाइव रूम नियम</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-amber-400" />
            </button>

            {/* 7-Day Login Streak Banner */}
            <button
              onClick={() => {
                sound.playGrandVictory();
                onOpenModal('streak');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-yellow-950/60 via-slate-900 to-amber-950/60 border border-yellow-500/40 flex items-center justify-between text-left group hover:border-yellow-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-amber-600 flex items-center justify-center text-xl border border-yellow-300 shadow-[0_0_12px_#eab308]">
                  📅
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-yellow-300 group-hover:text-amber-200">
                      7-Day Daily Calendar
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-yellow-400 text-slate-950 font-black">
                      GIFTS
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Daily Coins, Diamonds & Butterfly Eggs</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-yellow-400" />
            </button>

            {/* Balloons & Splash Collection Banner (Bible Item 11) */}
            <button
              onClick={() => {
                sound.playTokenHop(2);
                onOpenModal('balloons');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-amber-950/60 border border-rose-500/40 flex items-center justify-between text-left group hover:border-rose-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-xl border border-rose-300 shadow-[0_0_12px_#f43f5e]">
                  🎈
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-rose-300 group-hover:text-pink-200">
                      Balloons & Splash (2💎)
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-black">
                      20+ FX
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Balloon Bombs, Mud & Pichkari Jets</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-rose-400" />
            </button>

            {/* Couple & Social Sanctuary Banner (Bible Item 14) */}
            <button
              onClick={() => {
                sound.playGrandVictory();
                onOpenModal('couple');
                onClose();
              }}
              className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-pink-950/60 via-purple-950/60 to-slate-900 border border-pink-500/40 flex items-center justify-between text-left group hover:border-pink-400 hover:scale-[1.02] active:scale-95 transition-all shadow-md"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-xl border border-pink-300 shadow-[0_0_12px_#ec4899]">
                  💞
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-pink-300 group-hover:text-rose-200">
                      Couple & Birthday
                    </p>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-pink-500 text-white font-black">
                      AWARD
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">10 Double Hearts & 50 Birthday Hearts</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-pink-400" />
            </button>

            {/* Section 1: Divine & Weapons */}
            <div>
              <p className="text-[11px] font-bold tracking-wider uppercase text-amber-400/80 px-1 mb-2">
                🔱 Astra & Rare Companions
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('astra');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticTrishulIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-amber-200">Astra Universe</p>
                    <p className="text-[10px] text-slate-400">Trishul · Gada · Chakra</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('pets');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticDragonIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-cyan-200">30 Rare Pets</p>
                    <p className="text-[10px] text-slate-400">Dragon · Eagle · Cobra</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playForgeStart();
                    onOpenModal('forge');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticDiceIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-amber-200">Dice Forge</p>
                    <p className="text-[10px] text-slate-400">Enchant & Upgrade Runes</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playGrandVictory();
                    onOpenModal('clan');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticCrownIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-red-300">Clan Wars</p>
                    <p className="text-[10px] text-slate-400">Guild Leagues & Treasury</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Section 2: Lore & Minigames */}
            <div>
              <p className="text-[11px] font-bold tracking-wider uppercase text-purple-400/80 px-1 mb-2">
                📜 Sacred Lore & Arcade
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('codex');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <span className="text-xl">🪐</span>
                  <div>
                    <p className="text-xs font-bold text-purple-200">Cosmic Codex</p>
                    <p className="text-[10px] text-slate-400">14 Lokas & Avatars</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('minigames');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticArcadeTargetIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-rose-200">Mini-Games</p>
                    <p className="text-[10px] text-slate-400">Bow · Connect · Carrom</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('flute');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticFluteIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-amber-200">Flute Tiny (Item 20)</p>
                    <p className="text-[10px] text-slate-400">30+ Characters & Curtains</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('visuals');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticDiamondIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-cyan-200">4D Neon Suite (Item 22)</p>
                    <p className="text-[10px] text-slate-400">Holo Dice, Weather, Cam</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('missions');
                    onClose();
                  }}
                  className="col-span-2 flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-amber-950/60 to-orange-950/60 border border-amber-500/40 text-left hover:border-amber-400/60 transition shadow-sm"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">📋</span>
                    <div>
                      <p className="text-xs font-bold text-amber-200">Mission & Quest Board (Item 19)</p>
                      <p className="text-[10px] text-slate-400">Daily, Weekly & Festival Rewards</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    QUESTS
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('tutorial');
                    onClose();
                  }}
                  className="col-span-2 flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-indigo-950/60 to-purple-950/60 border border-indigo-500/40 text-left hover:border-indigo-400/60 transition shadow-sm"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">🎓</span>
                    <div>
                      <p className="text-xs font-bold text-indigo-200">Interactive Tutorial (Item 40)</p>
                      <p className="text-[10px] text-slate-400">Watch or Skip · Fast 5 Steps</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                    TUTORIAL
                  </span>
                </button>
              </div>
            </div>

            {/* Section 3: Crates, Gifts & Economy */}
            <div>
              <p className="text-[11px] font-bold tracking-wider uppercase text-cyan-400/80 px-1 mb-2">
                💎 Luxury Economy & Crates
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('gifts');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <RealisticGiftIcon size={24} />
                  <div>
                    <p className="text-xs font-bold text-pink-200">3D Gift Store</p>
                    <p className="text-[10px] text-slate-400">Bugatti · Rose · Jets</p>
                  </div>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('crates');
                    onClose();
                  }}
                  className="flex items-center gap-2.5 p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <span className="text-xl">📦</span>
                  <div>
                    <p className="text-xs font-bold text-amber-200">Mystery Crates</p>
                    <p className="text-[10px] text-slate-400">Legendary Chests</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Section 4: Social & Customization */}
            <div>
              <p className="text-[11px] font-bold tracking-wider uppercase text-emerald-400/80 px-1 mb-2">
                🎨 Identity & Profile
              </p>
              <div className="space-y-2">
                <button
                  onClick={() => {
                    sound.playClick();
                    onNavigate('map');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🗺️</span>
                    <div>
                      <p className="text-xs font-bold text-white">3D Celestial World Map</p>
                      <p className="text-[10px] text-slate-400">Kingdoms, Pet Forest & Secret Valley</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                    World
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    if (onOpenMuseum) onOpenMuseum();
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🏛️</span>
                    <div>
                      <p className="text-xs font-bold text-white">Player 3D Museum Showroom</p>
                      <p className="text-[10px] text-slate-400">Rarest Pets, Trophies & Weapon Shrine</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-300 font-bold">
                    Showroom
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('private-room');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left border border-amber-500/30"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🎮</span>
                    <div>
                      <p className="text-xs font-bold text-amber-200">Play with Friends (Private Room)</p>
                      <p className="text-[10px] text-slate-400">Create 6-Digit Code & Custom Stakes</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    Private
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onNavigate('profile');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">👑</span>
                    <div>
                      <p className="text-xs font-bold text-white">20+ Animated Avatar Frames</p>
                      <p className="text-[10px] text-slate-400">Equip Koh-i-Noor, Wings & Halos</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                    Atelier
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenModal('models');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left border border-rose-500/30"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🌶️</span>
                    <div>
                      <p className="text-xs font-bold text-rose-300">Glamour Models Atelier</p>
                      <p className="text-[10px] text-slate-400">Balqis, Aanya, Zoya & Royal Avatars</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold">
                    Models
                  </span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    onNavigate('store');
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl glass-card glass-card-hover text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">🏎️</span>
                    <div>
                      <p className="text-xs font-bold text-white">Hypercar & Vehicle Garage</p>
                      <p className="text-[10px] text-slate-400">Neon Bugatti & Royal Rath Arrivals</p>
                    </div>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold">
                    Garage
                  </span>
                </button>
              </div>
            </div>

            {/* Section 5: Admin & Controls */}
            <div className="space-y-2">
              <p className="text-[11px] font-bold tracking-wider uppercase text-rose-400/80 px-1 mb-2">
                ⚙️ Master Controls & Player Auth
              </p>
              <button
                onClick={() => {
                  sound.playClick();
                  onOpenModal('auth');
                  onClose();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-amber-950/60 to-slate-900 border border-amber-500/40 text-left hover:border-amber-400/60 transition shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <span className="text-xl">🆔</span>
                  <div>
                    <p className="text-xs font-bold text-amber-200">Player Login Board (Item 26)</p>
                    <p className="text-[10px] text-slate-400">Email & Sequential IDs #100002+</p>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  AUTH
                </span>
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onOpenModal('admin');
                  onClose();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-rose-950/60 to-purple-950/60 border border-rose-500/30 text-left hover:border-rose-400/60 transition"
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck size={20} className="text-rose-400" />
                  <div>
                    <p className="text-xs font-bold text-rose-200">Admin & Testing Center</p>
                    <p className="text-[10px] text-slate-400">Owner #777777 · RBAC · Force Dice</p>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold">
                  DEV
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Settings */}
        <div className="pt-4 mt-6 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => {
              onToggleAudio();
            }}
            className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-slate-300"
          >
            <Volume2 size={16} className={isAudioMuted ? 'text-slate-500' : 'text-amber-400'} />
            {isAudioMuted ? 'Unmute Audio' : 'Sound FX On'}
          </button>

          <p className="text-[10px] text-slate-500">v3.5 Cosmic Royale</p>
        </div>
      </div>
    </div>
  );
};
