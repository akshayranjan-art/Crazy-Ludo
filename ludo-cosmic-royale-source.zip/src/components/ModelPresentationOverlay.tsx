import React, { useState, useEffect } from 'react';
import { Sparkles, Heart, Crown, X } from 'lucide-react';
import { ModelProfile } from './ModelGalleryModal';
import { sound } from '../utils/soundEngine';

interface ModelPresentationOverlayProps {
  model: ModelProfile | null;
  onClose: () => void;
}

export const ModelPresentationOverlay: React.FC<ModelPresentationOverlayProps> = ({
  model,
  onClose,
}) => {
  // Bible Item 17:
  // "Selected character appears on board for ~5 seconds with lighting/cinematic reveal; dialogue lasts ~10 seconds."
  // Dialogues: Two funny lines per character.
  const [phase, setPhase] = useState<'spotlight' | 'dialogue'>('spotlight');
  const [dialogueCountdown, setDialogueCountdown] = useState(10);

  useEffect(() => {
    if (!model) return;

    sound.playGiftFanfare();
    setPhase('spotlight');
    setDialogueCountdown(10);

    // 5 seconds spotlight lighting / cinematic reveal
    const spotlightTimer = setTimeout(() => {
      setPhase('dialogue');
    }, 5000);

    // 10 seconds dialogue timer
    const countdownInterval = setInterval(() => {
      setDialogueCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownInterval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Auto-close after 15 seconds total (5s reveal + 10s dialogue)
    const closeTimer = setTimeout(() => {
      onClose();
    }, 15000);

    return () => {
      clearTimeout(spotlightTimer);
      clearTimeout(closeTimer);
      clearInterval(countdownInterval);
    };
  }, [model]);

  if (!model) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      {/* Cinematic Golden Overhead Spotlight */}
      <div className="absolute top-0 w-72 sm:w-96 h-full bg-gradient-to-b from-pink-400/30 via-purple-500/15 to-transparent blur-2xl pointer-events-none" />

      {/* Floating Sparkles & Light Beams */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 text-2xl animate-ping opacity-60">✨</div>
        <div className="absolute top-1/3 right-1/4 text-3xl animate-pulse opacity-70">💖</div>
        <div className="absolute bottom-1/3 left-1/3 text-xl animate-bounce opacity-60">⭐</div>
      </div>

      {/* Dismiss button */}
      <button
        onClick={onClose}
        className="pointer-events-auto absolute top-16 right-6 p-2 rounded-full bg-black/70 border border-pink-400/50 text-pink-300 hover:text-white hover:bg-black/90 transition shadow-lg"
        title="Dismiss presentation"
      >
        <X size={18} />
      </button>

      {/* Main Character Presentation Card */}
      <div className="relative pointer-events-auto flex flex-col items-center max-w-sm w-full">
        {/* Phase Notification Pill */}
        <div className="mb-3 px-4 py-1 rounded-full bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 text-white font-black text-xs uppercase tracking-widest border border-pink-300 shadow-[0_0_20px_rgba(236,72,153,0.6)] flex items-center gap-2 animate-bounce">
          <Crown size={14} className="text-yellow-300" />
          <span>
            {phase === 'spotlight' ? 'Cinematic Runway Reveal (5s)' : `Dialogue Presentation (${dialogueCountdown}s)`}
          </span>
        </div>

        {/* Character Card Frame */}
        <div className="relative w-64 h-80 sm:w-72 sm:h-92 rounded-3xl overflow-hidden border-3 border-pink-400 shadow-[0_0_60px_rgba(236,72,153,0.7)] bg-gradient-to-b from-slate-950 via-purple-950 to-black flex flex-col justify-end p-4 group">
          {/* Spotlight Cone Background */}
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-48 h-64 bg-gradient-to-b from-white/35 via-pink-400/20 to-transparent blur-md" />

          {/* Model Full Portrait */}
          <img
            src={model.image}
            alt={model.name}
            referrerPolicy="no-referrer"
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
          />

          {/* Soft Bottom Shadow Gradient for Text Readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />

          {/* Model Identity Badge */}
          <div className="relative z-10">
            <span className="text-[10px] font-black uppercase tracking-wider text-pink-300 bg-black/75 px-2.5 py-0.5 rounded-full border border-pink-400/50 inline-block mb-1">
              {model.title}
            </span>
            <h3 className="text-xl font-black text-white font-serif tracking-wide drop-shadow-md">
              {model.name}
            </h3>
            <p className="text-[11px] text-pink-200 font-medium italic mt-0.5 line-clamp-1">
              "{model.quote}"
            </p>
          </div>
        </div>

        {/* Funny Dialogues Stage (Bible Item 17: Two funny lines per character, lasting ~10 seconds) */}
        {phase === 'dialogue' && (
          <div className="relative z-20 mt-3 w-full bg-slate-950/95 border-2 border-pink-400/80 rounded-2xl p-3.5 shadow-2xl animate-fade-in space-y-2">
            <div className="flex items-center justify-between border-b border-pink-500/20 pb-1.5">
              <span className="text-[10px] font-black text-pink-300 uppercase tracking-widest flex items-center gap-1">
                <span>💬</span> 2 Funny Character Lines
              </span>
              <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-500/20 px-2 py-0.2 rounded-full border border-amber-400/40">
                ⏱️ {dialogueCountdown}s
              </span>
            </div>

            {/* Line 1 */}
            <div className="p-2 rounded-xl bg-pink-950/50 border border-pink-500/30 text-xs font-bold text-pink-100 flex items-start gap-2">
              <span className="text-base shrink-0">1️⃣</span>
              <p>"{model.dialogue}"</p>
            </div>

            {/* Line 2 */}
            <div className="p-2 rounded-xl bg-purple-950/50 border border-purple-500/30 text-xs font-bold text-purple-100 flex items-start gap-2">
              <span className="text-base shrink-0">2️⃣</span>
              <p>"{model.dialogue2}"</p>
            </div>

            <p className="text-[9px] text-slate-400 text-center uppercase tracking-wider font-semibold">
              Max 10 uses/day per character · Unlimited for Owner
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
