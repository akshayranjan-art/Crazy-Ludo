import React, { useState } from 'react';
import { sound } from '../utils/soundEngine';

interface Dice3DProps {
  value: number; // 1 to 6
  isRolling: boolean;
  onRoll: () => void;
  canRoll: boolean;
  activeColor: 'red' | 'green' | 'yellow' | 'blue';
  bonusRoll?: boolean;
  isHolographic?: boolean;
}

export const Dice3D: React.FC<Dice3DProps> = ({
  value,
  isRolling,
  onRoll,
  canRoll,
  activeColor,
  bonusRoll,
  isHolographic = false,
}) => {
  const [internalRollAnim, setInternalRollAnim] = useState(false);

  const handleRollClick = () => {
    if (!canRoll || isRolling) return;
    setInternalRollAnim(true);
    sound.playDiceRoll();
    onRoll();
    setTimeout(() => {
      setInternalRollAnim(false);
    }, 700);
  };

  // Rotation angles for 3D Cube faces
  const getCubeRotation = (val: number) => {
    switch (val) {
      case 1: return 'rotateX(0deg) rotateY(0deg)';
      case 2: return 'rotateX(0deg) rotateY(180deg)';
      case 3: return 'rotateX(0deg) rotateY(-90deg)';
      case 4: return 'rotateX(0deg) rotateY(90deg)';
      case 5: return 'rotateX(-90deg) rotateY(0deg)';
      case 6: return 'rotateX(90deg) rotateY(0deg)';
      default: return 'rotateX(0deg) rotateY(0deg)';
    }
  };

  const colorThemes = {
    red: { ring: 'ring-red-500', glow: 'shadow-[0_0_25px_rgba(239,68,68,0.7)]', text: 'text-red-400', bg: 'from-red-600 to-rose-900' },
    green: { ring: 'ring-emerald-500', glow: 'shadow-[0_0_25px_rgba(16,185,129,0.7)]', text: 'text-emerald-400', bg: 'from-emerald-600 to-teal-900' },
    yellow: { ring: 'ring-amber-400', glow: 'shadow-[0_0_25px_rgba(245,158,11,0.7)]', text: 'text-amber-300', bg: 'from-amber-500 to-yellow-800' },
    blue: { ring: 'ring-blue-500', glow: 'shadow-[0_0_25px_rgba(59,130,246,0.7)]', text: 'text-blue-400', bg: 'from-blue-600 to-indigo-950' },
  };

  const theme = colorThemes[activeColor];

  // Render dice pips for standard 1 to 6 layout
  const renderPips = (faceNum: number) => {
    const pips: React.ReactNode[] = [];
    const pipClass = 'w-3 h-3 rounded-full bg-white shadow-[0_0_8px_#ffffff]';

    switch (faceNum) {
      case 1:
        return <div className="flex items-center justify-center w-full h-full"><div className="w-5 h-5 rounded-full bg-amber-400 shadow-[0_0_12px_#fbbf24]" /></div>;
      case 2:
        return (
          <div className="flex justify-between w-full h-full p-2">
            <div className={pipClass} />
            <div className={`${pipClass} self-end`} />
          </div>
        );
      case 3:
        return (
          <div className="flex justify-between w-full h-full p-2">
            <div className={pipClass} />
            <div className={`${pipClass} self-center`} />
            <div className={`${pipClass} self-end`} />
          </div>
        );
      case 4:
        return (
          <div className="grid grid-cols-2 gap-3 p-2 place-items-center w-full h-full">
            <div className={pipClass} /><div className={pipClass} />
            <div className={pipClass} /><div className={pipClass} />
          </div>
        );
      case 5:
        return (
          <div className="relative w-full h-full p-2">
            <div className="absolute top-2 left-2"><div className={pipClass} /></div>
            <div className="absolute top-2 right-2"><div className={pipClass} /></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"><div className="w-3.5 h-3.5 rounded-full bg-amber-300 shadow-[0_0_10px_#fcd34d]" /></div>
            <div className="absolute bottom-2 left-2"><div className={pipClass} /></div>
            <div className="absolute bottom-2 right-2"><div className={pipClass} /></div>
          </div>
        );
      case 6:
        return (
          <div className="grid grid-cols-2 gap-y-1.5 gap-x-3 p-1.5 place-items-center w-full h-full">
            <div className={pipClass} /><div className={pipClass} />
            <div className={pipClass} /><div className={pipClass} />
            <div className={pipClass} /><div className={pipClass} />
          </div>
        );
      default:
        return null;
    }
  };

  const rolling = isRolling || internalRollAnim;

  return (
    <div className="flex flex-col items-center select-none">
      {/* 3D Dice Stage with Perspective */}
      <div 
        onClick={handleRollClick}
        className={`relative w-20 h-20 cursor-pointer transition-transform duration-200 active:scale-95 group ${canRoll ? 'cursor-pointer' : 'cursor-not-allowed opacity-80'}`}
        style={{ perspective: '800px' }}
        title={canRoll ? 'Click to Roll 3D Dice!' : 'Waiting for turn or token move'}
      >
        {/* Glowing Base Platform */}
        <div className={`absolute -bottom-3 left-1/2 -translate-x-1/2 w-24 h-6 rounded-full blur-md opacity-70 transition-all ${theme.glow} ${canRoll ? 'animate-pulse' : ''}`} />

        {/* 4D Holographic Matrix Projection Frame (Bible Item 22) */}
        {isHolographic && (
          <div className="absolute -inset-3 rounded-2xl border-2 border-cyan-400/80 border-dashed animate-[spin_8s_linear_infinite] shadow-[0_0_20px_rgba(6,182,212,0.8)] pointer-events-none z-20 flex items-center justify-center">
            <span className="absolute -top-2 text-[8px] font-black text-cyan-300 bg-slate-950 px-1 rounded border border-cyan-400">
              4D HOLO
            </span>
          </div>
        )}

        {/* The 3D Cube */}
        <div
          className={`w-full h-full relative transition-all ${rolling ? 'animate-[diceRoll_0.6s_ease-out_infinite]' : 'duration-500 ease-out'}`}
          style={{
            transformStyle: 'preserve-3d',
            transform: rolling
              ? 'rotateX(720deg) rotateY(1080deg) rotateZ(360deg)'
              : getCubeRotation(value),
          }}
        >
          {/* Face 1: Front */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateY(0deg) translateZ(40px)' }}
          >
            {renderPips(1)}
          </div>

          {/* Face 2: Back */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateY(180deg) translateZ(40px)' }}
          >
            {renderPips(2)}
          </div>

          {/* Face 3: Right */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateY(90deg) translateZ(40px)' }}
          >
            {renderPips(3)}
          </div>

          {/* Face 4: Left */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateY(-90deg) translateZ(40px)' }}
          >
            {renderPips(4)}
          </div>

          {/* Face 5: Top */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateX(90deg) translateZ(40px)' }}
          >
            {renderPips(5)}
          </div>

          {/* Face 6: Bottom */}
          <div
            className="absolute inset-0 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 border-2 border-amber-400/80 shadow-inner flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateX(-90deg) translateZ(40px)' }}
          >
            {renderPips(6)}
          </div>
        </div>

        {/* Touch ripple on ready */}
        {canRoll && (
          <span className="absolute -top-1 -right-1 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-amber-500"></span>
          </span>
        )}
      </div>

      {/* Roll Action Bar */}
      <div className="mt-3 flex flex-col items-center">
        <button
          onClick={handleRollClick}
          disabled={!canRoll || isRolling}
          className={`px-4 py-1.5 rounded-full font-bold text-xs tracking-wider uppercase transition-all duration-200 shadow-md ${
            canRoll
              ? `bg-gradient-to-r ${theme.bg} text-white shadow-lg hover:brightness-110 active:scale-95 ${theme.glow}`
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
          }`}
        >
          {rolling ? 'Rolling 3D...' : canRoll ? 'Roll Dice' : `Rolled ${value}`}
        </button>

        {bonusRoll && (
          <span className="mt-1 text-[11px] font-bold text-amber-300 animate-bounce tracking-wide">
            ★ Rolled a 6! Bonus Roll! ★
          </span>
        )}
      </div>
    </div>
  );
};
