import React, { useState } from 'react';
import { X, Sparkles, Box, Gift, Check } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface CratesModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onOpenCrate: (coinsReward: number, diamondsReward: number, title: string) => void;
}

export const CratesModal: React.FC<CratesModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onOpenCrate,
}) => {
  const [openingCrateId, setOpeningCrateId] = useState<string | null>(null);
  const [unboxedReward, setUnboxedReward] = useState<{ title: string; coins: number; diamonds: number } | null>(null);

  if (!isOpen) return null;

  const crates = [
    { id: 'common', name: 'Common Wooden Chest', cost: 5000, currency: 'coins', color: 'from-emerald-950 to-slate-900', border: 'border-emerald-500/50', icon: '📦', rewardDesc: '10K Coins & 50 Diamonds' },
    { id: 'rare', name: 'Rare Crystalline Vault', cost: 25000, currency: 'coins', color: 'from-blue-950 to-slate-900', border: 'border-blue-500/50', icon: '💎', rewardDesc: '50K Coins & 250 Diamonds' },
    { id: 'epic', name: 'Epic Amethyst Relic', cost: 500, currency: 'diamonds', color: 'from-purple-950 to-slate-900', border: 'border-purple-500/50', icon: '🔮', rewardDesc: '200K Coins & 1,500 Diamonds' },
    { id: 'legendary', name: 'Legendary Royal Treasury', cost: 2000, currency: 'diamonds', color: 'from-amber-950 to-slate-900', border: 'border-amber-500/60', icon: '👑', rewardDesc: '1M Coins & 5,000 Diamonds' },
    { id: 'genesis', name: 'Genesis Cosmic Cube', cost: 10000, currency: 'diamonds', color: 'from-cyan-950 to-indigo-950', border: 'border-cyan-400', icon: '🌌', rewardDesc: '10M Coins & 25,000 Diamonds' },
  ];

  const handleOpen = (crate: typeof crates[0]) => {
    const hasEnough = crate.currency === 'coins' ? userCoins >= crate.cost : userDiamonds >= crate.cost;
    if (!hasEnough || openingCrateId) return;

    setOpeningCrateId(crate.id);
    sound.playDiceRoll();

    setTimeout(() => {
      sound.playGiftFanfare();
      let c = 0;
      let d = 0;
      if (crate.id === 'common') { c = 10000; d = 50; }
      else if (crate.id === 'rare') { c = 50000; d = 250; }
      else if (crate.id === 'epic') { c = 200000; d = 1500; }
      else if (crate.id === 'legendary') { c = 1000000; d = 5000; }
      else if (crate.id === 'genesis') { c = 10000000; d = 25000; }

      const reward = { title: crate.name, coins: c, diamonds: d };
      setUnboxedReward(reward);
      onOpenCrate(c, d, `Unboxed ${crate.name}!`);
      setOpeningCrateId(null);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-950 border-2 border-cyan-500/50 rounded-3xl shadow-[0_0_60px_rgba(6,182,212,0.25)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-cyan-500/20 bg-gradient-to-r from-cyan-950/70 via-slate-900 to-indigo-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-xl shadow-[0_0_15px_#06b6d4]">
              📦
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-cyan-200 tracking-wide font-cinzel">
                  UNLOCK YOUR JOURNEY CRATES
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40">
                  MYSTERY VAULT
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Open Common, Rare, Epic, Legendary & Genesis chests
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {unboxedReward && (
            <div className="mb-4 p-4 rounded-2xl bg-gradient-to-r from-amber-950 to-slate-900 border border-amber-400 flex items-center justify-between animate-bounce">
              <div className="flex items-center gap-3">
                <span className="text-3xl">🎉</span>
                <div>
                  <h4 className="text-sm font-bold text-amber-300 font-cinzel">
                    Loot Unboxed from {unboxedReward.title}!
                  </h4>
                  <p className="text-xs text-slate-200">
                    +{unboxedReward.coins.toLocaleString()} 🪙 Coins & +{unboxedReward.diamonds.toLocaleString()} 💎 Diamonds!
                  </p>
                </div>
              </div>
              <button
                onClick={() => setUnboxedReward(null)}
                className="px-3 py-1 bg-amber-500 text-slate-950 text-xs font-bold rounded-lg"
              >
                Claim
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {crates.map((crate) => {
              const isOpening = openingCrateId === crate.id;
              const hasEnough = crate.currency === 'coins' ? userCoins >= crate.cost : userDiamonds >= crate.cost;

              return (
                <div
                  key={crate.id}
                  className={`p-4 rounded-2xl bg-gradient-to-b ${crate.color} border ${crate.border} flex flex-col justify-between items-center text-center shadow-lg transition-all hover:scale-[1.02]`}
                >
                  <div className="text-4xl mb-2 filter drop-shadow-md">
                    {crate.icon}
                  </div>
                  <h3 className="text-sm font-bold text-slate-100 font-cinzel">
                    {crate.name}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-1 mb-3">
                    Contains: {crate.rewardDesc}
                  </p>

                  <button
                    onClick={() => handleOpen(crate)}
                    disabled={!hasEnough || isOpening}
                    className={`w-full py-2 rounded-xl text-xs font-bold transition-all shadow-md ${
                      isOpening
                        ? 'bg-amber-400 text-slate-950 animate-pulse'
                        : hasEnough
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95'
                        : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                    }`}
                  >
                    {isOpening
                      ? 'Unlocking Mystery...'
                      : `Open for ${crate.cost.toLocaleString()} ${crate.currency === 'coins' ? '🪙' : '💎'}`}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
