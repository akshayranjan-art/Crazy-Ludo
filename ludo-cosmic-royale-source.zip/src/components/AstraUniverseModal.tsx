import React, { useState } from 'react';
import { ASTRA_ITEMS } from '../data/gameConstants';
import { AstraItem } from '../types/game';
import {
  X,
  Sparkles,
  Zap,
  Play,
  Flame,
  Hammer,
  ArrowRight,
  Plus,
  Check,
  AlertTriangle,
  Award,
  Crown,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface AstraUniverseModalProps {
  isOpen: boolean;
  onClose: () => void;
  userDiamonds: number;
  unlockedAstraIds: string[];
  equippedAstraId: string | null;
  astraInventory: Record<string, number>;
  onEquipAstra: (astra: AstraItem) => void;
  onBuyAstra: (astra: AstraItem) => void;
  onTestAstraFX: (astra: AstraItem) => void;
  onForgeAstra: (sourceAstra: AstraItem) => AstraItem | null;
  onAddTestAstraCopies?: (astraId: string, count: number) => void;
  onTriggerCombo?: (comboName: string, desc: string) => void;
}

// Tier Progression Mapping
export const TIER_ORDER: Record<AstraItem['tier'], number> = {
  'Vedic Astra': 1,
  'High Celestial': 2,
  'Ultra Divine': 3,
  'Apex Divine': 4,
};

export const NEXT_TIER: Record<AstraItem['tier'], AstraItem['tier'] | null> = {
  'Vedic Astra': 'High Celestial',
  'High Celestial': 'Ultra Divine',
  'Ultra Divine': 'Apex Divine',
  'Apex Divine': null,
};

export const AstraUniverseModal: React.FC<AstraUniverseModalProps> = ({
  isOpen,
  onClose,
  userDiamonds,
  unlockedAstraIds,
  equippedAstraId,
  astraInventory,
  onEquipAstra,
  onBuyAstra,
  onTestAstraFX,
  onForgeAstra,
  onAddTestAstraCopies,
  onTriggerCombo,
}) => {
  const [activeTab, setActiveTab] = useState<'arsenal' | 'third-eye' | 'combos' | 'forge'>('arsenal');
  const [selectedForgeAstraId, setSelectedForgeAstraId] = useState<string | null>(null);
  const [isForging, setIsForging] = useState<boolean>(false);
  const [craftedResult, setCraftedResult] = useState<AstraItem | null>(null);

  if (!isOpen) return null;

  const handleTest = (astra: AstraItem) => {
    if (astra.cinematicEffect === 'tandav') sound.playTrishulTandav();
    else if (astra.cinematicEffect === 'gada-smash') sound.playGadaSmash();
    else if (astra.cinematicEffect === 'sudarshan-spin') sound.playSudarshanChakra();
    else sound.playTrishulTandav();
    onTestAstraFX(astra);
  };

  const selectedForgeAstra = ASTRA_ITEMS.find((a) => a.id === selectedForgeAstraId);
  const selectedCount = selectedForgeAstraId ? astraInventory[selectedForgeAstraId] || 0 : 0;
  const nextTierName = selectedForgeAstra ? NEXT_TIER[selectedForgeAstra.tier] : null;
  const potentialHigherTierAstras = nextTierName
    ? ASTRA_ITEMS.filter((a) => a.tier === nextTierName)
    : [];

  const handleStartForge = () => {
    if (!selectedForgeAstra || selectedCount < 3 || !nextTierName) return;

    sound.playForgeStart();
    setIsForging(true);

    setTimeout(() => {
      const createdItem = onForgeAstra(selectedForgeAstra);
      setIsForging(false);

      if (createdItem) {
        setCraftedResult(createdItem);
        sound.playForgeSuccess();
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#f59e0b', '#ec4899', '#3b82f6', '#10b981', '#ffffff'],
        });
      }
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[94vh] flex flex-col bg-slate-950 border-2 border-amber-500/60 rounded-3xl shadow-[0_0_70px_rgba(245,158,11,0.35)] overflow-hidden">
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between p-3 sm:p-4 border-b border-amber-500/20 bg-gradient-to-r from-purple-950/70 via-slate-900 to-amber-950/70 gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-xl shadow-[0_0_15px_#f59e0b]">
              🔱
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-amber-200 tracking-wide font-cinzel">
                  ASTRA UNIVERSE & FORGE
                </h2>
                <span className="text-[9px] sm:text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  DIVINE CRUCIBLE
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden xs:block">
                Permanent Celestial weapons with legendary cinematic VFX & Astra Forge Altar
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Diamond Balance */}
            <div className="px-3 py-1 rounded-full bg-slate-900 border border-cyan-500/30 flex items-center gap-1.5 text-xs font-bold text-cyan-300 shadow-sm">
              <span>💎</span>
              <span className="font-mono">{userDiamonds.toLocaleString()}</span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Switcher: Divine Arsenal vs Third Eye vs Combos vs Astra Forge */}
        <div className="flex items-center border-b border-slate-800 bg-slate-900/60 px-4 pt-2 gap-2 overflow-x-auto">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('arsenal');
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 shrink-0 ${
              activeTab === 'arsenal'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <span>🔱 All Astras</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
              {ASTRA_ITEMS.length}
            </span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('third-eye');
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 shrink-0 ${
              activeTab === 'third-eye'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <span>👁️ Third Eye Mahabharata</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
              Item 18
            </span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('combos');
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 shrink-0 ${
              activeTab === 'combos'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <span>⚡ Astra Combos</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40">
              Item 19
            </span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('forge');
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 shrink-0 relative ${
              activeTab === 'forge'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-1">
              <Hammer size={14} className="text-amber-400" />
              <span>Astra Forge</span>
            </span>
            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-slate-950 font-black">
              3x
            </span>
          </button>
        </div>

        {/* TAB 1: DIVINE ARSENAL (BROWSE, BUY, EQUIP, TEST) */}
        {activeTab === 'arsenal' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
            {ASTRA_ITEMS.map((astra) => {
              const ownedCount = astraInventory[astra.id] || 0;
              const isUnlocked = ownedCount > 0 || unlockedAstraIds.includes(astra.id);
              const isEquipped = equippedAstraId === astra.id;
              const canAfford = userDiamonds >= astra.permanentDiamondCost;

              return (
                <div
                  key={astra.id}
                  className={`relative rounded-2xl p-3 sm:p-4 flex flex-col justify-between border transition-all duration-300 ${
                    isEquipped
                      ? 'bg-gradient-to-br from-amber-950/70 via-slate-900 to-purple-950/70 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.4)]'
                      : 'bg-slate-900/80 border-slate-800 hover:border-amber-500/50'
                  }`}
                >
                  {/* Header of Card */}
                  <div className="flex gap-3 sm:gap-4">
                    <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border border-amber-400/50 bg-black flex-shrink-0 shadow-lg group">
                      <img
                        src={astra.image}
                        alt={astra.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-[8px] sm:text-[9px] font-bold text-amber-300 border border-amber-400/30">
                        {astra.tier}
                      </div>

                      {/* Owned Multiplicity Quantity Badge */}
                      {ownedCount > 0 && (
                        <div className="absolute bottom-1 right-1 px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black border border-white shadow-md">
                          {ownedCount}x Owned
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm sm:text-base font-bold text-slate-100 font-cinzel truncate">
                          {astra.name}
                        </h3>
                      </div>
                      <p className="text-xs text-amber-400 font-semibold mb-1 truncate">
                        {astra.hindiName}
                      </p>
                      <p className="text-[10px] sm:text-[11px] text-slate-400 line-clamp-2 mb-1.5">
                        {astra.description}
                      </p>
                      <div className="flex items-center gap-1.5 text-[10px] text-cyan-300 font-medium">
                        <Zap className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                        <span className="truncate">{astra.passiveBonus}</span>
                      </div>
                    </div>
                  </div>

                  {/* Footer / Cost & Actions */}
                  <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-col">
                      <span className="text-[9px] text-slate-400 uppercase font-semibold">
                        Permanent Cost
                      </span>
                      <div className="flex items-center gap-1 font-mono text-xs sm:text-sm font-black text-amber-300">
                        <span>💎</span>
                        <span>{astra.permanentDiamondCost.toLocaleString()}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Test FX Button */}
                      <button
                        onClick={() => handleTest(astra)}
                        className="px-2 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 border border-slate-700 transition-colors"
                        title="Preview sound & animation"
                      >
                        <Play className="w-3 h-3 text-amber-400 fill-amber-400" />
                        <span className="hidden xs:inline">Test FX</span>
                      </button>

                      {/* Equip / Buy Extra Copy Button */}
                      {isUnlocked ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => onEquipAstra(astra)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                              isEquipped
                                ? 'bg-emerald-500 text-slate-950 font-black cursor-default'
                                : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                            }`}
                          >
                            {isEquipped ? 'Equipped' : 'Equip'}
                          </button>

                          {/* Buy extra copy for forge */}
                          <button
                            onClick={() => onBuyAstra(astra)}
                            disabled={!canAfford}
                            className="px-2 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-all flex items-center gap-1"
                            title="Buy another copy of this Astra to use in the Forge"
                          >
                            <Plus size={11} />
                            <span>Buy Copy</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => onBuyAstra(astra)}
                          disabled={!canAfford}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md ${
                            canAfford
                              ? 'bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-white shadow-amber-500/20'
                              : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                          }`}
                        >
                          Unlock Permanent
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB: THIRD EYE MAHABHARATA COLLECTION (ITEM 18) */}
        {activeTab === 'third-eye' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
            <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between">
              <div>
                <h4 className="text-sm font-black text-amber-300 flex items-center gap-1.5 font-cinzel">
                  <span>👁️</span> Third Eye / Mahabharata Divine Arsenal
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Sacred weapons spanning Trishul Tandav, Gada Wobble, Indra Vajra, Gandiva Dhanush, Surya Rath, Sudarshan Chakra, Brahmastra & Pashupatastra.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
              {ASTRA_ITEMS.filter((a) => a.isThirdEyeCollection).map((astra) => {
                const ownedCount = astraInventory[astra.id] || 0;
                const isUnlocked = ownedCount > 0 || unlockedAstraIds.includes(astra.id);
                const isEquipped = equippedAstraId === astra.id;

                return (
                  <div
                    key={astra.id}
                    className={`rounded-2xl p-3.5 border transition flex flex-col justify-between ${
                      isEquipped
                        ? 'bg-amber-950/60 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.4)]'
                        : 'bg-slate-900/80 border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-400/40 flex items-center gap-1">
                          <span>👁️</span> {astra.tier}
                        </span>
                        {astra.id === 'brahmastra-apex' && (
                          <span className="text-[9px] font-black text-rose-300 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-500/40">
                            10 Board Hold Uses
                          </span>
                        )}
                        {astra.id === 'pashupatastra-apex' && (
                          <span className="text-[9px] font-black text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/40">
                            Admin Configurable
                          </span>
                        )}
                      </div>

                      <div className="flex gap-3">
                        <div className="w-16 h-16 rounded-xl overflow-hidden border border-amber-400/40 bg-black shrink-0">
                          <img src={astra.image} alt={astra.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-black text-white font-cinzel truncate">{astra.name}</h4>
                          <p className="text-xs text-amber-400 font-bold truncate">{astra.hindiName}</p>
                          <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{astra.description}</p>
                        </div>
                      </div>

                      <div className="mt-2.5 p-2 rounded-xl bg-black/50 border border-white/5 text-[10px] text-cyan-300 font-medium">
                        ⚡ {astra.passiveBonus}
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between">
                      <button
                        onClick={() => handleTest(astra)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1"
                      >
                        <Play size={12} className="fill-amber-400" />
                        <span>Test VFX</span>
                      </button>

                      {isUnlocked ? (
                        <button
                          onClick={() => onEquipAstra(astra)}
                          disabled={isEquipped}
                          className={`px-3 py-1 rounded-xl text-xs font-black transition ${
                            isEquipped
                              ? 'bg-emerald-500 text-slate-950 cursor-default'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          {isEquipped ? 'Equipped' : 'Equip Astra'}
                        </button>
                      ) : (
                        <span className="text-xs font-mono font-black text-amber-300">
                          💎 {astra.permanentDiamondCost.toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB: ASTRA COMBOS & MASTI (ITEM 19) */}
        {activeTab === 'combos' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
            <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/40 flex items-center justify-between">
              <div>
                <h4 className="text-sm font-black text-purple-300 flex items-center gap-1.5 font-cinzel">
                  <span>⚡</span> Astra Combos & Masti Sequences
                </h4>
                <p className="text-xs text-slate-300 mt-0.5">
                  Bible Item 19: Cosmetic sequence counter & pet reactions! Pure spectacle with zero unfair gameplay advantage.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              {/* Combo 1: Mahabharata Tandav Combo */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-purple-500/40 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/40 uppercase">
                      COMBO 1 · TANDAV CHAOS
                    </span>
                    <span className="text-xs text-amber-300 font-bold">4-Step Chain</span>
                  </div>

                  <h4 className="text-base font-black text-white mt-2 font-cinzel">
                    Mahabharata Tandav Combo
                  </h4>
                  <p className="text-xs text-amber-300 font-bold mt-0.5">
                    Trishul → Tandav → Vajra Lightning → Gada Wobble
                  </p>
                  <p className="text-[11px] text-slate-400 mt-2">
                    Triggers full-screen Nataraja flame trails, followed by Indra electrical storms and an earth-shattering Gada seat wobble!
                  </p>
                </div>

                <button
                  onClick={() => {
                    sound.playTrishulTandav();
                    setTimeout(() => sound.playGadaSmash(), 1200);
                    if (onTriggerCombo) {
                      onTriggerCombo(
                        'Mahabharata Tandav Combo',
                        'Trishul Tandav flames roared across board, Indra lightning crashed, and Hanuman Gada wobbled all 8 seats!'
                      );
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Zap size={14} />
                  <span>Execute Tandav Combo</span>
                </button>
              </div>

              {/* Combo 2: Nag Masti Combo */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/40 flex flex-col justify-between space-y-3">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 uppercase">
                      COMBO 2 · MASTI CHAIN
                    </span>
                    <span className="text-xs text-emerald-300 font-bold">3-Step Gag</span>
                  </div>

                  <h4 className="text-base font-black text-white mt-2 font-cinzel">
                    Takshak Nag Masti Combo
                  </h4>
                  <p className="text-xs text-emerald-300 font-bold mt-0.5">
                    Takshak + Pet + Funny Character
                  </p>
                  <p className="text-[11px] text-slate-400 mt-2">
                    Takshak slithers in, playfully swallows player pet for 25s, while your equipped glamour model drops a witty comedy dialogue!
                  </p>
                </div>

                <button
                  onClick={() => {
                    sound.playGrandVictory();
                    if (onTriggerCombo) {
                      onTriggerCombo(
                        'Takshak Nag Masti Combo',
                        'Takshak serpent had comedic pet playtime while Glamour Model entertained the room with laughs!'
                      );
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
                >
                  <Sparkles size={14} />
                  <span>Execute Masti Combo</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ASTRA FORGE & SACRED ALTAR */}
        {activeTab === 'forge' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 flex flex-col space-y-4">
            {/* Forge Banner & Rules */}
            <div className="p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-950/80 via-purple-950/70 to-slate-900 border border-amber-500/40 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center text-slate-950 shadow-[0_0_20px_#f59e0b] flex-shrink-0">
                  <Hammer size={24} />
                </div>
                <div>
                  <h3 className="text-base font-black text-amber-200 font-cinzel">
                    SACRED ASTRA FORGE & ALTAR
                  </h3>
                  <p className="text-xs text-slate-300">
                    Combine <strong className="text-amber-300 font-bold">3 identical lower-tier Astras</strong> to destroy them in the cosmic crucible and manifest a <strong className="text-cyan-300 font-bold">random higher-tier artifact</strong>!
                  </p>
                </div>
              </div>

              {/* Tier Flow Badge */}
              <div className="flex items-center gap-1 text-[10px] font-bold text-slate-300 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-amber-500/30">
                <span className="text-amber-400">Vedic</span>
                <span>➔</span>
                <span className="text-blue-400">Celestial</span>
                <span>➔</span>
                <span className="text-purple-400">Ultra</span>
                <span>➔</span>
                <span className="text-rose-400 font-black">Apex</span>
              </div>
            </div>

            {/* Selection Grid: Lower-Tier Items in Inventory */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <Sparkles size={13} />
                  <span>Step 1: Select an Astra to Combine (3x Required)</span>
                </h4>
                <span className="text-[11px] text-slate-400">
                  Tap an item with 3x copies below
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
                {ASTRA_ITEMS.filter((a) => a.tier !== 'Apex Divine').map((astra) => {
                  const count = astraInventory[astra.id] || 0;
                  const isSelected = selectedForgeAstraId === astra.id;
                  const hasEnough = count >= 3;

                  return (
                    <div
                      key={astra.id}
                      onClick={() => {
                        sound.playClick();
                        setSelectedForgeAstraId(astra.id);
                      }}
                      className={`relative rounded-2xl p-2 sm:p-2.5 border cursor-pointer transition-all duration-200 flex flex-col justify-between ${
                        isSelected
                          ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.5)] scale-[1.02]'
                          : hasEnough
                          ? 'bg-slate-900/90 border-amber-500/40 hover:border-amber-400'
                          : 'bg-slate-950/70 border-slate-800 opacity-70 hover:opacity-100'
                      }`}
                    >
                      {/* Image & Quantity */}
                      <div className="relative aspect-video rounded-xl overflow-hidden bg-black mb-1.5 border border-slate-700">
                        <img
                          src={astra.image}
                          alt={astra.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/80 text-[8px] font-bold text-amber-300">
                          {astra.tier}
                        </div>
                        {/* Count Badge */}
                        <div
                          className={`absolute bottom-1 right-1 px-2 py-0.5 rounded-full text-[10px] font-black border shadow-md ${
                            hasEnough
                              ? 'bg-emerald-500 text-slate-950 border-white animate-pulse'
                              : 'bg-slate-800 text-slate-300 border-slate-600'
                          }`}
                        >
                          {count}/3
                        </div>
                      </div>

                      <div className="min-w-0">
                        <h5 className="text-xs font-bold text-white truncate">
                          {astra.name}
                        </h5>
                        <p className="text-[10px] text-amber-400/90 truncate">
                          {astra.hindiName}
                        </p>
                      </div>

                      {/* Add +3 copies test button */}
                      {onAddTestAstraCopies && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            sound.playClick();
                            onAddTestAstraCopies(astra.id, 3);
                            setSelectedForgeAstraId(astra.id);
                          }}
                          className="mt-1.5 w-full py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-amber-500/30 flex items-center justify-center gap-1 transition"
                          title="Instant test: Add 3 copies to inventory"
                        >
                          <Plus size={10} />
                          <span>+3 Test Copies</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sacred Forge Crucible Stage */}
            <div className="relative rounded-3xl p-4 sm:p-6 bg-gradient-to-b from-[#180a02] via-[#090510] to-[#120619] border-2 border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.25)] flex flex-col items-center justify-center overflow-hidden">
              {/* Divine Sunburst Background */}
              <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/10 via-transparent to-purple-500/10 pointer-events-none" />

              <h4 className="text-xs sm:text-sm font-black uppercase tracking-widest text-amber-300 mb-4 flex items-center gap-2">
                <Flame size={16} className="text-amber-500 animate-pulse" />
                <span>The Transmutation Crucible</span>
                <Flame size={16} className="text-amber-500 animate-pulse" />
              </h4>

              {/* 3 Pedestal Sockets for the 3 Identical Items */}
              <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-6 mb-6">
                {[0, 1, 2].map((slotIdx) => {
                  const isFilled = selectedForgeAstra && selectedCount >= slotIdx + 1;

                  return (
                    <div
                      key={`forge-slot-${slotIdx}`}
                      className={`relative w-20 h-24 sm:w-24 sm:h-28 rounded-2xl flex flex-col items-center justify-center border-2 transition-all duration-300 ${
                        isFilled
                          ? 'border-amber-400 bg-amber-950/40 shadow-[0_0_20px_rgba(245,158,11,0.5)]'
                          : 'border-slate-700/80 bg-slate-900/60 border-dashed'
                      }`}
                    >
                      {isFilled && selectedForgeAstra ? (
                        <>
                          <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden border border-amber-400/60 mb-1 shadow-md">
                            <img
                              src={selectedForgeAstra.image}
                              alt={selectedForgeAstra.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <span className="text-[9px] font-black text-amber-300 truncate max-w-[70px]">
                            {selectedForgeAstra.name}
                          </span>
                          <span className="text-[8px] text-slate-400">
                            Slot #{slotIdx + 1}
                          </span>
                        </>
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-500">
                          <span className="text-xl">🔮</span>
                          <span className="text-[10px] font-bold mt-1">
                            Slot #{slotIdx + 1}
                          </span>
                          <span className="text-[8px] text-slate-600">Requires 1x</span>
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Arrow to Outcome */}
                <div className="flex flex-col items-center justify-center px-1 text-amber-400 animate-pulse">
                  <ArrowRight size={22} className="hidden sm:block" />
                  <span className="text-[10px] font-black uppercase">Forge</span>
                </div>

                {/* Target Higher Tier Manifestation Pedestal */}
                <div className="relative w-24 h-28 sm:w-28 sm:h-32 rounded-2xl flex flex-col items-center justify-center border-2 border-cyan-400 bg-gradient-to-br from-indigo-950/80 to-purple-950/80 shadow-[0_0_25px_rgba(6,182,212,0.4)] p-1">
                  <div className="absolute -top-2.5 px-2 py-0.5 rounded-full bg-cyan-400 text-slate-950 text-[9px] font-black">
                    TARGET TIER
                  </div>
                  <Crown size={24} className="text-amber-300 animate-bounce mb-1" />
                  <span className="text-xs font-black text-cyan-200 text-center">
                    {nextTierName || 'Apex Divine'}
                  </span>
                  <span className="text-[8px] text-slate-400 text-center mt-0.5">
                    Random Manifestation
                  </span>
                </div>
              </div>

              {/* Potential Higher-Tier Artifact Previews */}
              {nextTierName && potentialHigherTierAstras.length > 0 && (
                <div className="mb-4 text-center">
                  <p className="text-[10px] font-bold text-slate-400 mb-1">
                    Possible Crafting Outcomes:
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-1.5">
                    {potentialHigherTierAstras.map((art) => (
                      <span
                        key={art.id}
                        className="text-[10px] px-2 py-0.5 rounded-full bg-slate-900/90 text-cyan-300 border border-cyan-500/30 font-medium"
                      >
                        ✨ {art.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Main Transmutation Action Button */}
              <button
                onClick={handleStartForge}
                disabled={!selectedForgeAstra || selectedCount < 3 || isForging || !nextTierName}
                className={`relative px-8 py-3 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center gap-2 transition-all shadow-xl ${
                  isForging
                    ? 'bg-amber-600 text-slate-950 cursor-wait animate-pulse'
                    : selectedForgeAstra && selectedCount >= 3 && nextTierName
                    ? 'liquid-btn-gold text-slate-950 shadow-[0_0_30px_rgba(245,158,11,0.8)] hover:scale-105 active:scale-95'
                    : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                }`}
              >
                <Hammer size={18} className={isForging ? 'animate-spin' : ''} />
                <span>
                  {isForging
                    ? 'Cosmic Transmutation in Progress...'
                    : selectedCount >= 3 && selectedForgeAstra
                    ? `TRANSMUTE 3x ${selectedForgeAstra.name}`
                    : 'SELECT 3x IDENTICAL ASTRAS'}
                </span>
              </button>

              {/* Helper note */}
              {selectedForgeAstra && selectedCount < 3 && (
                <p className="text-[11px] text-rose-400 font-bold mt-2 flex items-center gap-1">
                  <AlertTriangle size={12} />
                  <span>You need {3 - selectedCount} more copy of this Astra to forge! (Tap '+3 Test Copies' or buy from Arsenal)</span>
                </p>
              )}
            </div>
          </div>
        )}

        {/* FORGE CRAFTED RESULT CELEBRATION MODAL */}
        {craftedResult && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fadeIn">
            <div className="relative w-full max-w-md p-6 rounded-3xl bg-gradient-to-b from-amber-950 via-slate-900 to-purple-950 border-2 border-amber-400 shadow-[0_0_80px_rgba(245,158,11,0.8)] text-center flex flex-col items-center">
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-200 flex items-center justify-center text-3xl shadow-[0_0_30px_#f59e0b] mb-3 animate-bounce">
                👑
              </div>

              <span className="text-[10px] px-3 py-1 rounded-full bg-amber-500 text-slate-950 font-black tracking-widest uppercase mb-1">
                FORGE SUCCESS · TIER UPGRADED!
              </span>

              <h3 className="text-xl font-black text-amber-200 font-cinzel">
                {craftedResult.name}
              </h3>
              <p className="text-sm font-bold text-amber-400 mb-3">
                {craftedResult.hindiName}
              </p>

              {/* Artifact Card Display */}
              <div className="w-full rounded-2xl overflow-hidden border-2 border-amber-400/80 bg-black/80 mb-4 shadow-xl">
                <div className="h-44 w-full relative">
                  <img
                    src={craftedResult.image}
                    alt={craftedResult.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/80 text-xs font-black text-amber-300 border border-amber-400/50">
                    {craftedResult.tier}
                  </div>
                </div>
                <div className="p-3 text-left">
                  <p className="text-xs text-slate-300 mb-1">
                    {craftedResult.description}
                  </p>
                  <p className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
                    <Zap size={13} className="text-cyan-400" />
                    <span>{craftedResult.passiveBonus}</span>
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="w-full flex items-center gap-3">
                <button
                  onClick={() => {
                    sound.playClick();
                    onEquipAstra(craftedResult);
                    setCraftedResult(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider transition shadow-lg"
                >
                  Equip Now
                </button>
                <button
                  onClick={() => {
                    sound.playClick();
                    setCraftedResult(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider transition border border-slate-700"
                >
                  Continue Forging
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
