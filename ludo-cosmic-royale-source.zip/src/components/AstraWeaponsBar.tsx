import React from 'react';
import { Zap, Shield, Sparkles, Flame, Hammer } from 'lucide-react';
import { sound } from '../utils/soundEngine';

export interface AstraWeapon {
  id: 'gada' | 'trishul' | 'sudarshan' | 'vajra' | 'dhanush' | 'brahmastra';
  name: string;
  hindiName: string;
  icon: string;
  color: string;
  borderGlow: string;
  actionDesc: string;
  effectType: string;
}

export const ASTRA_WEAPONS: AstraWeapon[] = [
  {
    id: 'gada',
    name: 'Gada Slam',
    hindiName: 'गदा प्रहार',
    icon: '🔨',
    color: 'from-amber-600 to-orange-700',
    borderGlow: 'border-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.6)]',
    actionDesc: 'Guarantees Lucky 6 & Shakes Arena',
    effectType: 'Lucky 6 Roll',
  },
  {
    id: 'trishul',
    name: 'Trishul Tandav',
    hindiName: 'त्रिशूल प्रहार',
    icon: '🔱',
    color: 'from-cyan-600 to-blue-800',
    borderGlow: 'border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.6)]',
    actionDesc: 'Strikes & Banishes Opponent to Yard',
    effectType: 'Opponent Kill',
  },
  {
    id: 'sudarshan',
    name: 'Sudarshan Warp',
    hindiName: 'सुदर्शन चक्र',
    icon: '☀️',
    color: 'from-yellow-500 to-amber-600',
    borderGlow: 'border-yellow-300 shadow-[0_0_15px_rgba(234,179,8,0.6)]',
    actionDesc: '+4 Tile Warp & Extra Bonus Turn',
    effectType: '+4 Steps & Turn',
  },
  {
    id: 'vajra',
    name: 'Vajra Shield',
    hindiName: 'वज्र कवच',
    icon: '⚡',
    color: 'from-purple-600 to-indigo-800',
    borderGlow: 'border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.6)]',
    actionDesc: '3-Turn Invulnerability from Captures',
    effectType: 'Godmode Shield',
  },
  {
    id: 'dhanush',
    name: 'Gandiva Bow',
    hindiName: 'गांडीव बाण',
    icon: '🏹',
    color: 'from-emerald-600 to-teal-800',
    borderGlow: 'border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.6)]',
    actionDesc: 'Arrow Volley strikes path ahead',
    effectType: 'Volley +3',
  },
  {
    id: 'brahmastra',
    name: 'Brahmastra',
    hindiName: 'ब्रह्मास्त्र',
    icon: '✨',
    color: 'from-rose-600 to-red-800',
    borderGlow: 'border-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.6)]',
    actionDesc: 'Board Hold Freeze (Safety Controlled, 10x)',
    effectType: 'Board Hold',
  },
];

export interface AstraWeaponsBarProps {
  onCastWeapon: (weaponId: 'gada' | 'trishul' | 'sudarshan' | 'vajra' | 'dhanush' | 'brahmastra') => void;
  isShieldActive: boolean;
  shieldTurnsRemaining: number;
  cooldowns: Record<string, number>;
  disabled?: boolean;
}

export const AstraWeaponsBar: React.FC<AstraWeaponsBarProps> = ({
  onCastWeapon,
  isShieldActive,
  shieldTurnsRemaining,
  cooldowns,
  disabled = false,
}) => {
  return (
    <div className="w-full bg-gradient-to-r from-slate-950 via-[#190d2e] to-slate-950 border-2 border-amber-500/40 rounded-2xl p-2.5 sm:p-3 shadow-[0_4px_25px_rgba(0,0,0,0.8)] flex flex-col gap-2">
      {/* Header bar */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <span className="p-1 rounded-lg bg-amber-500/20 text-amber-300">
            <Zap size={14} className="animate-pulse" />
          </span>
          <span className="text-xs font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
            <span>Divine Astra Arsenal</span>
            <span className="text-[10px] text-amber-400/80 font-normal hidden sm:inline">
              (Interactive Board Powers)
            </span>
          </span>
        </div>

        {/* Shield active indicator */}
        {isShieldActive && (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-500/20 border border-purple-400 text-purple-300 text-[10px] font-bold animate-pulse">
            <Shield size={12} className="text-purple-300" />
            <span>Vajra Shield: {shieldTurnsRemaining} Turns</span>
          </div>
        )}
      </div>

      {/* 4 Weapon Action Buttons */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {ASTRA_WEAPONS.map((weapon) => {
          const cd = cooldowns[weapon.id] || 0;
          const isReady = cd <= 0 && !disabled;

          return (
            <button
              key={weapon.id}
              onClick={() => {
                if (isReady) {
                  onCastWeapon(weapon.id);
                } else {
                  sound.playClick();
                }
              }}
              disabled={!isReady}
              className={`relative overflow-hidden rounded-xl p-2 flex items-center gap-2 border transition-all text-left group ${
                isReady
                  ? `bg-gradient-to-br ${weapon.color} ${weapon.borderGlow} hover:scale-[1.03] active:scale-95 cursor-pointer`
                  : 'bg-slate-900/80 border-slate-800 text-slate-500 cursor-not-allowed opacity-60'
              }`}
              title={`${weapon.name}: ${weapon.actionDesc}`}
            >
              {/* Cooldown progress cover */}
              {cd > 0 && (
                <div
                  className="absolute inset-0 bg-black/75 z-10 flex items-center justify-center font-mono font-black text-amber-300 text-xs"
                >
                  ⏳ {cd}s
                </div>
              )}

              {/* Icon */}
              <div className="w-8 h-8 rounded-lg bg-black/40 border border-white/20 flex items-center justify-center text-lg shrink-0">
                {weapon.icon}
              </div>

              {/* Text */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] sm:text-xs font-black text-white truncate drop-shadow">
                    {weapon.name}
                  </span>
                </div>
                <div className="text-[9px] sm:text-[10px] text-amber-200/90 font-medium truncate">
                  {weapon.effectType}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
