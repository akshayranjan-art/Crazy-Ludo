import React, { useState } from 'react';
import { X, Sparkles, Check, ChevronRight, Egg, Zap } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { BUTTERFLY_SPECIES } from '../data/butterflyData';
import confetti from 'canvas-confetti';

interface ButterflyEggModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onDeductCoins: (amt: number) => void;
  onDeductDiamonds: (amt: number) => void;
  equippedButterflyId: string;
  onEquipButterfly: (id: string) => void;
  onOpenRules: () => void;
}

export const ButterflyEggModal: React.FC<ButterflyEggModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onDeductCoins,
  onDeductDiamonds,
  equippedButterflyId,
  onEquipButterfly,
  onOpenRules,
}) => {
  const [selectedButterfly, setSelectedButterfly] = useState(
    BUTTERFLY_SPECIES.find((b) => b.id === equippedButterflyId) || BUTTERFLY_SPECIES[0]
  );
  const [isIncubating, setIsIncubating] = useState(false);

  if (!isOpen) return null;

  const handleIncubateEgg = () => {
    if (userDiamonds < 50) {
      sound.playError();
      return;
    }
    sound.playAstraReady();
    onDeductDiamonds(50);
    setIsIncubating(true);
    setTimeout(() => {
      setIsIncubating(false);
      confetti({ particleCount: 60, spread: 60 });
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-emerald-500/50 rounded-3xl bg-gradient-to-b from-[#091f16] via-[#0c141d] to-black text-slate-100 shadow-[0_0_50px_rgba(16,185,129,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-700/40 via-teal-700/30 to-slate-900 border-b border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center text-2xl shadow-lg border border-emerald-300">
              🦋
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-teal-200 to-amber-300">
                Mystic Butterfly Sanctuary
              </h3>
              <p className="text-xs text-slate-300">
                Divine egg incubator & companion buffs
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Egg Incubator Card */}
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-900/80 border border-emerald-400 flex items-center justify-center text-2xl animate-pulse">
                🥚
              </div>
              <div>
                <h4 className="text-sm font-black text-emerald-300">Cosmic Egg Incubator</h4>
                <p className="text-[11px] text-slate-300">Hatch rare celestial butterflies (50 💎)</p>
              </div>
            </div>
            <button
              onClick={handleIncubateEgg}
              disabled={isIncubating}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md transition active:scale-95 cursor-pointer"
            >
              {isIncubating ? 'Hatching...' : 'Hatch Egg'}
            </button>
          </div>

          {/* Butterfly List */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Available Butterflies ({BUTTERFLY_SPECIES.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {BUTTERFLY_SPECIES.map((bf) => {
                const isEquipped = equippedButterflyId === bf.id;
                return (
                  <div
                    key={bf.id}
                    onClick={() => {
                      sound.playClick();
                      setSelectedButterfly(bf);
                    }}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isEquipped
                        ? 'bg-emerald-950/80 border-emerald-400 shadow-md'
                        : selectedButterfly.id === bf.id
                        ? 'bg-slate-800/80 border-teal-500'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span
                          className="text-[9px] px-2 py-0.5 rounded-full font-black uppercase"
                          style={{
                            backgroundColor: `${bf.glowColor}25`,
                            color: bf.glowColor,
                            border: `1px solid ${bf.glowColor}50`,
                          }}
                        >
                          {bf.rarity}
                        </span>
                        {isEquipped && (
                          <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black flex items-center gap-0.5">
                            <Check size={10} /> Active
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">🦋</span>
                        <div>
                          <p className="text-xs font-black text-white">{bf.name}</p>
                          <p className="text-[10px] text-emerald-400 font-bold">{bf.hindiName}</p>
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-300 mt-2 bg-black/40 p-1.5 rounded-lg border border-white/5">
                        ✨ {bf.buffTitle}: {bf.buffDescription}
                      </p>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        sound.playGrandVictory();
                        onEquipButterfly(bf.id);
                        confetti({ particleCount: 30, spread: 40 });
                      }}
                      disabled={isEquipped}
                      className={`mt-2.5 w-full py-1.5 rounded-xl text-xs font-black transition ${
                        isEquipped
                          ? 'bg-white/10 text-slate-400 cursor-default'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 active:scale-95 cursor-pointer'
                      }`}
                    >
                      {isEquipped ? 'Equipped' : 'Equip Companion'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick link to Rules */}
          <div className="pt-2 flex justify-end">
            <button
              onClick={() => {
                sound.playClick();
                onClose();
                onOpenRules();
              }}
              className="text-xs text-amber-300 hover:text-amber-200 flex items-center gap-1 font-bold"
            >
              <span>View Official Game Niyam (खेल नियम)</span>
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
