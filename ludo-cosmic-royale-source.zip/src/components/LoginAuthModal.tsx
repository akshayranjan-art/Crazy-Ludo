import React, { useState } from 'react';
import { X, Mail, Shield, Check, Crown, KeyRound, Copy, Send, Sparkles, AlertCircle } from 'lucide-react';
import { authService, PlayerUser, OWNER_USER } from '../utils/authService';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface LoginAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: PlayerUser;
  onUserChange: (user: PlayerUser) => void;
}

export const LoginAuthModal: React.FC<LoginAuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onUserChange,
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [idInput, setIdInput] = useState('');
  const [activeTab, setActiveTab] = useState<'email' | 'id'>('email');
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);
  const [emailDispatchSimulated, setEmailDispatchSimulated] = useState<{
    to: string;
    id: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleEmailLogin = (emailToUse?: string) => {
    const targetEmail = (emailToUse || emailInput).trim();
    if (!targetEmail || !targetEmail.includes('@')) {
      sound.playError();
      setFeedbackMessage('Please enter a valid email address (e.g. user@gmail.com).');
      return;
    }

    sound.playClick();
    const result = authService.loginWithEmail(targetEmail);
    onUserChange(result.user);
    setFeedbackMessage(result.message);

    if (result.isNew) {
      sound.playGrandVictory();
      confetti({ particleCount: 70, spread: 60 });
      setEmailDispatchSimulated({ to: targetEmail, id: result.user.id });
    } else {
      sound.playSafeCell();
      setTimeout(() => {
        onClose();
      }, 1800);
    }
  };

  const handleIdLogin = () => {
    const targetId = idInput.trim();
    if (!targetId) {
      sound.playError();
      setFeedbackMessage('Please enter your unique Player ID number (e.g. 777777 or 100002).');
      return;
    }

    sound.playClick();
    const result = authService.loginWithId(targetId);
    if (result.user) {
      onUserChange(result.user);
      sound.playGrandVictory();
      setFeedbackMessage(result.message);
      setTimeout(() => {
        onClose();
      }, 1800);
    } else {
      sound.playError();
      setFeedbackMessage(result.message);
    }
  };

  const handleCopyId = () => {
    navigator.clipboard?.writeText(currentUser.id);
    setCopiedId(true);
    sound.playSafeCell();
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md overflow-hidden border-2 border-amber-400/60 rounded-3xl bg-gradient-to-b from-[#160c2b] via-[#0d0718] to-black text-slate-100 shadow-[0_0_60px_rgba(245,158,11,0.35)] flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-purple-950/80 via-indigo-950/70 to-amber-950/70 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-slate-950 text-xl font-black shadow-[0_0_15px_#f59e0b]">
              🆔
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-black text-amber-200 tracking-wide font-cinzel">
                  Player Login Board
                </h3>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 font-black">
                  BIBLE ITEM 26
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                One-time Email login · Unique IDs from #100002+ · Owner #777777
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Current Active Account Card */}
        <div className="p-4 border-b border-white/10 bg-slate-900/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              {currentUser.role === 'owner' && (
                <div className="absolute -top-2 -right-1 text-sm">👑</div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white">{currentUser.name}</span>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40">
                  {currentUser.tag}
                </span>
              </div>
              <p className="text-[10px] text-slate-400">{currentUser.email}</p>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-[10px] font-mono font-black text-emerald-400">
                  ID: #{currentUser.id}
                </span>
                <button
                  onClick={handleCopyId}
                  className="text-[10px] text-amber-300 hover:text-white flex items-center gap-0.5 ml-1 transition"
                  title="Copy Player ID"
                >
                  <Copy size={10} />
                  <span>{copiedId ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>

          {currentUser.role === 'owner' && (
            <span className="px-2 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[10px] uppercase shadow-md flex items-center gap-1">
              <Crown size={12} />
              <span>Owner</span>
            </span>
          )}
        </div>

        {/* Body Form */}
        <div className="p-4 overflow-y-auto space-y-4">
          {/* Quick 1-Click Owner Login Shortcut */}
          <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/50 to-slate-900 border border-amber-500/40 flex items-center justify-between">
            <div>
              <p className="text-xs font-black text-amber-300 flex items-center gap-1">
                <span>👑</span> Sovereign Owner ID #777777
              </p>
              <p className="text-[10px] text-slate-300">
                Verified: akvikings05@gmail.com (Super Admin)
              </p>
            </div>
            <button
              onClick={() => handleEmailLogin('akvikings05@gmail.com')}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
            >
              Login Owner
            </button>
          </div>

          {/* Login Mode Switcher */}
          <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-900 border border-slate-800">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('email');
              }}
              className={`py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                activeTab === 'email'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Mail size={14} />
              <span>Login via Email</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('id');
              }}
              className={`py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 ${
                activeTab === 'id'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <KeyRound size={14} />
              <span>Login via Player ID</span>
            </button>
          </div>

          {/* TAB 1: EMAIL LOGIN / REGISTRATION */}
          {activeTab === 'email' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Enter Your Email Address:
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="e.g. rohit.player@gmail.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  New users will automatically receive a permanent ID (starting from #100002).
                </p>
              </div>

              <button
                onClick={() => handleEmailLogin()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition flex items-center justify-center gap-2"
              >
                <Send size={14} />
                <span>Continue & Save ID</span>
              </button>
            </div>
          )}

          {/* TAB 2: PLAYER ID LOGIN */}
          {activeTab === 'id' && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Enter Your Permanent Player ID Number:
                </label>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                  <input
                    type="text"
                    value={idInput}
                    onChange={(e) => setIdInput(e.target.value)}
                    placeholder="e.g. 777777 or 100002"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 text-xs font-mono font-bold focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Login instantly with the ID sent to your email.
                </p>
              </div>

              <button
                onClick={handleIdLogin}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition flex items-center justify-center gap-2"
              >
                <Check size={14} />
                <span>Verify & Login with ID</span>
              </button>
            </div>
          )}

          {/* Simulated Email Dispatch Card */}
          {emailDispatchSimulated && (
            <div className="p-3 rounded-2xl bg-emerald-950/70 border border-emerald-500/50 text-xs text-emerald-200 space-y-1 animate-fadeIn">
              <div className="flex items-center gap-1.5 font-bold text-emerald-300">
                <Send size={14} />
                <span>ID Dispatch Email Sent to: {emailDispatchSimulated.to}</span>
              </div>
              <p className="text-[11px] text-slate-200">
                "Welcome to Ludo Cosmic Royale! Your permanent Player ID is <strong>#{emailDispatchSimulated.id}</strong>. You can sign in anytime using your Email or ID #{emailDispatchSimulated.id}."
              </p>
            </div>
          )}

          {/* Feedback message */}
          {feedbackMessage && !emailDispatchSimulated && (
            <div className="p-2.5 rounded-xl bg-slate-900 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-2">
              <AlertCircle size={15} className="text-amber-400 shrink-0 mt-0.5" />
              <span>{feedbackMessage}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
