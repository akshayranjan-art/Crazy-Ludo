import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Trophy,
  Crown,
  Shield,
  Zap,
  Eye,
  Heart,
  Share2,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASSETS, ASTRA_ITEMS, RARE_PETS } from '../data/gameConstants';

interface PlayerMuseumModalProps {
  isOpen: boolean;
  onClose: () => void;
  equippedPetId: string;
  equippedAstraId: string;
  userFame: number;
}

export const PlayerMuseumModal: React.FC<PlayerMuseumModalProps> = ({
  isOpen,
  onClose,
  equippedPetId,
  equippedAstraId,
  userFame,
}) => {
  const [activeTab, setActiveTab] = useState<'hall' | 'astras' | 'trophies'>('hall');

  if (!isOpen) return null;

  const currentPet = RARE_PETS.find((p) => p.id === equippedPetId) || RARE_PETS[0];
  const currentAstra = ASTRA_ITEMS.find((a) => a.id === equippedAstraId) || ASTRA_ITEMS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg max-h-[92vh] flex flex-col glass-panel border-2 border-amber-500/40 rounded-3xl shadow-[0_0_50px_rgba(245,158,11,0.3)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-amber-500/20 bg-gradient-to-r from-amber-950/70 via-purple-950/80 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-xl shadow-[0_0_15px_#f59e0b]">
              🏛️
            </div>
            <div>
              <h2 className="text-base font-black text-amber-200 tracking-wide font-serif">
                VIKINGKING'S 3D MUSEUM
              </h2>
              <p className="text-[10px] text-slate-400">
                Personal 3D Showroom · 1,420 Visitors · Fame {userFame.toLocaleString()}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Tabs */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* 1. CENTRAL PEDESTAL: RAREST PET DISPLAY */}
          <div className="relative p-5 rounded-3xl bg-gradient-to-b from-purple-950/60 to-slate-900 border border-amber-400/30 flex flex-col items-center text-center shadow-xl">
            {/* Spotlight halo */}
            <div className="absolute top-0 w-32 h-32 bg-amber-400/15 rounded-full blur-2xl pointer-events-none" />

            <span className="text-[9px] font-black px-2.5 py-0.5 rounded-full bg-amber-500 text-slate-950 uppercase tracking-wider mb-2">
              Crown Guardian Companion
            </span>

            {/* 3D Pet Showcase */}
            <div className="relative w-28 h-28 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.5)] bg-slate-950 animate-pulse">
              <img
                src={currentPet.image}
                alt={currentPet.name}
                className="w-full h-full object-cover"
              />
            </div>

            <h3 className="text-base font-black text-white mt-2">{currentPet.name}</h3>
            <p className="text-xs text-amber-300 font-semibold">
              Level {currentPet.level} · Affection {currentPet.affection}% · {currentPet.rarity}
            </p>
            <p className="text-[10px] text-slate-300 mt-1 max-w-xs">{currentPet.bonus}</p>
          </div>

          {/* 2. SACRED ASTRA WEAPON SHRINE */}
          <div className="p-4 rounded-3xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300">
                <Zap size={14} className="text-cyan-400" />
                <span>Primary Astra Weapon Shrine</span>
              </div>
              <span className="text-[10px] text-amber-300 font-black">{currentAstra.tier}</span>
            </div>

            <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-black/40 border border-cyan-500/30">
              <div className="w-14 h-14 rounded-xl overflow-hidden border border-cyan-400 flex-shrink-0">
                <img src={currentAstra.image} alt={currentAstra.name} className="w-full h-full object-cover" />
              </div>
              <div>
                <h4 className="text-xs font-black text-white">{currentAstra.name}</h4>
                <p className="text-[10px] text-slate-400">{currentAstra.element}</p>
                <p className="text-[10px] text-amber-300 font-bold mt-0.5">{currentAstra.passiveBonus}</p>
              </div>
            </div>
          </div>

          {/* 3. TROPHIES & COMBO BADGES CABINET */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
              <span className="text-2xl">🏆</span>
              <p className="text-[11px] font-bold text-white mt-1">Hall of Fame</p>
              <p className="text-[9px] text-amber-400">Season 1 God</p>
            </div>

            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
              <span className="text-2xl">⚔️</span>
              <p className="text-[11px] font-bold text-white mt-1">Cut Master</p>
              <p className="text-[9px] text-rose-400">890 Kills</p>
            </div>

            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 text-center">
              <span className="text-2xl">🧚</span>
              <p className="text-[11px] font-bold text-white mt-1">Flute Master</p>
              <p className="text-[9px] text-emerald-400">Miracle Arrival</p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3 border-t border-white/10 bg-black/40 flex items-center justify-between">
          <p className="text-[10px] text-slate-400">Publicly visible to all room visitors</p>
          <button
            onClick={() => {
              sound.playFanfare();
              alert('Museum link shared to Room Chat!');
            }}
            className="liquid-btn-gold text-slate-950 font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5"
          >
            <Share2 size={13} />
            <span>SHARE MUSEUM</span>
          </button>
        </div>
      </div>
    </div>
  );
};
