import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Flame,
  Gift,
  Crown,
  Heart,
  Sparkles,
  Send,
  Plus,
  Play,
  ArrowRight,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASSETS } from '../data/gameConstants';
import { LiveRoom } from '../types/game';

interface LiveRoomsDirectoryViewProps {
  onEnterRoom: (room: LiveRoom) => void;
  onNavigate: (view: 'lobby' | 'rooms' | 'arena' | 'leaderboard' | 'store' | 'profile') => void;
}

export const LiveRoomsDirectoryView: React.FC<LiveRoomsDirectoryViewProps> = ({
  onEnterRoom,
  onNavigate,
}) => {
  const [messages, setMessages] = useState([
    { id: '1', sender: 'Ananya', text: 'Hello everyone! 👋', color: 'text-pink-300' },
    { id: '2', sender: 'Rohan', text: 'Hi Ananya! Ready to play? 😎', color: 'text-amber-300' },
    { id: '3', sender: 'Priya', text: "Let's do this! 🎲", color: 'text-cyan-300' },
    { id: '4', sender: 'Karan', text: 'All the best team! 🍀', color: 'text-emerald-300' },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isMicOn, setIsMicOn] = useState(true);

  // 8 Authentic Seats (Matching Screenshot 3)
  const roomSeats = [
    { id: 1, type: 'open', label: 'Open Mic', num: 1 },
    { id: 2, type: 'user', name: 'Ananya', level: 28, frame: 'border-pink-500 shadow-[0_0_12px_#EC4899]', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80', badge: '👑' },
    { id: 3, type: 'user', name: 'Rohan', level: 35, frame: 'border-amber-400 shadow-[0_0_15px_#F59E0B]', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80', badge: '🦁' },
    { id: 4, type: 'user', name: 'Ishita', level: 22, frame: 'border-purple-400 shadow-[0_0_12px_#A855F7]', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80', badge: '✨' },
    { id: 5, type: 'open', label: 'Open Mic', num: 5 },
    { id: 6, type: 'open', label: 'Open Mic', num: 6 },
    { id: 7, type: 'user', name: 'Priya', level: 18, frame: 'border-yellow-300 shadow-[0_0_10px_#FDE047]', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80', badge: '💖' },
    { id: 8, type: 'user', name: 'You', level: 58, frame: 'border-cyan-400 shadow-[0_0_15px_#00F2FE]', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80', isYou: true },
  ];

  const handleSendChat = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;
    sound.playClick();
    setMessages((prev) => [
      ...prev,
      { id: Date.now().toString(), sender: 'You', text: chatInput, color: 'text-amber-300' },
    ]);
    setChatInput('');
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-3 pb-24 animate-fade-in px-3">
      {/* 1. HEADER (Exact match with Screenshot 3) */}
      <div className="text-center pt-1 pb-1">
        <div className="w-36 h-12 mx-auto drop-shadow-lg">
          <img src={ASSETS.logo} alt="LUDO PLAY" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-xl font-black tracking-wide text-white uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
          LIVE CHATROOM
        </h1>
        <div className="inline-flex items-center gap-1 px-4 py-0.5 rounded-full bg-gradient-to-r from-purple-900 via-indigo-800 to-purple-900 border border-amber-400/40 shadow-sm mt-0.5">
          <span className="text-amber-300 text-xs">★</span>
          <span className="text-[11px] font-bold text-amber-200">Talk, Meet & Play Together!</span>
          <span className="text-amber-300 text-xs">★</span>
        </div>
      </div>

      {/* 2. 8-SEAT LIVE AUDIO STAGE (Screenshot 3 Grid) */}
      <div className="p-3.5 rounded-3xl bg-gradient-to-b from-indigo-950/80 to-purple-950/90 border border-purple-500/30 shadow-2xl">
        <div className="grid grid-cols-4 gap-3 text-center">
          {roomSeats.map((seat) => (
            <div key={seat.id} className="flex flex-col items-center">
              {seat.type === 'open' ? (
                // Open Mic Slot
                <div
                  onClick={() => {
                    sound.playMicBeep(true);
                  }}
                  className="w-14 h-14 rounded-full border-2 border-dashed border-white/30 bg-black/40 flex flex-col items-center justify-center cursor-pointer hover:border-amber-400 transition group"
                >
                  <Mic size={18} className="text-slate-400 group-hover:text-amber-400" />
                  <span className="text-[9px] font-bold text-slate-400">{seat.num}</span>
                </div>
              ) : (
                // Occupied User Seat with Level Ring & Badge
                <div className="relative">
                  <div
                    className={`w-14 h-14 rounded-full overflow-hidden border-2 ${seat.frame} bg-slate-900 shadow-lg`}
                  >
                    <img src={seat.avatar} alt={seat.name} className="w-full h-full object-cover" />
                  </div>
                  {/* Level Pill */}
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[8px] font-black shadow-md border border-white/40">
                    {seat.level}
                  </span>
                  {/* Host badge */}
                  {seat.badge && (
                    <span className="absolute -top-1.5 -right-1 text-xs drop-shadow-md">
                      {seat.badge}
                    </span>
                  )}
                </div>
              )}
              <span className="text-[10px] font-bold text-white mt-1.5 truncate max-w-[65px]">
                {seat.name || seat.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 3. LIVE CHAT STREAM BOX (Screenshot 3) */}
      <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/10 shadow-lg space-y-2">
        {/* Welcome Notice */}
        <div className="p-2 rounded-xl bg-purple-950/60 border border-purple-400/30 flex items-center gap-2">
          <span className="text-lg">🎉</span>
          <p className="text-[10px] text-purple-200">
            <strong>Welcome to Ludo Play Chatroom!</strong> Be kind, chat nicely and enjoy the game together.
          </p>
        </div>

        {/* Messages List */}
        <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1 text-xs scrollbar-none">
          {messages.map((m) => (
            <p key={m.id} className="text-[11px] leading-tight">
              <strong className={m.color}>{m.sender}: </strong>
              <span className="text-slate-200">{m.text}</span>
            </p>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form onSubmit={handleSendChat} className="flex items-center gap-2 pt-1 border-t border-white/5">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder="Type a nice message..."
            className="flex-1 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400/50"
          />
          <button
            type="submit"
            className="p-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition"
          >
            <Send size={15} />
          </button>
        </form>
      </div>

      {/* 4. SEND GIFTS - WIN HEARTS (Screenshot 3) */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/80 via-pink-950/70 to-slate-900 border border-pink-500/30 flex items-center justify-between shadow-lg">
        <div>
          <div className="flex items-center gap-1 text-xs font-black text-pink-300">
            <Gift size={14} className="text-pink-400" />
            <span>Send Gifts</span>
          </div>
          <p className="text-[10px] text-slate-400">Win Hearts</p>
        </div>

        <div className="flex items-center gap-2">
          {/* Rose */}
          <button
            onClick={() => {
              sound.playFanfare();
              setMessages((prev) => [
                ...prev,
                { id: Date.now().toString(), sender: 'You', text: 'sent 🌹 Golden Rose to Ananya!', color: 'text-amber-300' },
              ]);
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-pink-500/20 border border-white/10 text-center transition active:scale-95"
          >
            <span className="text-lg">🌹</span>
            <p className="text-[9px] font-black text-amber-300">🪙 10</p>
          </button>

          {/* Heart */}
          <button
            onClick={() => {
              sound.playFanfare();
              setMessages((prev) => [
                ...prev,
                { id: Date.now().toString(), sender: 'You', text: 'sent 💖 Heart Love to the room!', color: 'text-pink-300' },
              ]);
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-pink-500/20 border border-white/10 text-center transition active:scale-95"
          >
            <span className="text-lg">💖</span>
            <p className="text-[9px] font-black text-amber-300">🪙 29</p>
          </button>

          {/* Trophy */}
          <button
            onClick={() => {
              sound.playFanfare();
              setMessages((prev) => [
                ...prev,
                { id: Date.now().toString(), sender: 'You', text: 'sent 🏆 Golden Trophy to Arjun!', color: 'text-yellow-300' },
              ]);
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-pink-500/20 border border-white/10 text-center transition active:scale-95"
          >
            <span className="text-lg">🏆</span>
            <p className="text-[9px] font-black text-amber-300">🪙 99</p>
          </button>
        </div>
      </div>

      {/* 5. TOP GIFTER THIS WEEK PODIUM (Screenshot 3) */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/70 via-purple-950/80 to-slate-950 border border-amber-400/40 shadow-xl space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-black text-amber-300">
            <Crown size={14} className="text-amber-400" />
            <span>Top Gifter This Week</span>
          </div>
          <span className="text-[10px] text-amber-400/80 font-bold">Refreshes Sunday</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* #1 Arjun */}
          <div className="p-2 rounded-xl bg-black/40 border border-amber-400/30 flex items-center gap-2">
            <span className="text-sm font-black text-amber-400">#1</span>
            <div className="w-8 h-8 rounded-full overflow-hidden border border-amber-400">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&auto=format&fit=crop&q=80"
                alt="Arjun"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <p className="text-[11px] font-bold text-white">Arjun</p>
              <p className="text-[10px] font-black text-amber-300 flex items-center gap-0.5">
                🌹 x77
              </p>
            </div>
          </div>

          {/* #2 Vihaan */}
          <div className="p-2 rounded-xl bg-black/40 border border-slate-400/30 flex items-center gap-2">
            <span className="text-sm font-black text-slate-300">#2</span>
            <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-300">
              <img
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&auto=format&fit=crop&q=80"
                alt="Vihaan"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <p className="text-[11px] font-bold text-white">Vihaan</p>
              <p className="text-[10px] font-black text-cyan-300 flex items-center gap-0.5">
                🏎️ x7
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 6. LAUNCH GAME FROM STAGE BUTTON */}
      <button
        onClick={() => {
          sound.playDiceRoll();
          onNavigate('arena');
        }}
        className="w-full py-3.5 rounded-2xl liquid-btn-gold text-slate-950 font-black text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-xl"
      >
        <Play size={16} />
        <span>START 4P MATCH WITH ROOM</span>
      </button>
    </div>
  );
};
