import React from 'react';
import {
  Compass,
  Sparkles,
  Crown,
  Zap,
  Radio,
  Gamepad2,
  Trophy,
  Lock,
  ChevronRight,
  ArrowRight,
  Eye,
  MapPin,
  X,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASSETS } from '../data/gameConstants';

interface WorldMapViewProps {
  onNavigate: (view: 'lobby' | 'rooms' | 'arena' | 'leaderboard' | 'store' | 'profile') => void;
  onOpenModal: (modal: 'astra' | 'pets' | 'gifts' | 'codex' | 'minigames' | 'crates' | 'admin') => void;
  onOpenMuseum: () => void;
}

export const WorldMapView: React.FC<WorldMapViewProps> = ({
  onNavigate,
  onOpenModal,
  onOpenMuseum,
}) => {
  const worldIslands = [
    {
      id: 'ludo-kingdom',
      name: '🏰 Ludo Royal Kingdom',
      hindi: 'लूडो राजमहल',
      desc: 'Heart of the Universe · 4P/8P Cosmic Arena battles',
      status: 'UNLOCKED',
      action: () => onNavigate('arena'),
      btnText: 'Enter Arena',
      color: 'from-amber-600 to-yellow-500',
      border: 'border-amber-400',
      bgImg: ASSETS.roomPawns,
      unlocked: true,
    },
    {
      id: 'astra-temple',
      name: '🔱 Astra Divine Temple',
      hindi: 'अस्त्र महामंदिर',
      desc: 'Abode of Mahadev Trishul, Hanuman Gada & Sudarshan Chakra',
      status: 'DIVINE',
      action: () => onOpenModal('astra'),
      btnText: 'Summon Astras',
      color: 'from-cyan-600 to-blue-500',
      border: 'border-cyan-400',
      bgImg: ASSETS.sudarshan,
      unlocked: true,
    },
    {
      id: 'pet-forest',
      name: '🐉 Mythic Pet Forest',
      hindi: 'रहस्यमयी वन',
      desc: 'Habitat of 30 Ultra-Rare Pets · Dragon, Lion & Moon Wolf',
      status: '30 SPECIES',
      action: () => onOpenModal('pets'),
      btnText: 'Visit Pets',
      color: 'from-emerald-600 to-teal-500',
      border: 'border-emerald-400',
      bgImg: ASSETS.dragonPet,
      unlocked: true,
    },
    {
      id: 'live-oasis',
      name: '🎙️ Live Audio Rooms Oasis',
      hindi: 'लाइव आवाज़ दरबार',
      desc: '8-Seat VIP Voice Stages, luxury gift showers & private rooms',
      status: 'LIVE 8-SEAT',
      action: () => onNavigate('rooms'),
      btnText: 'Join Stage',
      color: 'from-purple-600 to-pink-500',
      border: 'border-purple-400',
      bgImg: ASSETS.hostAnanya,
      unlocked: true,
    },
    {
      id: 'arcade-island',
      name: '🎯 Mini-Games Island',
      hindi: 'खेल द्वीप',
      desc: 'Bow & Arrow (Takshak Nag), Dot Connect (Chilli Puzzle) & Wheels',
      status: 'ARCADE',
      action: () => onOpenModal('minigames'),
      btnText: 'Play Games',
      color: 'from-rose-600 to-orange-500',
      border: 'border-rose-400',
      bgImg: ASSETS.hypercar,
      unlocked: true,
    },
    {
      id: 'player-museum',
      name: '🏛️ Digital Player Museum',
      hindi: 'शाही संग्रहालय',
      desc: 'Your 3D showroom for rarest pets, trophies, Astras & tiny companions',
      status: 'PERSONAL 3D',
      action: () => onOpenMuseum(),
      btnText: 'View Showroom',
      color: 'from-yellow-600 to-amber-500',
      border: 'border-yellow-400',
      bgImg: ASSETS.trishul,
      unlocked: true,
    },
    {
      id: 'mystery-valley',
      name: '🌋 Secret Valley & Chaos Core',
      hindi: 'गुप्त रहस्य लोक',
      desc: 'Locked mystery portal · Unlocks upon collecting 5 rare relics',
      status: 'LOCKED',
      action: () => onOpenModal('codex'),
      btnText: 'Explore Clues',
      color: 'from-slate-700 to-slate-900',
      border: 'border-slate-600',
      bgImg: ASSETS.sudarshan,
      unlocked: false,
    },
  ];

  return (
    <div className="w-full max-w-md mx-auto space-y-4 pb-24 animate-fade-in px-3 relative">
      {/* Top Right Exit/Close Button */}
      <button
        onClick={() => {
          sound.playClick();
          onNavigate('lobby');
        }}
        className="absolute top-2 right-3 z-30 p-2 rounded-full bg-slate-900/90 hover:bg-red-950/80 border border-amber-400/50 hover:border-red-400 text-amber-300 hover:text-white transition shadow-lg active:scale-95 flex items-center gap-1 cursor-pointer"
        title="Return to Lobby"
        aria-label="Close Screen"
      >
        <span className="text-[10px] font-black uppercase hidden sm:inline">Close</span>
        <X size={16} />
      </button>

      {/* 1. HEADER */}
      <div className="text-center pt-1 pb-1">
        <div className="w-36 h-12 mx-auto drop-shadow-lg">
          <img src={ASSETS.logo} alt="LUDO PLAY" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-xl font-black tracking-wide text-amber-300 uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
          3D WORLD MAP
        </h1>
        <div className="inline-flex items-center gap-1 px-4 py-0.5 rounded-full bg-gradient-to-r from-purple-900 via-indigo-800 to-purple-900 border border-amber-400/40 shadow-sm mt-0.5">
          <span className="text-amber-300 text-xs">🗺️</span>
          <span className="text-[11px] font-bold text-amber-200">Explore Islands & Secret Realms</span>
          <span className="text-amber-300 text-xs">🗺️</span>
        </div>
      </div>

      {/* 2. CELESTIAL ISLAND NODES LIST */}
      <div className="space-y-3">
        {worldIslands.map((island, idx) => (
          <div
            key={island.id}
            onClick={() => {
              sound.playClick();
              island.action();
            }}
            className={`group relative p-3.5 rounded-3xl overflow-hidden glass-panel border ${island.border} glass-card-hover cursor-pointer shadow-xl flex items-center justify-between gap-3`}
          >
            {/* Background Graphic Asset Preview */}
            <div className="w-16 h-16 rounded-2xl overflow-hidden border border-white/10 flex-shrink-0 group-hover:scale-105 transition shadow-md">
              <img
                src={island.bgImg}
                alt={island.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Island Info */}
            <div className="flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-white/10 text-amber-300 uppercase">
                  {island.status}
                </span>
                <span className="text-[10px] text-slate-400 font-bold">{island.hindi}</span>
              </div>
              <h3 className="text-sm font-black text-white mt-0.5 group-hover:text-amber-300 transition">
                {island.name}
              </h3>
              <p className="text-[10px] text-slate-300 line-clamp-1 mt-0.5">{island.desc}</p>
            </div>

            {/* Action Icon */}
            <div className="flex-shrink-0">
              <span className="w-8 h-8 rounded-full bg-white/10 group-hover:bg-amber-400 group-hover:text-slate-950 flex items-center justify-center text-xs font-bold transition shadow-sm">
                <ArrowRight size={14} />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
