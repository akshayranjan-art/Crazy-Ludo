import React, { useState } from 'react';
import {
  Coins,
  Sparkles,
  Zap,
  Shield,
  CreditCard,
  Gift,
  Check,
  Flame,
  ArrowRight,
  Car,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASSETS, EXACT_DIAMOND_SHOP_TIERS, TEN_COIN_ITEMS } from '../data/gameConstants';
import { RealisticCoinIcon, RealisticDiamondIcon } from './RealIcons';

interface StoreViewProps {
  userDiamonds: number;
  userCoins: number;
  onAddDiamonds: (amount: number) => void;
  onAddCoins: (amount: number) => void;
  onOpenModal: (modal: any) => void;
}

export const StoreView: React.FC<StoreViewProps> = ({
  userDiamonds,
  userCoins,
  onAddDiamonds,
  onAddCoins,
  onOpenModal,
}) => {
  const [activeTab, setActiveTab] = useState<'diamonds' | 'coins10' | 'vehicles'>('diamonds');
  const [purchasedId, setPurchasedId] = useState<string | null>(null);
  const [claimedDailyCoins, setClaimedDailyCoins] = useState(false);

  const diamondPacks = EXACT_DIAMOND_SHOP_TIERS;

  const vehicles = [
    {
      id: 'veh-bugatti',
      name: 'Neon Bugatti Chiron Supercar',
      type: 'Mega Supercar',
      cost: 1500,
      image: ASSETS.hypercar,
      speedVfx: 'Supersonic Cyan Trail & Engine Roar',
    },
    {
      id: 'veh-rath',
      name: 'Surya 7-Horse Golden Rath',
      type: 'Vedic Chariot',
      cost: 5000,
      image: ASSETS.sudarshan,
      speedVfx: 'Radiant Solar Flares & Divine Bell',
    },
  ];

  const handlePurchase = (id: string, diamonds: number) => {
    sound.playFanfare();
    onAddDiamonds(diamonds);
    setPurchasedId(id);
    setTimeout(() => setPurchasedId(null), 2500);
  };

  const handleClaimDailyCoins = () => {
    sound.playGrandVictory();
    onAddCoins(500);
    setClaimedDailyCoins(true);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-24 animate-fade-in px-2 sm:px-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
            <Coins size={22} />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-white tracking-wide">
              Cosmic Treasury & Diamond Store
            </h1>
            <p className="text-xs text-slate-400">
              Exact Game Bible Tiers (₹49 to ₹19,999) • 10-50 Coin Micro-Items • 500 Daily Coins
            </p>
          </div>
        </div>

        {/* 500 Daily Login Coins Button */}
        <button
          disabled={claimedDailyCoins}
          onClick={handleClaimDailyCoins}
          className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
            claimedDailyCoins
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md hover:scale-105 active:scale-95'
          }`}
        >
          <RealisticCoinIcon size={16} />
          <span>{claimedDailyCoins ? 'CLAIMED 500' : 'CLAIM 500 DAILY COINS'}</span>
        </button>
      </div>

      {/* Free Instant Developer Test Boost Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-emerald-950/70 via-teal-950/80 to-slate-900 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <span className="text-3xl">💎</span>
          <div>
            <h3 className="font-bold text-white text-sm">Instant Testing Vault (Free Sandbox)</h3>
            <p className="text-xs text-emerald-300">
              Inject +100 Million 💎 immediately to test all divine Astras and luxury gifts!
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            sound.playFanfare();
            onAddDiamonds(100000000);
          }}
          className="liquid-btn-cyan text-slate-950 font-black px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 flex-shrink-0"
        >
          <Sparkles size={14} />
          +100,000,000 💎 FREE
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'diamonds', label: '💎 Diamond Vault (₹49 - ₹19,999)' },
          { id: 'coins10', label: '🪙 10-50 Coin Items (Bible Ex.)' },
          { id: 'vehicles', label: '🏎️ Hypercar Garage' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              sound.playClick();
              setActiveTab(tab.id as any);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
              activeTab === tab.id
                ? 'liquid-btn-gold text-slate-950 font-black'
                : 'glass-card text-slate-300 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Diamond Vault Grid (Exact Bible Tiers ₹49 to ₹19,999) */}
      {activeTab === 'diamonds' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {diamondPacks.map((pack) => {
            const isPurchased = purchasedId === pack.id;
            return (
              <div
                key={pack.id}
                className={`group relative p-4 rounded-3xl glass-panel border ${
                  pack.popular ? 'border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]' : 'border-white/10'
                } glass-card-hover flex flex-col justify-between overflow-hidden`}
              >
                {/* Top Badge */}
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[9px] font-black px-1.5 py-0.5 rounded-full bg-white/10 text-amber-300 border border-white/10">
                    {pack.badge || 'PACK'}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-bold truncate max-w-[90px]">{pack.bonusText}</span>
                </div>

                {/* Amount */}
                <div className="text-center py-2 flex flex-col items-center">
                  <RealisticDiamondIcon size={32} />
                  <h3 className="text-xl font-black text-white mt-1">
                    {pack.diamonds.toLocaleString()}
                  </h3>
                  <p className="text-[10px] text-amber-300 font-semibold">Diamonds</p>
                </div>

                {/* Price & Buy Button */}
                <button
                  onClick={() => handlePurchase(pack.id, pack.diamonds)}
                  className={`w-full py-2.5 rounded-xl font-black text-xs transition flex items-center justify-center gap-1.5 ${
                    isPurchased
                      ? 'bg-emerald-500 text-slate-950'
                      : 'liquid-btn-gold text-slate-950 shadow-md'
                  }`}
                >
                  {isPurchased ? (
                    <>
                      <Check size={14} /> ADDED
                    </>
                  ) : (
                    <>
                      <span>BUY {pack.priceLabel}</span>
                      <ArrowRight size={12} />
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* 10-50 Coin Items (Bible Item 7) */}
      {activeTab === 'coins10' && (
        <div className="space-y-4">
          <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/20 flex items-center justify-between">
            <span className="text-xs text-amber-200">
              🪙 <strong>Coin Micro-Economy:</strong> Ten items discussed in Game Bible available at 10, 20, 30, 40, and 50 coins!
            </span>
            <span className="text-xs text-yellow-300 font-black">
              Balance: {userCoins.toLocaleString()} 🪙
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {TEN_COIN_ITEMS.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-400/40 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl">{item.icon}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-yellow-300 font-black border border-amber-500/30">
                      {item.coinCost} 🪙
                    </span>
                  </div>
                  <h4 className="text-xs font-black text-white mt-1.5">{item.name}</h4>
                  <span className="text-[10px] text-slate-400 block">{item.hindiName}</span>
                  <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">{item.description}</p>
                </div>
                <button
                  onClick={() => {
                    sound.playCoinDrop();
                    setPurchasedId(item.id);
                    setTimeout(() => setPurchasedId(null), 2000);
                  }}
                  className="mt-3 w-full py-1.5 rounded-xl text-[10px] font-black bg-amber-500 hover:bg-amber-400 text-slate-950 transition"
                >
                  {purchasedId === item.id ? 'ACTIVE' : `BUY (${item.coinCost} 🪙)`}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Vehicles Grid */}
      {activeTab === 'vehicles' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {vehicles.map((v) => (
            <div
              key={v.id}
              className="p-5 rounded-3xl glass-panel border border-cyan-500/20 flex flex-col justify-between gap-4"
            >
              <div className="relative h-40 rounded-2xl overflow-hidden border border-white/10">
                <img src={v.image} alt={v.name} className="w-full h-full object-cover" />
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md text-cyan-300 text-[10px] font-bold">
                  {v.type}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-white text-base">{v.name}</h3>
                <p className="text-xs text-slate-400 mt-1">{v.speedVfx}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/10">
                <span className="text-sm font-black text-amber-300 flex items-center gap-1">
                  💎 {v.cost.toLocaleString()}
                </span>
                <button
                  onClick={() => {
                    sound.playFanfare();
                    setPurchasedId(v.id);
                    setTimeout(() => setPurchasedId(null), 2000);
                  }}
                  className="px-4 py-2 rounded-xl liquid-btn-cyan text-slate-950 font-black text-xs"
                >
                  {purchasedId === v.id ? 'EQUIPPED IN GARAGE' : 'EQUIP VEHICLE'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Compliance Note */}
      <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 text-[11px] text-slate-400 text-center">
        🛡️ <strong>Fair Play & In-Game Virtual Economy:</strong> Diamonds, Stars & Coins are strictly virtual entertainment items for unlocking 3D avatar frames, pets, Astras and visual room effects. Exchange was explicitly removed from the concept scope per legal guidelines.
      </div>
    </div>
  );
};

