import React, { useState } from 'react';
import {
  X,
  Crown,
  Trophy,
  Sparkles,
  Zap,
  CheckCircle2,
  Lock,
  Gift,
  Coins,
  Flame,
  ChevronRight,
  Shield,
  Star,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

export interface PassTier {
  level: number;
  xpRequired: number;
  freeReward: {
    title: string;
    type: 'coins' | 'diamonds' | 'astra' | 'frame';
    amount?: number;
    icon: string;
  };
  vipReward: {
    title: string;
    type: 'coins' | 'diamonds' | 'astra' | 'frame' | 'dice';
    amount?: number;
    icon: string;
  };
}

export interface PassQuest {
  id: string;
  title: string;
  desc: string;
  xpReward: number;
  bonusReward?: string;
  progress: number;
  target: number;
  isClaimed: boolean;
  icon: string;
}

export const PASS_TIERS: PassTier[] = [
  {
    level: 1,
    xpRequired: 100,
    freeReward: { title: '10,000 Gold Coins', type: 'coins', amount: 10000, icon: '🪙' },
    vipReward: { title: '100,000 Gold + VIP Crown Frame', type: 'frame', icon: '👑' },
  },
  {
    level: 2,
    xpRequired: 250,
    freeReward: { title: '50 Cosmic Diamonds', type: 'diamonds', amount: 50, icon: '💎' },
    vipReward: { title: '500 Cosmic Diamonds', type: 'diamonds', amount: 500, icon: '💎' },
  },
  {
    level: 3,
    xpRequired: 450,
    freeReward: { title: '1x Hanuman Gada Charge', type: 'astra', icon: '🔨' },
    vipReward: { title: '3x Hanuman Gada Earthquake Slam', type: 'astra', icon: '🔨' },
  },
  {
    level: 4,
    xpRequired: 700,
    freeReward: { title: '25,000 Gold Coins', type: 'coins', amount: 25000, icon: '🪙' },
    vipReward: { title: 'Golden Celestial 3D Dice Skin', type: 'dice', icon: '🎲' },
  },
  {
    level: 5,
    xpRequired: 1000,
    freeReward: { title: '100 Cosmic Diamonds', type: 'diamonds', amount: 100, icon: '💎' },
    vipReward: { title: '1x Mahadev Trishul Tandav Astra', type: 'astra', icon: '🔱' },
  },
  {
    level: 6,
    xpRequired: 1350,
    freeReward: { title: '50,000 Gold Coins', type: 'coins', amount: 50000, icon: '🪙' },
    vipReward: { title: '1,500 Cosmic Diamonds', type: 'diamonds', amount: 1500, icon: '💎' },
  },
  {
    level: 7,
    xpRequired: 1750,
    freeReward: { title: '1x Indra Vajra Shield', type: 'astra', icon: '⚡' },
    vipReward: { title: 'Mythic "Kurukshetra Conqueror" Title', type: 'frame', icon: '🎖️' },
  },
  {
    level: 8,
    xpRequired: 2200,
    freeReward: { title: '100,000 Gold Coins', type: 'coins', amount: 100000, icon: '🪙' },
    vipReward: { title: '5,000 Cosmic Diamonds + Rare Pet Egg', type: 'diamonds', amount: 5000, icon: '🥚' },
  },
];

interface SeasonPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onAddCoins: (amt: number) => void;
  onAddDiamonds: (amt: number) => void;
}

export const SeasonPassModal: React.FC<SeasonPassModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onAddCoins,
  onAddDiamonds,
}) => {
  const [activeTab, setActiveTab] = useState<'rewards' | 'quests'>('rewards');
  const [currentLevel, setCurrentLevel] = useState<number>(4);
  const [currentXP, setCurrentXP] = useState<number>(680);
  const [isVipUnlocked, setIsVipUnlocked] = useState<boolean>(false);
  const [claimedFreeLevels, setClaimedFreeLevels] = useState<number[]>([1, 2]);
  const [claimedVipLevels, setClaimedVipLevels] = useState<number[]>([]);

  // Daily & Weekly Missions State
  const [quests, setQuests] = useState<PassQuest[]>([
    {
      id: 'q1',
      title: 'Chhakka Master',
      desc: 'Roll three 6s in any Arena or Private Room match',
      xpReward: 250,
      bonusReward: '25,000 Coins',
      progress: 3,
      target: 3,
      isClaimed: false,
      icon: '🎲',
    },
    {
      id: 'q2',
      title: 'Astra Commander',
      desc: 'Activate Hanuman Gada or Trishul Tandav in the Arena',
      xpReward: 350,
      bonusReward: '50 Diamonds',
      progress: 1,
      target: 1,
      isClaimed: false,
      icon: '🔨',
    },
    {
      id: 'q3',
      title: 'Pawn Hunter',
      desc: 'Capture 2 opponent tokens on the main circular track',
      xpReward: 300,
      bonusReward: '40,000 Coins',
      progress: 2,
      target: 2,
      isClaimed: false,
      icon: '⚔️',
    },
    {
      id: 'q4',
      title: 'Arena VIP Socialite',
      desc: 'Throw a throwable item or send a VIP voice taunt',
      xpReward: 200,
      bonusReward: '15,000 Coins',
      progress: 1,
      target: 1,
      isClaimed: true,
      icon: '🍅',
    },
    {
      id: 'q5',
      title: 'Grand Champion',
      desc: 'Reach 1st position in a 4-player Ludo clash',
      xpReward: 500,
      bonusReward: '100 Diamonds',
      progress: 1,
      target: 1,
      isClaimed: false,
      icon: '🏆',
    },
  ]);

  if (!isOpen) return null;

  const currentTier = PASS_TIERS.find((t) => t.level === currentLevel) || PASS_TIERS[0];
  const nextTier = PASS_TIERS.find((t) => t.level === currentLevel + 1);
  const nextXpGoal = nextTier ? nextTier.xpRequired : 2500;
  const progressPercent = Math.min(100, Math.round((currentXP / nextXpGoal) * 100));

  const handleClaimFreeReward = (tier: PassTier) => {
    if (claimedFreeLevels.includes(tier.level)) return;
    if (tier.level > currentLevel) return;

    sound.playFanfare();
    confetti({ particleCount: 70, spread: 60 });
    setClaimedFreeLevels((prev) => [...prev, tier.level]);

    if (tier.freeReward.type === 'coins' && tier.freeReward.amount) {
      onAddCoins(tier.freeReward.amount);
    } else if (tier.freeReward.type === 'diamonds' && tier.freeReward.amount) {
      onAddDiamonds(tier.freeReward.amount);
    }
  };

  const handleClaimVipReward = (tier: PassTier) => {
    if (!isVipUnlocked) {
      sound.playClick();
      return;
    }
    if (claimedVipLevels.includes(tier.level)) return;
    if (tier.level > currentLevel) return;

    sound.playGrandVictory();
    confetti({ particleCount: 100, spread: 80 });
    setClaimedVipLevels((prev) => [...prev, tier.level]);

    if (tier.vipReward.type === 'coins' && tier.vipReward.amount) {
      onAddCoins(tier.vipReward.amount);
    } else if (tier.vipReward.type === 'diamonds' && tier.vipReward.amount) {
      onAddDiamonds(tier.vipReward.amount);
    }
  };

  const handleClaimQuest = (questId: string) => {
    const q = quests.find((item) => item.id === questId);
    if (!q || q.isClaimed || q.progress < q.target) return;

    sound.playTrophy();
    confetti({ particleCount: 80, spread: 70 });

    setQuests((prev) =>
      prev.map((item) => (item.id === questId ? { ...item, isClaimed: true } : item))
    );

    // Add XP & potential level up
    const newXP = currentXP + q.xpReward;
    if (nextTier && newXP >= nextTier.xpRequired) {
      setCurrentLevel((prev) => Math.min(8, prev + 1));
      sound.playFanfare();
    }
    setCurrentXP(newXP);

    if (q.bonusReward?.includes('Coins')) {
      onAddCoins(35000);
    } else if (q.bonusReward?.includes('Diamonds')) {
      onAddDiamonds(75);
    }
  };

  const handleUnlockVipPass = () => {
    if (userDiamonds < 499) {
      alert('Insufficient Diamonds! Use Admin Center to boost diamonds instantly.');
      return;
    }

    sound.playGrandVictory();
    confetti({ particleCount: 150, spread: 100 });
    onAddDiamonds(-499);
    setIsVipUnlocked(true);
    setCurrentXP((prev) => prev + 500);
    setCurrentLevel((prev) => Math.min(8, prev + 1));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#160a29] via-[#0d0718] to-black text-slate-100 shadow-[0_0_50px_rgba(245,158,11,0.25)]">
        {/* Top Header Banner */}
        <div className="relative p-4 sm:p-5 bg-gradient-to-r from-amber-600/30 via-purple-700/30 to-amber-600/30 border-b border-amber-500/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-2xl shadow-[0_0_20px_rgba(245,158,11,0.5)] border border-amber-300">
                👑
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 tracking-wide">
                    Season 1: Kurukshetra Pass
                  </h2>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold">
                    27 DAYS LEFT
                  </span>
                </div>
                <p className="text-xs text-amber-200/80 font-medium">
                  Exclusive Astra Weapons, Golden 3D Dice & 1,000,000+ Bounty
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>

          {/* Level Progress Bar & VIP Status */}
          <div className="mt-4 p-3 rounded-2xl bg-black/50 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="w-full sm:w-2/3">
              <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                <span className="text-amber-300 flex items-center gap-1.5">
                  <Flame size={14} className="text-orange-400 animate-pulse" />
                  Pass Level {currentLevel} of 8
                </span>
                <span className="text-slate-400 font-mono">
                  {currentXP} / {nextXpGoal} XP
                </span>
              </div>
              {/* Animated Progress Track */}
              <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 rounded-full transition-all duration-700 shadow-[0_0_12px_rgba(245,158,11,0.8)]"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>

            {/* VIP Status Pill / Unlock Button */}
            {!isVipUnlocked ? (
              <button
                onClick={handleUnlockVipPass}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(245,158,11,0.5)] active:scale-95 transition cursor-pointer"
              >
                <Crown size={16} />
                <span>Unlock VIP Pass (499 💎)</span>
              </button>
            ) : (
              <div className="px-3 py-1.5 rounded-xl bg-purple-600/30 border border-purple-400 text-purple-300 text-xs font-black flex items-center gap-1.5 shadow-md">
                <Sparkles size={14} className="text-yellow-400 animate-spin" />
                <span>ROYAL VIP ACTIVATED</span>
              </div>
            )}
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-4">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('rewards');
              }}
              className={`flex-1 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
                activeTab === 'rewards'
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-lg'
                  : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <Trophy size={14} />
              <span>Reward Roadmap (Levels 1-8)</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('quests');
              }}
              className={`flex-1 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition ${
                activeTab === 'quests'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                  : 'bg-white/5 text-slate-400 hover:text-white'
              }`}
            >
              <Zap size={14} />
              <span>Daily Quests ({quests.filter((q) => !q.isClaimed && q.progress >= q.target).length} Ready)</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Reward Roadmap */}
        {activeTab === 'rewards' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400 font-bold px-1">
              <span className="text-slate-300">TIER ROADMAP</span>
              <div className="flex items-center gap-4">
                <span className="text-amber-300">FREE TRACK</span>
                <span className="text-purple-300">ROYAL VIP TRACK</span>
              </div>
            </div>

            {PASS_TIERS.map((tier) => {
              const isUnlocked = tier.level <= currentLevel;
              const isFreeClaimed = claimedFreeLevels.includes(tier.level);
              const isVipClaimed = claimedVipLevels.includes(tier.level);

              return (
                <div
                  key={tier.level}
                  className={`p-3 rounded-2xl border transition-all ${
                    tier.level === currentLevel
                      ? 'bg-amber-950/30 border-amber-500/60 shadow-[0_0_20px_rgba(245,158,11,0.2)]'
                      : isUnlocked
                      ? 'bg-slate-900/60 border-slate-700'
                      : 'bg-slate-950/40 border-slate-800/80 opacity-70'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    {/* Level Badge */}
                    <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                      <div
                        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center font-black text-sm border ${
                          isUnlocked
                            ? 'bg-gradient-to-br from-amber-500 to-yellow-600 text-slate-950 border-amber-300 shadow-md'
                            : 'bg-slate-800 text-slate-500 border-slate-700'
                        }`}
                      >
                        {tier.level}
                      </div>
                      <div>
                        <p className="text-xs font-black text-white">Tier {tier.level}</p>
                        <p className="text-[10px] text-slate-400">{tier.xpRequired} XP Goal</p>
                      </div>
                    </div>

                    {/* Both Reward Cards (Free vs VIP) */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 flex-1 max-w-md">
                      {/* Free Reward */}
                      <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/80 border border-slate-700">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-xl shrink-0">{tier.freeReward.icon}</span>
                          <div className="truncate">
                            <p className="text-[11px] font-bold text-slate-200 truncate">
                              {tier.freeReward.title}
                            </p>
                            <span className="text-[9px] text-amber-400 font-semibold uppercase">
                              Free Track
                            </span>
                          </div>
                        </div>

                        {isFreeClaimed ? (
                          <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1 shrink-0 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/40">
                            <CheckCircle2 size={12} /> Claimed
                          </span>
                        ) : isUnlocked ? (
                          <button
                            onClick={() => handleClaimFreeReward(tier)}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] shrink-0 active:scale-95 transition cursor-pointer"
                          >
                            Claim
                          </button>
                        ) : (
                          <span className="text-slate-600 shrink-0">
                            <Lock size={14} />
                          </span>
                        )}
                      </div>

                      {/* VIP Reward */}
                      <div className="flex items-center justify-between p-2 rounded-xl bg-gradient-to-r from-purple-950/50 to-indigo-950/50 border border-purple-500/40">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-xl shrink-0">{tier.vipReward.icon}</span>
                          <div className="truncate">
                            <p className="text-[11px] font-bold text-purple-200 truncate">
                              {tier.vipReward.title}
                            </p>
                            <span className="text-[9px] text-purple-400 font-semibold uppercase">
                              Royal VIP
                            </span>
                          </div>
                        </div>

                        {isVipClaimed ? (
                          <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1 shrink-0 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-500/40">
                            <CheckCircle2 size={12} /> Claimed
                          </span>
                        ) : isUnlocked && isVipUnlocked ? (
                          <button
                            onClick={() => handleClaimVipReward(tier)}
                            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white font-black text-[10px] shrink-0 active:scale-95 transition cursor-pointer shadow-md"
                          >
                            Claim VIP
                          </button>
                        ) : (
                          <span className="text-purple-400/60 shrink-0">
                            <Lock size={14} />
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: Quests & Missions */}
        {activeTab === 'quests' && (
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-2.5">
            <div className="p-3 rounded-2xl bg-purple-950/30 border border-purple-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-purple-400" />
                <span className="text-xs font-bold text-purple-200">
                  Daily Quests refresh in 14h 22m
                </span>
              </div>
              <span className="text-[11px] text-amber-300 font-bold">
                +{quests.reduce((acc, q) => acc + q.xpReward, 0)} Total XP available
              </span>
            </div>

            {quests.map((quest) => {
              const isReady = quest.progress >= quest.target && !quest.isClaimed;

              return (
                <div
                  key={quest.id}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isReady
                      ? 'bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-900 border-amber-500/60 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                      : quest.isClaimed
                      ? 'bg-slate-950/40 border-slate-800 opacity-60'
                      : 'bg-slate-900/60 border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-black/40 border border-white/10 flex items-center justify-center text-xl shrink-0">
                      {quest.icon}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs sm:text-sm font-bold text-white">
                          {quest.title}
                        </h4>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">
                          +{quest.xpReward} XP
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">{quest.desc}</p>
                      {quest.bonusReward && (
                        <p className="text-[10px] text-emerald-400 font-semibold mt-0.5">
                          Bonus: {quest.bonusReward}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-slate-400 hidden sm:inline">
                      {quest.progress} / {quest.target}
                    </span>

                    {quest.isClaimed ? (
                      <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-1 bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-500/40">
                        <CheckCircle2 size={12} /> Claimed
                      </span>
                    ) : isReady ? (
                      <button
                        onClick={() => handleClaimQuest(quest.id)}
                        className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider animate-bounce shadow-md hover:scale-105 active:scale-95 transition cursor-pointer"
                      >
                        Claim!
                      </button>
                    ) : (
                      <span className="text-xs font-bold text-slate-500 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                        {quest.progress} / {quest.target}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
