import React, { useState } from 'react';
import { Sparkles, MessageSquare, Flame } from 'lucide-react';
import { sound } from '../utils/soundEngine';

export interface ThrowableReaction {
  id: string;
  type: 'tomato' | 'bomb' | 'rose' | 'water' | 'punch' | 'egg' | 'trophy';
  emoji: string;
  name: string;
}

export const THROWABLE_LIST: ThrowableReaction[] = [
  { id: 'tomato', type: 'tomato', emoji: '🍅', name: 'Tomato Splat' },
  { id: 'bomb', type: 'bomb', emoji: '💣', name: 'Cosmic Bomb' },
  { id: 'rose', type: 'rose', emoji: '🌹', name: 'Red Rose' },
  { id: 'water', type: 'water', emoji: '💦', name: 'Water Splash' },
  { id: 'punch', type: 'punch', emoji: '🥊', name: 'Glove Punch' },
  { id: 'egg', type: 'egg', emoji: '🥚', name: 'Egg Splat' },
  { id: 'trophy', type: 'trophy', emoji: '🏆', name: 'Golden Cup' },
];

export const VOICE_TAUNTS = [
  { text: 'Arre yaar!', label: 'Arre yaar! 🤦‍♂️' },
  { text: 'Mera chhakka aayega!', label: 'Chhakka aayega! 🎲' },
  { text: 'Bachke kahan jaoge!', label: 'Bachke kahan! 🏹' },
  { text: 'Khel khatam!', label: 'Khel khatam! ⚡' },
  { text: 'Hurry up please!', label: 'Hurry up! ⏰' },
  { text: 'Good game dost!', label: 'Good game! 🤝' },
];

interface BoardReactionsBarProps {
  onThrow: (reaction: ThrowableReaction) => void;
  onTaunt: (text: string) => void;
}

export const BoardReactionsBar: React.FC<BoardReactionsBarProps> = ({
  onThrow,
  onTaunt,
}) => {
  const [activeTab, setActiveTab] = useState<'throw' | 'taunts'>('throw');

  return (
    <div className="w-full max-w-2xl bg-slate-900/90 backdrop-blur-md border border-amber-500/30 rounded-2xl p-2.5 shadow-2xl">
      {/* Mini Tab Switcher */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/10 text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('throw')}
            className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition ${
              activeTab === 'throw'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Flame size={13} />
            <span>Throwables 🎯</span>
          </button>

          <button
            onClick={() => setActiveTab('taunts')}
            className={`px-3 py-1 rounded-lg font-bold flex items-center gap-1.5 transition ${
              activeTab === 'taunts'
                ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare size={13} />
            <span>Voice Taunts 🗣️</span>
          </button>
        </div>

        <span className="text-[10px] text-amber-300 font-mono hidden sm:inline-block">
          Tap to throw on board & seats!
        </span>
      </div>

      {/* Throwables List */}
      {activeTab === 'throw' && (
        <div className="flex items-center justify-around gap-1.5 overflow-x-auto py-1">
          {THROWABLE_LIST.map((item) => (
            <button
              key={item.id}
              onClick={() => onThrow(item)}
              title={item.name}
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-slate-800/80 hover:bg-amber-500/20 border border-slate-700 hover:border-amber-400/60 transition-all transform active:scale-90 hover:scale-105 group"
            >
              <span className="text-2xl group-hover:rotate-12 transition-transform">
                {item.emoji}
              </span>
              <span className="text-[10px] text-slate-300 font-semibold mt-0.5 whitespace-nowrap">
                {item.name.split(' ')[0]}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* Voice Taunts List */}
      {activeTab === 'taunts' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 py-1">
          {VOICE_TAUNTS.map((taunt, idx) => (
            <button
              key={idx}
              onClick={() => onTaunt(taunt.text)}
              className="px-2.5 py-1.5 rounded-xl bg-purple-900/40 hover:bg-purple-600/40 border border-purple-500/30 hover:border-purple-400 text-[11px] font-bold text-purple-200 hover:text-white transition-all text-left flex items-center justify-between active:scale-95"
            >
              <span>{taunt.label}</span>
              <Sparkles size={11} className="text-purple-400" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
