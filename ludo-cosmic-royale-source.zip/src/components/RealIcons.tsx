import React from 'react';

// ========================================================
// REALISTIC 3D VECTOR SVG ICONS FOR LUDO MASTER
// High-fidelity vector elements with metallic reflections,
// specular highlights, depth layers, jewel insets & gloss.
// Crisp, lossless at any DPI, zero network latency.
// ========================================================

export interface IconProps {
  className?: string;
  size?: number;
}

// 1. Realistic 3D Golden Victory Trophy
export const RealisticTrophyIcon: React.FC<IconProps> = ({ className = '', size = 48 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(245,158,11,0.6)] ${className}`}
  >
    <defs>
      <linearGradient id="trophyGoldGrad" x1="12" y1="6" x2="52" y2="42" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="20%" stopColor="#fde047" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="85%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#854d0e" />
      </linearGradient>
      <linearGradient id="trophyHighlight" x1="20" y1="8" x2="32" y2="36" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#fef08a" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="trophyBaseGrad" x1="18" y1="46" x2="46" y2="60" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#334155" />
        <stop offset="50%" stopColor="#1e293b" />
        <stop offset="100%" stopColor="#0f172a" />
      </linearGradient>
      <linearGradient id="trophyPlateGrad" x1="22" y1="49" x2="42" y2="55" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#ca8a04" />
      </linearGradient>
    </defs>

    {/* Handles Left & Right */}
    <path
      d="M17 14C10 14 8 22 10 28C12 34 18 36 21 36M47 14C54 14 56 22 54 28C52 34 46 36 43 36"
      stroke="url(#trophyGoldGrad)"
      strokeWidth="3.5"
      strokeLinecap="round"
    />
    <path
      d="M16 16C12 16 10.5 22 12 26C13.5 30 17 33 20 33M48 16C52 16 53.5 22 52 26C50.5 30 47 33 44 33"
      stroke="#fef08a"
      strokeWidth="1.2"
      strokeLinecap="round"
      opacity="0.8"
    />

    {/* Cup Body */}
    <path
      d="M18 10H46C46 24 40 36 32 38C24 36 18 24 18 10Z"
      fill="url(#trophyGoldGrad)"
      stroke="#78350f"
      strokeWidth="1.5"
    />
    {/* Specular Highlight Arc on Cup */}
    <path
      d="M21 12C21 22 25 31 31 34C24 31 20 22 20 12H21Z"
      fill="url(#trophyHighlight)"
    />

    {/* Cup Rim Top */}
    <ellipse cx="32" cy="10" rx="14" ry="3.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="1" />
    <ellipse cx="32" cy="10" rx="12" ry="2" fill="#fde047" />

    {/* Embossed Star on Cup */}
    <path
      d="M32 17L33.8 21.5L38.5 21.8L35 24.8L36 29.5L32 27L28 29.5L29 24.8L25.5 21.8L30.2 21.5L32 17Z"
      fill="#fffbeb"
      stroke="#854d0e"
      strokeWidth="0.8"
    />

    {/* Stem Connector */}
    <path d="M29 38H35V44H29V38Z" fill="url(#trophyGoldGrad)" stroke="#78350f" strokeWidth="1" />
    <ellipse cx="32" cy="44" rx="7" ry="2" fill="url(#trophyGoldGrad)" stroke="#78350f" strokeWidth="0.8" />

    {/* Pedestal Base */}
    <path
      d="M22 46H42L45 58H19L22 46Z"
      fill="url(#trophyBaseGrad)"
      stroke="#0f172a"
      strokeWidth="1.5"
    />
    {/* Base Rim Bottom */}
    <rect x="17" y="58" width="30" height="4" rx="1.5" fill="#0f172a" stroke="#475569" strokeWidth="0.8" />

    {/* Gold Inscription Plate */}
    <rect x="23" y="49" width="18" height="6" rx="1" fill="url(#trophyPlateGrad)" stroke="#78350f" strokeWidth="0.6" />
    <line x1="25" y1="52" x2="39" y2="52" stroke="#78350f" strokeWidth="1" strokeLinecap="round" />
  </svg>
);

// 2. Realistic 3D Royal Gold Crown
export const RealisticCrownIcon: React.FC<IconProps> = ({ className = '', size = 42 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_15px_rgba(234,179,8,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="crownGold" x1="10" y1="18" x2="54" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="25%" stopColor="#fde047" />
        <stop offset="55%" stopColor="#eab308" />
        <stop offset="85%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#713f12" />
      </linearGradient>
      <radialGradient id="rubyGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#fca5a5" />
        <stop offset="40%" stopColor="#ef4444" />
        <stop offset="100%" stopColor="#991b1b" />
      </radialGradient>
      <radialGradient id="emeraldGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#86efac" />
        <stop offset="40%" stopColor="#22c55e" />
        <stop offset="100%" stopColor="#14532d" />
      </radialGradient>
      <radialGradient id="sapphireGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#93c5fd" />
        <stop offset="40%" stopColor="#3b82f6" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </radialGradient>
    </defs>

    {/* Crown Spikes Body */}
    <path
      d="M10 24L18 44H46L54 24L41 33L32 18L23 33L10 24Z"
      fill="url(#crownGold)"
      stroke="#713f12"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    {/* Inner Shimmer Arc */}
    <path
      d="M14 28L20 42H44L50 28L40 35L32 23L24 35L14 28Z"
      fill="#ffffff"
      fillOpacity="0.25"
    />

    {/* Crown Base Velvet Band */}
    <rect x="16" y="44" width="32" height="7" rx="2" fill="#7f1d1d" stroke="#ca8a04" strokeWidth="1.2" />
    <rect x="18" y="45.5" width="28" height="4" rx="1" fill="#991b1b" />

    {/* Gemstones on Spikes */}
    <circle cx="32" cy="18" r="4" fill="url(#rubyGlow)" stroke="#fef08a" strokeWidth="1" />
    <circle cx="31" cy="16.5" r="1.2" fill="#ffffff" />

    <circle cx="10" cy="24" r="3.2" fill="url(#sapphireGlow)" stroke="#fef08a" strokeWidth="0.8" />
    <circle cx="9.2" cy="23" r="1" fill="#ffffff" />

    <circle cx="54" cy="24" r="3.2" fill="url(#sapphireGlow)" stroke="#fef08a" strokeWidth="0.8" />
    <circle cx="53.2" cy="23" r="1" fill="#ffffff" />

    <circle cx="23" cy="33" r="2.8" fill="url(#emeraldGlow)" stroke="#fef08a" strokeWidth="0.8" />
    <circle cx="41" cy="33" r="2.8" fill="url(#emeraldGlow)" stroke="#fef08a" strokeWidth="0.8" />

    {/* Band Pearls */}
    <circle cx="22" cy="47.5" r="1.8" fill="#f8fafc" stroke="#ca8a04" strokeWidth="0.6" />
    <circle cx="28" cy="47.5" r="1.8" fill="url(#rubyGlow)" stroke="#ca8a04" strokeWidth="0.6" />
    <circle cx="34" cy="47.5" r="2.2" fill="url(#sapphireGlow)" stroke="#fef08a" strokeWidth="0.8" />
    <circle cx="40" cy="47.5" r="1.8" fill="url(#emeraldGlow)" stroke="#ca8a04" strokeWidth="0.6" />
    <circle cx="46" cy="47.5" r="1.8" fill="#f8fafc" stroke="#ca8a04" strokeWidth="0.6" />
  </svg>
);

// 3. Realistic 3D Olympic Medal (Rank 1 Gold, Rank 2 Silver, Rank 3 Bronze)
export const RealisticMedalIcon: React.FC<{ rank: 1 | 2 | 3; size?: number; className?: string }> = ({
  rank,
  size = 40,
  className = '',
}) => {
  const isGold = rank === 1;
  const isSilver = rank === 2;

  const medalGradId = `medalGrad_${rank}`;
  const ribbonGradId = `ribbonGrad_${rank}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`drop-shadow-lg ${className}`}
    >
      <defs>
        {isGold ? (
          <linearGradient id={medalGradId} x1="16" y1="20" x2="48" y2="56" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#fffbeb" />
            <stop offset="25%" stopColor="#fde047" />
            <stop offset="60%" stopColor="#eab308" />
            <stop offset="90%" stopColor="#ca8a04" />
            <stop offset="100%" stopColor="#854d0e" />
          </linearGradient>
        ) : isSilver ? (
          <linearGradient id={medalGradId} x1="16" y1="20" x2="48" y2="56" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="30%" stopColor="#e2e8f0" />
            <stop offset="65%" stopColor="#94a3b8" />
            <stop offset="90%" stopColor="#64748b" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>
        ) : (
          <linearGradient id={medalGradId} x1="16" y1="20" x2="48" y2="56" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#fef3c7" />
            <stop offset="25%" stopColor="#f59e0b" />
            <stop offset="55%" stopColor="#d97706" />
            <stop offset="85%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>
        )}

        <linearGradient id={ribbonGradId} x1="14" y1="4" x2="50" y2="28" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGold ? '#dc2626' : isSilver ? '#0284c7' : '#059669'} />
          <stop offset="100%" stopColor={isGold ? '#991b1b' : isSilver ? '#0369a1' : '#065f46'} />
        </linearGradient>
      </defs>

      {/* Satin Ribbon */}
      <path d="M22 6L28 26H36L42 6H34L32 14L30 6H22Z" fill={`url(#${ribbonGradId})`} />
      <path d="M25 6L30 24H34L39 6" stroke="#fef08a" strokeWidth="1" strokeOpacity="0.5" />

      {/* Medal Loop Connector */}
      <rect x="29" y="24" width="6" height="4" rx="1" fill={`url(#${medalGradId})`} stroke="#1e293b" strokeWidth="0.8" />

      {/* Outer Medal Circle */}
      <circle
        cx="32"
        cy="42"
        r="17"
        fill={`url(#${medalGradId})`}
        stroke={isGold ? '#78350f' : isSilver ? '#334155' : '#451a03'}
        strokeWidth="1.8"
      />
      {/* Embossed Inner Rim */}
      <circle
        cx="32"
        cy="42"
        r="13.5"
        stroke="#ffffff"
        strokeWidth="1"
        strokeOpacity="0.7"
        strokeDasharray="2 1.5"
      />

      {/* Starburst Laurels */}
      <path
        d="M23 44C23 37 27 34 32 34C37 34 41 37 41 44"
        stroke="#ffffff"
        strokeWidth="0.8"
        strokeOpacity="0.5"
        strokeLinecap="round"
      />

      {/* Rank Number */}
      <text
        x="32"
        y="47"
        textAnchor="middle"
        fontSize="14"
        fontWeight="900"
        fontFamily="Cinzel, serif, Arial"
        fill={isGold ? '#451a03' : isSilver ? '#0f172a' : '#291003'}
      >
        {rank}
      </text>
    </svg>
  );
};

// 4. Realistic 3D Crystal Diamond Gem
export const RealisticDiamondIcon: React.FC<IconProps> = ({ className = '', size = 32 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_2px_10px_rgba(6,182,212,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="diamondTop" x1="16" y1="14" x2="48" y2="28" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#cffafe" />
        <stop offset="50%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#0284c7" />
      </linearGradient>
      <linearGradient id="diamondFacet1" x1="10" y1="28" x2="32" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#e0f2fe" />
        <stop offset="100%" stopColor="#0369a1" />
      </linearGradient>
      <linearGradient id="diamondFacet2" x1="32" y1="28" x2="54" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#7dd3fc" />
        <stop offset="100%" stopColor="#0c4a6e" />
      </linearGradient>
      <linearGradient id="diamondFacetCenter" x1="22" y1="28" x2="42" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="60%" stopColor="#38bdf8" />
        <stop offset="100%" stopColor="#0284c7" />
      </linearGradient>
    </defs>

    {/* Top Crown Facets */}
    <polygon points="20,16 44,16 54,28 10,28" fill="url(#diamondTop)" stroke="#0284c7" strokeWidth="1" />
    <polygon points="20,16 32,16 32,28 18,28" fill="#ffffff" fillOpacity="0.4" />

    {/* Bottom Pavilion Facets */}
    <polygon points="10,28 32,52 22,28" fill="url(#diamondFacet1)" stroke="#075985" strokeWidth="1" />
    <polygon points="42,28 32,52 54,28" fill="url(#diamondFacet2)" stroke="#075985" strokeWidth="1" />
    <polygon points="22,28 32,52 42,28" fill="url(#diamondFacetCenter)" stroke="#0369a1" strokeWidth="1" />

    {/* Specular Sparkle */}
    <circle cx="28" cy="22" r="2.5" fill="#ffffff" />
    <line x1="28" y1="17" x2="28" y2="27" stroke="#ffffff" strokeWidth="0.8" />
    <line x1="23" y1="22" x2="33" y2="22" stroke="#ffffff" strokeWidth="0.8" />
  </svg>
);

// 5. Realistic 3D Golden Coin
export const RealisticCoinIcon: React.FC<IconProps> = ({ className = '', size = 32 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)] ${className}`}
  >
    <defs>
      <linearGradient id="coinGrad" x1="12" y1="8" x2="52" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="35%" stopColor="#facc15" />
        <stop offset="70%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#713f12" />
      </linearGradient>
      <radialGradient id="coinCenter" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#fef9c3" />
        <stop offset="60%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#a16207" />
      </radialGradient>
    </defs>

    <circle cx="32" cy="32" r="24" fill="url(#coinGrad)" stroke="#78350f" strokeWidth="2" />
    <circle cx="32" cy="32" r="21" stroke="#fef08a" strokeWidth="1.2" strokeDasharray="3 1.5" />
    <circle cx="32" cy="32" r="17" fill="url(#coinCenter)" stroke="#a16207" strokeWidth="1" />

    <text
      x="32"
      y="38"
      textAnchor="middle"
      fontSize="18"
      fontWeight="900"
      fontFamily="Cinzel, Arial, sans-serif"
      fill="#78350f"
    >
      ₹
    </text>
  </svg>
);

// 6. Realistic 3D Weighted Red/White Dice
export const RealisticDiceIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] ${className}`}
  >
    <defs>
      <linearGradient id="diceTopFace" x1="18" y1="10" x2="46" y2="28" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="100%" stopColor="#e2e8f0" />
      </linearGradient>
      <linearGradient id="diceLeftFace" x1="10" y1="26" x2="32" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#cbd5e1" />
        <stop offset="100%" stopColor="#64748b" />
      </linearGradient>
      <linearGradient id="diceRightFace" x1="32" y1="26" x2="54" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#e2e8f0" />
        <stop offset="100%" stopColor="#94a3b8" />
      </linearGradient>
    </defs>

    <polygon points="32,8 54,20 32,32 10,20" fill="url(#diceTopFace)" stroke="#475569" strokeWidth="1.2" strokeLinejoin="round" />
    <polygon points="10,20 32,32 32,56 10,44" fill="url(#diceLeftFace)" stroke="#334155" strokeWidth="1.2" strokeLinejoin="round" />
    <polygon points="32,32 54,20 54,44 32,56" fill="url(#diceRightFace)" stroke="#334155" strokeWidth="1.2" strokeLinejoin="round" />

    {/* Pips on Top Face (Red center dot) */}
    <ellipse cx="23" cy="16" rx="2.2" ry="1.2" fill="#ef4444" />
    <ellipse cx="32" cy="20" rx="2.5" ry="1.4" fill="#ef4444" />
    <ellipse cx="41" cy="24" rx="2.2" ry="1.2" fill="#ef4444" />

    {/* Pips on Left Face */}
    <circle cx="17" cy="28" r="2.2" fill="#0f172a" />
    <circle cx="25" cy="33" r="2.2" fill="#0f172a" />
    <circle cx="21" cy="38" r="2.2" fill="#0f172a" />
    <circle cx="17" cy="43" r="2.2" fill="#0f172a" />
    <circle cx="25" cy="48" r="2.2" fill="#0f172a" />

    {/* Pips on Right Face */}
    <circle cx="39" cy="33" r="2.2" fill="#0f172a" />
    <circle cx="47" cy="28" r="2.2" fill="#0f172a" />
    <circle cx="39" cy="40" r="2.2" fill="#0f172a" />
    <circle cx="47" cy="35" r="2.2" fill="#0f172a" />
    <circle cx="39" cy="47" r="2.2" fill="#0f172a" />
    <circle cx="47" cy="42" r="2.2" fill="#0f172a" />
  </svg>
);

// 7. Realistic 3D Trishul / Divine Astra Icon
export const RealisticTrishulIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(6,182,212,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="trishulGold" x1="12" y1="6" x2="52" y2="58" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="25%" stopColor="#fde047" />
        <stop offset="60%" stopColor="#eab308" />
        <stop offset="90%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#78350f" />
      </linearGradient>
    </defs>

    <path
      d="M32 6L35 18L34 32H30L29 18L32 6Z"
      fill="url(#trishulGold)"
      stroke="#78350f"
      strokeWidth="1.2"
    />
    <path
      d="M20 12C20 22 26 28 30 30L30 33C24 31 16 24 16 12L20 12Z"
      fill="url(#trishulGold)"
      stroke="#78350f"
      strokeWidth="1.2"
    />
    <path
      d="M44 12C44 22 38 28 34 30L34 33C40 31 48 24 48 12L44 12Z"
      fill="url(#trishulGold)"
      stroke="#78350f"
      strokeWidth="1.2"
    />

    {/* Damru */}
    <path d="M26 35H38L34 40H30L26 35Z" fill="#b91c1c" stroke="#ca8a04" strokeWidth="1" />
    <path d="M34 40H30L26 45H38L34 40Z" fill="#b91c1c" stroke="#ca8a04" strokeWidth="1" />

    {/* Shaft */}
    <rect x="30.5" y="45" width="3" height="15" rx="1.5" fill="url(#trishulGold)" stroke="#78350f" strokeWidth="0.8" />
  </svg>
);

// 8. Realistic 3D Golden Gada (Hanuman Mace)
export const RealisticGadaIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(245,158,11,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="gadaGold" x1="14" y1="8" x2="50" y2="44" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="30%" stopColor="#fde047" />
        <stop offset="60%" stopColor="#eab308" />
        <stop offset="90%" stopColor="#b45309" />
        <stop offset="100%" stopColor="#78350f" />
      </linearGradient>
    </defs>
    {/* Head of Mace */}
    <circle cx="32" cy="20" r="14" fill="url(#gadaGold)" stroke="#78350f" strokeWidth="1.5" />
    <circle cx="32" cy="20" r="11" stroke="#fef08a" strokeWidth="1" strokeDasharray="3 2" />
    <circle cx="32" cy="20" r="5" fill="#ca8a04" stroke="#78350f" strokeWidth="1" />
    {/* Spikes */}
    <polygon points="32,4 34,7 30,7" fill="#fde047" stroke="#78350f" strokeWidth="0.8" />
    <polygon points="16,20 19,18 19,22" fill="#fde047" stroke="#78350f" strokeWidth="0.8" />
    <polygon points="48,20 45,18 45,22" fill="#fde047" stroke="#78350f" strokeWidth="0.8" />
    {/* Handle / Shaft */}
    <rect x="29.5" y="32" width="5" height="26" rx="2.5" fill="url(#gadaGold)" stroke="#78350f" strokeWidth="1.2" />
    {/* Pommel */}
    <circle cx="32" cy="58" r="4.5" fill="url(#gadaGold)" stroke="#78350f" strokeWidth="1" />
  </svg>
);

// 9. Realistic 3D Sudarshan Chakra (Spinning Solar Disc)
export const RealisticChakraIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_0_15px_rgba(56,189,248,0.8)] ${className}`}
  >
    <defs>
      <linearGradient id="chakraBlue" x1="10" y1="10" x2="54" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#ffffff" />
        <stop offset="30%" stopColor="#7dd3fc" />
        <stop offset="70%" stopColor="#0284c7" />
        <stop offset="100%" stopColor="#0369a1" />
      </linearGradient>
    </defs>
    {/* Outer Serrated Blades */}
    <circle cx="32" cy="32" r="22" stroke="url(#chakraBlue)" strokeWidth="3" strokeDasharray="5 3" />
    {/* Core Aura */}
    <circle cx="32" cy="32" r="16" fill="url(#chakraBlue)" stroke="#e0f2fe" strokeWidth="1.5" />
    <circle cx="32" cy="32" r="8" fill="#ffffff" />
    {/* Rays */}
    <line x1="32" y1="14" x2="32" y2="50" stroke="#ffffff" strokeWidth="1.5" />
    <line x1="14" y1="32" x2="50" y2="32" stroke="#ffffff" strokeWidth="1.5" />
    <line x1="19" y1="19" x2="45" y2="45" stroke="#ffffff" strokeWidth="1.2" />
    <line x1="45" y1="19" x2="19" y2="45" stroke="#ffffff" strokeWidth="1.2" />
  </svg>
);

// 10. Realistic 3D Celestial Dragon (Pet Universe)
export const RealisticDragonIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(16,185,129,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="dragonJade" x1="12" y1="10" x2="52" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#a7f3d0" />
        <stop offset="35%" stopColor="#10b981" />
        <stop offset="75%" stopColor="#047857" />
        <stop offset="100%" stopColor="#064e3b" />
      </linearGradient>
    </defs>
    {/* Dragon Horns */}
    <path d="M22 10C24 16 28 20 28 24M42 10C40 16 36 20 36 24" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
    {/* Head Outline */}
    <path
      d="M20 24C16 30 18 42 22 48L32 54L42 48C46 42 48 30 44 24C38 20 26 20 20 24Z"
      fill="url(#dragonJade)"
      stroke="#064e3b"
      strokeWidth="1.5"
    />
    {/* Glowing Eyes */}
    <circle cx="26" cy="30" r="3.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" />
    <circle cx="26" cy="30" r="1.5" fill="#dc2626" />
    <circle cx="38" cy="30" r="3.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" />
    <circle cx="38" cy="30" r="1.5" fill="#dc2626" />
    {/* Snout & Whiskers */}
    <path d="M28 42H36M24 40C18 42 12 40 10 36M40 40C46 42 52 40 54 36" stroke="#fde047" strokeWidth="1.5" strokeLinecap="round" />
    {/* Forehead Pearl */}
    <circle cx="32" cy="22" r="2.5" fill="#f8fafc" stroke="#fde047" strokeWidth="1" />
  </svg>
);

// 11. Realistic 3D Gift Box
export const RealisticGiftIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(236,72,153,0.6)] ${className}`}
  >
    <defs>
      <linearGradient id="giftBox" x1="12" y1="20" x2="52" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f472b6" />
        <stop offset="50%" stopColor="#ec4899" />
        <stop offset="100%" stopColor="#be185d" />
      </linearGradient>
      <linearGradient id="giftGold" x1="16" y1="12" x2="48" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#a16207" />
      </linearGradient>
    </defs>
    {/* Box Body */}
    <rect x="14" y="24" width="36" height="30" rx="3" fill="url(#giftBox)" stroke="#831843" strokeWidth="1.5" />
    {/* Box Lid */}
    <rect x="11" y="20" width="42" height="8" rx="2" fill="#db2777" stroke="#831843" strokeWidth="1.5" />
    {/* Vertical Gold Ribbon */}
    <rect x="29" y="20" width="6" height="34" fill="url(#giftGold)" stroke="#854d0e" strokeWidth="0.8" />
    {/* Horizontal Gold Ribbon on Lid */}
    <rect x="11" y="22" width="42" height="4" fill="url(#giftGold)" stroke="#854d0e" strokeWidth="0.8" />
    {/* Bow on Top */}
    <ellipse cx="26" cy="16" rx="5" ry="3.5" fill="url(#giftGold)" stroke="#854d0e" strokeWidth="0.8" />
    <ellipse cx="38" cy="16" rx="5" ry="3.5" fill="url(#giftGold)" stroke="#854d0e" strokeWidth="0.8" />
    <circle cx="32" cy="17" r="2.5" fill="#fef08a" stroke="#854d0e" strokeWidth="0.8" />
  </svg>
);

// 12. Realistic 3D Crest Shield
export const RealisticShieldIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(59,130,246,0.6)] ${className}`}
  >
    <defs>
      <linearGradient id="shieldGrad" x1="12" y1="10" x2="52" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="50%" stopColor="#2563eb" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </linearGradient>
    </defs>
    <path
      d="M14 14L32 8L50 14V32C50 44 32 56 32 56C32 56 14 44 14 32V14Z"
      fill="url(#shieldGrad)"
      stroke="#facc15"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <path
      d="M20 18L32 14L44 18V30C44 39 32 48 32 48C32 48 20 39 20 30V18Z"
      fill="#1d4ed8"
      stroke="#93c5fd"
      strokeWidth="1"
    />
    {/* Embossed Star */}
    <polygon
      points="32,22 34,28 40,28 35,32 37,38 32,34 27,38 29,32 24,28 30,28"
      fill="#fef08a"
      stroke="#ca8a04"
      strokeWidth="0.6"
    />
  </svg>
);

// 13. Realistic 3D Flame / Fire
export const RealisticFlameIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_15px_rgba(239,68,68,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="flameOuter" x1="20" y1="8" x2="44" y2="56" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f97316" />
        <stop offset="50%" stopColor="#ef4444" />
        <stop offset="100%" stopColor="#b91c1c" />
      </linearGradient>
      <linearGradient id="flameInner" x1="24" y1="24" x2="40" y2="54" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="70%" stopColor="#f59e0b" />
        <stop offset="100%" stopColor="#ea580c" />
      </linearGradient>
    </defs>
    {/* Outer Flame */}
    <path
      d="M32 8C32 8 38 18 38 26C38 30 46 32 46 40C46 50 38 56 32 56C26 56 18 50 18 40C18 30 26 20 28 14C30 18 32 20 32 8Z"
      fill="url(#flameOuter)"
      stroke="#7f1d1d"
      strokeWidth="1.2"
    />
    {/* Inner Core */}
    <path
      d="M32 24C32 24 36 30 36 36C36 44 32 48 32 48C32 48 28 44 28 36C28 30 32 24 32 24Z"
      fill="url(#flameInner)"
    />
  </svg>
);

// 14. Realistic 3D Bow & Arrow (Gandiva Takshak)
export const RealisticBowArrowIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(245,158,11,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="bowGold" x1="12" y1="12" x2="52" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#854d0e" />
      </linearGradient>
    </defs>
    {/* Curved Bow Body */}
    <path
      d="M16 12C28 20 32 44 16 52"
      stroke="url(#bowGold)"
      strokeWidth="3.5"
      strokeLinecap="round"
    />
    {/* Bowstring */}
    <line x1="16" y1="12" x2="16" y2="52" stroke="#e2e8f0" strokeWidth="1" strokeDasharray="2 1" />
    {/* Arrow Shaft & Nock */}
    <line x1="12" y1="32" x2="48" y2="32" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" />
    {/* Flaming Arrowhead */}
    <polygon points="46,26 56,32 46,38 48,32" fill="#ef4444" stroke="#fef08a" strokeWidth="1" />
    {/* Feathers */}
    <path d="M12 28L16 32L12 36" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// 15. Realistic 3D Divine Flute & Mor Pankh (Krishna Flute)
export const RealisticFluteIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(168,85,247,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="fluteGold" x1="8" y1="40" x2="54" y2="20" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fef08a" />
        <stop offset="50%" stopColor="#eab308" />
        <stop offset="100%" stopColor="#ca8a04" />
      </linearGradient>
      <radialGradient id="peacockEye" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#38bdf8" />
        <stop offset="50%" stopColor="#10b981" />
        <stop offset="100%" stopColor="#1e3a8a" />
      </radialGradient>
    </defs>
    {/* Bamboo Golden Flute Bar */}
    <rect
      x="8"
      y="28"
      width="46"
      height="6"
      rx="3"
      transform="rotate(-20 31 31)"
      fill="url(#fluteGold)"
      stroke="#78350f"
      strokeWidth="1.2"
    />
    {/* Flute Finger Holes */}
    <circle cx="22" cy="34" r="1.5" fill="#451a03" />
    <circle cx="28" cy="32" r="1.5" fill="#451a03" />
    <circle cx="34" cy="30" r="1.5" fill="#451a03" />
    <circle cx="40" cy="28" r="1.5" fill="#451a03" />

    {/* Mor Pankh (Peacock Feather on Top) */}
    <path
      d="M44 26C46 16 54 10 56 12C58 14 52 22 46 28Z"
      fill="#059669"
      stroke="#fde047"
      strokeWidth="0.8"
    />
    <circle cx="52" cy="16" r="3" fill="url(#peacockEye)" stroke="#fef08a" strokeWidth="0.8" />
    <circle cx="52" cy="16" r="1.2" fill="#3b82f6" />
  </svg>
);

// 16. Realistic 3D Arcade Target & Crosshair
export const RealisticArcadeTargetIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(244,63,94,0.7)] ${className}`}
  >
    <circle cx="32" cy="32" r="24" fill="#881337" stroke="#fb7185" strokeWidth="2" />
    <circle cx="32" cy="32" r="18" fill="#ffffff" stroke="#f43f5e" strokeWidth="1.5" />
    <circle cx="32" cy="32" r="12" fill="#e11d48" stroke="#ffffff" strokeWidth="1.5" />
    <circle cx="32" cy="32" r="6" fill="#facc15" stroke="#78350f" strokeWidth="1" />
    {/* Crosshairs */}
    <line x1="32" y1="4" x2="32" y2="60" stroke="#fecdd3" strokeWidth="1" strokeDasharray="3 3" />
    <line x1="4" y1="32" x2="60" y2="32" stroke="#fecdd3" strokeWidth="1" strokeDasharray="3 3" />
  </svg>
);

// 17. Realistic 3D VIP Voice Mic (8-Seat VIP Rooms)
export const RealisticVIPMicIcon: React.FC<IconProps> = ({ className = '', size = 38 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_15px_rgba(234,179,8,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="micGold" x1="22" y1="8" x2="42" y2="34" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fffbeb" />
        <stop offset="35%" stopColor="#fde047" />
        <stop offset="70%" stopColor="#ca8a04" />
        <stop offset="100%" stopColor="#78350f" />
      </linearGradient>
    </defs>
    {/* Sound Waves Left & Right */}
    <path d="M14 20C12 24 12 30 14 34M50 20C52 24 52 30 50 34" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
    <path d="M10 16C7 22 7 32 10 38M54 16C57 22 57 32 54 38" stroke="#818cf8" strokeWidth="1.5" strokeLinecap="round" />
    {/* Capsule Grille */}
    <rect x="24" y="8" width="16" height="24" rx="8" fill="url(#micGold)" stroke="#78350f" strokeWidth="1.5" />
    <line x1="24" y1="18" x2="40" y2="18" stroke="#78350f" strokeWidth="1" />
    {/* Shockmount Cradle */}
    <path d="M18 24C18 34 24 40 32 40C40 40 46 34 46 24" stroke="#facc15" strokeWidth="2.5" strokeLinecap="round" />
    {/* Stem & Round Base */}
    <rect x="30" y="40" width="4" height="12" fill="#ca8a04" />
    <ellipse cx="32" cy="54" rx="14" ry="4" fill="url(#micGold)" stroke="#78350f" strokeWidth="1.2" />
  </svg>
);

// 18. Realistic 3D Ancient Codex / Game Bible Book
export const RealisticCodexBookIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_12px_rgba(168,85,247,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="bookCover" x1="10" y1="12" x2="54" y2="52" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#7c3aed" />
        <stop offset="50%" stopColor="#581c87" />
        <stop offset="100%" stopColor="#3b0764" />
      </linearGradient>
    </defs>
    {/* Book Cover */}
    <path
      d="M12 12C20 10 32 14 32 14C32 14 44 10 52 12V50C44 48 32 52 32 52C32 52 20 48 12 50V12Z"
      fill="url(#bookCover)"
      stroke="#facc15"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    {/* Gold Inscription Star */}
    <polygon
      points="32,24 34,29 40,29 35,33 37,39 32,35 27,39 29,33 24,29 30,29"
      fill="#fde047"
      stroke="#ca8a04"
      strokeWidth="0.8"
    />
    <path d="M32 14V52" stroke="#facc15" strokeWidth="1.5" />
  </svg>
);

// 19. Realistic 3D Couple Social Hearts
export const RealisticCoupleHeartsIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_15px_rgba(244,63,94,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="heartPink" x1="16" y1="16" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#f43f5e" />
        <stop offset="50%" stopColor="#e11d48" />
        <stop offset="100%" stopColor="#881337" />
      </linearGradient>
    </defs>
    {/* Primary Heart */}
    <path
      d="M28 20C24 14 16 14 12 20C6 28 16 38 28 48C40 38 50 28 44 20C40 14 32 14 28 20Z"
      fill="url(#heartPink)"
      stroke="#fda4af"
      strokeWidth="1.5"
    />
    {/* Secondary Overlay Heart */}
    <path
      d="M44 24C41 19 35 19 32 24C27 30 35 38 44 46C53 38 61 30 56 24C53 19 47 19 44 24Z"
      fill="#f43f5e"
      stroke="#ffffff"
      strokeWidth="1.2"
      opacity="0.9"
    />
  </svg>
);

// 20. Realistic 3D Android APK Capsule
export const RealisticAndroidApkIcon: React.FC<IconProps> = ({ className = '', size = 36 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`drop-shadow-[0_4px_15px_rgba(16,185,129,0.7)] ${className}`}
  >
    <defs>
      <linearGradient id="androidGreen" x1="16" y1="14" x2="48" y2="50" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#a7f3d0" />
        <stop offset="35%" stopColor="#10b981" />
        <stop offset="100%" stopColor="#047857" />
      </linearGradient>
    </defs>
    {/* Android Head Domes */}
    <path d="M20 28C20 18 44 18 44 28H20Z" fill="url(#androidGreen)" stroke="#064e3b" strokeWidth="1.5" />
    {/* Antennas */}
    <line x1="24" y1="18" x2="20" y2="12" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="40" y1="18" x2="44" y2="12" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" />
    {/* Eyes */}
    <circle cx="27" cy="22" r="2" fill="#ffffff" />
    <circle cx="37" cy="22" r="2" fill="#ffffff" />
    {/* Body */}
    <rect x="20" y="30" width="24" height="20" rx="3" fill="url(#androidGreen)" stroke="#064e3b" strokeWidth="1.5" />
    {/* Download Arrow Emblem on Chest */}
    <path d="M32 34V44M28 40L32 44L36 40" stroke="#f8fafc" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// ========================================================
// 4D VOLUMETRIC GLASSMORPHISM PEDESTAL WRAPPER
// Inspired by Icons8 3D Fluency, Iconfinder Glass & UI8 Assets
// Applies volumetric perspective, inset glow, & hover elevation
// ========================================================
export interface Icon4DWrapperProps {
  children: React.ReactNode;
  theme?: 'cyberpunk' | 'gold' | 'cyan' | 'ruby' | 'emerald' | 'amethyst';
  className?: string;
  tilt?: boolean;
}

export const Icon4DWrapper: React.FC<Icon4DWrapperProps> = ({
  children,
  theme = 'cyberpunk',
  className = '',
  tilt = true,
}) => {
  const themeClass =
    theme === 'gold'
      ? 'icon-4d-gold'
      : theme === 'cyan'
      ? 'icon-4d-cyan'
      : theme === 'ruby'
      ? 'icon-4d-ruby'
      : theme === 'emerald'
      ? 'icon-4d-emerald'
      : theme === 'amethyst'
      ? 'icon-4d-amethyst'
      : 'icon-4d';

  return (
    <div
      className={`relative inline-flex items-center justify-center p-2 select-none ${themeClass} ${className}`}
      style={!tilt ? { transform: 'none' } : undefined}
    >
      {/* Specular corner glint */}
      <div className="absolute top-1 left-1.5 w-3 h-1.5 bg-white/40 rounded-full blur-[0.5px] pointer-events-none" />
      {children}
    </div>
  );
};

// ========================================================
// UNIVERSAL REAL 3D / 4D ICON DISPATCHER
// ========================================================
export interface Real3DIconProps extends IconProps {
  name: string;
  wrap4D?: boolean;
  theme?: 'cyberpunk' | 'gold' | 'cyan' | 'ruby' | 'emerald' | 'amethyst';
}

export const Real3DIcon: React.FC<Real3DIconProps> = ({
  name,
  size = 32,
  className = '',
  wrap4D = false,
  theme = 'cyberpunk',
}) => {
  const normalized = (name || '').toLowerCase();

  let renderedIcon: React.ReactNode;

  if (normalized.includes('trophy') || normalized.includes('rank') || normalized.includes('cup') || normalized.includes('winner')) {
    renderedIcon = <RealisticTrophyIcon size={size} className={className} />;
  } else if (normalized.includes('crown') || normalized.includes('king') || normalized.includes('queen') || normalized.includes('vip')) {
    renderedIcon = <RealisticCrownIcon size={size} className={className} />;
  } else if (normalized.includes('diamond') || normalized.includes('gem') || normalized.includes('crystal') || normalized.includes('visual')) {
    renderedIcon = <RealisticDiamondIcon size={size} className={className} />;
  } else if (normalized.includes('coin') || normalized.includes('rupee') || normalized.includes('gold')) {
    renderedIcon = <RealisticCoinIcon size={size} className={className} />;
  } else if (normalized.includes('dice') || normalized.includes('roll') || normalized.includes('forge')) {
    renderedIcon = <RealisticDiceIcon size={size} className={className} />;
  } else if (normalized.includes('trishul') || normalized.includes('astra')) {
    renderedIcon = <RealisticTrishulIcon size={size} className={className} />;
  } else if (normalized.includes('gada') || normalized.includes('mace')) {
    renderedIcon = <RealisticGadaIcon size={size} className={className} />;
  } else if (normalized.includes('chakra') || normalized.includes('sudarshan')) {
    renderedIcon = <RealisticChakraIcon size={size} className={className} />;
  } else if (normalized.includes('dragon') || normalized.includes('pet')) {
    renderedIcon = <RealisticDragonIcon size={size} className={className} />;
  } else if (normalized.includes('gift') || normalized.includes('present') || normalized.includes('crate')) {
    renderedIcon = <RealisticGiftIcon size={size} className={className} />;
  } else if (normalized.includes('shield') || normalized.includes('defense') || normalized.includes('admin') || normalized.includes('safe')) {
    renderedIcon = <RealisticShieldIcon size={size} className={className} />;
  } else if (normalized.includes('flame') || normalized.includes('fire') || normalized.includes('streak')) {
    renderedIcon = <RealisticFlameIcon size={size} className={className} />;
  } else if (normalized.includes('bow') || normalized.includes('arrow') || normalized.includes('takshak')) {
    renderedIcon = <RealisticBowArrowIcon size={size} className={className} />;
  } else if (normalized.includes('flute') || normalized.includes('peacock') || normalized.includes('morpankh')) {
    renderedIcon = <RealisticFluteIcon size={size} className={className} />;
  } else if (normalized.includes('arcade') || normalized.includes('minigame') || normalized.includes('target')) {
    renderedIcon = <RealisticArcadeTargetIcon size={size} className={className} />;
  } else if (normalized.includes('mic') || normalized.includes('voice') || normalized.includes('room')) {
    renderedIcon = <RealisticVIPMicIcon size={size} className={className} />;
  } else if (normalized.includes('bible') || normalized.includes('codex') || normalized.includes('book') || normalized.includes('niyam') || normalized.includes('rule')) {
    renderedIcon = <RealisticCodexBookIcon size={size} className={className} />;
  } else if (normalized.includes('couple') || normalized.includes('heart') || normalized.includes('love')) {
    renderedIcon = <RealisticCoupleHeartsIcon size={size} className={className} />;
  } else if (normalized.includes('apk') || normalized.includes('android') || normalized.includes('install')) {
    renderedIcon = <RealisticAndroidApkIcon size={size} className={className} />;
  } else {
    renderedIcon = <RealisticTrophyIcon size={size} className={className} />;
  }

  if (wrap4D) {
    return <Icon4DWrapper theme={theme}>{renderedIcon}</Icon4DWrapper>;
  }

  return <>{renderedIcon}</>;
};
