import React, { useState } from 'react';
import { X, Sparkles, Trophy, RotateCw } from 'lucide-react';
import { DAILY_WHEEL_SEGMENTS } from '../data/gameConstants';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface DailyWheelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (type: 'diamonds' | 'coins' | 'stars', amount: number) => void;
}

export const DailyWheelModal: React.FC<DailyWheelModalProps> = ({
  isOpen,
  onClose,
  onClaimReward,
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotationAngle, setRotationAngle] = useState(0);
  const [wonSegment, setWonSegment] = useState<typeof DAILY_WHEEL_SEGMENTS[0] | null>(null);

  if (!isOpen) return null;

  const handleSpin = () => {
    if (isSpinning) return;

    sound.playDiceRoll();
    setIsSpinning(true);
    setWonSegment(null);

    // Pick random segment (0 to 7)
    const randomIndex = Math.floor(Math.random() * DAILY_WHEEL_SEGMENTS.length);
    const segmentAngle = 360 / DAILY_WHEEL_SEGMENTS.length;
    // Calculate final rotation to land on chosen segment:
    // 5 full rotations (1800 deg) + offset
    const targetAngle = 1800 + (360 - randomIndex * segmentAngle) - segmentAngle / 2;
    const finalAngle = rotationAngle + targetAngle;

    setRotationAngle(finalAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const chosen = DAILY_WHEEL_SEGMENTS[randomIndex];
      setWonSegment(chosen);
      sound.playFanfare();
      onClaimReward(chosen.rewardType as any, chosen.amount);

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md p-6 overflow-hidden border rounded-3xl glass-panel border-amber-500/30 text-slate-100">
        {/* Background glow */}
        <div className="absolute -top-20 -left-20 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="p-2 text-xl rounded-xl bg-amber-500/20 text-amber-400">🎡</span>
            <div>
              <h2 className="text-xl font-bold font-serif text-gold-gradient tracking-wide">
                Cosmic Lucky Wheel
              </h2>
              <p className="text-xs text-slate-400">Daily Free Fortune Spin · Win 100K 💎</p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Wheel Container */}
        <div className="relative flex flex-col items-center justify-center my-6">
          {/* Top Indicator Pointer */}
          <div className="absolute top-0 z-20 transform -translate-y-2">
            <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[24px] border-t-amber-400 drop-shadow-[0_4px_8px_rgba(245,158,11,0.8)]" />
          </div>

          {/* Rotating Wheel Disc */}
          <div
            className="relative w-64 h-64 rounded-full border-4 border-amber-400 shadow-[0_0_35px_rgba(245,158,11,0.5)] overflow-hidden transition-all duration-[4000ms] ease-out flex items-center justify-center"
            style={{
              transform: `rotate(${rotationAngle}deg)`,
              background: 'radial-gradient(circle, #2E1065 0%, #0F0A1E 100%)',
            }}
          >
            {DAILY_WHEEL_SEGMENTS.map((seg, idx) => {
              const rotate = idx * (360 / DAILY_WHEEL_SEGMENTS.length);
              return (
                <div
                  key={idx}
                  className="absolute w-full h-full top-0 left-0 flex justify-center items-start pt-2 origin-center"
                  style={{ transform: `rotate(${rotate}deg)` }}
                >
                  <div
                    className="text-[11px] font-bold px-2 py-0.5 rounded-full border shadow-sm tracking-wider"
                    style={{
                      borderColor: seg.color,
                      backgroundColor: `${seg.color}25`,
                      color: seg.color,
                    }}
                  >
                    {seg.label}
                  </div>
                </div>
              );
            })}

            {/* Wheel Center Hub */}
            <div className="absolute z-10 w-16 h-16 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-200 border-2 border-white/60 shadow-[0_0_20px_rgba(255,215,0,0.8)] flex items-center justify-center">
              <span className="text-xl">⭐</span>
            </div>
          </div>
        </div>

        {/* Won Banner */}
        {wonSegment && (
          <div className="mb-4 p-3 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-center animate-bounce">
            <p className="text-xs uppercase text-amber-300 font-semibold tracking-wider">Congratulations!</p>
            <p className="text-lg font-black text-amber-200">Won {wonSegment.label}</p>
          </div>
        )}

        {/* Action Button */}
        <div className="flex flex-col gap-2">
          <button
            onClick={handleSpin}
            disabled={isSpinning}
            className={`w-full py-3.5 px-6 rounded-2xl font-bold flex items-center justify-center gap-2 text-slate-900 ${
              isSpinning
                ? 'opacity-60 cursor-not-allowed bg-slate-600 text-slate-300'
                : 'liquid-btn-gold text-slate-950 font-black tracking-wide text-base'
            }`}
          >
            <RotateCw size={18} className={isSpinning ? 'animate-spin' : ''} />
            {isSpinning ? 'SPINNING CELESTIAL WHEEL...' : 'FREE DAILY SPIN'}
          </button>
          <p className="text-[11px] text-center text-slate-400">
            Resets daily at 00:00 UTC · VIP players get +2 Bonus Spins
          </p>
        </div>
      </div>
    </div>
  );
};
