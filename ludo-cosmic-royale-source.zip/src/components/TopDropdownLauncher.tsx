import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronDown,
  ChevronUp,
  X,
  Sparkles,
  Book,
  Zap,
  Flame,
  Award,
  Layers,
  Settings,
  Shield,
  KeyRound,
  Compass,
  ArrowRight,
  MoreHorizontal,
  Plus,
  RotateCcw,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import {
  RealisticTrishulIcon,
  RealisticDragonIcon,
  RealisticDiamondIcon,
  RealisticGiftIcon,
  RealisticShieldIcon,
  RealisticCrownIcon,
  RealisticTrophyIcon,
  RealisticArcadeTargetIcon,
  RealisticFluteIcon,
  RealisticVIPMicIcon,
  RealisticCodexBookIcon,
  RealisticCoupleHeartsIcon,
  RealisticAndroidApkIcon,
  RealisticDiceIcon,
  Icon4DWrapper,
} from './RealIcons';

export interface TopLauncherItem {
  id: string;
  name: string;
  icon: string;
  badge?: string;
  color: string;
  action: () => void;
}

interface TopDropdownLauncherProps {
  onOpenModal: (modal: any) => void;
  onNavigate: (view: any) => void;
  onOpenMuseum: () => void;
}

export const TopDropdownLauncher: React.FC<TopDropdownLauncherProps> = ({
  onOpenModal,
  onNavigate,
  onOpenMuseum,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMoreExpanded, setIsMoreExpanded] = useState(false);
  const [isReordering, setIsReordering] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when tapping outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setIsMoreExpanded(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Initial ~10 Quick Jump Icons (Bible Section 4: Reduced from 40 to ~10 visible + More/+)
  const [quickJumpItems, setQuickJumpItems] = useState<TopLauncherItem[]>([
    {
      id: 'astra',
      name: 'Astra',
      icon: '🔱',
      badge: 'ITEM 14',
      color: 'from-cyan-500 to-blue-600',
      action: () => onOpenModal('astra'),
    },
    {
      id: 'pets',
      name: '30 Pets',
      icon: '🐉',
      badge: 'ITEM 11',
      color: 'from-emerald-500 to-teal-600',
      action: () => onOpenModal('pets'),
    },
    {
      id: 'minigames',
      name: 'Arcade',
      icon: '🎯',
      badge: 'ITEM 13',
      color: 'from-rose-500 to-pink-600',
      action: () => onOpenModal('minigames'),
    },
    {
      id: 'missions',
      name: 'Missions',
      icon: '📋',
      badge: 'ITEM 19',
      color: 'from-amber-500 to-orange-600',
      action: () => onOpenModal('missions'),
    },
    {
      id: 'visuals',
      name: '4D Neon',
      icon: '💎',
      badge: 'ITEM 2',
      color: 'from-blue-500 to-cyan-500',
      action: () => onOpenModal('visuals'),
    },
    {
      id: 'flute',
      name: 'Flute',
      icon: '🪈',
      badge: 'ITEM 15',
      color: 'from-purple-500 to-violet-600',
      action: () => onOpenModal('flute'),
    },
    {
      id: 'rooms',
      name: '8-Seat VIP',
      icon: '🎙️',
      badge: 'ITEM 5',
      color: 'from-fuchsia-500 to-pink-600',
      action: () => onNavigate('rooms'),
    },
    {
      id: 'museum',
      name: 'Museum',
      icon: '🏛️',
      badge: 'ITEM 20',
      color: 'from-amber-600 to-yellow-500',
      action: () => onOpenMuseum(),
    },
    {
      id: 'rules',
      name: 'Rules',
      icon: '📜',
      badge: 'ITEM 7',
      color: 'from-indigo-500 to-purple-600',
      action: () => onOpenModal('rules'),
    },
    {
      id: 'tutorial',
      name: 'Tutorial',
      icon: '🎓',
      badge: 'ITEM 0/40',
      color: 'from-emerald-600 to-cyan-600',
      action: () => onOpenModal('tutorial'),
    },
  ]);

  // Extended More / + Items
  const moreItems: TopLauncherItem[] = [
    {
      id: 'bible',
      name: 'Game Bible',
      icon: '📖',
      badge: '1–43',
      color: 'from-purple-600 to-indigo-700',
      action: () => onOpenModal('bible'),
    },
    {
      id: 'auth',
      name: 'Login Board',
      icon: '🆔',
      badge: '#100002+',
      color: 'from-amber-500 to-yellow-600',
      action: () => onOpenModal('auth'),
    },
    {
      id: 'admin',
      name: 'Admin Center',
      icon: '🛡️',
      badge: '#777777',
      color: 'from-red-600 to-rose-700',
      action: () => onOpenModal('admin'),
    },
    {
      id: 'map',
      name: 'World Map',
      icon: '🗺️',
      badge: '3D',
      color: 'from-teal-500 to-emerald-600',
      action: () => onNavigate('map'),
    },
    {
      id: 'clan',
      name: 'Clan Wars',
      icon: '⚔️',
      badge: 'LEAGUE',
      color: 'from-red-500 to-amber-600',
      action: () => onOpenModal('clan'),
    },
    {
      id: 'forge',
      name: 'Dice Forge',
      icon: '⚒️',
      badge: '3X ALTAR',
      color: 'from-orange-500 to-amber-600',
      action: () => onOpenModal('forge'),
    },
    {
      id: 'crates',
      name: 'Crates',
      icon: '📦',
      badge: 'LOOT',
      color: 'from-yellow-600 to-amber-500',
      action: () => onOpenModal('crates'),
    },
    {
      id: 'gifts',
      name: '3D Gifts',
      icon: '🎁',
      badge: '50 TYPES',
      color: 'from-pink-500 to-rose-600',
      action: () => onOpenModal('gifts'),
    },
    {
      id: 'balloons',
      name: 'Balloons',
      icon: '🎈',
      badge: '2💎 SPLASH',
      color: 'from-cyan-500 to-blue-600',
      action: () => onOpenModal('balloons'),
    },
    {
      id: 'couple',
      name: 'Couple Social',
      icon: '💑',
      badge: 'DOUBLE HEARTS',
      color: 'from-rose-500 to-pink-600',
      action: () => onOpenModal('couple'),
    },
    {
      id: 'apk',
      name: 'ZIP & APK',
      icon: '📦',
      badge: 'OFFLINE',
      color: 'from-amber-500 to-yellow-600',
      action: () => onOpenModal('apk'),
    },
  ];

  const handleToggle = () => {
    sound.playClick();
    setIsOpen((prev) => !prev);
    if (isOpen) {
      setIsMoreExpanded(false);
      setIsReordering(false);
    }
  };

  const handleItemClick = (item: TopLauncherItem) => {
    sound.playClick();
    setIsOpen(false);
    setIsMoreExpanded(false);
    setIsReordering(false);
    item.action();
  };

  const handleMoveLeft = (index: number) => {
    if (index === 0) return;
    sound.playSafeCell();
    const updated = [...quickJumpItems];
    const temp = updated[index - 1];
    updated[index - 1] = updated[index];
    updated[index] = temp;
    setQuickJumpItems(updated);
  };

  const renderLauncherIcon = (item: TopLauncherItem) => {
    switch (item.id) {
      case 'astra':
        return <RealisticTrishulIcon size={26} className="group-hover:scale-110 transition-transform" />;
      case 'pets':
        return <RealisticDragonIcon size={26} className="group-hover:scale-110 transition-transform" />;
      case 'visuals':
        return <RealisticDiamondIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'gifts':
        return <RealisticGiftIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'admin':
        return <RealisticShieldIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'minigames':
        return <RealisticArcadeTargetIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'flute':
        return <RealisticFluteIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'rooms':
        return <RealisticVIPMicIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'bible':
      case 'rules':
        return <RealisticCodexBookIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'couple':
        return <RealisticCoupleHeartsIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'apk':
        return <RealisticAndroidApkIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'forge':
        return <RealisticDiceIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'clan':
        return <RealisticCrownIcon size={24} className="group-hover:scale-110 transition-transform" />;
      case 'missions':
        return <RealisticTrophyIcon size={24} className="group-hover:scale-110 transition-transform" />;
      default:
        return (
          <span className="text-xl sm:text-2xl group-hover:scale-110 transition-transform">
            {item.icon}
          </span>
        );
    }
  };

  return (
    <div ref={dropdownRef} className="fixed top-0 left-0 right-0 z-40 pointer-events-none flex flex-col items-center">
      {/* Top Toggle Handle Bar (Discreet Arrow at Top Center) */}
      <div className="pointer-events-auto">
        <button
          onClick={handleToggle}
          className={`flex items-center gap-1.5 px-4 py-1 rounded-b-2xl transition-all duration-300 shadow-lg border-b border-x ${
            isOpen
              ? 'bg-gradient-to-r from-purple-900 via-indigo-900 to-purple-900 border-amber-400/80 text-amber-200 shadow-[0_4px_25px_rgba(245,158,11,0.5)]'
              : 'bg-black/80 hover:bg-black/95 backdrop-blur-md border-amber-400/40 text-amber-300 hover:text-amber-200 hover:border-amber-400/70 hover:scale-105 active:scale-95'
          }`}
          title="Top Dropdown Launcher (Bible Section 4)"
        >
          <span className="text-[10px] font-black uppercase tracking-wider font-cinzel flex items-center gap-1">
            <span>⚡</span>
            <span>Quick Launcher</span>
          </span>
          {isOpen ? (
            <ChevronUp size={14} className="text-amber-400 animate-bounce" />
          ) : (
            <ChevronDown size={14} className="text-amber-400 animate-pulse" />
          )}
        </button>
      </div>

      {/* Expanded Dropdown Drawer (Bible Section 4: ~10 visible + More/+) */}
      {isOpen && (
        <div className="pointer-events-auto w-full max-w-2xl px-2 sm:px-4 mt-1 animate-fade-in">
          <div className="relative rounded-3xl bg-slate-950/95 border-2 border-amber-400/70 shadow-[0_10px_50px_rgba(0,0,0,0.9),0_0_35px_rgba(245,158,11,0.35)] backdrop-blur-2xl p-3 sm:p-4 text-slate-100 flex flex-col gap-2.5">
            {/* Header info bar */}
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1">
                  <span>⚡ Quick-Jump Navigation</span>
                  <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                    BIBLE SEC 4
                  </span>
                </span>
                <span className="text-[10px] text-slate-400 hidden sm:inline">
                  (10 Primary Icons + Expandable Drawer)
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsReordering((prev) => !prev)}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition ${
                    isReordering
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
                  }`}
                >
                  {isReordering ? 'Done Ordering' : 'Reorder'}
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    setIsOpen(false);
                    setIsMoreExpanded(false);
                  }}
                  className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 transition"
                  title="Close Launcher"
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Grid of ~10 Core Quick Jump Items */}
            <div className="grid grid-cols-5 sm:grid-cols-5 gap-1.5 sm:gap-2">
              {quickJumpItems.map((item, idx) => (
                <div key={item.id} className="relative group">
                  <button
                    onClick={() => handleItemClick(item)}
                    className="w-full flex flex-col items-center justify-center p-2 sm:p-2.5 rounded-2xl bg-gradient-to-b from-white/5 to-white/0 hover:from-white/15 hover:to-white/5 border border-white/10 hover:border-amber-400/60 transition-all hover:scale-105 active:scale-95 group text-center shadow-sm"
                  >
                    <div className="h-7 sm:h-8 flex items-center justify-center">
                      {renderLauncherIcon(item)}
                    </div>
                    <span className="text-[10px] sm:text-xs font-bold text-slate-200 group-hover:text-amber-200 truncate mt-1">
                      {item.name}
                    </span>
                    {item.badge && (
                      <span className="text-[7px] sm:text-[8px] px-1 rounded-full bg-white/10 text-slate-400 group-hover:text-amber-300 group-hover:bg-amber-500/20 transition mt-0.5">
                        {item.badge}
                      </span>
                    )}
                  </button>

                  {/* Reorder control arrow */}
                  {isReordering && idx > 0 && (
                    <button
                      onClick={() => handleMoveLeft(idx)}
                      className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] flex items-center justify-center shadow"
                      title="Move Left"
                    >
                      ←
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Expandable More / + Button */}
            <div className="pt-1 flex items-center justify-between border-t border-white/10 text-[11px]">
              <button
                onClick={() => {
                  sound.playClick();
                  setIsMoreExpanded((prev) => !prev);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-indigo-950/70 border border-purple-500/30 text-purple-200 hover:text-white hover:border-purple-400 transition font-bold"
              >
                <MoreHorizontal size={14} className="text-purple-400" />
                <span>{isMoreExpanded ? 'Collapse More Icons ▲' : 'More Features & Systems (+11) ▼'}</span>
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onOpenModal('rules');
                  setIsOpen(false);
                }}
                className="text-amber-300 hover:underline font-bold text-[10px] flex items-center gap-1"
              >
                <Book size={12} />
                <span>Niyam & Rules</span>
              </button>
            </div>

            {/* Expanded More Icons Drawer */}
            {isMoreExpanded && (
              <div className="pt-2 grid grid-cols-4 sm:grid-cols-6 gap-1.5 sm:gap-2 border-t border-purple-500/20 animate-fade-in">
                {moreItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item)}
                    className="flex flex-col items-center justify-center p-2 rounded-2xl bg-white/5 hover:bg-purple-950/40 border border-white/10 hover:border-purple-400/50 transition-all hover:scale-105 active:scale-95 text-center shadow-sm group"
                  >
                    <div className="h-6 sm:h-7 flex items-center justify-center">
                      {renderLauncherIcon(item)}
                    </div>
                    <span className="text-[9px] sm:text-[10px] font-bold text-slate-200 truncate mt-0.5">
                      {item.name}
                    </span>
                    <span className="text-[7px] text-purple-300 font-mono mt-0.5">{item.badge}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
