import React, { useState } from 'react';
import {
  X,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  SkipForward,
  Play,
  Eye,
  Shield,
  Zap,
  Volume2,
  VolumeX,
  Camera,
  Layers,
  Award,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface InteractiveTutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete?: () => void;
  onNavigateToArena?: () => void;
}

interface TutorialStep {
  title: string;
  hindiTitle: string;
  subtitle: string;
  icon: string;
  accentColor: string;
  borderColor: string;
  description: string;
  keyRule: string;
  ruleTag: string;
  bullets: string[];
}

export const InteractiveTutorialModal: React.FC<InteractiveTutorialModalProps> = ({
  isOpen,
  onClose,
  onComplete,
  onNavigateToArena,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isOpen) return null;

  const TUTORIAL_STEPS: TutorialStep[] = [
    {
      title: '1. Cosmic 3D Board & Readability',
      hindiTitle: '3D लूडो बोर्ड और स्पष्टता',
      subtitle: 'Bible Items 40 & 41: Fast Play & Token Readability',
      icon: '🎲',
      accentColor: 'from-amber-500 to-yellow-600',
      borderColor: 'border-amber-400',
      description:
        'Roll 3D physics dice and navigate dynamic paths. All tokens, star cells, and dice numbers are visually layered above atmospheric effects so gameplay always remains instant and crystal clear.',
      keyRule: 'Fast & Clear: Reveals last seconds, not minutes. Tokens and paths remain top priority.',
      ruleTag: 'ITEM 41 READABILITY',
      bullets: [
        'Holographic dice rolls with tactile sound and vibration.',
        'Jelly squash & stretch token movement along safe celestial cells.',
        'Normal gameplay camera seamlessly blends into 5-second cinematic slow-mo kill cams.',
      ],
    },
    {
      title: '2. Divine Astras & 3x Crucible Forge',
      hindiTitle: 'दिव्य अस्त्र और 3x फोर्ज',
      subtitle: 'Bible Items 18, 19 & 34: Power Families & Combos',
      icon: '🔱',
      accentColor: 'from-cyan-500 to-blue-600',
      borderColor: 'border-cyan-400',
      description:
        'Harness the Trishul Tandav, Indra Vajra storm, and Sudarshan vortex. Sacrifice 3 identical lower-tier cards in the Forge Crucible altar to forge higher-tier weapons up to 79 Billion 💎.',
      keyRule: 'Cosmetic Mastery: Astras create stunning weather and kill-cams without breaking game fairness.',
      ruleTag: 'ITEM 34 ASTRA COMBOS',
      bullets: [
        'Mahabharata Tandav Combo: Trishul → Vajra Lightning → Gada Wobble.',
        'Brahmastra safety limits: 10 tactical board holds, never a game ban.',
        'Pashupatastra singularity void: Configurable apex weapon.',
      ],
    },
    {
      title: '3. 30 Mythic Pets & Flute Tiny Characters',
      hindiTitle: '30 दुर्लभ साथी और म्यूट मिरेकल आगमन',
      subtitle: 'Bible Items 20, 35 & 41: Audio Balance & Silent Arrivals',
      icon: '🐉',
      accentColor: 'from-emerald-500 to-teal-600',
      borderColor: 'border-emerald-400',
      description:
        'Adopt dragons, moon wolves, and lions that react dynamically to your dice rolls. Tiny Flute companions travel across seats to draw curtains and present your avatar.',
      keyRule: 'Audio Rule: Audio plays where appropriate; Miracle Arrival specifically remains SILENT.',
      ruleTag: 'ITEM 41 AUDIO SPEC',
      bullets: [
        '30 Rare Pets earned solely through quests and achievements, never purchased.',
        'Takshak Nag gag: Playfully swallows pet for 25 seconds with 0 HP damage.',
        '10 Silent Miracle Arrival variants: Dash, Royal Curtain, Double Arrival.',
      ],
    },
    {
      title: '4. 8-Seat VIP Voice Rooms & 3D Gifts',
      hindiTitle: 'लाइव वॉयस रूम और प्राइवेट स्पेंडिंग',
      subtitle: 'Bible Items 23, 25 & 40: Public Status, Private Spend',
      icon: '🎙️',
      accentColor: 'from-purple-500 to-pink-600',
      borderColor: 'border-purple-400',
      description:
        'Join live audio stages with real-time mic streaming and throw animated 3D Bugattis, private jets, or water balloons at friends. Celebrate prestige while keeping user balances confidential.',
      keyRule: 'Privacy Promise: Public status for Top Gifters, but spending amount is never exposed.',
      ruleTag: 'ITEM 40 PRIVACY',
      bullets: [
        'Prestige Top Gifter banner shows rank without displaying total currency spent.',
        'Top 200 Name Tags: Egg Hunter, Secret Keeper, Matrix Master, President.',
        'Spatial audio filters: Robot, Helium, Deep Voice, and Cinema acoustics.',
      ],
    },
    {
      title: '5. Living World Map & Sovereign Owner Command',
      hindiTitle: '3D वर्ल्ड मैप और सॉवरेन एडमिन सेंटर',
      subtitle: 'Bible Items 26, 38 & 42: Phase 1–5 Complete Build',
      icon: '👑',
      accentColor: 'from-red-500 to-amber-600',
      borderColor: 'border-red-400',
      description:
        'Explore the 3D map connecting Ludo Kingdom, Pet Forest, Astra Temple, and Hall of Fame. Verify your identity with Owner ID #777777 or sequential player IDs starting from #100002+.',
      keyRule: 'Sovereign Control: Real Mode vs Ghost Mode, audit logs, and weekly ops toggles.',
      ruleTag: 'ITEM 42 BUILD ORDER',
      bullets: [
        'One-time email login via Login Board with permanent sequential IDs from #100002+.',
        'Verified Owner credentials: akvikings05@gmail.com (ID 777777).',
        'Year-End Awards across 12 apex categories with 3D trophy ceremonies.',
      ],
    },
  ];

  const currentStep = TUTORIAL_STEPS[currentStepIndex];
  const isLastStep = currentStepIndex === TUTORIAL_STEPS.length - 1;

  const handleNext = () => {
    sound.playClick();
    if (isLastStep) {
      sound.playGrandVictory();
      try {
        localStorage.setItem('ludo_tutorial_completed', 'true');
      } catch {
        // Ignore
      }
      if (onComplete) onComplete();
      onClose();
    } else {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    sound.playClick();
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handleSkip = () => {
    sound.playSafeCell();
    try {
      localStorage.setItem('ludo_tutorial_completed', 'true');
    } catch {
      // Ignore
    }
    if (onComplete) onComplete();
    onClose();
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl overflow-hidden border-2 border-amber-400/60 rounded-3xl bg-gradient-to-b from-[#160c2b] via-[#0d0718] to-black text-slate-100 shadow-[0_0_60px_rgba(245,158,11,0.35)] flex flex-col max-h-[92vh]"
      >
        {/* Header with Watch / Skip controls */}
        <div className="p-4 bg-gradient-to-r from-purple-950/80 via-slate-900 to-amber-950/80 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${currentStep.accentColor} flex items-center justify-center text-slate-950 text-2xl font-black shadow-md border border-white/20`}>
              {currentStep.icon}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-amber-200 font-cinzel">
                  Interactive Game Tutorial
                </h3>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40">
                  ITEM 40: WATCH OR SKIP
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                Step {currentStepIndex + 1} of {TUTORIAL_STEPS.length} · Fast {currentStep.subtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Skip Button */}
            <button
              onClick={handleSkip}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition text-xs font-bold border border-white/10"
              title="Skip Tutorial (Bible Item 40)"
            >
              <span>Skip</span>
              <SkipForward size={14} />
            </button>

            {/* X Close Button */}
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-red-950/80 border border-white/10 hover:border-red-400 text-slate-300 hover:text-white transition active:scale-95 cursor-pointer"
              title="Close Tutorial"
              aria-label="Close Screen"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Step Progress Bar */}
        <div className="px-4 py-2 bg-slate-950/60 border-b border-white/5 flex items-center gap-1.5">
          {TUTORIAL_STEPS.map((step, idx) => (
            <div
              key={step.title}
              onClick={() => {
                sound.playClick();
                setCurrentStepIndex(idx);
              }}
              className={`flex-1 h-2 rounded-full cursor-pointer transition-all duration-300 ${
                idx === currentStepIndex
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-500 shadow-[0_0_8px_#f59e0b]'
                  : idx < currentStepIndex
                  ? 'bg-emerald-500/80'
                  : 'bg-white/10 hover:bg-white/20'
              }`}
            />
          ))}
        </div>

        {/* Step Card Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1">
          {/* Main Title & Hindi Tag */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-lg font-black text-white font-cinzel flex items-center gap-2">
                <span>{currentStep.title}</span>
              </h2>
              <p className="text-xs text-amber-300 font-semibold">{currentStep.hindiTitle}</p>
            </div>
            <span className="text-[10px] px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-black border border-amber-500/40 tracking-wider">
              {currentStep.ruleTag}
            </span>
          </div>

          {/* Description */}
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {currentStep.description}
          </p>

          {/* Highlight Key Rule Box */}
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-2.5 shadow-sm">
            <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[11px] font-bold text-amber-200 uppercase tracking-wide">
                Core Game Bible Rule
              </p>
              <p className="text-xs text-slate-200 font-medium mt-0.5">
                {currentStep.keyRule}
              </p>
            </div>
          </div>

          {/* Bullet points */}
          <div className="space-y-2 pt-1">
            {currentStep.bullets.map((bullet, i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <span>{bullet}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer Navigation Controls */}
        <div className="p-4 bg-slate-950/90 border-t border-amber-500/20 flex items-center justify-between gap-3">
          <button
            onClick={handlePrev}
            disabled={currentStepIndex === 0}
            className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition ${
              currentStepIndex === 0
                ? 'opacity-40 cursor-not-allowed text-slate-500'
                : 'bg-white/10 hover:bg-white/20 text-slate-200'
            }`}
          >
            <ChevronLeft size={16} />
            <span>Previous</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSkip}
              className="text-xs font-bold text-slate-400 hover:text-white px-3 py-2 transition"
            >
              Skip All
            </button>

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-xs shadow-[0_0_15px_rgba(245,158,11,0.4)] transition hover:scale-105 active:scale-95"
            >
              <span>{isLastStep ? 'Finish & Play 🎲' : 'Next Step'}</span>
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
