import React, { useState } from 'react';
import { Crown, Trophy, Sparkles, Flame, Shield, Award, Medal, Egg, Heart, Tag } from 'lucide-react';
import { ASSETS } from '../data/gameConstants';
import { sound } from '../utils/soundEngine';

export const LeaderboardView: React.FC = () => {
  const [activeBoard, setActiveBoard] = useState<
    'daily' | 'weekly' | 'monthly' | 'hall-of-fame' | 'unstoppable' | 'trophy' | 'sunday'
  >('daily');

  // Top 3 Podium (Exact match with Screenshot 4)
  const podiumData = {
    rank1: {
      name: 'Aditi',
      coins: '200M',
      diamonds: '11,245',
      title: '👑 Diamond Mafia',
      tag: 'President 👑',
      hotSeatStatus: '🔥 6-Streak',
      level: 284,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=140&auto=format&fit=crop&q=80',
    },
    rank2: {
      name: 'Riya',
      coins: '150M',
      diamonds: '8,763',
      title: '🩸 Goti Killer',
      tag: 'Matrix Master ⚡',
      hotSeatStatus: '⚔️ Goti Hunter',
      level: 195,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=140&auto=format&fit=crop&q=80',
    },
    rank3: {
      name: 'Karan',
      coins: '80M',
      diamonds: '7,240',
      title: '🎯 Lucky Sixer',
      tag: 'Egg Hunter 🥚',
      hotSeatStatus: '🛡️ Safe Master',
      level: 142,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=140&auto=format&fit=crop&q=80',
    },
  };

  const ranksList = [
    { rank: 1, name: 'Aditi', diamonds: '11,245', title: '👑 Diamond Mafia', tag: 'President 👑', hotSeatStatus: '🔥 6-Streak', level: 284, avatar: podiumData.rank1.avatar, trophyType: 'gold' },
    { rank: 2, name: 'Riya', diamonds: '8,763', title: '🩸 Goti Killer', tag: 'Matrix Master ⚡', hotSeatStatus: '⚔️ Goti Hunter', level: 195, avatar: podiumData.rank2.avatar, trophyType: 'silver' },
    { rank: 3, name: 'Karan', diamonds: '7,240', title: '🎯 Lucky Sixer', tag: 'Egg Hunter 🥚', hotSeatStatus: '🛡️ Safe Master', level: 142, avatar: podiumData.rank3.avatar, trophyType: 'bronze' },
    { rank: 4, name: 'Ananya', diamonds: '5,128', title: '⚡ Speed Demon', tag: 'Secret Keeper 🗝️', hotSeatStatus: '👑 Champion', level: 110, avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80' },
    { rank: 5, name: 'Vivaan', diamonds: '3,986', title: '💖 Heart Master', tag: 'Love Birds 💞', hotSeatStatus: '🎲 Lucky Roll', level: 98, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80' },
    { rank: 6, name: 'Sovereign Aryan', diamonds: '9,850', title: '💎 Luxury Sovereign', tag: 'God 🔱', hotSeatStatus: '🌟 VIP Beacon', level: 175, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80' },
  ];

  // Top 200 Name Tag System (Bible Item 25)
  const NAME_TAGS = [
    'Egg Hunter',
    'Secret Keeper',
    'Matrix Master',
    'God',
    'Live',
    'Z',
    'Butcher',
    'Slaver',
    'Love Birds',
    'Phantom',
    'President',
    'Vice President',
  ];

  return (
    <div className="w-full max-w-lg mx-auto space-y-4 pb-24 animate-fade-in px-3">
      {/* 1. HEADER */}
      <div className="text-center pt-1 pb-1">
        <div className="w-36 h-12 mx-auto drop-shadow-lg">
          <img src={ASSETS.logo} alt="LUDO PLAY" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-xl font-black tracking-wide text-amber-300 uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] font-cinzel">
          RANKINGS & FAME BOARD
        </h1>
        <div className="inline-flex items-center gap-1 px-4 py-0.5 rounded-full bg-gradient-to-r from-purple-900 via-indigo-800 to-purple-900 border border-amber-400/40 shadow-sm mt-0.5">
          <span className="text-amber-300 text-xs">★</span>
          <span className="text-[11px] font-bold text-amber-200">Bible 23–25: Hot Seats, Name Tags & Awards</span>
          <span className="text-amber-300 text-xs">★</span>
        </div>
      </div>

      {/* Top Gifter Public Status Banner (Bible Item 23: Spending remains private) */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/80 via-pink-950/70 to-slate-900 border border-pink-500/40 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-pink-500/20 border border-pink-400 flex items-center justify-center text-xl shadow-[0_0_15px_#ec4899]">
            🎁
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-pink-200 uppercase tracking-wider">Top Gifter of the Week</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-pink-500 text-slate-950 font-black">
                ITEM 23
              </span>
            </div>
            <p className="text-xs font-bold text-white">Sovereign Aryan 👑</p>
            <p className="text-[10px] text-pink-300/80">Public status verified · Spending amount remains strictly private</p>
          </div>
        </div>
        <span className="px-2.5 py-1 rounded-xl bg-pink-600/30 border border-pink-400 text-pink-300 font-black text-[10px]">
          Prestige Rank #1
        </span>
      </div>

      {/* Weekly Egg Leaderboard #1 Banner (Bible Item 25) */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-amber-950/60 border border-emerald-500/40 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-xl shadow-[0_0_12px_#10b981]">
            🥚
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-emerald-300 uppercase tracking-wider">Weekly Egg #1 Award</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 font-black">
                ITEM 25
              </span>
            </div>
            <p className="text-[11px] text-white">
              Reward: <strong>5,000 Diamonds + Emerald Egg</strong> (Configured by Admin)
            </p>
          </div>
        </div>
        <span className="text-[10px] font-bold text-emerald-300 bg-black/50 px-2 py-1 rounded-lg border border-emerald-500/30">
          Karan (#1 Egg Hunter)
        </span>
      </div>

      {/* 7 Competitive Boards Tabs (Bible Item 24) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'daily', label: 'Daily Board' },
          { id: 'weekly', label: 'Weekly Board' },
          { id: 'monthly', label: 'Monthly Board' },
          { id: 'hall-of-fame', label: 'Hall of Fame' },
          { id: 'unstoppable', label: 'Unstoppable' },
          { id: 'trophy', label: 'Trophy Wall' },
          { id: 'sunday', label: 'Sunday Tournament' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              sound.playClick();
              setActiveBoard(tab.id as any);
            }}
            className={`px-3 py-1.5 rounded-xl text-[11px] font-black whitespace-nowrap transition ${
              activeBoard === tab.id
                ? 'liquid-btn-gold text-slate-950 font-black shadow-md'
                : 'glass-card text-slate-300 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 1,000-Level Progress Banner for User */}
      <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/70 via-slate-900 to-amber-950/70 border border-amber-500/30 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-xs shadow-md">
            LV.42
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white">VikingKing (You)</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-red-600 text-white font-black">
                🩸 Goti Killer
              </span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold">
                President 👑
              </span>
            </div>
            <div className="w-40 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
              <div className="bg-gradient-to-r from-amber-400 to-yellow-400 h-full w-[42%]" />
            </div>
            <span className="text-[9px] text-slate-400 block mt-0.5">Next Milestone: Level 50 (Lucky Sixer & Green Dice)</span>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs font-black text-amber-300">#42 Global</span>
          <span className="text-[9px] text-emerald-400 block">Top 1% Player</span>
        </div>
      </div>

      {/* THREE REGAL HANGING SCROLLS */}
      <div className="grid grid-cols-3 gap-2 items-end pt-2">
        {/* Rank 2: Riya */}
        <div className="flex flex-col items-center">
          <div className="royal-scroll-blue w-full rounded-2xl p-2.5 flex flex-col items-center text-center shadow-xl">
            <div className="text-xl -mt-5 mb-1 drop-shadow-md">👑</div>
            <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-slate-300 bg-slate-900 shadow-lg">
              <img src={podiumData.rank2.avatar} alt="Riya" className="w-full h-full object-cover" />
            </div>
            <h4 className="text-xs font-black text-white mt-1.5 truncate w-full">Riya</h4>
            <span className="text-[8px] text-blue-200 font-bold truncate">{podiumData.rank2.title}</span>
            <span className="text-[8px] bg-blue-500/20 text-blue-300 px-1.5 py-0.2 rounded-full border border-blue-400/30 mt-0.5">
              {podiumData.rank2.hotSeatStatus}
            </span>
            <div className="mt-1 px-2 py-0.5 rounded-full bg-black/40 border border-blue-400/40 text-[10px] font-black text-blue-200 flex items-center gap-1">
              <span>🪙</span>
              <span>{podiumData.rank2.coins}</span>
            </div>
          </div>
        </div>

        {/* Rank 1: Aditi */}
        <div className="flex flex-col items-center -translate-y-3">
          <div className="royal-scroll-gold w-full rounded-2xl p-3 flex flex-col items-center text-center shadow-[0_0_25px_rgba(245,158,11,0.6)]">
            <div className="text-2xl -mt-6 mb-1 drop-shadow-[0_0_8px_rgba(255,215,0,0.8)] animate-bounce">
              👑
            </div>
            <div className="w-16 h-16 rounded-full overflow-hidden border-3 border-amber-300 bg-slate-900 shadow-2xl">
              <img src={podiumData.rank1.avatar} alt="Aditi" className="w-full h-full object-cover" />
            </div>
            <h4 className="text-sm font-black text-amber-300 mt-1.5 truncate w-full">Aditi</h4>
            <span className="text-[9px] text-amber-200 font-bold truncate">{podiumData.rank1.title}</span>
            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-2 py-0.2 rounded-full border border-amber-400/40 mt-0.5">
              {podiumData.rank1.hotSeatStatus}
            </span>
            <div className="mt-1 px-2.5 py-0.5 rounded-full bg-black/50 border border-amber-400 text-xs font-black text-amber-200 flex items-center gap-1 shadow-md">
              <span>🪙</span>
              <span>{podiumData.rank1.coins}</span>
            </div>
          </div>
        </div>

        {/* Rank 3: Karan */}
        <div className="flex flex-col items-center">
          <div className="royal-scroll-purple w-full rounded-2xl p-2.5 flex flex-col items-center text-center shadow-xl">
            <div className="text-xl -mt-5 mb-1 drop-shadow-md">👑</div>
            <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-purple-300 bg-slate-900 shadow-lg">
              <img src={podiumData.rank3.avatar} alt="Karan" className="w-full h-full object-cover" />
            </div>
            <h4 className="text-xs font-black text-white mt-1.5 truncate w-full">Karan</h4>
            <span className="text-[8px] text-purple-200 font-bold truncate">{podiumData.rank3.title}</span>
            <span className="text-[8px] bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded-full border border-purple-400/30 mt-0.5">
              {podiumData.rank3.hotSeatStatus}
            </span>
            <div className="mt-1 px-2 py-0.5 rounded-full bg-black/40 border border-purple-400/40 text-[10px] font-black text-purple-200 flex items-center gap-1">
              <span>🪙</span>
              <span>{podiumData.rank3.coins}</span>
            </div>
          </div>
        </div>
      </div>

      {/* PARCHMENT SCROLL RANK LIST WITH TROPHIES, TAGS & HOT SEATS (Items 24 & 25) */}
      <div className="p-2.5 rounded-3xl bg-amber-100 text-slate-950 shadow-2xl border-4 border-amber-400 space-y-2">
        {ranksList.map((item) => (
          <div
            key={item.rank}
            className="flex items-center justify-between p-2 rounded-2xl bg-amber-50/90 border border-amber-300 shadow-sm"
          >
            <div className="flex items-center gap-2.5">
              <span className="w-6 text-center font-black text-xs text-amber-900">
                #{item.rank}
              </span>
              <img src={item.avatar} alt={item.name} className="w-9 h-9 rounded-full object-cover border border-amber-500 shadow-sm" />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-black text-slate-900">{item.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-900 font-bold border border-amber-500/40">
                    {item.tag}
                  </span>
                  <span className="text-[8px] px-1 py-0.2 rounded bg-slate-900 text-amber-300 font-bold">
                    {item.hotSeatStatus}
                  </span>
                </div>
                <p className="text-[10px] text-amber-800 font-semibold">{item.title}</p>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs font-mono font-black text-purple-900">
                💎 {item.diamonds}
              </span>
              <span className="text-[9px] text-slate-600 block">Level {item.level}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Top 200 Name Tag Showcase (Bible Item 25) */}
      <div className="p-3.5 rounded-2xl bg-slate-900 border border-cyan-500/30 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-cyan-300 flex items-center gap-1 uppercase tracking-wider">
            <Tag size={12} />
            <span>Top 200 Name Tag System (Item 25)</span>
          </span>
          <span className="text-[9px] text-slate-400">Chat · Profile · Seat · Entry</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {NAME_TAGS.map((tag) => (
            <span
              key={tag}
              className="text-[10px] px-2 py-0.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-200 font-bold"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
