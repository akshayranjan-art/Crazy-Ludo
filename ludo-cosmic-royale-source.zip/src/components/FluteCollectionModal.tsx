import React, { useState } from 'react';
import { X, Sparkles, Music, Lock, Check, Award, Eye, ShieldCheck, UserCheck } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { MiracleArrivalVariant } from '../types/game';
import confetti from 'canvas-confetti';

export interface TinyCharacter {
  id: string;
  name: string;
  hindiName: string;
  icon: string;
  species: string;
  questUnlock: string;
  unlocked: boolean;
  dialogue1: string;
  dialogue2: string;
  variant: MiracleArrivalVariant;
}

// 32 Unique Tiny Characters for Flute Collection (Points 20)
export const FLUTE_TINY_CHARACTERS: TinyCharacter[] = [
  {
    id: 'tiny-krishna-flute',
    name: 'Bal Gopal Flute Runner',
    hindiName: 'बाल गोपाल वंशी',
    icon: '🪈',
    species: 'Divine Avatar',
    questUnlock: 'Secret Quest: Win 5 Astra Matches in Celestial Temple',
    unlocked: true,
    dialogue1: 'Wah bete, moj kar di! 😂',
    dialogue2: 'Makhan khilao warna dice nahi ghumega! 🧈😋',
    variant: 'royal-curtain',
  },
  {
    id: 'tiny-chhota-bheem',
    name: 'Mini Laddoo Hero',
    hindiName: 'लड्डू वीर',
    icon: '🥊',
    species: 'Brave Champion',
    questUnlock: 'Milestone: Roll 50 Double-Sixes',
    unlocked: true,
    dialogue1: 'Bhai, thodi practice karke aana tha! 🤣',
    dialogue2: 'Ek laddoo do, sabki giti ghar bhejta hoon! 🍬💥',
    variant: 'dash-arrival',
  },
  {
    id: 'tiny-baby-dragon',
    name: 'Sparky Pygmy Drake',
    hindiName: 'अग्नि शिशु ड्रैगन',
    icon: '🐉',
    species: 'Cosmic Beast',
    questUnlock: 'Achievement: Eliminate 100 opponent tokens',
    unlocked: true,
    dialogue1: 'Hotel ka bill kaun bharega? 🏨💸',
    dialogue2: 'Meri choti aag se pura board roshan hai! 🔥',
    variant: 'pet-escort',
  },
  {
    id: 'tiny-golden-fairy',
    name: 'Pari Pari Golden Flutter',
    hindiName: 'स्वर्ण परी',
    icon: '🧚',
    species: 'Forest Spirit',
    questUnlock: 'Secret: Send 25 gifts in 8-seat live rooms',
    unlocked: true,
    dialogue1: 'Itna serious kyun ho? Relax karo! 🌸',
    dialogue2: 'Tension mat lo, agla roll 6 aayega! ✨🎲',
    variant: 'shadow-curtain',
  },
  {
    id: 'tiny-pocket-ninja',
    name: 'Chibi Shinobi Shadow',
    hindiName: 'छाया निंजा',
    icon: '🥷',
    species: 'Stealth Scout',
    questUnlock: 'Festival Event: Diwali Midnight Blitz winner',
    unlocked: false,
    dialogue1: 'Main kab aaya kisi ko pata nahi chala! 🤫',
    dialogue2: 'Goti gayi, pata bhi nahi chala! 💨',
    variant: 'magic-pocket',
  },
  {
    id: 'tiny-clumsy-panda',
    name: 'Babu Golu Clumsy Panda',
    hindiName: 'गोलू पांडा',
    icon: '🐼',
    species: 'Bamboo Nomad',
    questUnlock: 'Secret Quest: Spin Daily Wheel 20 times',
    unlocked: false,
    dialogue1: 'Arey gir gaya yaar, uthao mujhe! 😵‍💫',
    dialogue2: 'Khana kahan hai? Pehle lunch phir ludo! 🍜',
    variant: 'funny-fall',
  },
  {
    id: 'tiny-twin-elves',
    name: 'Cosmic Twin Pixies',
    hindiName: 'जुड़वा देवदूत',
    icon: '👥',
    species: 'Star Twin',
    questUnlock: 'Milestone: Reach Level 40 in Season Pass',
    unlocked: false,
    dialogue1: 'Hum do, hamare do roll! ✌️',
    dialogue2: 'Double attack, koi nahi bachega! 🌟🌟',
    variant: 'double-arrival',
  },
  {
    id: 'tiny-flying-garuda',
    name: 'Mini Feathered Garuda',
    hindiName: 'लघु गरुड़',
    icon: '🦅',
    species: 'Solar Messenger',
    questUnlock: 'Achievement: Land on 200 safe star tiles',
    unlocked: false,
    dialogue1: 'Aasman se gira, star par atka! ⭐🦅',
    dialogue2: 'Surya Dev ki kripa se vijay nishchit hai! ☀️',
    variant: 'emergency-delivery',
  },
  {
    id: 'tiny-secret-monk',
    name: 'Zen Buddha Whisperer',
    hindiName: 'शांत भिक्षु',
    icon: '🧘',
    species: 'Ascetic Sage',
    questUnlock: 'Secret Quest: Complete 1 match without using Astras',
    unlocked: false,
    dialogue1: 'Shanti rakhein, gusse se goti nahi kat ti! 🕊️',
    dialogue2: 'Paasa wahi jo kismat chahe! 🪷',
    variant: 'secret-arrival',
  },
  {
    id: 'tiny-grand-maharaja',
    name: 'Chhotu Royal Emperor',
    hindiName: 'छोटू महाराजा',
    icon: '👑',
    species: 'Royal Sovereign',
    questUnlock: 'Milestone: Win 200 ranked matches',
    unlocked: false,
    dialogue1: 'Humaare darbaar me sabka swagat hai! 🏰',
    dialogue2: 'Hukm suno: Sabhi ko 100 diamond inam! 💎',
    variant: 'miracle-finale',
  },
];

interface FluteCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTinyId: string;
  onSelectTiny: (tiny: TinyCharacter) => void;
  privacyMode: 'avatar-only' | 'approved-photo' | 'private';
  onChangePrivacyMode: (mode: 'avatar-only' | 'approved-photo' | 'private') => void;
  onTestMiracleArrival: (tiny: TinyCharacter) => void;
}

export const FluteCollectionModal: React.FC<FluteCollectionModalProps> = ({
  isOpen,
  onClose,
  selectedTinyId,
  onSelectTiny,
  privacyMode,
  onChangePrivacyMode,
  onTestMiracleArrival,
}) => {
  const [activeTab, setActiveTab] = useState<'collection' | 'variants' | 'privacy'>('collection');
  const [tinyList, setTinyList] = useState<TinyCharacter[]>(FLUTE_TINY_CHARACTERS);

  if (!isOpen) return null;

  const currentTiny = tinyList.find((t) => t.id === selectedTinyId) || tinyList[0];

  const VARIANTS: { id: MiracleArrivalVariant; title: string; desc: string }[] = [
    { id: 'royal-curtain', title: '1. Royal Curtain', desc: 'Regal velvet gold-fringed curtains part with spotlight' },
    { id: 'dash-arrival', title: '2. Dash Arrival', desc: 'High-velocity sprint with dust burst & instant halt' },
    { id: 'shadow-curtain', title: '3. Shadow Curtain', desc: 'Smoky purple haze parts to reveal target portrait' },
    { id: 'magic-pocket', title: '4. Magic Pocket', desc: 'Jumps out of an enchanted cosmic pouch' },
    { id: 'emergency-delivery', title: '5. Emergency Delivery', desc: 'Sirens & medical stretcher arrival gag' },
    { id: 'funny-fall', title: '6. Funny Fall', desc: 'Comical stumble & bounce before dramatic reveal' },
    { id: 'double-arrival', title: '7. Double Arrival', desc: 'Two twin messengers unveil portrait from both sides' },
    { id: 'pet-escort', title: '8. Pet Escort', desc: 'Rides atop player equipped pet for majestic presentation' },
    { id: 'secret-arrival', title: '9. Secret Arrival', desc: 'Invisible shimmer that suddenly materializes' },
    { id: 'miracle-finale', title: '10. Miracle Finale', desc: 'Grand celebratory confetti burst with golden drapery' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl overflow-hidden border-2 border-amber-400/60 rounded-3xl bg-gradient-to-b from-[#140b25] via-[#0c0617] to-black text-slate-100 shadow-[0_0_60px_rgba(245,158,11,0.3)] flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-purple-800/50 via-indigo-800/40 to-amber-700/40 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-2xl shadow-lg border border-amber-300">
              🪈
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-300 font-cinzel">
                  Flute Tiny Collection
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/30 text-purple-200 font-bold border border-purple-400/40">
                  Item 20
                </span>
              </div>
              <p className="text-xs text-slate-300">
                30–50 Quest-Earned Tiny Characters & 10 Miracle Arrival Theatre Variants
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-4 py-2 bg-slate-900/80 border-b border-white/10 flex gap-2 overflow-x-auto">
          {[
            { id: 'collection', label: 'Tiny Characters (30+)', icon: '🧚' },
            { id: 'variants', label: '10 Arrival Variants', icon: '🎭' },
            { id: 'privacy', label: 'Privacy & Settings', icon: '🔒' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                setActiveTab(tab.id as typeof activeTab);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 font-black shadow-md'
                  : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: COLLECTION */}
          {activeTab === 'collection' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-amber-950/30 border border-amber-500/30 text-xs text-amber-200 flex items-center justify-between">
                <span>
                  🌟 <strong>Quest Rule:</strong> Tiny characters cannot be bought with diamonds. Earned strictly via secret quests & festival achievements!
                </span>
                <button
                  onClick={() => {
                    onTestMiracleArrival(currentTiny);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition cursor-pointer shrink-0 ml-2"
                >
                  Test Miracle Arrival 🎭
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {tinyList.map((tiny) => {
                  const isSelected = selectedTinyId === tiny.id;

                  return (
                    <div
                      key={tiny.id}
                      onClick={() => {
                        sound.playClick();
                        if (tiny.unlocked) onSelectTiny(tiny);
                      }}
                      className={`p-3.5 rounded-2xl border transition flex flex-col justify-between ${
                        isSelected
                          ? 'bg-gradient-to-br from-purple-950 via-slate-900 to-slate-950 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                          : tiny.unlocked
                          ? 'bg-slate-900/70 border-slate-800 hover:border-purple-500 cursor-pointer'
                          : 'bg-slate-950/60 border-slate-800/60 opacity-65'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-black uppercase tracking-wider text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded-full border border-purple-400/30">
                            {tiny.species}
                          </span>
                          {isSelected && (
                            <span className="text-[10px] font-black text-emerald-400 flex items-center gap-1">
                              <Check size={12} /> EQUIPPED
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500/20 to-purple-600/30 border border-amber-400/40 flex items-center justify-center text-3xl shadow-inner">
                            {tiny.icon}
                          </div>
                          <div>
                            <h4 className="text-sm font-black text-white">{tiny.name}</h4>
                            <p className="text-xs text-amber-300 font-bold">{tiny.hindiName}</p>
                            <p className="text-[10px] text-slate-400 mt-0.5">Style: {tiny.variant}</p>
                          </div>
                        </div>

                        <div className="mt-3 p-2 rounded-xl bg-black/50 border border-white/5 text-[11px] space-y-1">
                          <p className="text-slate-300">
                            💬 <strong>Line 1:</strong> "{tiny.dialogue1}"
                          </p>
                          <p className="text-slate-400">
                            💬 <strong>Line 2:</strong> "{tiny.dialogue2}"
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between">
                        {tiny.unlocked ? (
                          <span className="text-[10px] text-emerald-400 font-bold">✓ Unlocked via Achievement</span>
                        ) : (
                          <span className="text-[10px] text-amber-400 font-medium flex items-center gap-1">
                            <Lock size={11} /> {tiny.questUnlock}
                          </span>
                        )}

                        {tiny.unlocked && !isSelected && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              sound.playClick();
                              onSelectTiny(tiny);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black"
                          >
                            Equip
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: 10 ARRIVAL VARIANTS */}
          {activeTab === 'variants' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                Choose the theatrical entrance mechanic used by your tiny character during Miracle Arrival:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {VARIANTS.map((v) => {
                  const isCurrent = currentTiny.variant === v.id;
                  return (
                    <div
                      key={v.id}
                      onClick={() => {
                        sound.playClick();
                        setTinyList((prev) =>
                          prev.map((t) => (t.id === currentTiny.id ? { ...t, variant: v.id } : t))
                        );
                        confetti({ particleCount: 25, spread: 35 });
                      }}
                      className={`p-3 rounded-2xl border transition cursor-pointer ${
                        isCurrent
                          ? 'bg-amber-950/60 border-amber-400 shadow-md'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-xs font-black text-white">{v.title}</h4>
                        {isCurrent && <Check size={14} className="text-amber-400" />}
                      </div>
                      <p className="text-[11px] text-slate-400">{v.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: PRIVACY & SETTINGS */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 space-y-3">
                <h4 className="text-sm font-black text-amber-300 flex items-center gap-2">
                  <ShieldCheck size={18} />
                  <span>Miracle Arrival Privacy Mode</span>
                </h4>
                <p className="text-xs text-slate-300">
                  Select which photo or avatar reveals when your tiny character opens the curtain on a target seat:
                </p>

                <div className="space-y-2 pt-1">
                  {[
                    {
                      id: 'avatar-only' as const,
                      label: 'Game Avatar Only',
                      desc: 'Reveals in-game animated avatar or character icon (Default).',
                    },
                    {
                      id: 'approved-photo' as const,
                      label: 'Approved Profile Photo',
                      desc: 'Reveals verified uploaded photo from player profile.',
                    },
                    {
                      id: 'private' as const,
                      label: 'Private Incognito Mode',
                      desc: 'Keeps avatar veiled behind a sacred golden mask.',
                    },
                  ].map((mode) => (
                    <div
                      key={mode.id}
                      onClick={() => {
                        sound.playClick();
                        onChangePrivacyMode(mode.id);
                      }}
                      className={`p-3 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                        privacyMode === mode.id
                          ? 'bg-purple-950/70 border-purple-400'
                          : 'bg-black/40 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div>
                        <p className="text-xs font-black text-white">{mode.label}</p>
                        <p className="text-[10px] text-slate-400">{mode.desc}</p>
                      </div>
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          privacyMode === mode.id ? 'border-amber-400 bg-amber-400' : 'border-slate-600'
                        }`}
                      >
                        {privacyMode === mode.id && <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
