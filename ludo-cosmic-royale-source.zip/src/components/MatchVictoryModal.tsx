import React, { useEffect, useState } from 'react';
import { Player } from '../types/game';
import {
  Crown,
  Trophy,
  Coins,
  Sparkles,
  ArrowRight,
  Share2,
  RotateCcw,
  Home,
  Zap,
  Shield,
  Flame,
  Check,
  FastForward,
  Star,
  Award,
  X,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { sound } from '../utils/soundEngine';
import {
  RealisticTrophyIcon,
  RealisticCrownIcon,
  RealisticMedalIcon,
  RealisticGiftIcon,
  RealisticCoinIcon,
  RealisticDiamondIcon,
} from './RealIcons';

export interface MatchVictoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  winner: Player | null;
  players: Player[];
  onPlayAgain: () => void;
  onReturnToLobby: () => void;
  onClaimRewards: (coins: number, diamonds: number) => void;
  winStreak?: number;
  onStreakChange?: (streak: number) => void;
}

export const MatchVictoryModal: React.FC<MatchVictoryModalProps> = ({
  isOpen,
  onClose,
  winner,
  players,
  onPlayAgain,
  onReturnToLobby,
  onClaimRewards,
  winStreak = 3,
  onStreakChange,
}) => {
  const [claimed, setClaimed] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);
  // Staged entrance animation: 0 = starting lights, 1 = 3rd place, 2 = 2nd place, 3 = 1st place champion, 4 = full reveal
  const [entranceStage, setEntranceStage] = useState<number>(0);
  const [showFullDetails, setShowFullDetails] = useState<boolean>(false);

  // Active win streak tracking on podium (defaults to prop or winner.winStreak or 3)
  const [activeStreak, setActiveStreak] = useState<number>(
    typeof winStreak === 'number' ? winStreak : (winner?.winStreak ?? 3)
  );

  // Sync activeStreak when props change
  useEffect(() => {
    if (typeof winStreak === 'number') {
      setActiveStreak(winStreak);
    } else if (winner?.winStreak !== undefined) {
      setActiveStreak(winner.winStreak);
    }
  }, [winStreak, winner, isOpen]);

  // =========================================================================
  // DEDICATED 3-GAME WIN STREAK CANVAS-CONFETTI VISUAL EFFECT
  // TRIGGERS ONLY WHEN A PLAYER REACHES A 3-GAME WIN STREAK ON THE PODIUM
  // =========================================================================
  const triggerThreeWinStreakConfettiEffect = () => {
    // Strict requirement check: triggers ONLY when a player reaches a 3-game win streak!
    if (activeStreak !== 3) return;

    sound.playTrishulThunder();
    sound.playGrandVictory();

    // Wave 1: Win #1 Left Cannon Blast (Fiery Ruby & Sunfire Gold shockwave)
    confetti({
      particleCount: 85,
      angle: 55,
      spread: 60,
      origin: { x: 0.12, y: 0.72 },
      startVelocity: 48,
      scalar: 1.25,
      shapes: ['star', 'circle'],
      colors: ['#ef4444', '#f59e0b', '#fbbf24', '#ffffff'],
      zIndex: 9999,
    });

    // Wave 2: Win #2 Right Cannon Blast (Electric Cyan & Solar Gold shockwave at 320ms)
    setTimeout(() => {
      confetti({
        particleCount: 85,
        angle: 125,
        spread: 60,
        origin: { x: 0.88, y: 0.72 },
        startVelocity: 48,
        scalar: 1.25,
        shapes: ['star', 'circle'],
        colors: ['#06b6d4', '#f59e0b', '#38bdf8', '#fbbf24'],
        zIndex: 9999,
      });
    }, 320);

    // Wave 3: Win #3 TRIPLE CROWN APEX ERUPTION (Central Volcano directly above Gold Podium at 680ms)
    setTimeout(() => {
      sound.playFanfare();

      // Huge central star volcano
      confetti({
        particleCount: 160,
        angle: 90,
        spread: 110,
        origin: { x: 0.5, y: 0.52 },
        startVelocity: 56,
        scalar: 1.45,
        shapes: ['star'],
        colors: ['#ffd700', '#f59e0b', '#ef4444', '#ec4899', '#ffffff'],
        zIndex: 9999,
      });

      // Supporting dual side bursts creating a triumphal arch
      confetti({
        particleCount: 55,
        angle: 70,
        spread: 48,
        origin: { x: 0.22, y: 0.58 },
        startVelocity: 44,
        colors: ['#fbbf24', '#f97316', '#dc2626'],
        zIndex: 9999,
      });
      confetti({
        particleCount: 55,
        angle: 110,
        spread: 48,
        origin: { x: 0.78, y: 0.58 },
        colors: ['#fbbf24', '#f97316', '#dc2626'],
        zIndex: 9999,
      });
    }, 680);

    // Wave 4: 2.5-second continuous rain of fiery stars and golden sparks falling across the podium
    const showerEnd = Date.now() + 2500;
    const showerInterval = setInterval(() => {
      const remaining = showerEnd - Date.now();
      if (remaining <= 0) {
        clearInterval(showerInterval);
        return;
      }
      confetti({
        particleCount: 4,
        angle: 90,
        spread: 90,
        startVelocity: 26,
        gravity: 0.75,
        origin: { x: Math.random() * 0.8 + 0.1, y: 0.08 },
        shapes: ['star', 'circle'],
        colors: ['#ffd700', '#f59e0b', '#ef4444', '#fef08a'],
        ticks: 220,
        scalar: 1.15,
        zIndex: 9999,
      });
    }, 120);
  };

  const handleSetStreak = (streak: number) => {
    sound.playClick();
    setActiveStreak(streak);
    if (onStreakChange) {
      onStreakChange(streak);
    }
    // Triggers ONLY when reaching a 3-game win streak!
    if (streak === 3) {
      triggerThreeWinStreakConfettiEffect();
    }
  };

  // Trigger staged entrance sequence & fireworks on open
  useEffect(() => {
    if (!isOpen) {
      setEntranceStage(0);
      setShowFullDetails(false);
      return;
    }

    setClaimed(false);
    setCopiedShare(false);
    setEntranceStage(0);
    setShowFullDetails(false);

    // Initial spotlight & stage prep sound
    sound.playSafeCell();

    // Stage 1 (600ms): 3rd Place arrives on Bronze pedestal
    const timer1 = setTimeout(() => {
      setEntranceStage(1);
      sound.playTokenHop(1);
      confetti({
        particleCount: 25,
        angle: 120,
        spread: 40,
        origin: { x: 0.75, y: 0.6 },
        colors: ['#cd7f32', '#d97706', '#b45309'],
      });
    }, 600);

    // Stage 2 (1400ms): 2nd Place arrives on Silver pedestal
    const timer2 = setTimeout(() => {
      setEntranceStage(2);
      sound.playTokenHop(2);
      confetti({
        particleCount: 35,
        angle: 60,
        spread: 45,
        origin: { x: 0.25, y: 0.55 },
        colors: ['#e2e8f0', '#94a3b8', '#38bdf8'],
      });
    }, 1400);

    // Stage 3 (2200ms): 1st Place Champion arrives on Gold pedestal with grand fireworks
    const timer3 = setTimeout(() => {
      setEntranceStage(3);
      sound.playGrandVictory();

      // Golden fireworks blast
      confetti({
        particleCount: 70,
        angle: 90,
        spread: 70,
        origin: { x: 0.5, y: 0.45 },
        colors: ['#f59e0b', '#fbbf24', '#fef08a', '#e11d48'],
      });

      // Special 3-Game Win Streak Confetti Effect TRIGGERS ONLY WHEN A PLAYER REACHES A 3-GAME WIN STREAK
      if (activeStreak === 3) {
        triggerThreeWinStreakConfettiEffect();
      }
    }, 2200);

    // Stage 4 (3000ms): Full celebration, bounty and controls reveal
    const timer4 = setTimeout(() => {
      setEntranceStage(4);
      setShowFullDetails(true);

      // Multi-angle cascading stadium fireworks
      const end = Date.now() + 1500;
      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#f59e0b', '#ec4899', '#8b5cf6', '#10b981'],
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#f59e0b', '#ec4899', '#8b5cf6', '#3b82f6'],
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };
      frame();
    }, 3000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [isOpen, activeStreak]);

  if (!isOpen) return null;

  // Determine rankings based on finished tokens, then token step counts
  const rankedPlayers = [...players].sort((a, b) => {
    const aFinished = a.tokens.filter((t) => t.position === 999).length;
    const bFinished = b.tokens.filter((t) => t.position === 999).length;
    if (bFinished !== aFinished) return bFinished - aFinished;
    const aSteps = a.tokens.reduce((acc, t) => acc + (t.stepCount || 0), 0);
    const bSteps = b.tokens.reduce((acc, t) => acc + (t.stepCount || 0), 0);
    return bSteps - aSteps;
  });

  const activeWinner = winner || rankedPlayers[0];
  const isHumanWinner = activeWinner ? !activeWinner.isBot : true;
  const isThreeStreak = activeStreak === 3;
  const streakMultiplier = isThreeStreak ? 3 : 1;

  // Podiums: 2nd place (left), 1st place (center), 3rd place (right)
  const firstPlayer = rankedPlayers[0];
  const secondPlayer = rankedPlayers[1] || rankedPlayers[0];
  const thirdPlayer = rankedPlayers[2] || (rankedPlayers.length > 1 ? rankedPlayers[1] : rankedPlayers[0]);
  const fourthPlayer = rankedPlayers[3] || null;

  // Reward calculations (tripled on 3-game win streak!)
  const coinPrize = (isHumanWinner ? 1250000 : 250000) * streakMultiplier;
  const diamondPrize = (isHumanWinner ? 250 : 50) * streakMultiplier;
  const expGained = (isHumanWinner ? 850 : 300) * streakMultiplier;

  const handleClaim = () => {
    if (claimed) return;
    setClaimed(true);
    sound.playGiftFanfare();
    onClaimRewards(coinPrize, diamondPrize);
    confetti({ particleCount: 70, spread: 80 });
  };

  const handleShare = () => {
    sound.playClick();
    const shareText = `👑 Ludo Supreme Victory! ${activeWinner?.name} clinched 1st Place with 4 Tokens Finished & +${coinPrize.toLocaleString()} Coins won! 🎲✨`;
    navigator.clipboard?.writeText?.(shareText);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  const handleSkipAnimation = () => {
    sound.playSafeCell();
    setEntranceStage(4);
    setShowFullDetails(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/92 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      {/* Dynamic Animated Spotlight Cones */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Left Spotlight Beam pointing to center/left podium */}
        <div
          className={`absolute -top-10 left-10 w-44 sm:w-72 h-[120%] bg-gradient-to-b from-amber-300/35 via-yellow-500/15 to-transparent blur-2xl transform -rotate-25 origin-top transition-opacity duration-1000 ${
            entranceStage >= 2 ? 'opacity-100' : 'opacity-20'
          }`}
        />

        {/* Right Spotlight Beam pointing to center/right podium */}
        <div
          className={`absolute -top-10 right-10 w-44 sm:w-72 h-[120%] bg-gradient-to-b from-cyan-300/35 via-blue-500/15 to-transparent blur-2xl transform rotate-25 origin-top transition-opacity duration-1000 ${
            entranceStage >= 1 ? 'opacity-100' : 'opacity-20'
          }`}
        />

        {/* Center Champion Overhead Spotlight */}
        <div
          className={`absolute -top-10 left-1/2 -translate-x-1/2 w-60 sm:w-96 h-[110%] bg-gradient-to-b from-amber-200/50 via-yellow-400/20 to-transparent blur-xl transition-all duration-700 ${
            entranceStage >= 3 ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
          }`}
        />

        {/* Ground Radial Glow */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-t from-amber-500/15 via-purple-900/25 to-transparent rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Main Modal Card */}
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-[#140b26] to-[#07030e] border-2 border-amber-400/70 rounded-3xl p-4 sm:p-6 shadow-[0_0_70px_rgba(245,158,11,0.45)] text-white flex flex-col items-center my-auto z-10 overflow-hidden">
        {/* Top-Right Dedicated 'X' Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 z-50 p-2 sm:p-2.5 rounded-full bg-slate-900/90 hover:bg-red-950/90 border border-amber-400/70 hover:border-red-400 text-amber-300 hover:text-white transition-all shadow-lg active:scale-95 flex items-center justify-center cursor-pointer group"
          title="Close Victory Ceremony"
          aria-label="Close Screen"
        >
          <X size={18} className="stroke-[2.5]" />
        </button>

        {/* Skip Animation Button (Top Right next to Close) */}
        {!showFullDetails && (
          <button
            onClick={handleSkipAnimation}
            className="absolute top-3 right-12 sm:top-4 sm:right-16 z-40 flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white text-[11px] font-bold border border-white/10 transition backdrop-blur-sm"
            title="Skip to final results"
          >
            <span>Skip</span>
            <FastForward size={12} />
          </button>
        )}

        {/* Top Trophy Banner with Shimmer */}
        <div className="relative -mt-9 mb-1 flex flex-col items-center">
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 p-1 shadow-[0_0_35px_rgba(245,158,11,0.85)] animate-bounce flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-black/85 flex items-center justify-center">
              <RealisticTrophyIcon size={52} className="animate-pulse" />
            </div>
            <div className="absolute -top-2.5 -right-2 bg-gradient-to-r from-red-600 to-amber-500 text-[9px] font-black uppercase px-2 py-0.5 rounded-full border border-amber-300 shadow-md">
              1st Rank
            </div>
          </div>
        </div>

        {/* Ceremony Header */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-amber-400">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spin" />
            <span>Grand Victory Podium Ceremony</span>
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 animate-spin" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500 tracking-wide mt-0.5 font-cinzel">
            {activeWinner?.name}
          </h2>
          <p className="text-[11px] text-amber-200/80 font-medium">
            {isHumanWinner
              ? '👑 Magnificent Triumph! You conquered the Cosmic Arena!'
              : '⚔️ Fierce arena contest! Top champions claim the podium!'}
          </p>
        </div>

        {/* Win Streak Indicator & Interactive Podium Controls */}
        <div className="w-full mt-3 px-3 py-2 rounded-2xl bg-black/60 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-2 shadow-inner">
          <div className="flex items-center gap-2">
            <div
              className={`p-1.5 rounded-xl border transition-all ${
                isThreeStreak
                  ? 'bg-gradient-to-br from-red-600 to-amber-500 border-amber-300 text-white shadow-[0_0_20px_rgba(239,68,68,0.9)] animate-pulse'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              <Flame size={18} className={isThreeStreak ? 'animate-bounce text-yellow-200 fill-amber-300' : ''} />
            </div>
            <div className="text-left">
              <div className="text-[11px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                <span>Podium Win Streak:</span>
                <span
                  className={`px-2 py-0.2 rounded-full text-[10px] font-black ${
                    isThreeStreak
                      ? 'bg-red-600 text-white border border-amber-300 shadow-[0_0_10px_rgba(239,68,68,0.8)]'
                      : 'bg-slate-800 text-slate-300 border border-white/10'
                  }`}
                >
                  {activeStreak} {activeStreak === 1 ? 'Win' : 'Wins'} {isThreeStreak && '🔥 ON FIRE!'}
                </span>
              </div>
              <p className="text-[9px] text-slate-400">
                {isThreeStreak
                  ? '🔥 3-Game Win Streak reached! Special canvas-confetti visual effect unlocked & 3x Rewards active!'
                  : 'Special canvas-confetti visual effect triggers exclusively when reaching a 3-game win streak.'}
              </p>
            </div>
          </div>

          {/* Streak Level Switcher for Testing & Verification */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-white/10">
            <span className="text-[9px] font-bold text-slate-400 px-1">Streak:</span>
            {[1, 2, 3, 4].map((s) => (
              <button
                key={s}
                onClick={() => handleSetStreak(s)}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-black transition active:scale-95 ${
                  activeStreak === s
                    ? s === 3
                      ? 'bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-white border border-amber-300 shadow-[0_0_15px_rgba(239,68,68,0.9)]'
                      : 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
                title={s === 3 ? 'Trigger 3-game win streak confetti visual effect' : `Set win streak to ${s}`}
              >
                {s === 3 ? '🔥 3' : s}
              </button>
            ))}
            {isThreeStreak && (
              <button
                onClick={triggerThreeWinStreakConfettiEffect}
                className="ml-1 px-2 py-0.5 rounded-lg text-[9px] font-black uppercase bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white border border-amber-300 shadow transition active:scale-95 flex items-center gap-1"
                title="Re-trigger 3-game win streak canvas-confetti effect"
              >
                <Sparkles size={10} />
                <span>Trigger</span>
              </button>
            )}
          </div>
        </div>

        {/* ========================================================
            CINEMATIC 3D TIERED PODIUM (Top 3 Players)
            Layout: 2nd (Silver, Left) | 1st (Gold, Center) | 3rd (Bronze, Right)
           ======================================================== */}
        <div
          className="w-full mt-4 pt-4 pb-2 flex items-end justify-center gap-2 sm:gap-3"
          style={{ perspective: '1000px' }}
        >
          {/* ---------------- 2ND PLACE (SILVER, LEFT) ---------------- */}
          {secondPlayer && (
            <div
              className={`flex-1 flex flex-col items-center transition-all duration-700 ease-out transform ${
                entranceStage >= 2
                  ? 'opacity-100 translate-y-0 scale-100'
                  : 'opacity-0 translate-y-12 scale-75'
              }`}
            >
              {/* Avatar Leaping In */}
              <div className="relative mb-2 flex flex-col items-center">
                {/* Silver Spotlight Pool Under Avatar */}
                <div className="absolute -bottom-1 w-12 h-3 bg-cyan-400/30 rounded-full blur-sm" />

                <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-slate-300 bg-slate-900 shadow-[0_0_20px_rgba(148,163,184,0.6)] overflow-hidden flex items-center justify-center">
                  {secondPlayer.avatar ? (
                    <img src={secondPlayer.avatar} alt={secondPlayer.name} className="w-full h-full object-cover" />
                  ) : (
                    <RealisticMedalIcon rank={2} size={36} />
                  )}
                </div>
                <span className="absolute -top-2 px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-950 text-[9px] font-black border border-white shadow">
                  #2
                </span>
              </div>

              {/* Player Name */}
              <p className="text-[11px] font-bold text-slate-200 truncate max-w-[80px] text-center">
                {secondPlayer.name}
              </p>
              <p className="text-[9px] text-slate-400 font-semibold mb-1">
                {secondPlayer.tokens.filter((t) => t.position === 999).length}/4 Home
              </p>

              {/* 3D Tiered Pedestal (Medium Height: Silver) */}
              <div className="w-full h-24 sm:h-28 rounded-t-2xl bg-gradient-to-b from-slate-300 via-slate-500 to-slate-800 border-t-2 border-x-2 border-slate-200 shadow-[0_15px_30px_rgba(0,0,0,0.8),inset_0_2px_10px_rgba(255,255,255,0.4)] flex flex-col items-center justify-between p-2 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-transparent to-white/10 pointer-events-none" />
                <span className="text-xl sm:text-2xl font-black text-slate-900 font-cinzel drop-shadow-sm">
                  2
                </span>
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-slate-950 bg-white/70 px-2 py-0.5 rounded-full shadow-sm">
                  Silver
                </span>
              </div>
            </div>
          )}

          {/* ---------------- 1ST PLACE (GOLD, CENTER - HIGHEST) ---------------- */}
          {firstPlayer && (
            <div
              className={`flex-1 flex flex-col items-center z-10 transition-all duration-700 ease-out transform ${
                entranceStage >= 3
                  ? 'opacity-100 translate-y-0 scale-105'
                  : 'opacity-0 -translate-y-16 scale-125'
              }`}
            >
              {/* Crown & Avatar Dropping In */}
              <div className="relative mb-2 flex flex-col items-center">
                {/* 3-Game Streak Flaming Badge */}
                {isThreeStreak && (
                  <div className="animate-pulse mb-1 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-[9px] font-black uppercase text-white tracking-widest border border-amber-300 shadow-[0_0_20px_rgba(239,68,68,0.9)]">
                    <Flame size={12} className="text-yellow-200 fill-amber-300 animate-bounce" />
                    <span>3-GAME STREAK!</span>
                    <Flame size={12} className="text-yellow-200 fill-amber-300 animate-bounce" />
                  </div>
                )}

                {/* Golden Animated Floating Crown */}
                <div className="animate-bounce -mb-1 filter drop-shadow-[0_0_10px_#f59e0b]">
                  <RealisticCrownIcon size={34} />
                </div>

                {/* Golden Spotlight Pool Under Avatar */}
                <div className="absolute -bottom-1 w-16 h-4 bg-amber-400/50 rounded-full blur-md animate-pulse" />

                <div
                  className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full border-3 ${
                    isThreeStreak
                      ? 'border-red-500 ring-4 ring-amber-400/80 shadow-[0_0_40px_rgba(239,68,68,0.9),0_0_25px_rgba(245,158,11,0.9)]'
                      : 'border-amber-300 shadow-[0_0_30px_rgba(245,158,11,0.9)]'
                  } bg-gradient-to-b from-amber-400 to-yellow-600 overflow-hidden flex items-center justify-center p-0.5`}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-black/50 flex items-center justify-center">
                    {firstPlayer.avatar ? (
                      <img src={firstPlayer.avatar} alt={firstPlayer.name} className="w-full h-full object-cover" />
                    ) : (
                      <RealisticMedalIcon rank={1} size={38} />
                    )}
                  </div>
                </div>
                <span className="absolute -bottom-1 px-2 py-0.2 rounded-full bg-gradient-to-r from-red-600 to-amber-500 text-white text-[9px] font-black border border-amber-300 shadow">
                  CHAMPION
                </span>
              </div>

              {/* Player Name */}
              <p className="text-xs font-black text-amber-200 truncate max-w-[90px] text-center mt-0.5 drop-shadow">
                {firstPlayer.name}
              </p>
              <p className="text-[10px] text-amber-300 font-bold mb-1">
                {firstPlayer.tokens.filter((t) => t.position === 999).length}/4 Home
              </p>

              {/* 3D Tiered Pedestal (Highest Height: Gold) */}
              <div
                className={`w-full h-32 sm:h-36 rounded-t-2xl bg-gradient-to-b from-amber-300 via-yellow-500 to-amber-800 border-t-2 border-x-2 ${
                  isThreeStreak
                    ? 'border-red-400 ring-2 ring-red-500/50 shadow-[0_20px_45px_rgba(239,68,68,0.7),inset_0_3px_15px_rgba(255,255,255,0.7)]'
                    : 'border-yellow-200 shadow-[0_20px_40px_rgba(0,0,0,0.9),inset_0_3px_12px_rgba(255,255,255,0.6)]'
                } flex flex-col items-center justify-between p-2 relative overflow-hidden group`}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-transparent to-white/10 pointer-events-none" />
                <div className="absolute top-1 text-xs text-yellow-200 animate-pulse">✨</div>
                <span className="text-2xl sm:text-3xl font-black text-slate-950 font-cinzel drop-shadow-md">
                  1
                </span>
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-950 bg-yellow-200/90 px-2.5 py-0.5 rounded-full shadow">
                  Winner
                </span>
              </div>
            </div>
          )}

          {/* ---------------- 3RD PLACE (BRONZE, RIGHT) ---------------- */}
          {thirdPlayer && (
            <div
              className={`flex-1 flex flex-col items-center transition-all duration-700 ease-out transform ${
                entranceStage >= 1
                  ? 'opacity-100 translate-y-0 scale-100'
                  : 'opacity-0 translate-y-12 scale-75'
              }`}
            >
              {/* Avatar Leaping In */}
              <div className="relative mb-2 flex flex-col items-center">
                {/* Bronze Spotlight Pool Under Avatar */}
                <div className="absolute -bottom-1 w-12 h-3 bg-amber-700/30 rounded-full blur-sm" />

                <div className="relative w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-amber-600 bg-slate-900 shadow-[0_0_20px_rgba(180,83,9,0.6)] overflow-hidden flex items-center justify-center">
                  {thirdPlayer.avatar ? (
                    <img src={thirdPlayer.avatar} alt={thirdPlayer.name} className="w-full h-full object-cover" />
                  ) : (
                    <RealisticMedalIcon rank={3} size={34} />
                  )}
                </div>
                <span className="absolute -top-2 px-1.5 py-0.2 rounded-full bg-amber-700 text-white text-[9px] font-black border border-amber-500 shadow">
                  #3
                </span>
              </div>

              {/* Player Name */}
              <p className="text-[11px] font-bold text-slate-200 truncate max-w-[80px] text-center">
                {thirdPlayer.name}
              </p>
              <p className="text-[9px] text-amber-400 font-semibold mb-1">
                {thirdPlayer.tokens.filter((t) => t.position === 999).length}/4 Home
              </p>

              {/* 3D Tiered Pedestal (Lowest Height: Bronze) */}
              <div className="w-full h-18 sm:h-22 rounded-t-2xl bg-gradient-to-b from-amber-600 via-amber-800 to-stone-900 border-t-2 border-x-2 border-amber-500 shadow-[0_15px_30px_rgba(0,0,0,0.8),inset_0_2px_8px_rgba(255,255,255,0.3)] flex flex-col items-center justify-between p-2 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-r from-white/15 via-transparent to-white/5 pointer-events-none" />
                <span className="text-xl sm:text-2xl font-black text-amber-200 font-cinzel drop-shadow-sm">
                  3
                </span>
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider text-white bg-amber-950/80 px-2 py-0.5 rounded-full shadow-sm">
                  Bronze
                </span>
              </div>
            </div>
          )}
        </div>

        {/* 4th Place Honorable Mention (if 4 players) */}
        {fourthPlayer && (
          <div
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl bg-slate-900/60 border border-white/5 text-[11px] text-slate-300 mt-2 transition-opacity duration-500 ${
              showFullDetails ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-bold">4th Place:</span>
              <div className="w-5 h-5 rounded-full overflow-hidden bg-slate-800 border border-white/10">
                {fourthPlayer.avatar ? (
                  <img src={fourthPlayer.avatar} alt={fourthPlayer.name} className="w-full h-full object-cover" />
                ) : (
                  <span>🔵</span>
                )}
              </div>
              <span className="font-semibold text-white">{fourthPlayer.name}</span>
            </div>
            <span className="text-slate-400 font-mono">
              {fourthPlayer.tokens.filter((t) => t.position === 999).length}/4 Home Finished
            </span>
          </div>
        )}

        {/* ========================================================
            VICTORY REWARDS & STATS BREAKDOWN (Revealed smoothly)
           ======================================================== */}
        {showFullDetails && (
          <div className="w-full space-y-3 mt-3 animate-fade-in">
            {/* Bounty Rewards Chest */}
            <div className="w-full bg-gradient-to-r from-amber-950/70 via-purple-950/70 to-amber-950/70 border border-amber-500/50 rounded-2xl p-3 flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center p-1 shadow">
                  <RealisticGiftIcon size={34} />
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1.5">
                    <span>Match Prize Bounty</span>
                    {isThreeStreak && (
                      <span className="px-1.5 py-0.2 rounded-full bg-gradient-to-r from-red-600 to-amber-500 text-white text-[9px] font-black border border-amber-300 animate-pulse">
                        🔥 3X STREAK BONUS
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2.5 text-xs sm:text-sm font-black">
                    <span className="flex items-center gap-1 text-yellow-300">
                      <RealisticCoinIcon size={18} /> +{coinPrize.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1 text-cyan-300">
                      <RealisticDiamondIcon size={18} /> +{diamondPrize}
                    </span>
                    <span className="text-[10px] text-purple-300 font-bold bg-purple-950/80 px-1.5 py-0.5 rounded border border-purple-500/40">
                      +{expGained} EXP
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleClaim}
                disabled={claimed}
                className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition shadow-lg ${
                  claimed
                    ? 'bg-emerald-600/80 text-white cursor-default flex items-center gap-1'
                    : 'bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 active:scale-95 shadow-[0_0_15px_rgba(245,158,11,0.6)] animate-pulse'
                }`}
              >
                {claimed ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Claimed
                  </>
                ) : (
                  'Claim!'
                )}
              </button>
            </div>

            {/* Battle Stats Breakdown */}
            <div className="w-full grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-black/50 border border-amber-500/20 rounded-xl p-2 flex flex-col items-center">
                <span className="text-amber-400 text-[11px]">⚔️ Kills</span>
                <span className="text-sm font-black text-white mt-0.5">3 Strikes</span>
              </div>
              <div className="bg-black/50 border border-amber-500/20 rounded-xl p-2 flex flex-col items-center">
                <span className="text-yellow-400 text-[11px]">🎲 Sixes</span>
                <span className="text-sm font-black text-white mt-0.5">7 Rolled</span>
              </div>
              <div className="bg-black/50 border border-amber-500/20 rounded-xl p-2 flex flex-col items-center">
                <span className="text-purple-400 text-[11px]">🔱 Astras</span>
                <span className="text-sm font-black text-white mt-0.5">2 Unleashed</span>
              </div>
            </div>

            {/* Action Controls */}
            <div className="w-full flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  sound.playClick();
                  onPlayAgain();
                  onClose();
                }}
                className="flex-1 py-2.5 sm:py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-[0_0_20px_rgba(16,185,129,0.5)] active:scale-95 transition"
              >
                <RotateCcw className="w-4 h-4" /> Rematch
              </button>

              <button
                onClick={handleShare}
                className="px-3.5 py-2.5 sm:py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700/90 border border-slate-600 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 shadow active:scale-95 transition"
                title="Share victory"
              >
                {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span className="hidden sm:inline">{copiedShare ? 'Copied!' : 'Share'}</span>
              </button>

              <button
                onClick={() => {
                  sound.playClick();
                  onReturnToLobby();
                  onClose();
                }}
                className="flex-1 py-2.5 sm:py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-amber-500/30 text-amber-200 font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-1.5 shadow active:scale-95 transition"
              >
                <Home className="w-4 h-4" /> Lobby
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
