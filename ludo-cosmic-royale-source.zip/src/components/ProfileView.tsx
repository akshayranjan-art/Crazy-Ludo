import React, { useState } from 'react';
import {
  Crown,
  Sparkles,
  Trophy,
  Shield,
  Award,
  Zap,
  Check,
  Flame,
  ArrowUpRight,
  Heart,
  Palette,
  MessageCircle,
  Users,
  Star,
  Copy,
  Mail,
  KeyRound,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { AVATAR_FRAMES, ASTRA_ITEMS, RARE_PETS, ASSETS } from '../data/gameConstants';
import { FrameStyleId } from '../types/game';
import { PlayerUser, OWNER_USER } from '../utils/authService';

interface ProfileViewProps {
  userDiamonds: number;
  userCoins: number;
  userStars: number;
  equippedFrame: FrameStyleId;
  onEquipFrame: (frameId: FrameStyleId) => void;
  equippedAstraId: string;
  equippedPetId: string;
  onOpenModal: (modal: any) => void;
  currentUser?: PlayerUser;
  onOpenAuthModal?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userDiamonds,
  userCoins,
  userStars,
  equippedFrame,
  onEquipFrame,
  equippedAstraId,
  equippedPetId,
  onOpenModal,
  currentUser = OWNER_USER,
  onOpenAuthModal,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'frames'>('profile');
  const [copiedId, setCopiedId] = useState(false);

  const activeAstra = ASTRA_ITEMS.find((a) => a.id === equippedAstraId) || ASTRA_ITEMS[0];
  const activePet = RARE_PETS.find((p) => p.id === equippedPetId) || RARE_PETS[0];

  const handleCopyId = () => {
    navigator.clipboard?.writeText(currentUser.id);
    setCopiedId(true);
    sound.playSafeCell();
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-4 pb-24 animate-fade-in px-3">
      {/* 1. HEADER */}
      <div className="text-center pt-1 pb-1">
        <div className="w-36 h-12 mx-auto drop-shadow-lg">
          <img src={ASSETS.logo} alt="LUDO PLAY" className="w-full h-full object-contain" />
        </div>
        <div className="inline-flex items-center gap-1.5 px-4 py-0.5 rounded-full bg-gradient-to-r from-purple-950 via-pink-950 to-purple-950 border border-pink-400/40 shadow-sm mt-0.5">
          <span className="text-pink-400 text-xs">♥</span>
          <span className="text-[11px] font-bold text-pink-200">Play, Chat & Make New Friends</span>
          <span className="text-pink-400 text-xs">♥</span>
        </div>
      </div>

      {/* Tabs Switcher: Profile Card vs Frame Atelier */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex-1 py-2 rounded-xl text-xs font-black transition ${
            activeTab === 'profile'
              ? 'liquid-btn-gold text-slate-950'
              : 'glass-card text-slate-300'
          }`}
        >
          PROFILE SHOWCASE
        </button>
        <button
          onClick={() => setActiveTab('frames')}
          className={`flex-1 py-2 rounded-xl text-xs font-black transition ${
            activeTab === 'frames'
              ? 'liquid-btn-purple text-white'
              : 'glass-card text-slate-300'
          }`}
        >
          20+ ANIMATED FRAMES
        </button>
      </div>

      {/* 2. PROFILE SHOWCASE */}
      {activeTab === 'profile' && (
        <div className="rounded-3xl overflow-hidden glass-panel border border-white/10 shadow-2xl space-y-4">
          {/* Top Banner Image with Avatar Badge Overlay */}
          <div className="relative h-52 w-full overflow-hidden">
            <img
              src={ASSETS.hostAnanya}
              alt="Banner"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

            {/* Circular Avatar Badge */}
            <div className="absolute -bottom-2 left-6">
              <div className="relative w-20 h-20 rounded-full border-3 border-amber-400 p-0.5 bg-gradient-to-tr from-amber-600 to-yellow-300 shadow-[0_0_20px_rgba(245,158,11,0.6)]">
                <div className="w-full h-full rounded-full overflow-hidden bg-slate-900">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                {currentUser.role === 'owner' && (
                  <div className="absolute -top-3 -right-2 text-xl filter drop-shadow">👑</div>
                )}
                {/* Level Badge */}
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-purple-700 border border-amber-300 text-white text-[10px] font-black shadow-md flex items-center gap-0.5">
                  128
                </div>
              </div>
            </div>

            {/* Unique Player ID Badge in Banner (Bible Item 26) */}
            <div className="absolute top-3 right-3 flex items-center gap-2">
              <div className="px-3 py-1 rounded-full bg-slate-950/80 border border-amber-400/60 shadow-lg flex items-center gap-1.5 text-xs font-mono font-black text-amber-300">
                <span>{currentUser.role === 'owner' ? '👑' : '🆔'}</span>
                <span>#{currentUser.id}</span>
                <button
                  onClick={handleCopyId}
                  className="text-[10px] text-slate-400 hover:text-white transition ml-1"
                  title="Copy ID"
                >
                  <Copy size={11} />
                </button>
              </div>

              {onOpenAuthModal && (
                <button
                  onClick={() => {
                    sound.playClick();
                    onOpenAuthModal();
                  }}
                  className="px-2.5 py-1 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] uppercase shadow-md transition"
                >
                  Switch / Login
                </button>
              )}
            </div>
          </div>

          {/* User Details */}
          <div className="px-6 pt-1 space-y-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white">{currentUser.name}</h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-400/40">
                  {currentUser.tag}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span className="flex items-center gap-1 text-emerald-400 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Online
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <span>🇮🇳</span> India
                </span>
                <span>·</span>
                <span className="text-slate-400 text-[11px]">{currentUser.email}</span>
              </div>
            </div>

            {/* Economy Pill Counters */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5 shadow-inner">
                <span className="text-xs text-slate-400 block font-bold">Diamonds</span>
                <span className="text-sm font-black text-amber-300 font-mono">
                  💎 {userDiamonds.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5 shadow-inner">
                <span className="text-xs text-slate-400 block font-bold">Gold Coins</span>
                <span className="text-sm font-black text-yellow-300 font-mono">
                  🪙 {userCoins.toLocaleString()}
                </span>
              </div>
              <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5 shadow-inner">
                <span className="text-xs text-slate-400 block font-bold">Stars</span>
                <span className="text-sm font-black text-emerald-300 font-mono">
                  ⭐ {userStars.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Equipped Astra & Companion Cards */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between text-xs font-black text-slate-300 px-1">
                <span>EQUIPPED CELESTIAL LOADOUT</span>
                <button
                  onClick={() => onOpenModal('collections')}
                  className="text-amber-400 hover:underline text-[10px]"
                >
                  Manage All
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {/* Active Astra */}
                <div
                  onClick={() => onOpenModal('astra')}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-amber-500/40 cursor-pointer hover:border-amber-400 transition flex items-center gap-2"
                >
                  <img src={activeAstra.image} alt={activeAstra.name} className="w-10 h-10 rounded-xl object-cover border border-amber-400/50" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-amber-300 font-bold truncate">{activeAstra.name}</p>
                    <p className="text-[9px] text-slate-400 truncate">{activeAstra.tier}</p>
                  </div>
                </div>

                {/* Active Pet */}
                <div
                  onClick={() => onOpenModal('pets')}
                  className="p-2.5 rounded-2xl bg-slate-900 border border-purple-500/40 cursor-pointer hover:border-purple-400 transition flex items-center gap-2"
                >
                  <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-400/50 flex items-center justify-center text-2xl shadow-inner">
                    {activePet.icon || '🐉'}
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] text-purple-200 font-bold truncate">{activePet.name}</p>
                    <p className="text-[9px] text-slate-400 truncate">{activePet.species}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Museum & Bible Quick Links */}
            <div className="pt-2 pb-4 grid grid-cols-2 gap-2">
              <button
                onClick={() => onOpenModal('bible')}
                className="py-2.5 rounded-xl bg-amber-500/20 border border-amber-400/50 text-amber-300 font-black text-xs uppercase flex items-center justify-center gap-1.5 hover:bg-amber-500/30 transition shadow-sm"
              >
                <span>📜</span>
                <span>Game Bible</span>
              </button>
              <button
                onClick={() => onOpenModal('admin')}
                className="py-2.5 rounded-xl bg-red-500/20 border border-red-400/50 text-red-300 font-black text-xs uppercase flex items-center justify-center gap-1.5 hover:bg-red-500/30 transition shadow-sm"
              >
                <span>🛡️</span>
                <span>Command Center</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. 20+ ANIMATED FRAMES ATELIER */}
      {activeTab === 'frames' && (
        <div className="rounded-3xl p-4 glass-panel border border-white/10 shadow-2xl space-y-3">
          <h3 className="text-sm font-black text-white font-cinzel">20+ Animated Avatar Frames</h3>
          <div className="grid grid-cols-2 gap-2.5">
            {AVATAR_FRAMES.map((f) => (
              <div
                key={f.id}
                onClick={() => {
                  sound.playClick();
                  onEquipFrame(f.id);
                }}
                className={`p-3 rounded-2xl border text-center cursor-pointer transition ${
                  equippedFrame === f.id
                    ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="w-14 h-14 mx-auto rounded-full overflow-hidden border-2 border-white/20 mb-2">
                  <img src={currentUser.avatar} alt="Avatar" className="w-full h-full object-cover" />
                </div>
                <p className="text-xs font-bold text-white truncate">{f.name}</p>
                <span className="text-[10px] text-amber-300 font-mono">
                  {equippedFrame === f.id
                    ? 'Equipped'
                    : f.diamondPrice
                    ? `💎 ${f.diamondPrice.toLocaleString()}`
                    : `✨ ${f.rarity}`}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
