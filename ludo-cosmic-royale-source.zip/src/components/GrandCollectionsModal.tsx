import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Crown,
  Trophy,
  Zap,
  Flame,
  Shield,
  Gift,
  Compass,
  Heart,
  ChevronRight,
  Volume2,
  Lock,
  CheckCircle2,
  Star,
  Coins,
  ArrowRight,
  Layers,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASTRA_ITEMS, RARE_PETS, LUXURY_GIFTS, ASSETS, COLLECTION_FAMILIES } from '../data/gameConstants';
import { GLAMOUR_MODELS, ModelProfile } from './ModelGalleryModal';
import { BUTTERFLY_SPECIES, ButterflyCompanion } from '../data/butterflyData';
import { GiftItem } from '../types/game';
import confetti from 'canvas-confetti';

export type CollectionTab =
  | 'astras'
  | 'pets'
  | 'butterflies'
  | 'universe'
  | 'hypercars'
  | 'dice-frames'
  | 'models'
  | 'lokas'
  | 'museum';

export interface DiceSkin {
  id: string;
  name: string;
  color: string;
  glow: string;
  tag: string;
  unlocked: boolean;
}

export const DICE_SKINS: DiceSkin[] = [
  { id: 'dice-gold', name: 'Golden Celestial Dice', color: 'from-amber-400 to-yellow-600', glow: 'border-amber-300 shadow-[0_0_15px_#f59e0b]', tag: 'MYTHIC', unlocked: true },
  { id: 'dice-ruby', name: 'Ruby Inferno Tandav Dice', color: 'from-rose-600 to-red-800', glow: 'border-red-400 shadow-[0_0_15px_#ef4444]', tag: 'ULTRA', unlocked: true },
  { id: 'dice-neon', name: 'Cyber Neon Plasma Dice', color: 'from-cyan-400 to-blue-600', glow: 'border-cyan-300 shadow-[0_0_15px_#06b6d4]', tag: 'VIP 10', unlocked: true },
  { id: 'dice-emerald', name: 'Imperial Emerald Dice', color: 'from-emerald-500 to-teal-700', glow: 'border-emerald-300 shadow-[0_0_15px_#10b981]', tag: 'RARE', unlocked: true },
  { id: 'dice-obsidian', name: 'Obsidian Black Gold Dice', color: 'from-slate-800 to-black', glow: 'border-amber-500/60 shadow-[0_0_15px_#f59e0b]', tag: 'LEGENDARY', unlocked: true },
  { id: 'dice-amethyst', name: 'Amethyst Cosmic Dice', color: 'from-purple-600 to-indigo-800', glow: 'border-purple-300 shadow-[0_0_15px_#a855f7]', tag: 'DIVINE', unlocked: true },
];

export const AVATAR_FRAME_COLLECTION = [
  { id: 'gold', name: 'Imperial 24K Gold Sovereign', icon: '👑', rarity: 'VIP 10', styleClass: 'border-4 border-amber-400 shadow-[0_0_20px_#f59e0b]' },
  { id: 'fire', name: 'Nataraja Cosmic Fire', icon: '🔥', rarity: 'MYTHIC', styleClass: 'border-4 border-orange-500 shadow-[0_0_20px_#f97316] animate-pulse' },
  { id: 'neon', name: 'Cyberpunk Hyper Neon', icon: '⚡', rarity: 'LEGENDARY', styleClass: 'border-4 border-cyan-400 shadow-[0_0_20px_#06b6d4]' },
  { id: 'dragon', name: 'Royal Emerald Dragon', icon: '🐉', rarity: 'ULTRA', styleClass: 'border-4 border-emerald-400 shadow-[0_0_20px_#10b981]' },
  { id: 'diamond', name: 'Celestial 100K Diamond', icon: '💎', rarity: 'APEX', styleClass: 'border-4 border-indigo-400 shadow-[0_0_25px_#818cf8]' },
  { id: 'peacock', name: 'Sacred Mayur Peacock', icon: '🦚', rarity: 'EPIC', styleClass: 'border-4 border-teal-400 shadow-[0_0_15px_#14b8a6]' },
];

export const COSMIC_LOKAS_PREVIEW = [
  { id: 'satya', name: 'Satyaloka (Brahma Realm)', icon: '🪐', tier: 'Highest Transcendental', desc: 'The abode of cosmic creators, where golden lotus flowers bloom in eternity.' },
  { id: 'tapoloka', name: 'Tapoloka (Ascetics Realm)', icon: '☀️', tier: 'Meditative Loka', desc: 'Realm of divine immortals engulfed in spiritual tapasya energy.' },
  { id: 'janaloka', name: 'Janaloka (Celestial Sons)', icon: '✨', tier: 'Cosmic Plane', desc: 'Sanatkumaras eternal realm of radiant youthful wisdom.' },
  { id: 'swarga', name: 'Swargaloka (Indra Deva Court)', icon: '⚡', tier: 'Heavenly Realm', desc: 'City of Amravati adorned with Kalpavriksha wishing trees and nectar fountains.' },
  { id: 'bhuloka', name: 'Bhuloka (Earthly Realm)', icon: '🌍', tier: 'Mortal Arena', desc: 'The battleground of karma, where the great Kurukshetra Ludo war takes place.' },
  { id: 'patala', name: 'Patala (Naga Realm of Takshak)', icon: '🐍', tier: 'Subterranean Jeweled Kingdom', desc: 'Deep cosmic nagaloka glowing with subterranean rubies and Nagmani gems.' },
];

interface GrandCollectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: CollectionTab;
  userDiamonds: number;
  userCoins: number;
  equippedAstraId: string;
  onEquipAstra: (id: string) => void;
  equippedPetId: string;
  onEquipPet: (id: string) => void;
  equippedButterflyId?: string;
  onEquipButterfly?: (id: string) => void;
  onOpenButterflyModal?: () => void;
  onTestAstraFX: (astra: typeof ASTRA_ITEMS[0]) => void;
  onOpenStore: () => void;
}

export const GrandCollectionsModal: React.FC<GrandCollectionsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'astras',
  userDiamonds,
  userCoins,
  equippedAstraId,
  onEquipAstra,
  equippedPetId,
  onEquipPet,
  equippedButterflyId = 'bf-azure-morpho',
  onEquipButterfly,
  onOpenButterflyModal,
  onTestAstraFX,
  onOpenStore,
}) => {
  const [activeTab, setActiveTab] = useState<CollectionTab>(initialTab);
  const [selectedAstra, setSelectedAstra] = useState(ASTRA_ITEMS[0]);
  const [equippedDice, setEquippedDice] = useState('dice-gold');
  const [equippedFrame, setEquippedFrame] = useState('gold');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[94vh] flex flex-col overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#130924] via-[#0c0617] to-black text-slate-100 shadow-[0_0_60px_rgba(245,158,11,0.3)]">
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600/30 via-purple-700/30 to-amber-600/30 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-2xl shadow-[0_0_20px_rgba(245,158,11,0.5)] border border-amber-300">
              🏛️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400 tracking-wide">
                  Grand Collections Vault
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold hidden sm:inline">
                  महारत्न महा-संग्रहालय
                </span>
              </div>
              <p className="text-xs text-amber-200/80 font-medium">
                14 Divine Astras · 30 Mythic Pets · Hypercars · Dice Skins · 3D Models · 14 Lokas
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 border border-amber-500/30 text-xs font-bold">
              <span>💎 {userDiamonds.toLocaleString()}</span>
              <span className="text-amber-400">🪙 {userCoins.toLocaleString()}</span>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* 7 Collection Navigation Tabs */}
        <div className="flex items-center gap-1.5 p-2 px-3 sm:px-5 bg-black/60 border-b border-white/10 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('astras');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'astras'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🔱</span>
            <span>14 Astras ({ASTRA_ITEMS.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('pets');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'pets'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🐉</span>
            <span>30 Pets ({RARE_PETS.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('butterflies');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'butterflies'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🦋</span>
            <span>Butterflies & Eggs ({BUTTERFLY_SPECIES.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('universe');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'universe'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🦚</span>
            <span>12 Families Universe ({COLLECTION_FAMILIES.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('hypercars');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'hypercars'
                ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🏎️</span>
            <span>Hypercars & Gifts ({LUXURY_GIFTS.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('dice-frames');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'dice-frames'
                ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🎲</span>
            <span>Dice & Frames (12)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('models');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'models'
                ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>💃</span>
            <span>Models Atelier ({GLAMOUR_MODELS.length})</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('lokas');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'lokas'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🪐</span>
            <span>14 Lokas Codex</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('museum');
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs shrink-0 flex items-center gap-1.5 transition ${
              activeTab === 'museum'
                ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md scale-105'
                : 'text-slate-400 hover:text-white bg-white/5'
            }`}
          >
            <span>🏆</span>
            <span>Trophy Museum</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5">
          {/* ===================== TAB 1: 14 DIVINE ASTRAS ===================== */}
          {activeTab === 'astras' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/30 to-slate-900 border border-amber-500/40 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-amber-300">
                    Supreme Divine Arsenal (14 Celestial Weapons)
                  </h3>
                  <p className="text-xs text-slate-300">
                    Equip an Astra to unlock unique board summoning cinematics, earthquake slams, and sound fx!
                  </p>
                </div>
                <button
                  onClick={() => onTestAstraFX(selectedAstra)}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 active:scale-95 transition shadow-lg shrink-0 cursor-pointer"
                >
                  <Sparkles size={14} />
                  <span>Test Cinematic FX</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {ASTRA_ITEMS.map((astra) => {
                  const isEquipped = equippedAstraId === astra.id;

                  return (
                    <div
                      key={astra.id}
                      onClick={() => setSelectedAstra(astra)}
                      className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between gap-3 cursor-pointer ${
                        isEquipped
                          ? 'bg-amber-950/40 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.25)]'
                          : 'bg-slate-900/60 border-slate-700 hover:border-amber-500/50 hover:bg-slate-900/90'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-950 border border-amber-500/40 shrink-0">
                          <img
                            src={astra.image}
                            alt={astra.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition"
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">
                              {astra.tier}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {astra.element}
                            </span>
                          </div>

                          <h4 className="text-sm font-black text-white mt-1 truncate">
                            {astra.name}
                          </h4>
                          <p className="text-[11px] text-amber-300 font-bold">{astra.hindiName}</p>
                          <p className="text-[10px] text-slate-400 line-clamp-2 mt-0.5">
                            {astra.description}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-white/10">
                        <div className="text-[10px] text-emerald-400 font-bold truncate max-w-[200px]">
                          ⚡ {astra.passiveBonus}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onTestAstraFX(astra);
                            }}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-amber-300 border border-white/10"
                            title="Play Audio FX"
                          >
                            <Volume2 size={13} />
                          </button>

                          {isEquipped ? (
                            <span className="px-3 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400 text-emerald-300 text-xs font-black flex items-center gap-1">
                              <CheckCircle2 size={12} /> Equipped
                            </span>
                          ) : (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                sound.playClick();
                                onEquipAstra(astra.id);
                                confetti({ particleCount: 50, spread: 50 });
                              }}
                              className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs active:scale-95 transition"
                            >
                              Equip
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ===================== TAB 2: 30 RARE PETS ===================== */}
          {activeTab === 'pets' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-cyan-300">
                    30 Sacred Pets & Divine Mounts (दिव्य वाहन)
                  </h3>
                  <p className="text-xs text-slate-300">
                    Dragons, Garuda, Nandi Bull, Sheshnag, and Celestial Companions granting match bonuses!
                  </p>
                </div>
                <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-black border border-cyan-400/40">
                  {RARE_PETS.length} Registered
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {RARE_PETS.map((pet) => {
                  const isEquipped = equippedPetId === pet.id;

                  return (
                    <div
                      key={pet.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col justify-between gap-2.5 ${
                        isEquipped
                          ? 'bg-cyan-950/40 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                          : 'bg-slate-900/60 border-slate-700 hover:border-cyan-500/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-950 border border-cyan-500/30 shrink-0">
                          <img
                            src={pet.image}
                            alt={pet.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                              {pet.rarity}
                            </span>
                            <span className="text-[10px] text-amber-400 font-bold">
                              Lv.{pet.level}
                            </span>
                          </div>
                          <h4 className="text-xs font-black text-white truncate mt-0.5">
                            {pet.name}
                          </h4>
                          <p className="text-[10px] text-slate-400 truncate">{pet.species}</p>
                        </div>
                      </div>

                      <div className="p-1.5 rounded-lg bg-black/40 border border-white/5 text-[10px] text-emerald-300 font-semibold truncate">
                        ✨ {pet.bonus}
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">
                          Affection: <strong className="text-pink-400">{pet.affection}%</strong>
                        </span>

                        {isEquipped ? (
                          <span className="px-2.5 py-0.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-[10px] font-black border border-cyan-400 flex items-center gap-1">
                            <CheckCircle2 size={11} /> Summoned
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              sound.playClick();
                              onEquipPet(pet.id);
                              confetti({ particleCount: 40, spread: 40 });
                            }}
                            className="px-2.5 py-0.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-[10px] font-black active:scale-95 transition"
                          >
                            Summon
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ===================== TAB: BUTTERFLIES & MYSTIC EGGS ===================== */}
          {activeTab === 'butterflies' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-teal-950/40 to-slate-900 border border-emerald-500/40 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-emerald-300 flex items-center gap-2">
                    <span>Mystic Butterfly Companions & Egg Hatchery</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/40 font-bold">
                      तितली महा-संग्रह
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300">
                    Incubate sacred eggs, hatch magical fluttering companions & activate game buffs!
                  </p>
                </div>
                {onOpenButterflyModal && (
                  <button
                    onClick={() => {
                      sound.playClick();
                      onClose();
                      onOpenButterflyModal();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition cursor-pointer flex items-center gap-1"
                  >
                    <span>Egg Incubator</span>
                    <ChevronRight size={14} />
                  </button>
                )}
              </div>

              {/* Butterflies Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {BUTTERFLY_SPECIES.map((butterfly) => {
                  const isEquipped = equippedButterflyId === butterfly.id;

                  return (
                    <div
                      key={butterfly.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                        isEquipped
                          ? 'bg-gradient-to-b from-emerald-950/90 to-slate-900 border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                          : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span
                            className="text-[9px] px-2 py-0.5 rounded-full font-black uppercase"
                            style={{
                              backgroundColor: `${butterfly.glowColor}25`,
                              color: butterfly.glowColor,
                              border: `1px solid ${butterfly.glowColor}60`,
                            }}
                          >
                            {butterfly.rarity} · {butterfly.element}
                          </span>
                          {isEquipped && (
                            <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black flex items-center gap-0.5 shadow-sm">
                              <CheckCircle2 size={10} />
                              <span>EQUIPPED</span>
                            </span>
                          )}
                        </div>

                        <div className="my-2.5 flex items-center justify-center">
                          <div
                            className="relative w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-inner border border-white/10"
                            style={{
                              background: `radial-gradient(circle, ${butterfly.glowColor}35 15%, #020617 80%)`,
                            }}
                          >
                            <span className="hover:scale-125 transition-transform duration-300">
                              🦋
                            </span>
                          </div>
                        </div>

                        <h4 className="text-xs font-black text-white text-center">{butterfly.name}</h4>
                        <p className="text-[10px] text-emerald-400 font-bold text-center">
                          {butterfly.hindiName}
                        </p>
                        <p className="text-[10px] text-slate-400 text-center mt-1 line-clamp-2">
                          {butterfly.description}
                        </p>

                        <div className="mt-2 p-1.5 rounded-xl bg-slate-950/80 border border-slate-800">
                          <div className="flex items-center gap-1 text-[9px] text-amber-300 font-bold">
                            <span>✨</span>
                            <span>{butterfly.buffTitle}</span>
                          </div>
                          <p className="text-[9px] text-slate-300 mt-0.5">
                            {butterfly.buffDescription}
                          </p>
                        </div>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                        <span className="text-[9px] text-slate-400">
                          Wingspan: <strong className="text-white">{butterfly.wingspan}</strong>
                        </span>

                        {butterfly.unlocked ? (
                          <button
                            onClick={() => {
                              sound.playGrandVictory();
                              if (onEquipButterfly) onEquipButterfly(butterfly.id);
                              confetti({ particleCount: 30, spread: 40 });
                            }}
                            disabled={isEquipped}
                            className={`px-3 py-1 rounded-xl text-xs font-black transition cursor-pointer ${
                              isEquipped
                                ? 'bg-slate-800 text-slate-500 cursor-default'
                                : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 shadow-md active:scale-95'
                            }`}
                          >
                            {isEquipped ? 'Active' : 'Equip'}
                          </button>
                        ) : (
                          <span className="text-[9px] text-rose-400 flex items-center gap-1 font-bold">
                            <Lock size={10} />
                            <span>Hatch from Egg</span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ===================== TAB: 12 COLLECTION FAMILIES UNIVERSE ===================== */}
          {activeTab === 'universe' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/50 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-black text-amber-300 flex items-center gap-1.5">
                    <span>🦚</span> The 12 Official Collection Families (Game Bible Page 2)
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Stars, Hearts, More Pank, Eggs, Butterflies, Fish, Kiss, Double Hearts, Balloons, Vegetables, Friends Band & Love Birds!
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-yellow-300 font-black border border-amber-500/30">
                    12 FAMILIES ACTIVE
                  </span>
                </div>
              </div>

              {/* Families Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {COLLECTION_FAMILIES.map((fam) => (
                  <div
                    key={fam.id}
                    className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-400/40 transition flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <span className="text-3xl">{fam.icon}</span>
                          <div>
                            <h4 className="text-xs font-black text-white">{fam.name}</h4>
                            <span className="text-[10px] text-amber-300 font-bold block">{fam.hindiName}</span>
                          </div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-black border border-slate-700">
                          {fam.itemsCount} Items
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-400 mt-2">{fam.description}</p>

                      <div className="mt-2.5 p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-[10px] space-y-1">
                        <div>
                          <strong className="text-slate-400">Earned Through: </strong>
                          <span className="text-slate-200">{fam.source}</span>
                        </div>
                        <div>
                          <strong className="text-amber-400">Bible Milestone Unlock: </strong>
                          <span className="text-amber-200 font-bold">{fam.specialUnlock}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between">
                      <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 size={12} /> Live in Universe
                      </span>
                      <button
                        onClick={() => {
                          sound.playClick();
                          confetti({ particleCount: 25, spread: 50 });
                        }}
                        className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-amber-500 hover:bg-amber-400 text-slate-950 transition"
                      >
                        INSPECT
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ===================== TAB 3: HYPERCARS & LUXURY GIFTS ===================== */}
          {activeTab === 'hypercars' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-gradient-to-r from-pink-950/40 via-purple-950/30 to-slate-900 border border-pink-500/30 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-pink-300">
                    Billionaire 3D Hypercars & Luxury Gifts
                  </h3>
                  <p className="text-xs text-slate-300">
                    Trigger full-screen arrivals: Bugatti Supercars, Gulfstream Jets, and Sudarshan Om Vortexes!
                  </p>
                </div>
                <button
                  onClick={() => {
                    sound.playClick();
                    onClose();
                    onOpenStore();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-pink-500 hover:bg-pink-400 text-white font-black text-xs flex items-center gap-1 active:scale-95 transition shrink-0"
                >
                  <Gift size={13} />
                  <span>Send Gift</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {LUXURY_GIFTS.map((gift: GiftItem) => (
                  <div
                    key={gift.id}
                    className="p-3 rounded-2xl bg-slate-900/70 border border-slate-700 hover:border-pink-500/50 transition-all flex flex-col justify-between gap-2"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-14 h-14 rounded-xl bg-black/60 border border-white/10 flex items-center justify-center text-3xl shrink-0">
                        {gift.icon}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-pink-500/20 text-pink-300 border border-pink-400/30">
                          {gift.rarity}
                        </span>
                        <h4 className="text-xs font-black text-white truncate mt-0.5">
                          {gift.name}
                        </h4>
                        <p className="text-[10px] text-slate-400 line-clamp-1">{gift.bannerText}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-white/10">
                      <span className="text-xs font-black text-amber-300">
                        {gift.currency === 'diamonds' ? '💎' : '🪙'} {gift.cost.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-pink-300 font-bold bg-pink-950/60 px-2 py-0.5 rounded border border-pink-500/30">
                        3D Cinematic
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ===================== TAB 4: DICE SKINS & AVATAR FRAMES ===================== */}
          {activeTab === 'dice-frames' && (
            <div className="space-y-5">
              {/* Dice Section */}
              <div>
                <h3 className="text-sm font-black text-amber-300 mb-2 flex items-center gap-1.5">
                  <span>🎲</span> 3D Custom Dice Skins Collection
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {DICE_SKINS.map((dice) => {
                    const isEquipped = equippedDice === dice.id;

                    return (
                      <div
                        key={dice.id}
                        className={`p-3 rounded-2xl border transition-all flex flex-col justify-between gap-2 ${
                          isEquipped
                            ? 'bg-amber-950/40 border-amber-400 shadow-md'
                            : 'bg-slate-900/60 border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-400/30">
                            {dice.tag}
                          </span>
                          <span className="text-lg">🎲</span>
                        </div>

                        <div className="my-1">
                          <h4 className="text-xs font-black text-white">{dice.name}</h4>
                          <div
                            className={`w-full h-2 rounded-full mt-2 bg-gradient-to-r ${dice.color}`}
                          />
                        </div>

                        <button
                          onClick={() => {
                            sound.playDiceRoll();
                            setEquippedDice(dice.id);
                            confetti({ particleCount: 30, spread: 30 });
                          }}
                          className={`w-full py-1 rounded-xl text-xs font-black active:scale-95 transition ${
                            isEquipped
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400'
                              : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                          }`}
                        >
                          {isEquipped ? 'Equipped' : 'Equip Skin'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Avatar Frames Section */}
              <div>
                <h3 className="text-sm font-black text-purple-300 mb-2 flex items-center gap-1.5">
                  <span>👑</span> VIP Royal Avatar Frames Atelier
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {AVATAR_FRAME_COLLECTION.map((frame) => {
                    const isEquipped = equippedFrame === frame.id;

                    return (
                      <div
                        key={frame.id}
                        className={`p-3 rounded-2xl border transition-all flex flex-col justify-between gap-2 ${
                          isEquipped
                            ? 'bg-purple-950/40 border-purple-400 shadow-md'
                            : 'bg-slate-900/60 border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-400/30">
                            {frame.rarity}
                          </span>
                          <span className="text-xl">{frame.icon}</span>
                        </div>

                        <div className="my-1">
                          <h4 className="text-xs font-black text-white truncate">{frame.name}</h4>
                          <p className="text-[10px] text-slate-400">Profile & Seat Glow</p>
                        </div>

                        <button
                          onClick={() => {
                            sound.playClick();
                            setEquippedFrame(frame.id);
                            confetti({ particleCount: 30, spread: 30 });
                          }}
                          className={`w-full py-1 rounded-xl text-xs font-black active:scale-95 transition ${
                            isEquipped
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400'
                              : 'bg-purple-600 hover:bg-purple-500 text-white'
                          }`}
                        >
                          {isEquipped ? 'Equipped' : 'Equip Frame'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ===================== TAB 5: MODELS ATELIER ===================== */}
          {activeTab === 'models' && (
            <div className="space-y-4">
              <div className="p-3 rounded-2xl bg-gradient-to-r from-rose-950/40 via-amber-950/30 to-slate-900 border border-rose-500/30 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-rose-300">
                    3D Glamour Models & Live Stage Hostesses
                  </h3>
                  <p className="text-xs text-slate-300">
                    Unlock companions with Chillies & trigger live audio voice greetings in rooms!
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {GLAMOUR_MODELS.map((model: ModelProfile) => (
                  <div
                    key={model.id}
                    className="p-3 rounded-2xl bg-slate-900/70 border border-slate-700 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 rounded-xl overflow-hidden bg-slate-950 border border-rose-500/30 shrink-0">
                        <img
                          src={model.image}
                          alt={model.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300">
                          {model.title}
                        </span>
                        <h4 className="text-xs font-black text-white">{model.name}</h4>
                        <p className="text-[10px] text-amber-300 font-semibold italic">
                          "{model.dialogue}"
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        sound.speakTaunt(model.dialogue);
                      }}
                      className="p-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 shrink-0"
                      title="Play Voice Dialogue"
                    >
                      <Volume2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ===================== TAB 6: 14 LOKAS CODEX ===================== */}
          {activeTab === 'lokas' && (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30">
                <h3 className="text-sm font-black text-emerald-300">
                  Cosmic Codex of the 14 Celestial Realms (चौदह भुवन)
                </h3>
                <p className="text-xs text-slate-300">
                  The sacred cosmology spanning Satyaloka down to Takshak Nag's subterranean Patala.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {COSMIC_LOKAS_PREVIEW.map((loka) => (
                  <div
                    key={loka.id}
                    className="p-3 rounded-2xl bg-slate-900/70 border border-slate-700 hover:border-emerald-500/40 transition-all flex items-start gap-3"
                  >
                    <div className="w-12 h-12 rounded-xl bg-black/60 border border-emerald-500/30 flex items-center justify-center text-2xl shrink-0">
                      {loka.icon}
                    </div>
                    <div>
                      <span className="text-[9px] font-black uppercase text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-500/30">
                        {loka.tier}
                      </span>
                      <h4 className="text-xs font-black text-white mt-1">{loka.name}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{loka.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ===================== TAB 7: TROPHY MUSEUM ===================== */}
          {activeTab === 'museum' && (
            <div className="space-y-4 text-center py-4">
              <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-4xl shadow-[0_0_30px_rgba(245,158,11,0.5)] border-2 border-amber-300">
                🏆
              </div>
              <div>
                <h3 className="text-lg font-black text-white">VikingKing's Hall of Fame Museum</h3>
                <p className="text-xs text-slate-400">
                  Total Prestige Fame: <strong className="text-amber-300 font-mono">42,500 PTS</strong> · Rank #7 Global
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-xl mx-auto pt-2">
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-amber-500/30">
                  <p className="text-2xl font-black text-amber-300">14 / 14</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Astras Collected</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-cyan-500/30">
                  <p className="text-2xl font-black text-cyan-300">30 / 30</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Rare Pets</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-pink-500/30">
                  <p className="text-2xl font-black text-pink-300">12 / 12</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Hypercars</p>
                </div>
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-purple-500/30">
                  <p className="text-2xl font-black text-purple-300">100%</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Museum Prestige</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
