import React from 'react';
import { X, Sparkles, Zap, Flame } from 'lucide-react';
import { sound } from '../utils/soundEngine';

export interface BalloonItem {
  id: string;
  name: string;
  icon: string;
  diamondCost: number;
  effectType: 'water' | 'bomb';
  splatDecal: string;
}

interface BalloonsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userDiamonds: number;
  onThrowBalloon: (balloon: BalloonItem, targetSeatName: string) => void;
}

export const BalloonsModal: React.FC<BalloonsModalProps> = ({
  isOpen,
  onClose,
  userDiamonds,
  onThrowBalloon,
}) => {
  if (!isOpen) return null;

  const BALLOONS: BalloonItem[] = [
    { id: 'water-splash', name: 'Aqua Splash Balloon', icon: '💧', diamondCost: 2, effectType: 'water', splatDecal: 'SPLASH!' },
    { id: 'color-party', name: 'Holi Colors Bomb', icon: '🎨', diamondCost: 2, effectType: 'water', splatDecal: 'COLORED!' },
    { id: 'spark-bomb', name: 'Cosmic Firecracker', icon: '💥', diamondCost: 2, effectType: 'bomb', splatDecal: 'BOOM!' },
    { id: 'heart-burst', name: 'Lovely Heart Pop', icon: '💖', diamondCost: 2, effectType: 'water', splatDecal: 'LOVE!' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-pink-500/50 rounded-3xl bg-gradient-to-b from-[#20081a] via-[#100612] to-black text-slate-100 shadow-[0_0_50px_rgba(236,72,153,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-pink-700/40 via-purple-700/30 to-slate-900 border-b border-pink-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-2xl shadow-lg border border-pink-400">
              🎈
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-amber-300">
                Balloons & Fun Splashes
              </h3>
              <p className="text-xs text-slate-300">
                Throw fun reactive balloons at players (2 💎 each)
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-3 overflow-y-auto max-h-[75vh]">
          {BALLOONS.map((balloon) => (
            <div
              key={balloon.id}
              className="p-3.5 rounded-2xl bg-slate-900/70 border border-pink-500/30 flex items-center justify-between hover:border-pink-400 transition"
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{balloon.icon}</span>
                <div>
                  <h4 className="text-sm font-black text-white">{balloon.name}</h4>
                  <p className="text-[11px] text-pink-300 font-bold">{balloon.diamondCost} 💎 Splash</p>
                </div>
              </div>

              <button
                onClick={() => {
                  sound.playPop();
                  onThrowBalloon(balloon, 'Arena Opponent');
                  onClose();
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-400 text-white font-black text-xs uppercase tracking-wider shadow-md active:scale-95 transition cursor-pointer"
              >
                Throw!
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
