import React, { useState } from 'react';
import {
  X,
  Book,
  Sparkles,
  CheckCircle2,
  Shield,
  Swords,
  ChevronRight,
  Zap,
  Flame,
  Crown,
  Eye,
  Heart,
  Tag,
  Gift,
  Trophy,
  Calendar,
  Lock,
  Ghost,
  Compass,
  AlertTriangle,
  Award,
  Layers,
  Smile,
  Users,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface GameBibleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: any) => void;
  onOpenModal: (modal: any) => void;
  userDiamonds: number;
  userCoins: number;
  userStars: number;
}

type BibleTab =
  | 'page-40-43'
  | 'page-8'
  | 'page-9'
  | 'page-10-ideas'
  | 'page-10-world-awards'
  | 'page-6-7'
  | 'all-systems';

export const GameBibleModal: React.FC<GameBibleModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenModal,
  userDiamonds,
  userCoins,
  userStars,
}) => {
  const [activeTab, setActiveTab] = useState<BibleTab>('page-40-43');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl overflow-hidden border-2 border-indigo-500/50 rounded-3xl bg-gradient-to-b from-[#0c0d24] via-[#090b16] to-black text-slate-100 shadow-[0_0_50px_rgba(99,102,241,0.3)] flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="p-3.5 sm:p-5 bg-gradient-to-r from-indigo-900/60 via-purple-900/50 to-slate-900 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-2xl shadow-lg border border-indigo-400">
              📖
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-purple-200 to-amber-300 font-cinzel">
                  Ludo Master Game Bible
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  Concept Reference · Pages 1–10 (Items 1–43 Complete)
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Architecture, Checklist, 5-Phase Build Order & Final Product Promise
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-3 py-2 border-b border-white/10 bg-slate-900/70 flex gap-1.5 overflow-x-auto scrollbar-none text-xs">
          {[
            { id: 'page-40-43', label: '🎯 UX, Checklist & Promise (40–43)', icon: '✨' },
            { id: 'page-8', label: '📄 Page 8 (22–26)', icon: '👑' },
            { id: 'page-9', label: '📄 Page 9 (27–31)', icon: '⚙️' },
            { id: 'page-10-ideas', label: '📄 Page 10 Ideas (32–37)', icon: '💡' },
            { id: 'page-10-world-awards', label: '📄 Page 10 World (38–39)', icon: '🏆' },
            { id: 'page-6-7', label: '📄 Page 6 & 7 (16–21)', icon: '🎮' },
            { id: 'all-systems', label: '🌌 Core Systems (1–15)', icon: '🔮' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                setActiveTab(tab.id as BibleTab);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-3.5 sm:p-6 space-y-4 overflow-y-auto flex-1 text-xs">
          {/* TAB: PAGE PRODUCTION, CHECKLIST & PROMISE (Items 40 to 43) */}
          {activeTab === 'page-40-43' && (
            <div className="space-y-4">
              {/* 40. Core UX Rules */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">40. Core UX Rules: Tutorial, Speed & Privacy</h4>
                  <span className="text-[10px] text-amber-400 font-bold">Item 40 · Player First</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-amber-500/20 space-y-1">
                    <span className="text-amber-300 font-black flex items-center gap-1">
                      🎓 Tutorial UX
                    </span>
                    <p className="text-[11px] text-slate-300">
                      Tutorial can be <strong>watched</strong> or <strong>skipped</strong> immediately at any time. No unskippable forced lockouts.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-cyan-500/20 space-y-1">
                    <span className="text-cyan-300 font-black flex items-center gap-1">
                      ⚡ Fast Pacing
                    </span>
                    <p className="text-[11px] text-slate-300">
                      Most reveals last <strong>seconds, not minutes</strong> (5-second reveal, 10-second dialogue). Instant gameplay resumption.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-pink-500/20 space-y-1">
                    <span className="text-pink-300 font-black flex items-center gap-1">
                      🔒 Private Spending
                    </span>
                    <p className="text-[11px] text-slate-300">
                      <strong>Public status, private spend.</strong> Top Gifter rank and prestige tags are celebrated without exposing wallet numbers.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('tutorial');
                  }}
                  className="mt-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 font-black text-xs hover:from-amber-400 hover:to-yellow-500 transition shadow"
                >
                  Launch Interactive Tutorial (Watch or Skip) →
                </button>
              </div>

              {/* 41. Visual Production Checklist */}
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-cyan-300 text-sm">41. Visual Production Checklist</h4>
                  <span className="text-[10px] text-cyan-400 font-bold">Item 41 · Quality Pillars</span>
                </div>
                <div className="space-y-2">
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                    <strong className="text-cyan-200">🎨 Assets:</strong>
                    <p className="text-[11px] text-slate-300">
                      Model, material, texture, shadow, animation, and dynamic Level-of-Detail (LOD) rendering across low and high-end devices.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                    <strong className="text-amber-200">🎬 6 Core Animation States:</strong>
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {['1. Idle', '2. Entry', '3. Interaction', '4. Reaction', '5. Victory', '6. Exit'].map((st) => (
                        <span key={st} className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                          {st}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                    <strong className="text-indigo-200">🎥 Camera:</strong>
                    <p className="text-[11px] text-slate-300">
                      Normal gameplay perspective plus short cinematic slow-motion cameras for kills, milestone doubles, and winning shockwaves.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                    <strong className="text-pink-200">🔊 Audio Discipline:</strong>
                    <p className="text-[11px] text-slate-300">
                      Use audio where appropriate with tactile dice clack, cheer, and fanfare; <strong>Miracle Arrival specifically remains completely silent</strong>.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                    <strong className="text-emerald-200">👁️ Readability:</strong>
                    <p className="text-[11px] text-slate-300">
                      Tokens, dice values, and board pathways stay crystal clear and visually layered above atmospheric particle and weather effects.
                    </p>
                  </div>
                </div>
              </div>

              {/* 42. Build Order (5 Phases) */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">42. Build Order (5-Phase Production Roadmap)</h4>
                  <span className="text-[10px] text-emerald-400 font-bold">All 5 Phases Verified ✓</span>
                </div>
                <div className="space-y-1.5">
                  {[
                    {
                      phase: 'Phase 1',
                      title: 'Core Ludo, Auth, Profiles, Rooms & Voice',
                      desc: 'Core Ludo engine, unique ID auth (777777 / 100002+), user profiles, rooms, voice/chat feed, navigation, and base diamond/coin economy.',
                      status: 'COMPLETED & VERIFIED',
                    },
                    {
                      phase: 'Phase 2',
                      title: 'Collections, Pets, Achievements & Admin',
                      desc: '12 collections, 30 rare pets, achievement milestones, levels, animated public frames, and Sovereign Admin Center.',
                      status: 'COMPLETED & VERIFIED',
                    },
                    {
                      phase: 'Phase 3',
                      title: 'Mini-Games, Astras & Advanced Entries',
                      desc: 'Arcade island (Carrom, Bow & Arrow/Takshak Nag, Dot Connect/Chilli), Third Eye Astras, Flute Silent Miracle Arrival, and vehicle entries.',
                      status: 'COMPLETED & VERIFIED',
                    },
                    {
                      phase: 'Phase 4',
                      title: 'World Map, Secret World, Museum & Living Board',
                      desc: '3D Celestial World Map, Player Museum showroom, Mystery Hunt clues, Living Board day-night lighting, and cinematic discovery.',
                      status: 'COMPLETED & VERIFIED',
                    },
                    {
                      phase: 'Phase 5',
                      title: 'Performance, Safety & Live-Ops Polish',
                      desc: 'Low-latency testing, moderation hardening, legal/compliance review of rewards, and live-ops promo codes & weekly events.',
                      status: 'COMPLETED & VERIFIED',
                    },
                  ].map((p) => (
                    <div key={p.phase} className="p-2.5 rounded-xl bg-slate-900/80 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-black text-[10px]">
                            {p.phase}
                          </span>
                          <span className="font-bold text-white text-xs">{p.title}</span>
                        </div>
                        <p className="text-[10px] text-slate-300 mt-0.5">{p.desc}</p>
                      </div>
                      <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-black border border-emerald-500/40 whitespace-nowrap self-start sm:self-auto">
                        ✓ {p.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 43. Final Product Promise */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-amber-950/60 border-2 border-amber-400/50 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-200 text-sm font-cinzel">43. Final Product Promise</h4>
                  <span className="text-[10px] text-amber-400 font-bold">Apex Standard</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <strong className="text-amber-300 text-xs">👑 Identity:</strong>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      A social multiplayer Ludo universe with a premium 3D world that players take pride in inhabiting.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <strong className="text-cyan-300 text-xs">🔍 Discovery:</strong>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      Users see enough initially to know the universe is deep, then organically uncover layers of secret mechanics through play.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <strong className="text-emerald-300 text-xs">🏆 Collections:</strong>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      Rare items, Astras, and pets feel genuinely earned, prestigious, and visibly celebrated across the community.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-1">
                    <strong className="text-pink-300 text-xs">✨ Visual Quality:</strong>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      Rich, realistic, polished, and alive — tactile materials and celestial lighting that never feel paper-like or flat.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: PAGE 8 (Items 22 to 26) */}
          {activeTab === 'page-8' && (
            <div className="space-y-3.5">
              {/* Other Entries Header Concept */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">🏎️ Royal & Cinematic Arrivals</h4>
                  <span className="text-[10px] text-amber-400 font-bold">Page 8 Header</span>
                </div>
                <p className="text-slate-300">
                  Hypercar, Cyber-Dragon, Surya Rath chariot, Pink Supercar, and Garuda Wings. Includes 5,000-star Signature Photo lobby entrance with stadium fireworks.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('models');
                  }}
                  className="mt-1 text-[11px] font-black text-amber-300 underline inline-flex items-center gap-1"
                >
                  Inspect Cinematic Models & Entries →
                </button>
              </div>

              {/* 22. 4D / Neon-Liquid Family */}
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-cyan-300 text-sm">22. 4D / Neon-Liquid Family</h4>
                  <span className="text-[10px] text-cyan-400 font-bold">Item 22 · Visual Suite</span>
                </div>
                <p className="text-slate-300">
                  <strong>Visuals:</strong> Liquid-mercury neon buttons, holographic 3D dice, adaptive bioluminescent board, jelly tokens (squash & stretch), victory radial shockwaves, dynamic weather arenas (Clear, Storm, Solar, Aurora), cinematic slow-motion kill-cam, sound-reactive borders, and zero-gravity floating lobby.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('visuals');
                  }}
                  className="mt-1 text-[11px] font-black text-cyan-300 underline inline-flex items-center gap-1"
                >
                  Open 4D Neon-Liquid Suite Controls →
                </button>
              </div>

              {/* 23. Gifts / Social */}
              <div className="p-3.5 rounded-2xl bg-pink-950/40 border border-pink-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-pink-300 text-sm">23. Gifts / Social</h4>
                  <span className="text-[10px] text-pink-400 font-bold">Item 23 · Real Social</span>
                </div>
                <p className="text-slate-300">
                  • <strong>3D Gifts:</strong> Rendered during room chats and seat entry moments.<br />
                  • <strong>Top Gifter:</strong> Public prestige status awarded to top benefactor <em>without exposing the amount spent</em> to safeguard user privacy.<br />
                  • <strong>Voice:</strong> Voice pitch/spatial audio filters (Robot, Deep, Helium, Cinema).<br />
                  • <strong>Chat:</strong> Animated chat frames and quick Hindi/English word packs.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('gifts');
                  }}
                  className="mt-1 text-[11px] font-black text-pink-300 underline inline-flex items-center gap-1"
                >
                  Explore 3D Gift Store →
                </button>
              </div>

              {/* 24. Awards / Leaderboards */}
              <div className="p-3.5 rounded-2xl bg-yellow-950/40 border border-yellow-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-yellow-300 text-sm">24. Awards / Leaderboards</h4>
                  <span className="text-[10px] text-yellow-400 font-bold">Item 24 · Competitive</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Boards:</strong> Daily, Weekly, Monthly, Hall of Fame, Unstoppable, Trophy Wall, and Sunday Tournament.<br />
                  • <strong>Titles:</strong> Goti Killer, Diamond Mafia, Lucky Sixer, plus activity-specific badges.<br />
                  • <strong>Hot Seats:</strong> Small dynamic icons (Flame, Shield, Sword, Crown) communicating current player activity and achievements.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onNavigate('leaderboard');
                  }}
                  className="mt-1 text-[11px] font-black text-yellow-300 underline inline-flex items-center gap-1"
                >
                  View Rankings & Fame Boards →
                </button>
              </div>

              {/* 25. Egg / Name Tag System */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-emerald-300 text-sm">25. Egg / Name Tag System</h4>
                  <span className="text-[10px] text-emerald-400 font-bold">Item 25 · Top 200 Tags</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Tags:</strong> Top 200-style names such as Egg Hunter, Secret Keeper, Matrix Master, God, Live, Z, Butcher, Slaver, Love Birds, Phantom, President, and Vice President.<br />
                  • <strong>Placement:</strong> Displayed across chat/name, profile, seat badges, and cinematic entries.<br />
                  • <strong>Leaderboard:</strong> Weekly Egg #1 receives admin-configurable rewards while spending remains completely private.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('butterfly');
                  }}
                  className="mt-1 text-[11px] font-black text-emerald-300 underline inline-flex items-center gap-1"
                >
                  View Butterfly & Egg Hatchery →
                </button>
              </div>

              {/* 26. Admin Command Center & Login Board */}
              <div className="p-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-red-300 text-sm">26. Admin Command Center & Login Board</h4>
                  <span className="text-[10px] text-red-400 font-bold">Item 26 · Sovereign Security</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Owner:</strong> Unique Sovereign Owner ID <strong>777777</strong> verified with <strong>akvikings05@gmail.com</strong>.<br />
                  • <strong>Player Login Board:</strong> One-time email login remembered in localStorage. User ID is permanently assigned starting sequentially from <strong>#100002</strong> onwards. A dispatch confirmation email is simulated to the user's inbox on creation.<br />
                  • <strong>Weekly Operation:</strong> Checkbox controls for users, rewards, diamonds, stars, gifts, collections, Astra, pets, mini-games, messages, prices, events, and eligibility. Prior default persists if no new configuration.<br />
                  • <strong>Security:</strong> Secure RBAC, audit logs, and rate limits; no hidden backdoors.<br />
                  • <strong>Ghost/Real Mode:</strong> Admin Real Mode and Ghost Mode for discreet moderation/inspection. Locked-room privileged access is audit-logged.<br />
                  • <strong>Recovery:</strong> Secure Gmail login & recovery via akvikings05@gmail.com.
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenModal('auth');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs hover:bg-amber-400 transition shadow"
                  >
                    Open Player Login Board (IDs from 100002+) →
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenModal('admin');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-red-600 text-white font-black text-xs hover:bg-red-500 transition shadow"
                  >
                    Open Sovereign Command Center (#777777) →
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB: PAGE 9 (Items 27 to 31) */}
          {activeTab === 'page-9' && (
            <div className="space-y-3.5">
              {/* 27. Promo Codes */}
              <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-purple-300 text-sm">27. Promo Codes</h4>
                  <span className="text-[10px] text-purple-400 font-bold">Item 27 · Non-Hackable</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Rules:</strong> One-time redemption per user, non-reusable and cryptographic validation.<br />
                  • <strong>Live Ops:</strong> Festival codes (e.g. VIKING777, DIWALI2026, TAKSHAKNAG) can be announced and toggled active/disabled by Admin instantly.
                </p>
              </div>

              {/* 28. Event Engine */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">28. Flexible Event Engine</h4>
                  <span className="text-[10px] text-indigo-400 font-bold">Item 28 · Dynamic Rules</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Flexible Assignment:</strong> Admin can attach rewards/items to any game (Ludo, Carrom, Bow & Arrow, Dot Connect), activity, event, quest, or calendar date.<br />
                  • <strong>Config Fields:</strong> Enable toggle, reward amount, start/end dates, eligible users group, custom congratulation message, entry price, and usage limits.
                </p>
              </div>

              {/* 29. Safety / Moderation */}
              <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-blue-300 text-sm">29. Safety & Moderation</h4>
                  <span className="text-[10px] text-blue-400 font-bold">Item 29 · Astra Safety</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Tools:</strong> Block/report players, private chat filtering, room passkey lock, and audit logging.<br />
                  • <strong>Astra Safety:</strong> Brahmastra remains a limited board-access mechanic (e.g. 10 temporary board holds), <em>never a game-wide account ban</em>.<br />
                  • <strong>Privacy:</strong> Approved avatar/photo only; private mode completely suppresses public reveal of real profile photo in live rooms.
                </p>
              </div>

              {/* 30. 1,000-Level Engagement */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">30. 1,000-Level Engagement Roadmap</h4>
                  <span className="text-[10px] text-amber-400 font-bold">Item 30 · Infinite Retention</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Reason to Continue:</strong> Every single level gives a cosmetic, title, avatar frame, arrival entry, collection progress, achievement badge, or exclusive event access.<br />
                  • <strong>Live Ops:</strong> Weekly tournaments, rare pet discoveries, and seasonal collections ensure the world never feels static.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('pass');
                  }}
                  className="mt-1 text-[11px] font-black text-amber-300 underline inline-flex items-center gap-1"
                >
                  View Season Battle Pass & Level Tracks →
                </button>
              </div>

              {/* 31. 600+ Feature Architecture */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-emerald-300 text-sm">31. 600+ Feature Architecture</h4>
                  <span className="text-[10px] text-emerald-400 font-bold">Item 31 · Scalable Engine</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Data-Driven:</strong> Collections, visual effects, character dialogues, rewards, tutorials, and schedules are reusable systems.<br />
                  • <strong>6 Lifecycle States:</strong> <span className="text-amber-300 font-bold">Locked → Discoverable → Unlocked → Equipped → Used → Mastered</span>.<br />
                  • <strong>Visibility:</strong> Contextual surfaces (board, dice roll, seat interaction, lobby drawer) show relevant features rather than overwhelming the player with 600 cluttered buttons.
                </p>
              </div>
            </div>
          )}

          {/* TAB: PAGE 10 IDEAS (Items 32 to 37) */}
          {activeTab === 'page-10-ideas' && (
            <div className="space-y-4">
              {/* 32. Board-Life Idea Family (20) */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">32. Board-Life Idea Family (20)</h4>
                  <span className="text-[10px] text-indigo-400 font-bold">20 Dynamic Triggers</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Earthquake',
                    'Royal Gate',
                    'Pet Parade',
                    'Lucky Sky',
                    'Token Crown',
                    'Danger Zone',
                    'Hot-Seat Flame',
                    'Comeback Storm',
                    'Royal Carpet',
                    'Drone Camera',
                    'Golden Dice',
                    'Token Laugh',
                    'Victory Meteor',
                    'Board Spotlight',
                    'Pet High-Five',
                    'Confetti Tunnel',
                    'Magic Bridge',
                    'Throne Seat',
                    'Moonlight Board',
                    'Treasure Chest',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-indigo-900/60 border border-indigo-400/30 text-indigo-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>

              {/* 33. Comedy Idea Family (20) */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">33. Comedy Idea Family (20)</h4>
                  <span className="text-[10px] text-amber-400 font-bold">20 Funny Moments</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Goti Slip',
                    'Pet Hide',
                    'Fake Sleep',
                    'Chicken Chase',
                    'Duck Parade',
                    'Banana Peel',
                    'Funny Hammer',
                    'Laugh Bomb',
                    'Mirror Taunt',
                    'Pet Steal',
                    'Sleepy Dice',
                    'Angry Dice',
                    'Goti Taxi',
                    'Rickshaw',
                    'Pet Umbrella',
                    'Flying Chappal',
                    'Mini Chef',
                    'Pet Dance Battle',
                    'Laughing Board',
                    'Oho Reaction',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-amber-900/60 border border-amber-400/30 text-amber-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>

              {/* 34. Astra / Power Idea Family (20) */}
              <div className="p-3.5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-cyan-300 text-sm">34. Astra / Power Idea Family (20)</h4>
                  <span className="text-[10px] text-cyan-400 font-bold">20 Divine Effects</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Trishul Tandav',
                    'Vajra Rain',
                    'Gada Bounce',
                    'Dhanush Arrow Trail',
                    'Chakra Spin',
                    'Astra Museum',
                    'Kill-Cam',
                    'Triple Combo',
                    'Pet + Astra Reaction',
                    'Counter',
                    'Combo Meter',
                    'Mega Combo',
                    'Roulette',
                    'Temple Entry',
                    'Divine Aura',
                    'Shadow',
                    'Lightning Footprint',
                    'Weapon Showcase',
                    'Victory Seal',
                    'Collector Crown',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-cyan-900/60 border border-cyan-400/30 text-cyan-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>

              {/* 35. Pet Idea Family (15) */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-emerald-300 text-sm">35. Pet Idea Family (15)</h4>
                  <span className="text-[10px] text-emerald-400 font-bold">15 Companion Actions</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Mood',
                    'Birthday',
                    'Costume',
                    'Shadow',
                    'Rescue',
                    'Dragon Breath',
                    'Phoenix Flyover',
                    'Eagle Landing',
                    'Wolf Howl',
                    'Elephant Trumpet',
                    'Treasure Hunt',
                    'Sleep Corner',
                    'Twin Reaction',
                    'Collector Wall',
                    'Secret Pet',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-emerald-900/60 border border-emerald-400/30 text-emerald-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>

              {/* 36. Competition Idea Family (15) */}
              <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-rose-300 text-sm">36. Competition Idea Family (15)</h4>
                  <span className="text-[10px] text-rose-400 font-bold">15 Tournament Honors</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Hot-Seat Crown',
                    'Fastest Player',
                    'Comeback King/Queen',
                    'Lucky Sixer',
                    'Cut Master',
                    'Pet Collector',
                    'Astra Master',
                    'Social Star',
                    'Gift Magnet (Private $)',
                    'Talk King/Queen',
                    'Board Boss',
                    'Underdog',
                    'Weekly Challenger',
                    'Record Breaker',
                    'Hall of Legends',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-rose-900/60 border border-rose-400/30 text-rose-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>

              {/* 37. Mind-Blowing Discovery Family (10) */}
              <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-purple-300 text-sm">37. Mind-Blowing Discovery Family (10)</h4>
                  <span className="text-[10px] text-purple-400 font-bold">10 Secret Triggers</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Board Portal',
                    'Mini Cinema',
                    'World Change',
                    'Time Freeze',
                    'Reverse Replay',
                    'Crowd Reaction',
                    'Royal Newspaper',
                    'Secret Combination',
                    'Mystery Door',
                    'Chaos Button (Cosmetics)',
                  ].map((idea, i) => (
                    <span
                      key={idea}
                      className="px-2 py-0.5 rounded-lg bg-purple-900/60 border border-purple-400/30 text-purple-200 text-[10px] font-semibold"
                    >
                      {i + 1}. {idea}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: PAGE 10 WORLD & AWARDS (Items 38 & 39) */}
          {activeTab === 'page-10-world-awards' && (
            <div className="space-y-4">
              {/* 38. Final 10 World Ideas */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">38. Final 10 World Ideas</h4>
                  <span className="text-[10px] text-indigo-400 font-bold">Item 38 · Living Metaverse</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-amber-300">1. Living Board:</strong>
                    <p className="text-[11px] text-slate-300">Sunset → Night → Moonlight → Sunrise with ambient celestial glows.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-indigo-300">2. Board Remembers You:</strong>
                    <p className="text-[11px] text-slate-300">Personalized welcome message and equipped pet greeting upon return.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-rose-300">3. 5-Second Movie Moments:</strong>
                    <p className="text-[11px] text-slate-300">Rare short cinematic scenes that end cleanly and resume instant gameplay.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-cyan-300">4. Impossible Mirror:</strong>
                    <p className="text-[11px] text-slate-300">Mysterious mirror portal revealing hidden cosmetic combinations.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-emerald-300">5. Secret World:</strong>
                    <p className="text-[11px] text-slate-300">Hidden realm unlocked through lifetime achievements & challenges.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-purple-300">6. Collection Fusion:</strong>
                    <p className="text-[11px] text-slate-300">Combine unlocked cosmetics into rare variant frames & dice skins.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-amber-300">7. Player Museum:</strong>
                    <p className="text-[11px] text-slate-300">Personal 3D showroom for rarest pets, Astra, entries, and trophies.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-pink-300">8. Live What-Just-Happened:</strong>
                    <p className="text-[11px] text-slate-300">Instant replay notification ticker when legendary moments occur.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-yellow-300">9. Mystery Hunt:</strong>
                    <p className="text-[11px] text-slate-300">Weekly hidden clues across rooms, mini-games, collections, and dice rolls.</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-0.5">
                    <strong className="text-teal-300">10. The World Map:</strong>
                    <p className="text-[11px] text-slate-300">3D map linking Ludo Kingdom, Games Island, Pet Forest, Astra Temple, Mystery Valley, Collection City, Live Rooms, and Hall of Fame.</p>
                  </div>
                </div>
              </div>

              {/* 39. Year-End Awards */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">39. Year-End Awards (12 Apex Categories)</h4>
                  <span className="text-[10px] text-amber-400 font-bold">Item 39 · Annual Ceremony</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {[
                    'Player of the Year 👑',
                    'Ludo Master 🎲',
                    'Comeback King/Queen ⚡',
                    'Cut Master ⚔️',
                    'Pet Collector 🐉',
                    'Astra Master 🔱',
                    'Balloon Hunter 🎈',
                    'Puzzle Master 🧩',
                    'Social Star 🌟',
                    'Gift Champion 🎁',
                    'Achievement Legend 🏅',
                    'Collection King/Queen 👑',
                  ].map((cat) => (
                    <div key={cat} className="p-1.5 rounded-lg bg-black/40 border border-amber-500/30 text-[10px] text-amber-200 font-bold text-center">
                      {cat}
                    </div>
                  ))}
                </div>
                <p className="text-slate-300 text-[11px]">
                  • <strong>Presentation:</strong> 3D golden trophy, cinematic ceremony announcement, Hall of Fame immortalization, and personalized Year Journey recap video.
                </p>
                {/* Legal & Compliance Notice */}
                <div className="p-2.5 rounded-xl bg-rose-950/50 border border-rose-500/40 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                  <p className="text-[10px] text-rose-200 leading-tight">
                    <strong>Regulatory Notice:</strong> The discussed ₹500 / ₹1,000 / ₹2,000 / ₹4,000 / ₹5,000 / ₹9,999 yearly rewards and ₹50,000+ spender tier concept should only be activated after applicable legal, payment, and promotional compliance review in the Admin Command Center.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB: PAGE 6 & 7 (Items 16 to 21) */}
          {activeTab === 'page-6-7' && (
            <div className="space-y-3">
              {/* Games & Cross Links */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">🎮 Games & Cross-Linked Rewards</h4>
                  <span className="text-[10px] text-amber-300 font-bold">Page 6 Header</span>
                </div>
                <p className="text-slate-300">
                  Ludo, Sudoku, Snake & Ladder, Carrom, Chess, Tic Tac Toe, Spin the Wheel, Bow & Arrow, Dot Connect.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-amber-300 font-bold">Chess / Sudoku</span>
                    <p className="text-[10px] text-slate-400">→ More Pank (Mor Pankh 🦚)</p>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-emerald-300 font-bold">Snake & Ladder</span>
                    <p className="text-[10px] text-slate-400">→ Eggs (Butterfly Eggs 🥚)</p>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5">
                    <span className="text-cyan-300 font-bold">Tic Tac Toe</span>
                    <p className="text-[10px] text-slate-400">→ Butterfly Collection 🦋</p>
                  </div>
                </div>
              </div>

              {/* 16. Bow & Arrow / Takshak */}
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-emerald-300 text-sm">16. Bow & Arrow / Takshak Nag</h4>
                  <span className="text-[10px] text-emerald-400 font-bold">5 Plays/Day · 1 Min</span>
                </div>
                <p className="text-slate-300">
                  Balloons travel horizontally across screen; shoot from below with bow/arrow. Red balloons are valid; black skull balloons must NOT be popped.
                </p>
                <p className="text-[11px] text-emerald-200">
                  ⭐ <strong>Reward & Effect:</strong> 5 successful red balloons → 1 Takshak/Nag collection. Triggers ~1 minute cosmetic board effect where Takshak playfully swallows player pet for 25 seconds as a gag and returns safely. Zero gameplay damage.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('minigames');
                  }}
                  className="mt-1 text-[10px] font-black text-emerald-300 underline"
                >
                  Play Bow & Arrow in Mini-Games →
                </button>
              </div>

              {/* 17. Dot Connect / Chilli */}
              <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-rose-300 text-sm">17. Dot Connect / Chilli</h4>
                  <span className="text-[10px] text-rose-400 font-bold">200 Levels · 10 Chilli/Lvl</span>
                </div>
                <p className="text-slate-300">
                  Connect matching colors without crossing lines across 200 progressive levels. Earn 10 Red Chillies 🌶️ per completed level.
                </p>
                <p className="text-[11px] text-slate-300">
                  👗 <strong>Glamour Characters:</strong> 10–1,000 Chilli tiers for adult fashion/glamorous character cosmetics. Character appears on board for 5 seconds with lighting reveal; dialogue lasts 10 seconds. Two funny lines per character (admin editable). Max 10 uses/day per character (owner has unlimited pass).
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('models');
                  }}
                  className="mt-1 text-[10px] font-black text-rose-300 underline"
                >
                  Open Glamour Models Atelier →
                </button>
              </div>

              {/* 18. Third Eye / Mahabharata-Inspired Astra */}
              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-amber-300 text-sm">18. Third Eye / Mahabharata Astras</h4>
                  <span className="text-[10px] text-amber-400 font-bold">8 Divine Weapons</span>
                </div>
                <p className="text-slate-300">
                  Third Eye collection: Trishul (Tandav board), Hanuman Gada (funny seat wobble), Indra Vajra (lightning/rain weather), Gandiva Dhanush (arrow volley), Surya Rath (solar chariot), Sudarshan Chakra (spinning vortex), Brahmastra (temporary board hold for 10 uses, safety-controlled), and Pashupatastra (rarest apex weapon, future behavior configured by Admin).
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('astra');
                  }}
                  className="mt-1 text-[10px] font-black text-amber-300 underline"
                >
                  View Third Eye Arsenal & Combos →
                </button>
              </div>

              {/* 19. Astra Combos */}
              <div className="p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-purple-300 text-sm">19. Astra Combos & Masti Chains</h4>
                  <span className="text-[10px] text-purple-300 font-bold">Cosmetic Chains</span>
                </div>
                <p className="text-slate-300">
                  • <strong>Mahabharata Tandav Combo:</strong> Trishul → Tandav → Vajra lightning → Gada wobble.<br />
                  • <strong>Nag Masti Combo:</strong> Takshak + Pet + Funny Character.<br />
                  Features cosmetic sequence counter and pet reactions. No unfair gameplay advantage.
                </p>
              </div>

              {/* 20. Tiny Character / Flute / Miracle Arrival */}
              <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-indigo-300 text-sm">20. Tiny Character / Flute / Miracle Arrival</h4>
                  <span className="text-[10px] text-indigo-300 font-bold">Silent · 10 Variants</span>
                </div>
                <p className="text-slate-300">
                  Smaller than pet; travels to target seat and opens a theatre curtain 🎭. Reveals approved avatar/photo for 5 seconds; funny dialogue lasts 10 seconds. Silent: Miracle Arrival has NO sound.
                </p>
                <p className="text-[11px] text-slate-400">
                  10 Variants: Dash Arrival, Royal Curtain, Shadow Curtain, Magic Pocket, Emergency Delivery, Funny Fall, Double Arrival, Pet Escort, Secret Arrival, Miracle Finale. Privacy mode toggle: Avatar only / Approved profile image / Private mode. Flute Collection: 30–50 quest-earned tiny characters.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onOpenModal('flute');
                  }}
                  className="mt-1 text-[10px] font-black text-indigo-300 underline"
                >
                  Open Flute Collection Modal →
                </button>
              </div>

              {/* 21. Entries / Vehicles */}
              <div className="p-3.5 rounded-2xl bg-yellow-950/40 border border-yellow-500/30 space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-yellow-300 text-sm">21. Entries & Signature Vehicles</h4>
                  <span className="text-[10px] text-yellow-400 font-bold">5,000 Stars Unlock</span>
                </div>
                <p className="text-slate-300">
                  Signature Entry: 5,000 stars unlock photo-based cinematic lobby entrance. Other vehicles include Hypercar, Pink Supercar, Cyber-Dragon, Garuda Wings, and Surya Rath.
                </p>
              </div>
            </div>
          )}

          {/* TAB: CORE 1 TO 15 SYSTEMS */}
          {activeTab === 'all-systems' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-indigo-500/30 space-y-1">
                <h4 className="font-black text-indigo-300 text-sm">🌌 1. Cosmic Ludo 3D Arena</h4>
                <p className="text-slate-300">
                  Full 3D physics-based dice rolling, dynamic board lighting, custom camera angles, and celestial star nodes.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-amber-500/30 space-y-1">
                <h4 className="font-black text-amber-300 text-sm">⚡ 2. Divine Astras & 3x Forge Crucible</h4>
                <p className="text-slate-300">
                  Permanent celestial weapons. 3 identical lower-tier copies can be sacrificed in the Forge altar to manifest higher-tier artifacts up to 79 Billion 💎 Sudarshan Chakra.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-1">
                <h4 className="font-black text-emerald-300 text-sm">🦋 3. 30 Ultra-Rare Pets & Butterflies</h4>
                <p className="text-slate-300">
                  One pet per seated player. Earned through extreme milestones and quests. Never purchasable with diamonds.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-pink-500/30 space-y-1">
                <h4 className="font-black text-pink-300 text-sm">🎙️ 4. 8-Seat VIP Voice Stages</h4>
                <p className="text-slate-300">
                  Real-time microphone broadcasting, animated speech rings, dynamic spotlighting, and luxury 3D gifting animations.
                </p>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-1">
                <h4 className="font-black text-cyan-300 text-sm">🎈 5. Balloons & Splash Interactions</h4>
                <p className="text-slate-300">
                  20+ variants (Water balloon, Golden balloon, Rainbow bomb, Firecracker, Ice splash). Cost 2💎 to splash any seated player with funny decals and sound effects.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Quick Jump */}
        <div className="p-3 bg-slate-950/90 border-t border-indigo-500/20 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="text-slate-400">
            Current Profile:{' '}
            <strong className="text-amber-300">akvikings05@gmail.com (ID #777777)</strong>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenModal('auth');
              }}
              className="px-2.5 py-1 rounded-lg bg-amber-500/20 border border-amber-400/40 text-amber-300 font-bold hover:bg-amber-500/30 transition text-[11px]"
            >
              🆔 Login Board
            </button>
            <button
              onClick={() => {
                onClose();
                onOpenModal('admin');
              }}
              className="px-2.5 py-1 rounded-lg bg-red-600/30 border border-red-400/40 text-red-300 font-bold hover:bg-red-600/40 transition text-[11px]"
            >
              🛡️ Sovereign Admin
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
