import React, { useState } from 'react';
import {
  Users,
  Sparkles,
  Zap,
  Gift,
  Trophy,
  Crown,
  Flame,
  Radio,
  Gamepad2,
  BookOpen,
  Box,
  ChevronRight,
  Shield,
  Layers,
  ArrowRight,
  Settings,
  Plus,
  Coins,
  Tv,
  Mail,
  ShoppingBag,
  Award,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import { ASSETS } from '../data/gameConstants';
import {
  RealisticCoinIcon,
  RealisticDiamondIcon,
  RealisticTrophyIcon,
  RealisticCrownIcon,
  RealisticTrishulIcon,
  RealisticBowArrowIcon,
  RealisticFluteIcon,
  RealisticAndroidApkIcon,
  Icon4DWrapper,
} from './RealIcons';

interface LobbyViewProps {
  onStartGame: (mode: 'quick' | 'astra' | 'bot') => void;
  onNavigate: (view: 'lobby' | 'rooms' | 'arena' | 'leaderboard' | 'store' | 'profile') => void;
  onOpenModal: (modal: 'astra' | 'pets' | 'gifts' | 'codex' | 'minigames' | 'crates' | 'admin' | 'models' | 'private-room' | 'pass' | 'collections' | 'apk' | 'butterfly' | 'rules' | 'streak' | 'forge' | 'clan' | 'bible' | 'balloons' | 'couple' | 'flute' | 'visuals' | 'auth' | 'tutorial' | 'missions') => void;
  onOpenWheel: () => void;
  onOpenDrawer: () => void;
  userDiamonds: number;
  userCoins: number;
  equippedAstra: string;
}

export const LobbyView: React.FC<LobbyViewProps> = ({
  onStartGame,
  onNavigate,
  onOpenModal,
  onOpenWheel,
  onOpenDrawer,
  userDiamonds,
  userCoins,
}) => {
  return (
    <div className="w-full max-w-md mx-auto space-y-3 pb-24 animate-fade-in px-3">
      {/* 1. TOP MOBILE GAME BAR (Matching Screenshot 1) */}
      <div className="flex items-center justify-between gap-1 p-2 rounded-2xl glass-panel border border-white/10 shadow-lg">
        {/* Profile Avatar Pill */}
        <div
          onClick={() => {
            sound.playClick();
            onNavigate('profile');
          }}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="relative w-10 h-10 rounded-full border-2 border-amber-400 overflow-hidden shadow-[0_0_10px_rgba(251,191,36,0.6)]">
            <img
              src={ASSETS.hostAnanya}
              alt="Ananya"
              className="w-full h-full object-cover"
            />
            <span className="absolute bottom-0 right-0 px-1 rounded-full bg-red-600 text-[8px] font-black text-white">
              31
            </span>
          </div>
        </div>

        {/* Currency Counters */}
        <div className="flex items-center gap-1.5">
          {/* Gold Coins */}
          <div
            onClick={() => {
              sound.playClick();
              onNavigate('store');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 border border-amber-400/40 text-xs font-black cursor-pointer shadow-inner"
          >
            <RealisticCoinIcon size={18} />
            <span className="text-amber-200">
              {userCoins >= 1000000 ? `${(userCoins / 1000000).toFixed(1)}M` : `${Math.floor(userCoins / 1000)}K`}
            </span>
            <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-[10px] font-black shadow-sm">
              +
            </span>
          </div>

          {/* Diamonds */}
          <div
            onClick={() => {
              sound.playClick();
              onNavigate('store');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/90 border border-cyan-400/40 text-xs font-black cursor-pointer shadow-inner"
          >
            <RealisticDiamondIcon size={18} />
            <span className="text-cyan-200">
              {userDiamonds >= 1000000 ? `${(userDiamonds / 1000000).toFixed(1)}M` : userDiamonds.toLocaleString()}
            </span>
            <span className="w-4 h-4 rounded-full bg-cyan-500 text-slate-950 flex items-center justify-center text-[10px] font-black shadow-sm">
              +
            </span>
          </div>

          {/* Settings / Admin */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenModal('admin');
            }}
            className="p-1.5 rounded-full bg-white/5 border border-white/10 text-slate-300 hover:text-white transition"
          >
            <Settings size={18} />
          </button>
        </div>
      </div>

      {/* APK & ZIP Mobile Install Banner */}
      <div
        onClick={() => {
          sound.playFanfare();
          onOpenModal('apk');
        }}
        className="p-2 px-3 rounded-2xl bg-gradient-to-r from-amber-600/30 via-slate-900 to-emerald-700/30 border border-amber-400/50 flex items-center justify-between cursor-pointer hover:border-amber-300 transition hover:scale-[1.02] active:scale-95 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center text-base shadow border border-amber-300">
            📦
          </div>
          <div>
            <p className="text-xs font-black text-amber-300 flex items-center gap-1.5">
              <span>Download ZIP & Android APK</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 font-black">
                OFFLINE + LIVE
              </span>
            </p>
            <p className="text-[10px] text-slate-300">Web2App Offline ZIP (2.6MB) + Full Source</p>
          </div>
        </div>
        <span className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-black text-[10px] uppercase tracking-wider shadow-sm">
          Get ZIP / APK
        </span>
      </div>

      {/* Quick Bible Page 6 & 7 Features Row (Items 16, 20, 22) */}
      <div className="grid grid-cols-3 gap-1.5">
        <div
          onClick={() => {
            sound.playClick();
            onOpenModal('minigames');
          }}
          className="p-2 rounded-2xl bg-gradient-to-b from-amber-950/70 to-slate-900 border border-amber-500/40 text-center cursor-pointer hover:border-amber-400 transition hover:scale-105 active:scale-95 group shadow-sm flex flex-col items-center justify-center"
        >
          <RealisticBowArrowIcon size={24} className="group-hover:scale-110 transition" />
          <p className="text-[10px] font-black text-amber-300 mt-0.5">Bow & Takshak</p>
          <p className="text-[8px] text-slate-400">Mini-Games (16)</p>
        </div>

        <div
          onClick={() => {
            sound.playClick();
            onOpenModal('flute');
          }}
          className="p-2 rounded-2xl bg-gradient-to-b from-purple-950/70 to-slate-900 border border-purple-500/40 text-center cursor-pointer hover:border-purple-400 transition hover:scale-105 active:scale-95 group shadow-sm flex flex-col items-center justify-center"
        >
          <RealisticFluteIcon size={24} className="group-hover:scale-110 transition" />
          <p className="text-[10px] font-black text-purple-300 mt-0.5">Flute Tiny (30+)</p>
          <p className="text-[8px] text-slate-400">Curtains (20)</p>
        </div>

        <div
          onClick={() => {
            sound.playClick();
            onOpenModal('visuals');
          }}
          className="p-2 rounded-2xl bg-gradient-to-b from-cyan-950/70 to-slate-900 border border-cyan-500/40 text-center cursor-pointer hover:border-cyan-400 transition hover:scale-105 active:scale-95 group shadow-sm flex flex-col items-center justify-center"
        >
          <RealisticDiamondIcon size={22} className="group-hover:scale-110 transition" />
          <p className="text-[10px] font-black text-cyan-300 mt-0.5">4D Neon Suite</p>
          <p className="text-[8px] text-slate-400">Holo & Weather (22)</p>
        </div>
      </div>

      {/* 2. LEAGUE, RANK & PASS BAR (Screenshot 1) */}
      <div className="grid grid-cols-5 gap-1 text-center">
        <div
          onClick={() => {
            sound.playClick();
            onNavigate('leaderboard');
          }}
          className="p-1.5 rounded-xl bg-gradient-to-b from-blue-900/40 to-slate-900/70 border border-blue-500/30 cursor-pointer"
        >
          <div className="flex items-center justify-center gap-0.5 text-amber-400 text-[10px] font-black">
            <Crown size={11} />
            <span>LEAGUE</span>
          </div>
          <p className="text-[10px] font-black text-white">NO. 1</p>
        </div>

        <div
          onClick={() => {
            sound.playClick();
            onNavigate('leaderboard');
          }}
          className="p-1.5 rounded-xl bg-gradient-to-b from-blue-900/40 to-slate-900/70 border border-blue-500/30 cursor-pointer"
        >
          <div className="flex items-center justify-center gap-0.5 text-cyan-400 text-[10px] font-black">
            <span>🌍</span>
            <span>RANK</span>
          </div>
          <p className="text-[10px] font-black text-white">NO. 7</p>
        </div>

        <div
          onClick={() => {
            sound.playFanfare();
            onOpenModal('pass');
          }}
          className="p-1.5 rounded-xl bg-gradient-to-b from-amber-900/60 to-slate-900/70 border border-amber-400/50 cursor-pointer hover:border-amber-300 transition-all hover:scale-105 active:scale-95 group shadow-[0_0_15px_rgba(245,158,11,0.3)]"
        >
          <div className="flex items-center justify-center gap-0.5 text-amber-300 text-[10px] font-black">
            <Crown size={11} className="text-yellow-400 animate-pulse" />
            <span>PASS</span>
          </div>
          <p className="text-[10px] font-black text-amber-300 group-hover:text-yellow-200">LV. 4</p>
        </div>

        <div
          onClick={() => {
            sound.playFanfare();
            onOpenWheel();
          }}
          className="p-1.5 rounded-xl bg-gradient-to-b from-emerald-900/40 to-slate-900/70 border border-emerald-500/30 cursor-pointer hover:border-emerald-400 transition"
        >
          <span className="text-xs">🌳</span>
          <p className="text-[10px] font-black text-emerald-300">SPIN</p>
        </div>

        <div
          onClick={() => {
            sound.playGrandVictory();
            onOpenModal('streak');
          }}
          className="p-1.5 rounded-xl bg-gradient-to-b from-yellow-900/60 to-slate-900/70 border border-yellow-400/50 cursor-pointer hover:border-yellow-300 transition-all hover:scale-105 active:scale-95 group shadow-[0_0_12px_rgba(234,179,8,0.3)]"
        >
          <div className="flex items-center justify-center gap-0.5 text-yellow-300 text-[10px] font-black">
            <span>📅</span>
            <span>DAY 3</span>
          </div>
          <p className="text-[9px] font-black text-emerald-300 group-hover:text-yellow-200">CLAIM</p>
        </div>
      </div>

      {/* 3. HERO CENTERPIECE: 3D "LUDO PLAY" EMBOSSED TITLE & GRAPHIC */}
      <div className="relative py-2 flex flex-col items-center justify-center">
        {/* Glowing cosmic stars */}
        <div className="absolute inset-0 bg-gradient-to-b from-amber-500/10 via-purple-600/15 to-transparent rounded-3xl blur-2xl pointer-events-none" />

        {/* 3D Title Graphic Logo */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="w-48 sm:w-56 h-28 sm:h-32 rounded-2xl overflow-hidden drop-shadow-[0_8px_20px_rgba(245,158,11,0.5)]">
            <img
              src={ASSETS.logo}
              alt="LUDO PLAY"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Subtitle Ribbon */}
          <div className="px-4 py-0.5 rounded-full bg-gradient-to-r from-purple-800 via-indigo-700 to-purple-800 border border-amber-400/50 shadow-md -mt-2">
            <span className="text-[11px] font-black tracking-wider text-amber-200 uppercase drop-shadow">
              ✦ Roll, Play & Win Together ✦
            </span>
          </div>
        </div>
      </div>

      {/* 4. CHUNKY 3D ARCADE PLAY BUTTONS (Exact 1:1 match with Screenshot 1!) */}
      <div className="space-y-3">
        {/* Row 1: Big 3D "PLAY ONLINE" (Yellow) & "ROOM" (Orange) Buttons */}
        <div className="grid grid-cols-2 gap-3">
          {/* PLAY ONLINE 3D BUTTON */}
          <button
            onClick={() => {
              sound.playDiceRoll();
              onStartGame('quick');
            }}
            className="btn-3d-yellow rounded-3xl p-3 flex flex-col items-center justify-between h-36 cursor-pointer text-slate-950 font-black relative overflow-hidden group"
          >
            {/* 3D Earth Globe Asset */}
            <div className="w-20 h-20 rounded-2xl overflow-hidden group-hover:scale-105 transition">
              <img
                src={ASSETS.playOnline}
                alt="Play Online"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full text-center">
              <span className="text-sm font-black tracking-wide text-slate-950 drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)] uppercase">
                PLAY ONLINE
              </span>
            </div>
          </button>

          {/* ROOM 3D BUTTON */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenModal('private-room');
            }}
            className="btn-3d-orange rounded-3xl p-3 flex flex-col items-center justify-between h-36 cursor-pointer text-white font-black relative overflow-hidden group"
          >
            {/* 3D Pawns & Dice Asset */}
            <div className="w-20 h-20 rounded-2xl overflow-hidden group-hover:scale-105 transition">
              <img
                src={ASSETS.roomPawns}
                alt="Room"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full text-center">
              <span className="text-sm font-black tracking-wide text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] uppercase">
                PRIVATE ROOM
              </span>
            </div>
          </button>
        </div>

        {/* Row 2: Trio of 3D Buttons: VS TEAM (Green), VS COMPUTER (Blue), VS FRIEND (Purple) */}
        <div className="grid grid-cols-3 gap-2">
          {/* VS TEAM (Green) */}
          <button
            onClick={() => {
              sound.playDiceRoll();
              onStartGame('astra');
            }}
            className="btn-3d-green rounded-2xl p-2.5 flex flex-col items-center justify-center gap-1.5 h-24 cursor-pointer text-white font-black group"
          >
            <span className="text-2xl group-hover:scale-110 transition">👥</span>
            <span className="text-[11px] font-black uppercase tracking-wider text-white drop-shadow">
              VS TEAM
            </span>
          </button>

          {/* VS COMPUTER (Blue) */}
          <button
            onClick={() => {
              sound.playDiceRoll();
              onStartGame('bot');
            }}
            className="btn-3d-blue rounded-2xl p-2.5 flex flex-col items-center justify-center gap-1.5 h-24 cursor-pointer text-white font-black group"
          >
            <span className="text-2xl group-hover:scale-110 transition">🤖</span>
            <span className="text-[11px] font-black uppercase tracking-wider text-white drop-shadow">
              VS COMPUTER
            </span>
          </button>

          {/* VS FRIEND (Purple) */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenModal('private-room');
            }}
            className="btn-3d-purple rounded-2xl p-2.5 flex flex-col items-center justify-center gap-1.5 h-24 cursor-pointer text-white font-black group"
          >
            <span className="text-2xl group-hover:scale-110 transition">🎮</span>
            <span className="text-[11px] font-black uppercase tracking-wider text-white drop-shadow">
              VS FRIEND
            </span>
          </button>
        </div>
      </div>

      {/* 5. GRAND COLLECTIONS VAULT (महारत्न महा-संग्रहालय) */}
      <div className="p-3 rounded-3xl bg-gradient-to-br from-amber-950/60 via-purple-950/50 to-slate-950 border-2 border-amber-400/50 shadow-[0_0_25px_rgba(245,158,11,0.25)] flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 text-base shadow-sm">
              🏛️
            </span>
            <div>
              <h3 className="text-xs font-black text-amber-300 flex items-center gap-1.5 uppercase tracking-wide">
                <span>Collections Vault</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-yellow-300 border border-amber-400/40 font-bold">
                  महारत्न
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">14 Astras · 30 Pets · Hypercars · Dice</p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playGrandVictory();
              onOpenModal('collections');
            }}
            className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-[10px] uppercase tracking-wider flex items-center gap-1 shadow-md active:scale-95 transition cursor-pointer"
          >
            <span>Open Vault</span>
            <ChevronRight size={12} />
          </button>
        </div>

        {/* 5 Mini Collection Highlight Badges */}
        <div className="grid grid-cols-5 gap-1.5">
          {/* Astras */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('collections');
            }}
            className="p-1.5 rounded-2xl bg-black/40 hover:bg-black/60 border border-amber-500/30 text-center cursor-pointer transition hover:scale-105 active:scale-95 group"
          >
            <span className="text-lg group-hover:scale-110 inline-block transition">🔱</span>
            <p className="text-[9px] font-black text-amber-300 mt-0.5">14 Astras</p>
            <p className="text-[7px] text-slate-400 font-bold truncate">Trishul</p>
          </div>

          {/* Pets */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('collections');
            }}
            className="p-1.5 rounded-2xl bg-black/40 hover:bg-black/60 border border-cyan-500/30 text-center cursor-pointer transition hover:scale-105 active:scale-95 group"
          >
            <span className="text-lg group-hover:scale-110 inline-block transition">🐉</span>
            <p className="text-[9px] font-black text-cyan-300 mt-0.5">30 Pets</p>
            <p className="text-[7px] text-slate-400 font-bold truncate">Dragon</p>
          </div>

          {/* Butterflies & Eggs */}
          <div
            onClick={() => {
              sound.playFanfare();
              onOpenModal('butterfly');
            }}
            className="p-1.5 rounded-2xl bg-gradient-to-b from-emerald-950/80 to-slate-900 hover:from-emerald-900 border border-emerald-400/50 text-center cursor-pointer transition hover:scale-105 active:scale-95 group shadow-[0_0_10px_rgba(16,185,129,0.3)]"
          >
            <span className="text-lg group-hover:scale-110 inline-block transition animate-bounce">🦋</span>
            <p className="text-[9px] font-black text-emerald-300 mt-0.5">12 Wings</p>
            <p className="text-[7px] text-yellow-300 font-bold truncate">Egg Hatch</p>
          </div>

          {/* Hypercars */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('collections');
            }}
            className="p-1.5 rounded-2xl bg-black/40 hover:bg-black/60 border border-pink-500/30 text-center cursor-pointer transition hover:scale-105 active:scale-95 group"
          >
            <span className="text-lg group-hover:scale-110 inline-block transition">🏎️</span>
            <p className="text-[9px] font-black text-pink-300 mt-0.5">12 Cars</p>
            <p className="text-[7px] text-slate-400 font-bold truncate">Bugatti</p>
          </div>

          {/* Dice & Frames */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('collections');
            }}
            className="p-1.5 rounded-2xl bg-black/40 hover:bg-black/60 border border-purple-500/30 text-center cursor-pointer transition hover:scale-105 active:scale-95 group"
          >
            <span className="text-lg group-hover:scale-110 inline-block transition">🎲</span>
            <p className="text-[9px] font-black text-purple-300 mt-0.5">6 Dice</p>
            <p className="text-[7px] text-slate-400 font-bold truncate">Gold</p>
          </div>
        </div>

        {/* Dual Direct Cards: Butterfly Egg Hatchery & Game Niyam (खेल के नियम) */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-amber-500/20">
          <div
            onClick={() => {
              sound.playFanfare();
              onOpenModal('butterfly');
            }}
            className="p-2 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-slate-900 border border-emerald-400/40 flex items-center justify-between cursor-pointer hover:border-emerald-300 transition group"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-lg">
                🦋
              </div>
              <div>
                <p className="text-[10px] font-black text-emerald-300 group-hover:text-emerald-200">
                  Butterfly Egg Hatchery
                </p>
                <p className="text-[8px] text-slate-400">तितली अंडा व साथी वरदान</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-emerald-400" />
          </div>

          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('rules');
            }}
            className="p-2 rounded-2xl bg-gradient-to-r from-amber-950/70 to-slate-900 border border-amber-400/40 flex items-center justify-between cursor-pointer hover:border-amber-300 transition group"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-lg">
                📜
              </div>
              <div>
                <p className="text-[10px] font-black text-amber-300 group-hover:text-yellow-200">
                  Game Niyam (नियम)
                </p>
                <p className="text-[8px] text-slate-400">लूडो, अस्त्र व अंडा नियम</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-amber-400" />
          </div>
        </div>

        {/* LUDO MASTER GAME BIBLE (Pages 1 to 10 · Items 1 to 39 Reference Banner) */}
        <div
          onClick={() => {
            sound.playGrandVictory();
            onOpenModal('bible');
          }}
          className="mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-amber-950/80 border-2 border-amber-400/60 flex items-center justify-between cursor-pointer hover:border-yellow-300 hover:scale-[1.01] transition shadow-[0_0_15px_rgba(245,158,11,0.25)] group"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-xl border border-amber-200 shadow-md">
              📖
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-black text-amber-200 group-hover:text-yellow-100">
                  Ludo Master Game Bible (Pages 1–10)
                </p>
                <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black">
                  ITEMS 1–39 VERIFIED
                </span>
              </div>
              <p className="text-[9px] text-slate-300">
                Astras • 4D Neon • Admin #777777 • Promo Codes • 7 Idea Families • Year-End Awards
              </p>
            </div>
          </div>
          <ChevronRight size={16} className="text-amber-400 group-hover:translate-x-0.5 transition" />
        </div>

        {/* INTERACTIVE GAME TUTORIAL (Bible Item 40: Watch or Skip) */}
        <div
          onClick={() => {
            sound.playClick();
            onOpenModal('tutorial');
          }}
          className="mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-purple-950/80 border border-indigo-500/40 flex items-center justify-between cursor-pointer hover:border-indigo-300 hover:scale-[1.01] transition shadow-sm group"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xl border border-indigo-300 shadow-md">
              🎓
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-black text-indigo-200 group-hover:text-purple-100">
                  Interactive Game Tutorial (Watch or Skip)
                </p>
                <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 font-black">
                  ITEM 40 FAST
                </span>
              </div>
              <p className="text-[9px] text-slate-300">
                5 Steps • Readability & Token Clarity • Audio Balance • Sovereign Auth
              </p>
            </div>
          </div>
          <ChevronRight size={16} className="text-indigo-400 group-hover:translate-x-0.5 transition" />
        </div>

        {/* OFFICIAL MISSION & QUEST BOARD (Bible Section 19) */}
        <div
          onClick={() => {
            sound.playClick();
            onOpenModal('missions');
          }}
          className="mt-2 p-2.5 rounded-2xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-orange-950/80 border border-amber-500/40 flex items-center justify-between cursor-pointer hover:border-amber-300 hover:scale-[1.01] transition shadow-sm group"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-xl border border-amber-300 shadow-md">
              📋
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-xs font-black text-amber-200 group-hover:text-yellow-100">
                  Mission & Quest Board
                </p>
                <span className="text-[8px] px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-black">
                  BIBLE ITEM 19
                </span>
              </div>
              <p className="text-[9px] text-slate-300">
                Daily, Weekly, Festival Quests & Lifetime Achievements
              </p>
            </div>
          </div>
          <ChevronRight size={16} className="text-amber-400 group-hover:translate-x-0.5 transition" />
        </div>

        {/* Dual Cards: Player Login Board (Bible 26) + Sovereign Command Center (Bible 26) */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('auth');
            }}
            className="p-2 rounded-2xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-900 border border-amber-500/40 cursor-pointer hover:border-amber-300 transition group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">🆔</span>
              <div>
                <p className="text-[11px] font-black text-amber-300">Login Board</p>
                <p className="text-[8px] text-slate-400">Email & IDs #100002+</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-amber-400 group-hover:translate-x-0.5 transition" />
          </div>

          <div
            onClick={() => {
              sound.playClick();
              onOpenModal('admin');
            }}
            className="p-2 rounded-2xl bg-gradient-to-br from-red-950/60 via-slate-900 to-slate-900 border border-red-500/40 cursor-pointer hover:border-red-300 transition group flex items-center justify-between shadow-sm"
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">🛡️</span>
              <div>
                <p className="text-[11px] font-black text-red-300">Admin Center</p>
                <p className="text-[8px] text-slate-400">Owner #777777 & RBAC</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-red-400 group-hover:translate-x-0.5 transition" />
          </div>
        </div>

        {/* Dual Cards: Balloons & Splash (Bible 11) + Couple & Birthday (Bible 14) */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          <div
            onClick={() => {
              sound.playTokenHop(2);
              onOpenModal('balloons');
            }}
            className="p-2 rounded-2xl bg-gradient-to-r from-rose-950/70 to-slate-900 border border-rose-500/40 flex items-center justify-between cursor-pointer hover:border-rose-400 transition group"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-500/20 border border-rose-400 flex items-center justify-center text-lg">
                🎈
              </div>
              <div>
                <p className="text-[10px] font-black text-rose-300 group-hover:text-pink-200">
                  Balloons & Mud (2💎)
                </p>
                <p className="text-[8px] text-slate-400">20+ Splash Decals</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-rose-400" />
          </div>

          <div
            onClick={() => {
              sound.playGrandVictory();
              onOpenModal('couple');
            }}
            className="p-2 rounded-2xl bg-gradient-to-r from-pink-950/70 to-slate-900 border border-pink-500/40 flex items-center justify-between cursor-pointer hover:border-pink-400 transition group"
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-pink-500/20 border border-pink-400 flex items-center justify-center text-lg">
                💞
              </div>
              <div>
                <p className="text-[10px] font-black text-pink-300 group-hover:text-rose-200">
                  Couple & Birthday
                </p>
                <p className="text-[8px] text-slate-400">10 Double Hearts</p>
              </div>
            </div>
            <ChevronRight size={14} className="text-pink-400" />
          </div>
        </div>
      </div>

      {/* 6. QUICK ACTION BARS: 500 COINS AD & LIVE CHATROOM MICROPHONE (Screenshot 1) */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        {/* Free Coins Gift Chest */}
        <div
          onClick={() => {
            sound.playFanfare();
            onOpenModal('crates');
          }}
          className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-600/40 via-purple-900/60 to-slate-900 border border-amber-400/40 flex items-center justify-between cursor-pointer hover:border-amber-300 transition shadow-lg"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎁</span>
            <div>
              <p className="text-[10px] font-black text-amber-300">FREE COINS</p>
              <p className="text-xs font-black text-white">🪙 +500</p>
            </div>
          </div>
          <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black">
            CLAIM
          </span>
        </div>

        {/* Live Audio Chatroom Badge */}
        <div
          onClick={() => {
            sound.playFanfare();
            onNavigate('rooms');
          }}
          className="p-2.5 rounded-2xl bg-gradient-to-r from-purple-600/40 via-pink-600/40 to-slate-900 border border-purple-400/40 flex items-center justify-between cursor-pointer hover:border-purple-300 transition shadow-lg"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl animate-pulse">🎙️</span>
            <div>
              <p className="text-[10px] font-black text-purple-300">VOICE ROOM</p>
              <p className="text-xs font-black text-white">CHATROOM</p>
            </div>
          </div>
          <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[9px] font-black animate-ping">
            ●
          </span>
        </div>

        {/* Dice Forge Card */}
        <div
          onClick={() => {
            sound.playForgeStart();
            onOpenModal('forge');
          }}
          className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-600/40 via-orange-900/60 to-slate-900 border border-amber-400/40 flex items-center justify-between cursor-pointer hover:border-amber-300 transition shadow-lg group"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl group-hover:scale-110 transition">⚒️</span>
            <div>
              <p className="text-[10px] font-black text-amber-300">DICE FORGE</p>
              <p className="text-xs font-black text-white">ENCHANT</p>
            </div>
          </div>
          <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[9px] font-black">
            RUNES
          </span>
        </div>

        {/* Clan Wars Card */}
        <div
          onClick={() => {
            sound.playGrandVictory();
            onOpenModal('clan');
          }}
          className="p-2.5 rounded-2xl bg-gradient-to-r from-red-600/40 via-amber-900/60 to-slate-900 border border-red-400/40 flex items-center justify-between cursor-pointer hover:border-red-300 transition shadow-lg group"
        >
          <div className="flex items-center gap-2">
            <span className="text-2xl group-hover:scale-110 transition">⚔️</span>
            <div>
              <p className="text-[10px] font-black text-red-300">CLAN WARS</p>
              <p className="text-xs font-black text-white">WEEKLY WAR</p>
            </div>
          </div>
          <span className="px-1.5 py-0.5 rounded-full bg-red-500 text-white text-[9px] font-black">
            WAR
          </span>
        </div>
      </div>

      {/* 6. + MORE UNIVERSE (700+ Master Plan Hub Access) */}
      <div
        onClick={() => {
          sound.playClick();
          onOpenDrawer();
        }}
        className="p-2.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-purple-950/80 to-slate-950 border border-amber-400/30 flex items-center justify-between cursor-pointer hover:border-amber-400 transition"
      >
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400">
            <Layers size={18} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Cosmic Universe & 700+ Hub</h4>
            <p className="text-[10px] text-slate-400">30 Rare Pets · Astras · Mini-Games · Codex</p>
          </div>
        </div>
        <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
          Open Hub <ChevronRight size={14} />
        </span>
      </div>
    </div>
  );
};
