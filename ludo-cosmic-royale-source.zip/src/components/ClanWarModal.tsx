import React from 'react';
import { X, Shield, Swords, Crown, Trophy, Users, Zap } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface ClanWarModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onStartClanMatch: () => void;
}

export const ClanWarModal: React.FC<ClanWarModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onStartClanMatch,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-red-500/50 rounded-3xl bg-gradient-to-b from-[#200a0d] via-[#10070b] to-black text-slate-100 shadow-[0_0_50px_rgba(239,68,68,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-red-700/40 via-rose-700/30 to-slate-900 border-b border-red-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-500 to-rose-700 flex items-center justify-center text-2xl shadow-lg border border-red-400">
              ⚔️
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-300 via-rose-200 to-amber-300">
                Royal Clans & War Sanctuary
              </h3>
              <p className="text-xs text-slate-300">
                Guild tournaments, clan trophies & team battles
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Active Clan Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-red-950/70 via-slate-900 to-black border border-red-500/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-400/40">
                ACTIVE CLAN: VIKING ROYALS
              </span>
              <span className="text-xs text-amber-300 font-bold flex items-center gap-1">
                <Trophy size={13} /> Tier 1
              </span>
            </div>

            <p className="text-xs text-slate-300">
              Fight alongside your clan members in Astra War Arena to earn exclusive crowns and seasonal clan rewards!
            </p>

            <button
              onClick={() => {
                sound.playGrandVictory();
                onClose();
                onStartClanMatch();
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-500 hover:from-red-500 hover:to-rose-400 text-white font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg active:scale-95 transition cursor-pointer"
            >
              <Swords size={18} />
              <span>Enter Clan War Match</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
