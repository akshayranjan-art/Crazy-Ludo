import React, { useState, useEffect } from 'react';
import {
  X,
  Target,
  Disc,
  RefreshCw,
  Trophy,
  Flame,
  AlertCircle,
  Sparkles,
  ChevronRight,
  Award,
  Zap,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';
import {
  RealisticArcadeTargetIcon,
  RealisticBowArrowIcon,
  RealisticCoinIcon,
  RealisticDiamondIcon,
} from './RealIcons';

interface MiniGamesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEarnReward: (coins: number, diamonds: number, message: string) => void;
  onOpenModels?: () => void;
  onAwardTakshakNag?: () => void;
  onAwardMorPankh?: (amt: number) => void;
  onAwardEggs?: (amt: number) => void;
  onAwardButterfly?: () => void;
  onTriggerTakshakBoard?: () => void;
  onAddChilli?: (amt: number) => void;
  userChillies?: number;
}

type MiniGameTab =
  | 'bow-arrow'
  | 'dot-connect'
  | 'carrom'
  | 'sudoku'
  | 'chess'
  | 'snake-ladder'
  | 'tictactoe'
  | 'spin-wheel';

interface CarromCoin {
  id: number;
  type: 'white' | 'black' | 'queen';
  x: number;
  y: number;
  pocketed: boolean;
}

export const MiniGamesModal: React.FC<MiniGamesModalProps> = ({
  isOpen,
  onClose,
  onEarnReward,
  onOpenModels,
  onAwardTakshakNag,
  onAwardMorPankh,
  onAwardEggs,
  onAwardButterfly,
  onTriggerTakshakBoard,
  onAddChilli,
  userChillies = 75,
}) => {
  const [activeGame, setActiveGame] = useState<MiniGameTab>('bow-arrow');

  // ==========================================
  // 16. BOW & ARROW / TAKSHAK STATE
  // ==========================================
  const [bowScore, setBowScore] = useState(0);
  const [redBalloonsPopped, setRedBalloonsPopped] = useState(0);
  const [bowGameActive, setBowGameActive] = useState(false);
  const [bowTimeRemaining, setBowTimeRemaining] = useState(60); // 1 minute limit (Bible Item 16)
  const [bowPosition, setBowPosition] = useState(50); // Bow horizontal position (percentage 10-90)
  const [dailyBowPlays, setDailyBowPlays] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('ludo_daily_bow_plays');
      return saved ? parseInt(saved, 10) : 1;
    } catch {
      return 1;
    }
  });
  const [balloons, setBalloons] = useState<
    Array<{ id: number; color: 'red' | 'black' | 'gold'; x: number; y: number; speed: number; popped: boolean }>
  >([]);

  // ==========================================
  // 17. DOT CONNECT / CHILLI (200 LEVELS)
  // ==========================================
  const [chilliLevel, setChilliLevel] = useState(1);
  const [colorNodes, setColorNodes] = useState<{ id: number; color: string; connected: boolean; name: string }[]>([
    { id: 1, color: '#ef4444', connected: false, name: 'Red' },
    { id: 2, color: '#3b82f6', connected: false, name: 'Blue' },
    { id: 3, color: '#10b981', connected: false, name: 'Green' },
    { id: 4, color: '#f59e0b', connected: false, name: 'Gold' },
  ]);
  const [dotConnectMessage, setDotConnectMessage] = useState<string | null>(null);

  // ==========================================
  // CARROM STATE (Page 6)
  // ==========================================
  const [strikerX, setStrikerX] = useState(50);
  const [strikerAngle, setStrikerAngle] = useState(0);
  const [strikerPower, setStrikerPower] = useState(70);
  const [carromScore, setCarromScore] = useState(0);
  const [carromCoins, setCarromCoins] = useState<CarromCoin[]>([
    { id: 1, type: 'queen', x: 50, y: 50, pocketed: false },
    { id: 2, type: 'white', x: 44, y: 46, pocketed: false },
    { id: 3, type: 'white', x: 56, y: 54, pocketed: false },
    { id: 4, type: 'black', x: 44, y: 54, pocketed: false },
    { id: 5, type: 'black', x: 56, y: 46, pocketed: false },
    { id: 6, type: 'white', x: 50, y: 42, pocketed: false },
    { id: 7, type: 'black', x: 50, y: 58, pocketed: false },
  ]);
  const [carromMessage, setCarromMessage] = useState<string | null>(null);

  // ==========================================
  // SUDOKU & CHESS (Links: Mor Pankh)
  // ==========================================
  const [sudokuGrid, setSudokuGrid] = useState<(number | null)[]>([
    5, 3, null, null, 7, null, null, null, null,
    6, null, null, 1, 9, 5, null, null, null,
    null, 9, 8, null, null, null, null, 6, null,
  ]);
  const [chessPuzzleSolved, setChessPuzzleSolved] = useState(false);

  // ==========================================
  // SNAKE & LADDER (Links: Eggs)
  // ==========================================
  const [snakePos, setSnakePos] = useState(1);
  const [snakeDice, setSnakeDice] = useState<number | null>(null);

  // ==========================================
  // TIC TAC TOE (Links: Butterfly Collection)
  // ==========================================
  const [tttBoard, setTttBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [tttWinner, setTttWinner] = useState<string | null>(null);

  // ==========================================
  // SPIN WHEEL
  // ==========================================
  const [isSpinning, setIsSpinning] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);
  const [spinReward, setSpinReward] = useState<string | null>(null);

  // 1-minute countdown timer & traveling balloons for Bow & Arrow
  useEffect(() => {
    if (!bowGameActive) return;

    const timer = setInterval(() => {
      setBowTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          finishBowGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Floating balloons horizontal travel across the screen (Bible Item 16)
    const floatInterval = setInterval(() => {
      setBalloons((prev) =>
        prev.map((b) => {
          let nextX = b.x + b.speed;
          if (nextX > 92) nextX = 5;
          return { ...b, x: nextX };
        })
      );
    }, 80);

    return () => {
      clearInterval(timer);
      clearInterval(floatInterval);
    };
  }, [bowGameActive, redBalloonsPopped]);

  if (!isOpen) return null;

  // ------------------------------------------
  // BOW & ARROW HANDLERS
  // ------------------------------------------
  const startBowGame = () => {
    if (dailyBowPlays >= 5) {
      sound.playError();
      return;
    }

    setBowScore(0);
    setRedBalloonsPopped(0);
    setBowTimeRemaining(60);
    setBowGameActive(true);

    const newPlays = dailyBowPlays + 1;
    setDailyBowPlays(newPlays);
    try {
      localStorage.setItem('ludo_daily_bow_plays', newPlays.toString());
    } catch {
      // Ignore
    }

    // Generate traveling balloons at varied elevations (y: 15% to 65%)
    const initialBalloons = Array.from({ length: 10 }).map((_, idx) => ({
      id: idx,
      color: idx % 3 === 0 ? ('black' as const) : idx === 4 ? ('gold' as const) : ('red' as const),
      x: (idx * 13 + 5) % 85,
      y: 15 + ((idx * 17) % 50),
      speed: 0.7 + (idx % 3) * 0.4,
      popped: false,
    }));
    setBalloons(initialBalloons);
  };

  const handlePopBalloon = (bId: number, color: 'red' | 'black' | 'gold') => {
    sound.playPop();
    setBalloons((prev) => prev.map((b) => (b.id === bId ? { ...b, popped: true } : b)));

    if (color === 'red') {
      const nextRed = redBalloonsPopped + 1;
      setRedBalloonsPopped(nextRed);
      setBowScore((s) => s + 100);

      // Bible Item 16: "Five successful red balloons → one Takshak/Nag collection."
      if (nextRed === 5) {
        sound.playGrandVictory();
        confetti({ particleCount: 80, spread: 70 });
        if (onAwardTakshakNag) onAwardTakshakNag();
        if (onTriggerTakshakBoard) onTriggerTakshakBoard();
      }
    } else if (color === 'gold') {
      setBowScore((s) => s + 250);
      sound.playGiftFanfare();
    } else {
      // Black balloon popped: Hazard! Must NOT be popped
      sound.playBombExplosion();
      setBowScore((s) => Math.max(0, s - 150));
    }
  };

  const finishBowGame = () => {
    setBowGameActive(false);
    const coinsWon = bowScore * 5;
    const diamondsWon = Math.floor(bowScore / 10);
    onEarnReward(coinsWon, diamondsWon, `Takshak Archery: ${bowScore} pts! (${redBalloonsPopped} Red popped)`);
    sound.playSafeCell();
  };

  // ------------------------------------------
  // DOT CONNECT HANDLERS (Bible Item 17)
  // ------------------------------------------
  const handleConnectDot = (index: number) => {
    sound.playTokenHop(index);
    const updated = [...colorNodes];
    updated[index].connected = true;
    setColorNodes(updated);

    if (updated.every((d) => d.connected)) {
      sound.playGrandVictory();
      confetti({ particleCount: 60, spread: 50 });
      setDotConnectMessage(`Level ${chilliLevel} Complete! +10 Red Chillies 🌶️ Harvested!`);
      if (onAddChilli) onAddChilli(10);
      onEarnReward(10000, 200, `Level ${chilliLevel} Dot Connect: +10 Red Chillies!`);
      setTimeout(() => {
        setChilliLevel((l) => Math.min(200, l + 1));
        setColorNodes(colorNodes.map((n) => ({ ...n, connected: false })));
        setDotConnectMessage(null);
      }, 1800);
    }
  };

  // ------------------------------------------
  // CARROM STRIKER FLICK HANDLER
  // ------------------------------------------
  const handleFlickStriker = () => {
    sound.playDiceRoll();
    // Simulate pocketing nearest coin aligned with angle
    const unpocketed = carromCoins.filter((c) => !c.pocketed);
    if (unpocketed.length === 0) {
      setCarromMessage('Board Cleared! All Carrom Men Pocketed! Resetting...');
      setTimeout(() => {
        setCarromCoins(carromCoins.map((c) => ({ ...c, pocketed: false })));
        setCarromMessage(null);
      }, 2000);
      return;
    }

    // Pick a coin to pocket based on power
    const targetCoin = unpocketed[Math.floor(Math.random() * unpocketed.length)];
    sound.playSafeCell();

    setCarromCoins((prev) =>
      prev.map((c) => (c.id === targetCoin.id ? { ...c, pocketed: true } : c))
    );

    if (targetCoin.type === 'queen') {
      sound.playGrandVictory();
      confetti({ particleCount: 70, spread: 60 });
      setCarromScore((s) => s + 1000);
      setCarromMessage('🔴 RED QUEEN POCKETED! +1,000 Points & 500 💎!');
      onEarnReward(15000, 500, 'Royal Carrom: Queen Pocketed (+15K Coins, +500 💎)');
    } else if (targetCoin.type === 'white') {
      setCarromScore((s) => s + 500);
      setCarromMessage('⚪ White Carrom Man Pocketed! +500 Points!');
      onEarnReward(5000, 50, 'Royal Carrom: White Man (+5,000 Coins)');
    } else {
      setCarromScore((s) => s + 250);
      setCarromMessage('⚫ Black Carrom Man Pocketed! +250 Points!');
      onEarnReward(2500, 25, 'Royal Carrom: Black Man (+2,500 Coins)');
    }

    setTimeout(() => setCarromMessage(null), 2500);
  };

  // ------------------------------------------
  // SUDOKU & CHESS HANDLERS (Links: Mor Pankh)
  // ------------------------------------------
  const handleSolveSudoku = () => {
    sound.playGrandVictory();
    confetti({ particleCount: 50, spread: 50 });
    if (onAwardMorPankh) onAwardMorPankh(5);
    onEarnReward(10000, 100, 'Sudoku Puzzle Solved: +5 Mor Pankh 🦚 Feathers!');
  };

  const handleSolveChess = () => {
    sound.playGrandVictory();
    confetti({ particleCount: 60, spread: 60 });
    setChessPuzzleSolved(true);
    if (onAwardMorPankh) onAwardMorPankh(5);
    onEarnReward(15000, 150, 'Chess Grandmaster Checkmate: +5 Mor Pankh 🦚 Feathers!');
  };

  // ------------------------------------------
  // SNAKE & LADDER HANDLER (Links: Eggs)
  // ------------------------------------------
  const handleSnakeRoll = () => {
    sound.playDiceRoll();
    const roll = Math.floor(Math.random() * 6) + 1;
    setSnakeDice(roll);
    const nextPos = Math.min(100, snakePos + roll);
    setSnakePos(nextPos);

    if (nextPos >= 50 || roll === 6) {
      sound.playGrandVictory();
      if (onAwardEggs) onAwardEggs(1);
      onEarnReward(5000, 50, 'Snake & Ladder milestone: +1 Cosmic Butterfly Egg 🥚!');
    }
  };

  // ------------------------------------------
  // TIC TAC TOE HANDLER (Links: Butterflies)
  // ------------------------------------------
  const handleTttClick = (idx: number) => {
    if (tttBoard[idx] || tttWinner) return;
    sound.playClick();
    const next = [...tttBoard];
    next[idx] = 'X';

    // Bot move
    const emptyIndices = next.map((val, i) => (val === null ? i : null)).filter((i) => i !== null) as number[];
    if (emptyIndices.length > 0) {
      const botIdx = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
      next[botIdx] = 'O';
    }

    setTttBoard(next);

    // Check winner
    const wins = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (const [a, b, c] of wins) {
      if (next[a] && next[a] === next[b] && next[a] === next[c]) {
        setTttWinner(next[a]);
        if (next[a] === 'X') {
          sound.playGrandVictory();
          if (onAwardButterfly) onAwardButterfly();
          onEarnReward(15000, 150, 'Tic Tac Toe Victory: Unlocked Rare Butterfly 🦋!');
        }
        return;
      }
    }
  };

  // ------------------------------------------
  // SPIN WHEEL
  // ------------------------------------------
  const handleSpin = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setSpinReward(null);
    sound.playDiceRoll();

    const randomDeg = 1440 + Math.floor(Math.random() * 360);
    const finalRot = wheelRotation + randomDeg;
    setWheelRotation(finalRot);

    setTimeout(() => {
      setIsSpinning(false);
      setSpinReward('10,000 Coins & 500 💎');
      sound.playGiftFanfare();
      onEarnReward(10000, 500, 'Divine Spin: Won 10,000 Coins & 500 💎!');
    }, 3200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-950 border-2 border-amber-500/50 rounded-3xl shadow-[0_0_60px_rgba(245,158,11,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-amber-500/20 bg-gradient-to-r from-amber-950/70 via-slate-900 to-rose-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center p-1 shadow-[0_0_15px_#f59e0b]">
              <RealisticArcadeTargetIcon size={26} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-amber-200 tracking-wide font-cinzel">
                  MINI-GAME UNIVERSE
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  PAGE 6 & 7 BIBLE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Chess/Sudoku → More Pank | Snake & Ladder → Eggs | Tic Tac Toe → Butterflies
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Game Tabs (All 9 Games from Bible Page 6) */}
        <div className="px-4 py-2 border-b border-slate-800 flex gap-2 overflow-x-auto bg-slate-900/50 scrollbar-none">
          {[
            { id: 'bow-arrow', label: '16. Bow & Arrow / Takshak', icon: '🏹' },
            { id: 'dot-connect', label: '17. Dot Connect (200 Lvls)', icon: '🌶️' },
            { id: 'carrom', label: 'Carrom Board', icon: '🎯' },
            { id: 'chess', label: 'Chess (More Pank)', icon: '♟️' },
            { id: 'sudoku', label: 'Sudoku (More Pank)', icon: '🔢' },
            { id: 'snake-ladder', label: 'Snake & Ladder (Eggs)', icon: '🐍🪜' },
            { id: 'tictactoe', label: 'Tic Tac Toe (Butterflies)', icon: '🦋' },
            { id: 'spin-wheel', label: 'Fortune Spin Wheel', icon: '🎡' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                sound.playClick();
                setActiveGame(tab.id as MiniGameTab);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                activeGame === tab.id
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.5)]'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="flex-1 p-4 overflow-y-auto flex flex-col items-center justify-center">
          {/* 1. BOW & ARROW / TAKSHAK (ITEM 16) */}
          {activeGame === 'bow-arrow' && (
            <div className="w-full max-w-xl flex flex-col items-center space-y-3">
              {/* Daily Limit Notice */}
              <div className="w-full flex items-center justify-between text-xs px-2">
                <span className="text-slate-300">
                  Daily Plays: <strong className="text-amber-400">{dailyBowPlays}/5</strong> (5 plays/day)
                </span>
                <span className="font-mono text-sm font-black text-amber-300">
                  {bowGameActive ? `⏱️ ${bowTimeRemaining}s | Score: ${bowScore} (Red: ${redBalloonsPopped}/5)` : '1 Min Limit'}
                </span>
              </div>

              {dailyBowPlays >= 5 && !bowGameActive && (
                <div className="w-full p-3 rounded-2xl bg-amber-950/60 border border-amber-500/50 flex items-center gap-2 text-xs text-amber-200 animate-pulse">
                  <AlertCircle size={18} className="text-amber-400 shrink-0" />
                  <span>
                    <strong>Daily Limit Reached (5/5):</strong> You have completed today's 5 archery sessions. Next sessions unlock tomorrow!
                  </span>
                </div>
              )}

              {/* Game Stage */}
              <div className="relative w-full h-84 rounded-3xl bg-gradient-to-b from-[#09152b] via-[#070b16] to-[#040810] border-2 border-emerald-500/40 overflow-hidden shadow-inner flex flex-col items-center justify-center">
                {!bowGameActive ? (
                  <div className="flex flex-col items-center gap-3 p-4 text-center">
                    <span className="text-5xl animate-bounce">🏹</span>
                    <h3 className="text-base font-black text-white font-cinzel">Takshak Bow & Arrow Challenge</h3>
                    <p className="text-xs text-slate-300 max-w-sm">
                      Balloons travel across the screen. Pop Red balloons (+100)! Avoid Black skulls. Pop <strong>5 Red Balloons</strong> to earn +1 Takshak/Nag collection item and trigger the 25-second board pet gag!
                    </p>
                    <button
                      onClick={startBowGame}
                      disabled={dailyBowPlays >= 5}
                      className={`px-6 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider shadow-lg transition ${
                        dailyBowPlays >= 5
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 hover:brightness-110 active:scale-95'
                      }`}
                    >
                      {dailyBowPlays >= 5 ? 'Play Tomorrow' : 'Start Archery (1 Min)'}
                    </button>
                  </div>
                ) : (
                  <>
                    {/* Floating Target Balloons Traveling Across Screen */}
                    {balloons.map((b) => {
                      if (b.popped) return null;
                      return (
                        <button
                          key={b.id}
                          onClick={() => handlePopBalloon(b.id, b.color)}
                          style={{ top: `${b.y}%`, left: `${b.x}%` }}
                          className="absolute -translate-x-1/2 -translate-y-1/2 p-2 rounded-full cursor-crosshair transform transition hover:scale-125"
                        >
                          {b.color === 'red' && (
                            <div className="w-12 h-14 rounded-full bg-gradient-to-br from-red-400 to-rose-700 shadow-[0_0_15px_#ef4444] flex items-center justify-center text-xs font-black text-white">
                              🎈 +100
                            </div>
                          )}
                          {b.color === 'gold' && (
                            <div className="w-12 h-14 rounded-full bg-gradient-to-br from-amber-300 to-yellow-600 shadow-[0_0_20px_#f59e0b] flex items-center justify-center text-xs font-black text-slate-950">
                              ⭐ +250
                            </div>
                          )}
                          {b.color === 'black' && (
                            <div className="w-11 h-13 rounded-full bg-slate-900 border-2 border-red-500 shadow-inner flex items-center justify-center text-xs">
                              💀 -150
                            </div>
                          )}
                        </button>
                      );
                    })}

                    {/* Interactive Bow Slider at Bottom */}
                    <div className="absolute bottom-2 left-6 right-6 flex items-center justify-between gap-4">
                      <div className="flex-1 flex items-center gap-2">
                        <span className="text-xl">🏹</span>
                        <input
                          type="range"
                          min="15"
                          max="85"
                          value={bowPosition}
                          onChange={(e) => setBowPosition(parseInt(e.target.value, 10))}
                          className="w-full accent-amber-400"
                        />
                      </div>
                      <button
                        onClick={finishBowGame}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs shadow-md hover:bg-emerald-500 shrink-0"
                      >
                        Finish & Claim
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* 2. DOT CONNECT / CHILLI (ITEM 17: 200 LEVELS) */}
          {activeGame === 'dot-connect' && (
            <div className="flex flex-col items-center w-full max-w-md space-y-3">
              <div className="flex items-center justify-between w-full px-2">
                <div className="flex items-center gap-1.5 text-xs text-rose-300 font-bold">
                  <Flame size={15} className="text-rose-500" />
                  <span>Level {chilliLevel} of 200</span>
                </div>
                <div className="text-xs text-amber-300 font-bold">
                  🌶️ Chillies: {userChillies} (+10 per completed level)
                </div>
              </div>

              {/* Level Quick Select (200 Levels) */}
              <div className="flex items-center gap-1.5 w-full overflow-x-auto py-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase shrink-0">Level Jump:</span>
                {[1, 5, 10, 25, 50, 100, 150, 200].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => {
                      sound.playClick();
                      setChilliLevel(lvl);
                    }}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                      chilliLevel === lvl
                        ? 'bg-rose-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    L{lvl}
                  </button>
                ))}
              </div>

              {dotConnectMessage && (
                <div className="w-full p-2 rounded-xl bg-rose-950/80 border border-rose-500 text-xs text-center text-rose-200 font-black animate-bounce">
                  {dotConnectMessage}
                </div>
              )}

              {/* Connect Grid */}
              <div className="relative w-72 h-72 rounded-3xl bg-slate-900 border-2 border-rose-500/40 p-4 shadow-inner flex items-center justify-center">
                <div className="grid grid-cols-2 gap-8">
                  {colorNodes.map((node, idx) => (
                    <button
                      key={node.id}
                      onClick={() => handleConnectDot(idx)}
                      style={{
                        backgroundColor: node.connected ? node.color : '#1e293b',
                        borderColor: node.color,
                      }}
                      className={`w-16 h-16 rounded-2xl border-2 flex items-center justify-center text-2xl font-bold transition-all shadow-md active:scale-95 ${
                        node.connected ? 'scale-105 shadow-[0_0_20px_rgba(244,63,94,0.6)] text-white' : 'text-slate-400'
                      }`}
                    >
                      {node.connected ? '🌶️' : `${node.name}`}
                    </button>
                  ))}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 text-center">
                Connect matching color nodes without crossing paths. Complete level to earn 10 Red Chillies.
              </p>

              {onOpenModels && (
                <button
                  onClick={() => {
                    sound.playClick();
                    onClose();
                    onOpenModels();
                  }}
                  className="mt-2 px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 text-white font-black text-xs uppercase tracking-wider shadow-lg hover:brightness-110 active:scale-95 flex items-center gap-2"
                >
                  <span>👗 Spend Chillies in Glamour Models Atelier (10–1,000 Tiers)</span>
                  <ChevronRight size={14} />
                </button>
              )}
            </div>
          )}

          {/* 3. ROYAL CARROM BOARD (PAGE 6) */}
          {activeGame === 'carrom' && (
            <div className="flex flex-col items-center w-full max-w-md space-y-3">
              <div className="flex items-center justify-between w-full px-2 text-xs">
                <span className="font-bold text-amber-300">Carrom Score: {carromScore} pts</span>
                <span className="text-slate-300 font-mono">
                  Pocket Queen for +1,000 pts & 500 💎
                </span>
              </div>

              {carromMessage && (
                <div className="w-full p-2 rounded-xl bg-amber-950/80 border border-amber-500 text-xs text-center text-amber-200 font-black animate-bounce">
                  {carromMessage}
                </div>
              )}

              {/* Wooden Carrom Arena */}
              <div className="relative w-72 h-72 rounded-3xl bg-[#5c3a21] border-4 border-[#3b2314] shadow-[0_0_30px_rgba(0,0,0,0.8)] p-3 overflow-hidden">
                {/* 4 Corner Pockets */}
                <div className="absolute top-2 left-2 w-7 h-7 rounded-full bg-black border border-white/20 shadow-inner" />
                <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black border border-white/20 shadow-inner" />
                <div className="absolute bottom-2 left-2 w-7 h-7 rounded-full bg-black border border-white/20 shadow-inner" />
                <div className="absolute bottom-2 right-2 w-7 h-7 rounded-full bg-black border border-white/20 shadow-inner" />

                {/* Center Circle */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full border border-amber-300/30 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full border border-red-500/40" />
                </div>

                {/* Carrom Men & Queen */}
                {carromCoins.map((coin) => {
                  if (coin.pocketed) return null;
                  return (
                    <div
                      key={coin.id}
                      style={{ top: `${coin.y}%`, left: `${coin.x}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full border shadow-md flex items-center justify-center text-[10px] font-black ${
                        coin.type === 'queen'
                          ? 'bg-rose-600 border-white text-white shadow-[0_0_10px_#ef4444]'
                          : coin.type === 'white'
                          ? 'bg-slate-100 border-amber-400 text-slate-900'
                          : 'bg-slate-950 border-slate-700 text-white'
                      }`}
                    >
                      {coin.type === 'queen' ? '👑' : ''}
                    </div>
                  );
                })}

                {/* Striker on baseline */}
                <div
                  style={{ left: `${strikerX}%` }}
                  className="absolute bottom-6 -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 border-2 border-white shadow-[0_0_12px_#f59e0b] flex items-center justify-center text-xs font-black text-slate-950 animate-pulse"
                >
                  ⚡
                </div>
              </div>

              {/* Striker Position & Flick Slider */}
              <div className="w-full space-y-2 px-2">
                <div className="flex items-center justify-between text-[11px] text-slate-300">
                  <span>Striker Baseline:</span>
                  <input
                    type="range"
                    min="25"
                    max="75"
                    value={strikerX}
                    onChange={(e) => setStrikerX(parseInt(e.target.value, 10))}
                    className="w-48 accent-amber-400"
                  />
                </div>
                <button
                  onClick={handleFlickStriker}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
                >
                  Flick Striker (Shoot Carrom Men)
                </button>
              </div>
            </div>
          )}

          {/* 4. CHESS CHALLENGE (PAGE 6 -> MOR PANKH) */}
          {activeGame === 'chess' && (
            <div className="flex flex-col items-center w-full max-w-md space-y-3 text-center">
              <span className="text-4xl animate-bounce">♟️</span>
              <h3 className="text-base font-black text-emerald-300 font-cinzel">Chess Tactical Sanctuary</h3>
              <p className="text-xs text-slate-300">
                Bible Cross-link: Solving Chess tactics awards <strong>Mor Pankh 🦚 (Peacock Feathers)</strong> for Krishna divine blessings!
              </p>

              <div className="w-full p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-3">
                <p className="text-xs font-bold text-emerald-200">Grandmaster Puzzle: Mate in 2 Moves</p>
                <div className="text-3xl font-mono p-3 rounded-xl bg-slate-900 border border-slate-700 tracking-wider">
                  ♚ · · ♛ ♞ ♝
                </div>
                <button
                  onClick={handleSolveChess}
                  disabled={chessPuzzleSolved}
                  className={`w-full py-2.5 rounded-xl font-black text-xs uppercase shadow-md active:scale-95 transition ${
                    chessPuzzleSolved
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  }`}
                >
                  {chessPuzzleSolved ? 'Tactical Move Solved! (+5 Mor Pankh Claimed)' : 'Execute Winning Queen Sacrifice (+5 Mor Pankh)'}
                </button>
              </div>
            </div>
          )}

          {/* 5. SUDOKU SANCTUARY (PAGE 6 -> MOR PANKH) */}
          {activeGame === 'sudoku' && (
            <div className="flex flex-col items-center w-full max-w-md space-y-3 text-center">
              <span className="text-4xl animate-bounce">🔢</span>
              <h3 className="text-base font-black text-emerald-300 font-cinzel">Sudoku Number Sanctuary</h3>
              <p className="text-xs text-slate-300">
                Bible Cross-link: Solving Sudoku puzzles awards <strong>Mor Pankh 🦚 (Peacock Feathers)</strong>!
              </p>

              <div className="grid grid-cols-3 gap-1.5 p-3 rounded-2xl bg-slate-900 border border-emerald-500/30 text-xs font-mono font-bold">
                {sudokuGrid.map((val, i) => (
                  <div
                    key={i}
                    className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-300 text-base"
                  >
                    {val || '?'}
                  </div>
                ))}
              </div>

              <button
                onClick={handleSolveSudoku}
                className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
              >
                Solve Mini-Sudoku (+5 Mor Pankh)
              </button>
            </div>
          )}

          {/* 6. SNAKE & LADDER (PAGE 6 -> EGGS) */}
          {activeGame === 'snake-ladder' && (
            <div className="flex flex-col items-center w-full max-w-md space-y-3 text-center">
              <span className="text-4xl animate-bounce">🐍🪜</span>
              <h3 className="text-base font-black text-amber-300 font-cinzel">Snake & Ladder Egg Journey</h3>
              <p className="text-xs text-slate-300">
                Bible Cross-link: Roll to climb ladders and dodge snakes. Reaching milestones awards <strong>Cosmic Butterfly Eggs 🥚</strong>!
              </p>

              <div className="w-full p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-300">Pawn Position: Tile {snakePos}/100</span>
                  {snakeDice && <span className="font-black text-white">Rolled: {snakeDice} 🎲</span>}
                </div>

                <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-all duration-300"
                    style={{ width: `${snakePos}%` }}
                  />
                </div>

                <button
                  onClick={handleSnakeRoll}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase shadow-md active:scale-95 transition"
                >
                  Roll Dice for Ladder Climb
                </button>
              </div>
            </div>
          )}

          {/* 7. TIC TAC TOE (PAGE 6 -> BUTTERFLY COLLECTION) */}
          {activeGame === 'tictactoe' && (
            <div className="flex flex-col items-center w-full max-w-sm space-y-3 text-center">
              <span className="text-4xl animate-bounce">🦋</span>
              <h3 className="text-base font-black text-cyan-300 font-cinzel">Tic Tac Toe Butterfly Duel</h3>
              <p className="text-xs text-slate-300">
                Bible Cross-link: Defeat the AI in Tic Tac Toe to unlock direct <strong>Butterfly Drops</strong> for your sanctuary!
              </p>

              <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-900 border border-cyan-500/30">
                {tttBoard.map((val, i) => (
                  <button
                    key={i}
                    onClick={() => handleTttClick(i)}
                    className="w-16 h-16 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl font-black text-cyan-400 hover:bg-slate-700 active:scale-95 transition"
                  >
                    {val}
                  </button>
                ))}
              </div>

              {tttWinner && (
                <div className="text-xs font-black text-emerald-300">
                  {tttWinner === 'X' ? '🎉 You Won! Butterfly Drop Granted!' : 'Duel finished!'}
                  <button
                    onClick={() => {
                      setTttBoard(Array(9).fill(null));
                      setTttWinner(null);
                    }}
                    className="ml-2 underline text-white"
                  >
                    Play Again
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 8. SPIN WHEEL */}
          {activeGame === 'spin-wheel' && (
            <div className="flex flex-col items-center">
              <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-amber-400 z-10 -mb-2 filter drop-shadow-md" />
              <div
                className="relative w-64 h-64 rounded-full border-4 border-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.5)] transition-all duration-[3200ms] ease-out overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900"
                style={{ transform: `rotate(${wheelRotation}deg)` }}
              >
                <div className="absolute inset-0 flex items-center justify-center font-bold text-xs text-white">
                  <div className="absolute top-4 text-center font-mono">10,000 🪙</div>
                  <div className="absolute right-4 text-center font-mono text-cyan-300">500 💎</div>
                  <div className="absolute bottom-4 text-center font-mono">25,000 🪙</div>
                  <div className="absolute left-4 text-center font-mono text-rose-300">1,000 💎</div>
                </div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-amber-400 border-2 border-white shadow-lg flex items-center justify-center font-black text-slate-950 text-xs">
                  SPIN
                </div>
              </div>

              {spinReward && (
                <div className="mt-3 px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400 text-xs font-bold animate-bounce">
                  🎉 {spinReward} Claimed!
                </div>
              )}

              <button
                onClick={handleSpin}
                disabled={isSpinning}
                className="mt-4 px-8 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition"
              >
                {isSpinning ? 'Spinning...' : 'Spin Fortune Wheel!'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
