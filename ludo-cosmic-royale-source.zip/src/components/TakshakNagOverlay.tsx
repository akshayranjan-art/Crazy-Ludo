import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { sound } from '../utils/soundEngine';

interface TakshakNagOverlayProps {
  isActive: boolean;
  onFinish: () => void;
  targetPetName?: string;
  petIcon?: string;
}

export const TakshakNagOverlay: React.FC<TakshakNagOverlayProps> = ({
  isActive,
  onFinish,
  targetPetName = 'Celestial Dragon',
  petIcon = '🐉',
}) => {
  // Phases:
  // 1. 'entering' (0-4s): Takshak slithers onto the board
  // 2. 'swallowing' (4-29s, exactly 25s pet gag): Pet swallowed playfully for comic relief
  // 3. 'returning' (29-34s): Takshak spits pet back with giggles & heart bubbles
  const [phase, setPhase] = useState<'entering' | 'swallowing' | 'returning'>('entering');
  const [secondsRemaining, setSecondsRemaining] = useState(25);

  useEffect(() => {
    if (!isActive) return;

    sound.playTrishulThunder();
    setPhase('entering');
    setSecondsRemaining(25);

    // After 4s: snake playful swallow
    const swallowTimer = setTimeout(() => {
      setPhase('swallowing');
    }, 4000);

    // 25s countdown timer for the gag
    const countdown = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(countdown);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // After 29s total: spit back and return
    const returnTimer = setTimeout(() => {
      setPhase('returning');
      sound.playGrandVictory();
    }, 29000);

    // Finish overlay after 34s
    const finishTimer = setTimeout(() => {
      onFinish();
    }, 34000);

    return () => {
      clearTimeout(swallowTimer);
      clearTimeout(returnTimer);
      clearTimeout(finishTimer);
      clearInterval(countdown);
    };
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center p-4">
      {/* Top Right Close Button */}
      <button
        onClick={() => {
          sound.playClick();
          onFinish();
        }}
        className="pointer-events-auto absolute top-4 right-4 sm:top-6 sm:right-6 z-50 p-2.5 rounded-full bg-slate-900/90 hover:bg-red-950/90 border-2 border-emerald-400 hover:border-red-400 text-emerald-300 hover:text-white transition shadow-lg active:scale-95 flex items-center gap-1 cursor-pointer"
        title="Close Takshak Nag Screen"
        aria-label="Close Screen"
      >
        <span className="text-[11px] font-black uppercase tracking-wider hidden sm:inline">Close</span>
        <X size={18} />
      </button>

      {/* Top Nag notification bar */}
      <div className="absolute top-16 z-20 px-5 py-2 rounded-full bg-emerald-950/95 border-2 border-emerald-400 text-center shadow-2xl animate-bounce">
        <p className="text-xs font-black text-emerald-300 uppercase tracking-wider flex items-center gap-1.5 justify-center">
          <span>🐍</span> TAKSHAK NAG COMEDIC GAG (Item 16) <span>🐍</span>
        </p>
        <p className="text-[11px] text-white">
          {phase === 'entering' && 'Takshak slithers onto the board for a playful visit...'}
          {phase === 'swallowing' &&
            `Takshak playfully swallowed ${targetPetName}! Returning in ${secondsRemaining}s... (Zero gameplay damage) 😆`}
          {phase === 'returning' && `Takshak safely spat ${targetPetName} back! Pet is happy and unharmed! 🎉`}
        </p>
      </div>

      {/* 3D Animated Takshak Serpent Graphic */}
      <div className="relative z-10 flex flex-col items-center">
        {phase === 'entering' && (
          <div className="text-8xl sm:text-9xl animate-[spin_4s_linear_infinite] filter drop-shadow-[0_0_35px_#10B981]">
            🐍
          </div>
        )}

        {phase === 'swallowing' && (
          <div className="relative p-7 rounded-full bg-emerald-950/70 border-4 border-emerald-400/80 shadow-[0_0_60px_rgba(16,185,129,0.8)] flex flex-col items-center animate-pulse">
            <div className="text-9xl">🐍</div>
            {/* Swallowed pet tummy bulge with wiggle animation */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-2.5 rounded-full bg-amber-400 text-slate-950 text-2xl font-black shadow-xl animate-bounce">
              {petIcon}
            </div>
            <span className="mt-3 text-xs font-black text-amber-300 bg-black/80 px-3.5 py-1 rounded-full border border-amber-400/50">
              *Pet vacation inside Nag* ({secondsRemaining}s)
            </span>
          </div>
        )}

        {phase === 'returning' && (
          <div className="flex items-center gap-4 text-7xl animate-bounce">
            <span>🐍💨</span>
            <span className="text-8xl">{petIcon}✨</span>
          </div>
        )}
      </div>
    </div>
  );
};
