import React, { useState } from 'react';
import {
  X,
  Users,
  Copy,
  Check,
  Play,
  Share2,
  Sparkles,
  Shield,
  Coins,
  Crown,
  KeyRound,
  ArrowRight,
  UserPlus,
  RefreshCw,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface PrivateRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  userDiamonds: number;
  onStartPrivateMatch: (config: {
    roomCode: string;
    mode: 'classic' | 'quick' | 'team';
    stakeAmount: number;
    currency: 'coins' | 'diamonds';
  }) => void;
}

const STAKE_OPTIONS = [
  { amount: 10000, label: '10K', currency: 'coins' as const, icon: '🪙' },
  { amount: 50000, label: '50K', currency: 'coins' as const, icon: '🪙' },
  { amount: 250000, label: '250K', currency: 'coins' as const, icon: '🪙' },
  { amount: 1000000, label: '1M', currency: 'coins' as const, icon: '🪙' },
  { amount: 5000000, label: '5M', currency: 'coins' as const, icon: '🪙' },
  { amount: 10000, label: '10K', currency: 'diamonds' as const, icon: '💎' },
  { amount: 100000, label: '100K', currency: 'diamonds' as const, icon: '💎' },
];

export const PrivateRoomModal: React.FC<PrivateRoomModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  userDiamonds,
  onStartPrivateMatch,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'join'>('create');
  const [selectedMode, setSelectedMode] = useState<'classic' | 'quick' | 'team'>('classic');
  const [selectedStakeIdx, setSelectedStakeIdx] = useState<number>(1); // Default 50K Coins
  const [copiedCode, setCopiedCode] = useState(false);
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [joinError, setJoinError] = useState('');

  // Generated room code for creation
  const [generatedCode] = useState(() => {
    const num = Math.floor(1000 + Math.random() * 9000);
    return `ROYAL-${num}`;
  });

  // Simulated friends in room lobby
  const [roomSlots, setRoomSlots] = useState([
    { id: 1, name: 'VikingKing (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80', isHost: true, isReady: true },
    { id: 2, name: 'Princess Balqis', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80', isHost: false, isReady: true },
    { id: 3, name: 'Open Seat', avatar: '', isHost: false, isReady: false },
    { id: 4, name: 'Open Seat', avatar: '', isHost: false, isReady: false },
  ]);

  if (!isOpen) return null;

  const currentStake = STAKE_OPTIONS[selectedStakeIdx];
  const canAfford =
    currentStake.currency === 'coins'
      ? userCoins >= currentStake.amount
      : userDiamonds >= currentStake.amount;

  const handleCopyCode = () => {
    sound.playClick();
    navigator.clipboard.writeText(generatedCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleFillBot = (slotIdx: number) => {
    sound.playClick();
    const botNames = ['Aryan Warrior', 'Danisya Nag', 'Cyber Phoenix', 'Royal Tiger'];
    const botAvatars = [
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
    ];
    setRoomSlots((prev) =>
      prev.map((s, i) =>
        i === slotIdx
          ? {
              ...s,
              name: botNames[i % botNames.length],
              avatar: botAvatars[i % botAvatars.length],
              isReady: true,
            }
          : s
      )
    );
  };

  const handleStartGame = () => {
    sound.playDiceRoll();
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    onStartPrivateMatch({
      roomCode: generatedCode,
      mode: selectedMode,
      stakeAmount: currentStake.amount,
      currency: currentStake.currency,
    });
    onClose();
  };

  const handleJoinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = joinCodeInput.trim().toUpperCase();
    if (!clean || clean.length < 4) {
      setJoinError('Please enter a valid 6-character room code!');
      return;
    }
    sound.playDiceRoll();
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    onStartPrivateMatch({
      roomCode: clean,
      mode: 'classic',
      stakeAmount: 50000,
      currency: 'coins',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg max-h-[94vh] flex flex-col bg-slate-950 border-2 border-amber-500/60 rounded-3xl shadow-[0_0_60px_rgba(245,158,11,0.35)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-amber-500/20 bg-gradient-to-r from-purple-950/70 via-slate-900 to-amber-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-xl shadow-[0_0_15px_#f59e0b]">
              🎮
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-amber-200 tracking-wide font-cinzel">
                  PLAY WITH FRIENDS
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                  PRIVATE ROOM
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Create a room code, invite buddies & compete for massive pots
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Create vs Join */}
        <div className="flex items-center border-b border-slate-800 bg-slate-900/60 px-4 pt-2 gap-2">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('create');
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 ${
              activeTab === 'create'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <span>👑 Create Room</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('join');
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl font-black text-xs sm:text-sm transition-all border-b-2 ${
              activeTab === 'join'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <KeyRound size={14} className="text-amber-400" />
            <span>Join with Code</span>
          </button>
        </div>

        {/* TAB 1: CREATE ROOM */}
        {activeTab === 'create' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Generated Room Code Box */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/60 border border-amber-400/50 flex items-center justify-between shadow-md">
              <div>
                <span className="text-[10px] text-amber-300 font-bold uppercase tracking-wider">
                  Your Private Room Code
                </span>
                <p className="text-xl sm:text-2xl font-black text-white font-mono tracking-widest drop-shadow-[0_0_10px_rgba(245,158,11,0.5)]">
                  {generatedCode}
                </p>
              </div>

              <button
                onClick={handleCopyCode}
                className="px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 transition shadow-lg active:scale-95"
              >
                {copiedCode ? <Check size={14} /> : <Copy size={14} />}
                <span>{copiedCode ? 'COPIED!' : 'COPY CODE'}</span>
              </button>
            </div>

            {/* Game Mode Selection */}
            <div>
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5 block">
                Select Game Mode
              </span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'classic', label: 'Classic 4P', desc: '4 Tokens Home', icon: '👑' },
                  { id: 'quick', label: 'Quick Rush', desc: '1 Token to Win', icon: '⚡' },
                  { id: 'team', label: 'Master 2v2', desc: 'Team Up 2vs2', icon: '👥' },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      sound.playClick();
                      setSelectedMode(m.id as any);
                    }}
                    className={`p-2.5 rounded-2xl border text-center transition-all flex flex-col items-center justify-center ${
                      selectedMode === m.id
                        ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-lg">{m.icon}</span>
                    <span className="text-xs font-black text-white mt-0.5">{m.label}</span>
                    <span className="text-[9px] text-slate-400">{m.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Entry Stake Selection */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  Entry Stake / Bet
                </span>
                <span className="text-[11px] font-mono font-bold text-amber-300">
                  Pot: {currentStake.icon} {(currentStake.amount * 4).toLocaleString()}
                </span>
              </div>

              <div className="grid grid-cols-4 gap-1.5">
                {STAKE_OPTIONS.map((stk, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      sound.playClick();
                      setSelectedStakeIdx(idx);
                    }}
                    className={`py-2 px-1 rounded-xl border text-center transition-all ${
                      selectedStakeIdx === idx
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black border-amber-300 shadow-md scale-105'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-[11px] font-black flex items-center justify-center gap-0.5">
                      <span>{stk.icon}</span>
                      <span>{stk.label}</span>
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 4-Player Waiting Room Lobby */}
            <div>
              <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                Room Slots (4 Players)
              </span>

              <div className="grid grid-cols-2 gap-2">
                {roomSlots.map((slot, idx) => {
                  const isOccupied = !!slot.avatar;

                  return (
                    <div
                      key={slot.id}
                      className={`p-2 rounded-2xl border flex items-center justify-between ${
                        isOccupied
                          ? 'bg-slate-900/90 border-slate-700'
                          : 'bg-slate-950/60 border-slate-800 border-dashed'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {isOccupied ? (
                          <div className="relative w-9 h-9 rounded-full overflow-hidden border border-amber-400">
                            <img src={slot.avatar} alt={slot.name} className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-500 text-xs">
                            👤
                          </div>
                        )}

                        <div>
                          <p className="text-xs font-bold text-white truncate max-w-[85px]">
                            {slot.name}
                          </p>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                              slot.isReady
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {slot.isHost ? '👑 Host' : slot.isReady ? 'Ready' : 'Waiting'}
                          </span>
                        </div>
                      </div>

                      {/* Fill Bot / Invite Button */}
                      {!isOccupied && (
                        <button
                          onClick={() => handleFillBot(idx)}
                          className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-[10px] font-bold border border-slate-700 transition"
                          title="Invite Bot or Buddy"
                        >
                          + Bot
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Launch Match Button */}
            <div className="pt-2">
              <button
                onClick={handleStartGame}
                disabled={!canAfford}
                className={`w-full py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-all ${
                  canAfford
                    ? 'liquid-btn-gold text-slate-950 shadow-[0_0_30px_rgba(245,158,11,0.7)] hover:scale-[1.02] active:scale-95'
                    : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                }`}
              >
                <Play size={18} />
                <span>
                  {canAfford
                    ? `START PRIVATE MATCH (${currentStake.icon} ${currentStake.label})`
                    : 'INSUFFICIENT BALANCE'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: JOIN WITH CODE */}
        {activeTab === 'join' && (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center space-y-5">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center text-3xl shadow-[0_0_30px_#f59e0b]">
              🔑
            </div>

            <div className="text-center">
              <h3 className="text-lg font-black text-amber-200 font-cinzel">
                JOIN PRIVATE LUDO ROOM
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Enter the room code shared by your friend (e.g. ROYAL-1234) to enter their match.
              </p>
            </div>

            <form onSubmit={handleJoinSubmit} className="w-full max-w-xs space-y-3">
              <input
                type="text"
                value={joinCodeInput}
                onChange={(e) => {
                  setJoinCodeInput(e.target.value.toUpperCase());
                  setJoinError('');
                }}
                placeholder="ENTER CODE (E.G. ROYAL-789)"
                className="w-full px-4 py-3 rounded-2xl bg-slate-900 border-2 border-amber-400/60 text-white font-mono font-black text-center text-base tracking-widest focus:outline-none focus:border-amber-400 shadow-inner"
              />

              {joinError && (
                <p className="text-xs text-rose-400 font-bold text-center">
                  {joinError}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl liquid-btn-gold text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl hover:scale-105 active:scale-95 transition"
              >
                <ArrowRight size={16} />
                <span>ENTER PRIVATE ARENA</span>
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
