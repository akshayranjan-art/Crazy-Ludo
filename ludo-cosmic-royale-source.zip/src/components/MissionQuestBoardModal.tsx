import React, { useState } from 'react';
import {
  X,
  Target,
  Sparkles,
  Trophy,
  CheckCircle2,
  Clock,
  Gift,
  Coins,
  ChevronRight,
  Flame,
  Zap,
  Calendar,
  Award,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

export type MissionCategory = 'daily' | 'weekly' | 'festival' | 'achievements';

export interface MissionItem {
  id: string;
  category: MissionCategory;
  title: string;
  description: string;
  target: number;
  currentProgress: number;
  rewardType: 'coins' | 'diamonds' | 'stars' | 'hearts' | 'eggs' | 'pass';
  rewardAmount: number;
  rewardLabel: string;
  expiryTime: string;
  eligibility: string;
  actionText: string;
  actionType: 'arena' | 'minigames' | 'rooms' | 'astra' | 'forge' | 'balloons';
  isClaimed: boolean;
  enabled: boolean;
}

interface MissionQuestBoardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (type: string, amount: number) => void;
  onNavigateToGame: (target: string) => void;
  userDiamonds: number;
  userCoins: number;
}

export const MissionQuestBoardModal: React.FC<MissionQuestBoardModalProps> = ({
  isOpen,
  onClose,
  onClaimReward,
  onNavigateToGame,
  userDiamonds,
  userCoins,
}) => {
  const [activeTab, setActiveTab] = useState<MissionCategory>('daily');

  // Server-Authoritative Mission Board State (Bible Section 19)
  const [missions, setMissions] = useState<MissionItem[]>([
    // Daily Missions
    {
      id: 'm-d1',
      category: 'daily',
      title: 'Roll Three 6s in 3D Arena',
      description: 'Strike lucky dice roll of six 3 times in any classic or Astra match.',
      target: 3,
      currentProgress: 3,
      rewardType: 'coins',
      rewardAmount: 500,
      rewardLabel: '500 Coins 🪙',
      expiryTime: 'Resets in 7h 20m',
      eligibility: 'All Verified (#100002+)',
      actionText: 'Play Arena',
      actionType: 'arena',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-d2',
      category: 'daily',
      title: 'Execute 2 Qualifying Token Cuts',
      description: 'Capture 2 opponent tokens in match. Earn 5 💎 per cut up to 40 💎 daily cap.',
      target: 2,
      currentProgress: 1,
      rewardType: 'diamonds',
      rewardAmount: 10,
      rewardLabel: '10 Diamonds 💎',
      expiryTime: 'Resets in 7h 20m',
      eligibility: 'All Verified (#100002+)',
      actionText: 'Enter Arena',
      actionType: 'arena',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-d3',
      category: 'daily',
      title: 'Play 1 Bow & Arrow Balloon Match',
      description: 'Pop red balloons without hitting black skull balloons in Mini-Games arcade.',
      target: 1,
      currentProgress: 1,
      rewardType: 'stars',
      rewardAmount: 50,
      rewardLabel: '50 Stars ⭐',
      expiryTime: 'Resets in 7h 20m',
      eligibility: 'All Verified (#100002+)',
      actionText: 'Claim',
      actionType: 'minigames',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-d4',
      category: 'daily',
      title: 'Splash 1 Water Balloon at Seated Player',
      description: 'Throw a 2💎 water or golden balloon in the 8-seat VIP room.',
      target: 1,
      currentProgress: 0,
      rewardType: 'hearts',
      rewardAmount: 5,
      rewardLabel: '5 Hearts ❤️',
      expiryTime: 'Resets in 7h 20m',
      eligibility: 'All Players',
      actionText: 'Throw Balloon',
      actionType: 'balloons',
      isClaimed: false,
      enabled: true,
    },

    // Weekly Missions
    {
      id: 'm-w1',
      category: 'weekly',
      title: 'Win 5 Complete 3D Matches',
      description: 'Guide all 4 tokens into celestial home center across 5 complete games.',
      target: 5,
      currentProgress: 3,
      rewardType: 'diamonds',
      rewardAmount: 25,
      rewardLabel: '25 Diamonds 💎',
      expiryTime: '4 days remaining',
      eligibility: 'All Players',
      actionText: 'Play Match',
      actionType: 'arena',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-w2',
      category: 'weekly',
      title: 'Solve 10 Dot-Connect Chilli Levels',
      description: 'Connect colored nodes across 200 progressive levels to earn chillies.',
      target: 10,
      currentProgress: 7,
      rewardType: 'coins',
      rewardAmount: 2000,
      rewardLabel: '2,000 Coins 🪙',
      expiryTime: '4 days remaining',
      eligibility: 'All Players',
      actionText: 'Play Dot Connect',
      actionType: 'minigames',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-w3',
      category: 'weekly',
      title: 'Hatch 1 Cosmic Butterfly Egg',
      description: 'Hatch eggs gathered from Snake & Ladder milestones in the hatchery.',
      target: 1,
      currentProgress: 1,
      rewardType: 'eggs',
      rewardAmount: 2,
      rewardLabel: '2 Butterfly Eggs 🥚',
      expiryTime: '4 days remaining',
      eligibility: 'All Players',
      actionText: 'Claim',
      actionType: 'minigames',
      isClaimed: false,
      enabled: true,
    },

    // Festival / Season Quests
    {
      id: 'm-f1',
      category: 'festival',
      title: 'Grand Astra Festival: Summon Trishul Tandav',
      description: 'Equip or test-fire Mahadev Trishul on the 3D board to trigger Tandav storm.',
      target: 1,
      currentProgress: 1,
      rewardType: 'pass',
      rewardAmount: 1,
      rewardLabel: '2-Hr Astra Pass 🎫',
      expiryTime: 'Festival ends Oct 31',
      eligibility: 'All Verified (#100002+)',
      actionText: 'Claim',
      actionType: 'astra',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-f2',
      category: 'festival',
      title: 'Visit 3D Player Museum Showroom',
      description: 'Inspect equipped mythic pets, trophies, and weapons in the museum.',
      target: 1,
      currentProgress: 1,
      rewardType: 'stars',
      rewardAmount: 100,
      rewardLabel: '100 Stars ⭐',
      expiryTime: 'Festival ends Oct 31',
      eligibility: 'All Players',
      actionText: 'Claim',
      actionType: 'arena',
      isClaimed: false,
      enabled: true,
    },

    // Achievements & Event Milestones
    {
      id: 'm-a1',
      category: 'achievements',
      title: 'Reach Level 10 Milestone',
      description: 'Earn experience points through daily rolls, room chats, and victories.',
      target: 10,
      currentProgress: 10,
      rewardType: 'diamonds',
      rewardAmount: 40,
      rewardLabel: '40 Diamonds 💎 (Cap)',
      expiryTime: 'Permanent Lifetime',
      eligibility: 'All Players',
      actionText: 'Claim',
      actionType: 'arena',
      isClaimed: false,
      enabled: true,
    },
    {
      id: 'm-a2',
      category: 'achievements',
      title: 'Forge 1 Higher Rune in Crucible Altar',
      description: 'Combine 3 identical lower cards into higher-tier artifacts in the Forge.',
      target: 1,
      currentProgress: 1,
      rewardType: 'coins',
      rewardAmount: 5000,
      rewardLabel: '5,000 Coins 🪙',
      expiryTime: 'Permanent Lifetime',
      eligibility: 'All Players',
      actionText: 'Claim',
      actionType: 'forge',
      isClaimed: false,
      enabled: true,
    },
  ]);

  if (!isOpen) return null;

  const handleClaim = (missionId: string) => {
    const mission = missions.find((m) => m.id === missionId);
    if (!mission || mission.isClaimed || mission.currentProgress < mission.target) return;

    sound.playGrandVictory();
    confetti({ particleCount: 75, spread: 60 });

    setMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, isClaimed: true } : m))
    );

    onClaimReward(mission.rewardType, mission.rewardAmount);
  };

  const handleActionClick = (mission: MissionItem) => {
    sound.playClick();
    onClose();
    onNavigateToGame(mission.actionType);
  };

  const currentMissions = missions.filter((m) => m.category === activeTab && m.enabled);
  const claimableCount = missions.filter(
    (m) => m.currentProgress >= m.target && !m.isClaimed
  ).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl overflow-hidden border-2 border-amber-400/60 rounded-3xl bg-gradient-to-b from-[#160c2b] via-[#0d0718] to-black text-slate-100 shadow-[0_0_60px_rgba(245,158,11,0.35)] flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-3.5 sm:p-5 bg-gradient-to-r from-purple-950/80 via-slate-900 to-amber-950/80 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-slate-950 text-2xl font-black shadow-[0_0_15px_#f59e0b]">
              📋
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-amber-200 font-cinzel">
                  Official Mission & Quest Board
                </h3>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  BIBLE ITEM 19
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Daily, Weekly, Festival Quests & Lifetime Achievements · Server-Validated Rewards
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-3 py-2 border-b border-white/10 bg-slate-900/60 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-xs">
          {[
            { id: 'daily', label: 'Daily (24h)', icon: '🎯' },
            { id: 'weekly', label: 'Weekly (7d)', icon: '📅' },
            { id: 'festival', label: 'Festival Quests', icon: '🎪' },
            { id: 'achievements', label: 'Lifetime Achievements', icon: '🏅' },
          ].map((tab) => {
            const count = missions.filter(
              (m) => m.category === tab.id && m.currentProgress >= m.target && !m.isClaimed
            ).length;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sound.playClick();
                  setActiveTab(tab.id as MissionCategory);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-600 text-slate-950 shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
                {count > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[9px] font-black animate-pulse">
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Missions list */}
        <div className="p-3.5 sm:p-5 space-y-3 overflow-y-auto flex-1">
          {currentMissions.map((mission) => {
            const isReadyToClaim = mission.currentProgress >= mission.target && !mission.isClaimed;
            const progressPercent = Math.min(100, Math.round((mission.currentProgress / mission.target) * 100));

            return (
              <div
                key={mission.id}
                className={`p-3 sm:p-4 rounded-2xl border transition-all ${
                  mission.isClaimed
                    ? 'bg-slate-900/40 border-white/5 opacity-60'
                    : isReadyToClaim
                    ? 'bg-gradient-to-r from-amber-950/40 via-purple-950/30 to-slate-900 border-amber-400/60 shadow-[0_0_20px_rgba(245,158,11,0.2)]'
                    : 'bg-slate-900/70 border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs sm:text-sm font-black text-white">{mission.title}</h4>
                      <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-white/10 text-slate-300 font-mono">
                        {mission.eligibility}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300">{mission.description}</p>
                    <div className="flex items-center gap-3 text-[10px] text-slate-400 pt-0.5">
                      <span className="flex items-center gap-1 text-amber-300 font-bold">
                        <Gift size={12} />
                        <span>Reward: {mission.rewardLabel}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={11} />
                        <span>{mission.expiryTime}</span>
                      </span>
                    </div>
                  </div>

                  {/* Action / Claim Button */}
                  <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                    {mission.isClaimed ? (
                      <span className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/5 text-slate-400 font-bold text-xs border border-white/5">
                        <CheckCircle2 size={14} className="text-emerald-400" />
                        <span>Claimed</span>
                      </span>
                    ) : isReadyToClaim ? (
                      <button
                        onClick={() => handleClaim(mission.id)}
                        className="flex items-center gap-1 px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-[0_0_15px_#f59e0b] animate-bounce"
                      >
                        <Sparkles size={13} />
                        <span>Claim Reward</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleActionClick(mission)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 font-bold text-xs border border-white/10 transition"
                      >
                        <span>{mission.actionText}</span>
                        <ChevronRight size={13} />
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-2.5 space-y-1">
                  <div className="flex justify-between text-[10px] font-bold">
                    <span className="text-slate-400">
                      Progress: {mission.currentProgress} / {mission.target}
                    </span>
                    <span className={isReadyToClaim ? 'text-amber-300' : 'text-slate-400'}>
                      {progressPercent}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden border border-white/5">
                    <div
                      className={`h-full transition-all duration-500 rounded-full ${
                        isReadyToClaim
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-500'
                          : 'bg-gradient-to-r from-purple-500 to-indigo-500'
                      }`}
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950/90 border-t border-amber-500/20 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck size={14} className="text-emerald-400" />
            <span className="text-slate-300 text-[11px]">
              Daily cut capture rewards capped at <strong>40 💎 / day</strong> (Bible Item 1 & 7).
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-amber-300 font-bold">💎 {userDiamonds.toLocaleString()}</span>
            <span className="text-yellow-400 font-bold">🪙 {userCoins.toLocaleString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
