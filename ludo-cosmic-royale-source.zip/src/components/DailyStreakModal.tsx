import React, { useState } from 'react';
import { X, Calendar, Gift, Check, Sparkles, Coins, Flame } from 'lucide-react';
import { sound } from '../utils/soundEngine';
import confetti from 'canvas-confetti';

interface DailyStreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClaimReward: (reward: { type: 'coins' | 'diamonds' | 'egg'; amount: number }) => void;
  onOpenButterflyHatchery: () => void;
}

export const DailyStreakModal: React.FC<DailyStreakModalProps> = ({
  isOpen,
  onClose,
  onClaimReward,
  onOpenButterflyHatchery,
}) => {
  const [claimedDays, setClaimedDays] = useState<number[]>([1, 2]);
  const currentDay = 3;

  if (!isOpen) return null;

  const STREAK_DAYS = [
    { day: 1, reward: { type: 'coins' as const, amount: 50000 }, label: '50K 🪙' },
    { day: 2, reward: { type: 'diamonds' as const, amount: 100 }, label: '100 💎' },
    { day: 3, reward: { type: 'coins' as const, amount: 150000 }, label: '150K 🪙' },
    { day: 4, reward: { type: 'diamonds' as const, amount: 250 }, label: '250 💎' },
    { day: 5, reward: { type: 'coins' as const, amount: 300000 }, label: '300K 🪙' },
    { day: 6, reward: { type: 'diamonds' as const, amount: 500 }, label: '500 💎' },
    { day: 7, reward: { type: 'egg' as const, amount: 1 }, label: '🥚 Rare Egg' },
  ];

  const handleClaim = (dayItem: typeof STREAK_DAYS[0]) => {
    sound.playGrandVictory();
    confetti({ particleCount: 70, spread: 60 });
    setClaimedDays((prev) => [...prev, dayItem.day]);
    onClaimReward(dayItem.reward);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg overflow-hidden border-2 border-amber-500/50 rounded-3xl bg-gradient-to-b from-[#1a1103] via-[#0d0a14] to-black text-slate-100 shadow-[0_0_50px_rgba(245,158,11,0.3)] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-600/40 via-yellow-600/30 to-slate-900 border-b border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 flex items-center justify-center text-2xl shadow-lg border border-amber-300">
              🔥
            </div>
            <div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-300">
                7-Day Login Streak
              </h3>
              <p className="text-xs text-slate-300">
                Daily rewards & 7th day Cosmic Butterfly Egg!
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 transition rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Days Grid */}
        <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
            {STREAK_DAYS.map((d) => {
              const isClaimed = claimedDays.includes(d.day);
              const isToday = d.day === currentDay;

              return (
                <div
                  key={d.day}
                  className={`p-3 rounded-2xl border flex flex-col items-center justify-between text-center relative ${
                    isClaimed
                      ? 'bg-slate-900/60 border-slate-800 opacity-60'
                      : isToday
                      ? 'bg-gradient-to-b from-amber-950 to-slate-900 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                      : 'bg-slate-900/40 border-slate-800'
                  }`}
                >
                  <span className="text-[10px] font-black uppercase text-slate-400">Day {d.day}</span>
                  <div className="my-2 text-xl">{d.reward.type === 'coins' ? '🪙' : d.reward.type === 'diamonds' ? '💎' : '🥚'}</div>
                  <span className="text-xs font-black text-amber-300">{d.label}</span>

                  {isClaimed ? (
                    <span className="mt-2 text-[10px] text-emerald-400 font-bold flex items-center gap-0.5">
                      <Check size={10} /> Claimed
                    </span>
                  ) : isToday ? (
                    <button
                      onClick={() => handleClaim(d)}
                      className="mt-2 px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 text-slate-950 font-black text-[10px] uppercase shadow-md active:scale-95 transition cursor-pointer"
                    >
                      Claim
                    </button>
                  ) : (
                    <span className="mt-2 text-[10px] text-slate-500 font-medium">Upcoming</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
