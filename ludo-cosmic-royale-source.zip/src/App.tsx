import React, { useState, useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  Player,
  PlayerColor,
  Token,
  Seat,
  AstraItem,
  PetItem,
  GiftItem,
  ChatMessage,
  AppView,
  FrameStyleId,
  LiveRoom,
} from './types/game';
import {
  ASTRA_ITEMS,
  RARE_PETS,
  LUXURY_GIFTS,
  SAFE_CELL_INDICES,
  PLAYER_START_CELLS,
  PLAYER_HOME_TURNS,
  ASSETS,
  AVATAR_FRAMES,
  FEATURED_LIVE_ROOMS,
} from './data/gameConstants';
import { sound } from './utils/soundEngine';

// Sub-views & Components
import { LobbyView } from './components/LobbyView';
import { LiveRoomsDirectoryView } from './components/LiveRoomsDirectoryView';
import { ProfileView } from './components/ProfileView';
import { LeaderboardView } from './components/LeaderboardView';
import { StoreView } from './components/StoreView';
import { SideDrawer } from './components/SideDrawer';
import { DailyWheelModal } from './components/DailyWheelModal';
import { Ludo3DBoard } from './components/Ludo3DBoard';
import { Dice3D } from './components/Dice3D';
import { LiveRoomSeats } from './components/LiveRoomSeats';
import { LiveChatFeed } from './components/LiveChatFeed';
import { AstraUniverseModal, NEXT_TIER } from './components/AstraUniverseModal';
import { PetUniverseModal } from './components/PetUniverseModal';
import { GiftStoreModal } from './components/GiftStoreModal';
import { CosmicCodexModal } from './components/CosmicCodexModal';
import { MiniGamesModal } from './components/MiniGamesModal';
import { CratesModal } from './components/CratesModal';
import { AdminCenterModal } from './components/AdminCenterModal';
import { EntryCinematicOverlay } from './components/EntryCinematicOverlay';
import { MiracleArrivalOverlay } from './components/MiracleArrivalOverlay';
import { TakshakNagOverlay } from './components/TakshakNagOverlay';
import { WorldMapView } from './components/WorldMapView';
import { PlayerMuseumModal } from './components/PlayerMuseumModal';
import { ModelGalleryModal, ModelProfile } from './components/ModelGalleryModal';
import { ModelPresentationOverlay } from './components/ModelPresentationOverlay';
import { FluteCollectionModal } from './components/FluteCollectionModal';
import { NeonLiquidVisualsModal } from './components/NeonLiquidVisualsModal';
import { AstraComboOverlay } from './components/AstraComboOverlay';
import { LoginAuthModal } from './components/LoginAuthModal';
import { authService, PlayerUser } from './utils/authService';
import { EntryCinematicType } from './components/EntryCinematicOverlay';
import { Visual4DState } from './types/game';
import { PrivateRoomModal } from './components/PrivateRoomModal';
import { MatchVictoryModal } from './components/MatchVictoryModal';
import { SeasonPassModal } from './components/SeasonPassModal';
import { GrandCollectionsModal } from './components/GrandCollectionsModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { ButterflyEggModal } from './components/ButterflyEggModal';
import { GameNiyamModal } from './components/GameNiyamModal';
import { DailyStreakModal } from './components/DailyStreakModal';
import { DiceForgeModal } from './components/DiceForgeModal';
import { ClanWarModal } from './components/ClanWarModal';
import { GameBibleModal } from './components/GameBibleModal';
import { InteractiveTutorialModal } from './components/InteractiveTutorialModal';
import { TopDropdownLauncher } from './components/TopDropdownLauncher';
import { MissionQuestBoardModal } from './components/MissionQuestBoardModal';
import { BalloonsModal } from './components/BalloonsModal';
import { CoupleSocialModal } from './components/CoupleSocialModal';
import { BUTTERFLY_SPECIES } from './data/butterflyData';
import { AstraWeaponsBar } from './components/AstraWeaponsBar';
import { BoardReactionsBar, ThrowableReaction, THROWABLE_LIST } from './components/BoardReactionsBar';
import { ReactionImpactOverlay, ActiveImpact } from './components/ReactionImpactOverlay';
import { ModalFadeWrapper } from './components/ModalFadeWrapper';

import {
  Home,
  Radio,
  Gamepad2,
  Trophy,
  Coins,
  User,
  Volume2,
  VolumeX,
  ShieldCheck,
  Plus,
  Sparkles,
  Crown,
  Flame,
  Zap,
} from 'lucide-react';

export default function App() {
  // Navigation View State ('lobby' | 'rooms' | 'arena' | 'leaderboard' | 'store' | 'profile')
  const [currentView, setCurrentView] = useState<AppView>('lobby');

  // Side Drawer & Wheel Modals
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isWheelOpen, setIsWheelOpen] = useState(false);

  // Economy balances (Starting with 100M+ diamonds for instant testing!)
  const [userCoins, setUserCoins] = useState<number>(2500000);
  const [userDiamonds, setUserDiamonds] = useState<number>(100000000); // 100 Million 💎 default
  const [userStars, setUserStars] = useState<number>(4500);

  // Equipped Avatar Frame
  const [equippedFrame, setEquippedFrame] = useState<FrameStyleId>('gold-wings');

  // Board Theme & Full Immersion Mode
  const [boardTheme, setBoardTheme] = useState<
    'royal-purple' | 'cosmic-gold' | 'cyber-neon' | 'shiva-temple'
  >('cosmic-gold');
  const [isImmersionMode, setIsImmersionMode] = useState<boolean>(false);
  const [isSeatsExpanded, setIsSeatsExpanded] = useState<boolean>(true);

  // Sound Mute Toggle
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  // Admin Ghost Mode vs Real Mode
  const [isGhostMode, setIsGhostMode] = useState(false);

  // Miracle Arrival State
  const [isMiracleActive, setIsMiracleActive] = useState(false);

  // Takshak Nag Masti State
  const [isTakshakActive, setIsTakshakActive] = useState(false);

  // 3D Player Museum State
  const [isMuseumOpen, setIsMuseumOpen] = useState(false);

  // Mic state in Live Feed
  const [isMicOn, setIsMicOn] = useState(true);
  const [voiceEffect, setVoiceEffect] = useState('normal');

  // Active Modals (including Flute Tiny and 4D Neon Suite)
  const [activeModal, setActiveModal] = useState<
    | 'astra'
    | 'pets'
    | 'gifts'
    | 'codex'
    | 'minigames'
    | 'crates'
    | 'admin'
    | 'models'
    | 'private-room'
    | 'pass'
    | 'collections'
    | 'apk'
    | 'butterfly'
    | 'rules'
    | 'streak'
    | 'forge'
    | 'clan'
    | 'bible'
    | 'balloons'
    | 'couple'
    | 'flute'
    | 'visuals'
    | 'auth'
    | 'tutorial'
    | 'missions'
    | null
  >(null);

  // Daily Cut Diamond Reward Tracker (Bible Section 1 & 7: 5💎 per cut, max 40💎/day cap)
  const [dailyCutDiamondsEarned, setDailyCutDiamondsEarned] = useState<number>(0);

  // Current Authenticated User (Bible Item 26: Unique Owner ID 777777 / akvikings05@gmail.com & User IDs from 100002+)
  const [currentUser, setCurrentUser] = useState<PlayerUser>(() => authService.getCurrentUser());

  // Equipped Butterfly Companion
  const [equippedButterflyId, setEquippedButterflyId] = useState<string>('bf-golden-monarch');

  // Red Chillies for Glamour Models Atelier
  const [userChillies, setUserChillies] = useState<number>(75);

  // Model Character Presentation Overlay (Bible Item 17: 5s reveal, 10s dialogue)
  const [selectedModelArrival, setSelectedModelArrival] = useState<ModelProfile | null>(null);

  // Flute Tiny Character State (Bible Item 20)
  const [selectedTinyId, setSelectedTinyId] = useState<string>('tiny-krishna-flute');
  const [tinyPrivacyMode, setTinyPrivacyMode] = useState<'avatar-only' | 'approved-photo' | 'private'>('avatar-only');

  // Astra Combo Overlay State (Bible Item 19)
  const [activeCombo, setActiveCombo] = useState<{
    name: string;
    count: number;
    description: string;
    petReactionEmoji?: string;
  } | null>(null);

  // 4D & Neon-Liquid Family Visual State (Bible Item 22)
  const [visual4D, setVisual4D] = useState<Visual4DState>({
    liquidNeonButtons: true,
    holographicDice: true,
    bioluminescentBoard: true,
    jellyTokens: true,
    victoryShockwaves: true,
    weatherArena: 'clear',
    cinematicKillCam: true,
    soundReactiveBorders: true,
    zeroGravityLobby: true,
  });

  // Active Flying Reaction & Throwable Impacts
  const [activeImpacts, setActiveImpacts] = useState<ActiveImpact[]>([]);

  // Selected Target Seat for Direct Gifting
  const [giftTargetSeat, setGiftTargetSeat] = useState<Seat | null>(null);

  // Cinematic Entry Overlay (Bible Item 21: Hypercar, Sudarshan, Gada, Trishul, Signature Photo, Cyber-Dragon)
  const [activeEntryCinematic, setActiveEntryCinematic] = useState<{
    type: EntryCinematicType;
    name: string;
    title: string;
  }>({ type: null, name: '', title: '' });

  // Active Board Astra visual effect overlay
  const [activeAstraEffect, setActiveAstraEffect] = useState<string | null>(null);

  // Active Private Room Match Config
  const [activePrivateRoom, setActivePrivateRoom] = useState<{
    roomCode: string;
    mode: 'classic' | 'quick' | 'team';
    stakeAmount: number;
    currency: 'coins' | 'diamonds';
  } | null>(null);

  // Match Victory & Podium State
  const [matchWinner, setMatchWinner] = useState<Player | null>(null);
  const [isVictoryModalOpen, setIsVictoryModalOpen] = useState<boolean>(false);
  const [userWinStreak, setUserWinStreak] = useState<number>(3); // Defaults to 3 for immediate 3-win streak experience!

  // Active Modal & Overlay Fade-Out Exit State
  const [closingModal, setClosingModal] = useState<string | null>(null);

  // Smooth fade-out exit handler for all modals and overlays (closed via close buttons or Escape key)
  const handleCloseWithExitAnimation = useCallback(
    (targetId?: string) => {
      if (closingModal) return;

      let id = targetId;
      let cleanupAction = () => {};

      if (id) {
        if (id === 'victory') {
          cleanupAction = () => setIsVictoryModalOpen(false);
        } else if (id === 'museum') {
          cleanupAction = () => setIsMuseumOpen(false);
        } else if (id === 'wheel') {
          cleanupAction = () => setIsWheelOpen(false);
        } else if (id === 'drawer') {
          cleanupAction = () => setIsDrawerOpen(false);
        } else if (id === 'miracle') {
          cleanupAction = () => setIsMiracleActive(false);
        } else if (id === 'takshak') {
          cleanupAction = () => setIsTakshakActive(false);
        } else if (id === 'cinematic') {
          cleanupAction = () =>
            setActiveEntryCinematic({ type: null, name: '', title: '' });
        } else if (id === 'model-presentation') {
          cleanupAction = () => setSelectedModelArrival(null);
        } else if (id === 'combo') {
          cleanupAction = () => setActiveCombo(null);
        } else {
          cleanupAction = () => {
            setActiveModal(null);
            if (id === 'gifts') setGiftTargetSeat(null);
          };
        }
      } else {
        // Auto-detect top-level modal or overlay currently visible
        if (activeCombo) {
          id = 'combo';
          cleanupAction = () => setActiveCombo(null);
        } else if (activeEntryCinematic.type) {
          id = 'cinematic';
          cleanupAction = () =>
            setActiveEntryCinematic({ type: null, name: '', title: '' });
        } else if (selectedModelArrival) {
          id = 'model-presentation';
          cleanupAction = () => setSelectedModelArrival(null);
        } else if (isMiracleActive) {
          id = 'miracle';
          cleanupAction = () => setIsMiracleActive(false);
        } else if (isTakshakActive) {
          id = 'takshak';
          cleanupAction = () => setIsTakshakActive(false);
        } else if (isVictoryModalOpen) {
          id = 'victory';
          cleanupAction = () => setIsVictoryModalOpen(false);
        } else if (activeModal) {
          id = activeModal;
          cleanupAction = () => {
            setActiveModal(null);
            if (activeModal === 'gifts') setGiftTargetSeat(null);
          };
        } else if (isMuseumOpen) {
          id = 'museum';
          cleanupAction = () => setIsMuseumOpen(false);
        } else if (isWheelOpen) {
          id = 'wheel';
          cleanupAction = () => setIsWheelOpen(false);
        } else if (isDrawerOpen) {
          id = 'drawer';
          cleanupAction = () => setIsDrawerOpen(false);
        }
      }

      if (!id) return;

      sound.playClick();
      setClosingModal(id);

      setTimeout(() => {
        cleanupAction();
        setClosingModal(null);
      }, 230); // 230ms smooth fade-out exit animation
    },
    [
      closingModal,
      activeCombo,
      activeEntryCinematic,
      selectedModelArrival,
      isMiracleActive,
      isTakshakActive,
      isVictoryModalOpen,
      activeModal,
      isMuseumOpen,
      isWheelOpen,
      isDrawerOpen,
    ]
  );

  // Global Escape keydown listener for all screens & modals
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseWithExitAnimation();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleCloseWithExitAnimation]);

  // Astra Activation Cooldown (in seconds)
  const ASTRA_COOLDOWN_TOTAL = 15;
  const [astraCooldown, setAstraCooldown] = useState<number>(0);
  const [isAstraGleam, setIsAstraGleam] = useState<boolean>(false);

  // Real In-Game Mechanical Astra Weapons State
  const [isEarthquakeActive, setIsEarthquakeActive] = useState<boolean>(false);
  const [isVajraShieldActive, setIsVajraShieldActive] = useState<boolean>(false);
  const [shieldTurnsRemaining, setShieldTurnsRemaining] = useState<number>(0);
  const [weaponCooldowns, setWeaponCooldowns] = useState<Record<string, number>>({
    gada: 0,
    trishul: 0,
    sudarshan: 0,
    vajra: 0,
  });

  // Tick weapon cooldowns down each second
  useEffect(() => {
    const hasCooldown = Object.values(weaponCooldowns).some((cd) => cd > 0);
    if (!hasCooldown) return;

    const timer = setInterval(() => {
      setWeaponCooldowns((prev) => {
        const next: Record<string, number> = {};
        Object.entries(prev).forEach(([key, val]) => {
          next[key] = Math.max(0, val - 1);
        });
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [weaponCooldowns]);

  // Visual Cooldown Timer for Astra abilities
  useEffect(() => {
    if (astraCooldown <= 0) return;

    const timer = setInterval(() => {
      setAstraCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Play dedicated divine celestial chime + sound.playClick()
          sound.playAstraReady();
          setIsAstraGleam(true);
          setTimeout(() => setIsAstraGleam(false), 2500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [astraCooldown]);

  // Forced Dice from Admin
  const [forcedDiceVal, setForcedDiceVal] = useState<number | null>(null);

  // Bot Speed
  const [botSpeed, setBotSpeed] = useState<'fast' | 'normal' | 'slow'>('normal');

  // Equipped Cosmetics & Astra Multiplicity Inventory for Astra Forge
  const [astraInventory, setAstraInventory] = useState<Record<string, number>>({
    'trishul-aura': 1,
    'surya-rath': 3,     // Vedic Astra (3x ready for Forge!)
    'varun-vortex': 1,
    'indra-vajra': 3,    // High Celestial (3x ready for Forge!)
    'gada-entry': 3,     // Ultra Divine (3x ready for Forge into Apex!)
  });

  const unlockedAstraIds = Object.keys(astraInventory).filter(
    (id) => (astraInventory[id] || 0) > 0
  );
  const [equippedAstraId, setEquippedAstraId] = useState<string>('trishul-aura');
  const [pets, setPets] = useState<PetItem[]>(RARE_PETS);
  const [equippedPetId, setEquippedPetId] = useState<string>('pet-celestial-dragon');
  const [hasClaimedCodex, setHasClaimedCodex] = useState(false);

  // 8-Seat Live Audio Room setup
  const [seats, setSeats] = useState<Seat[]>([
    {
      id: 1,
      playerName: 'VikingKing (You)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'gold-wings',
      isMuted: false,
      isSpeaking: true,
      volume: 85,
      level: 58,
      title: 'Trishul Master',
      coins: 2500000,
      diamonds: 100000000,
      isHotSeat: true,
      equippedAstra: 'trishul-aura',
    },
    {
      id: 2,
      playerName: 'Princess Balqis',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'purple-empress',
      isMuted: false,
      isSpeaking: false,
      volume: 60,
      level: 42,
      title: 'Amethyst Queen',
      coins: 890000,
      diamonds: 45000,
    },
    {
      id: 3,
      playerName: 'Sovereign Aryan',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'lion-crest',
      isMuted: true,
      isSpeaking: false,
      volume: 0,
      level: 70,
      title: 'Lion of Ayodhya',
      coins: 3400000,
      diamonds: 120000,
    },
    {
      id: 4,
      playerName: 'Danisya Nag',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'neon-heart',
      isMuted: false,
      isSpeaking: true,
      volume: 75,
      level: 35,
      title: 'Serpent Princess',
      coins: 560000,
      diamonds: 8900,
    },
    {
      id: 5,
      playerName: 'Indra Thunder',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'golden-vajra',
      isMuted: true,
      isSpeaking: false,
      volume: 0,
      level: 61,
      title: 'Vajra Wielder',
      coins: 1900000,
      diamonds: 67000,
    },
    {
      id: 6,
      playerName: 'Tara Starlight',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'blue-angel',
      isMuted: false,
      isSpeaking: false,
      volume: 40,
      level: 49,
      title: 'Cosmic Seeker',
      coins: 1100000,
      diamonds: 29000,
    },
    {
      id: 7,
      playerName: 'Maharishi Dev',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'divine-halo',
      isMuted: true,
      isSpeaking: false,
      volume: 0,
      level: 85,
      title: 'Vedic Elder',
      coins: 4500000,
      diamonds: 340000,
    },
    {
      id: 8,
      playerName: 'Cyber Phoenix',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'cyber-dragon',
      isMuted: false,
      isSpeaking: true,
      volume: 80,
      level: 52,
      title: 'Immortal Flame',
      coins: 980000,
      diamonds: 18000,
    },
  ]);

  // Live Chat Stream
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'System Broadcast',
      avatar: '',
      text: '🔱 Welcome to Ludo Cosmic Royale 3D! 8-Seat Live Audio Arena active.',
      type: 'astra',
      timestamp: 'Just now',
      badge: 'OFFICIAL',
    },
    {
      id: 'm2',
      sender: 'Princess Balqis',
      avatar: '',
      text: 'Good luck everyone! Let us roll high 6s! ✨',
      type: 'chat',
      timestamp: '1m ago',
      badge: 'VIP 5',
    },
  ]);

  // ===================== CORE LUDO STATE MACHINE =====================
  const [players, setPlayers] = useState<Player[]>([
    {
      id: 'p1',
      name: 'VikingKing (You)',
      color: 'red',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      avatarFrame: 'frame-gold-wings',
      isBot: false,
      tokens: [
        { id: 0, color: 'red', position: -1, stepCount: 0 },
        { id: 1, color: 'red', position: -2, stepCount: 0 },
        { id: 2, color: 'red', position: -3, stepCount: 0 },
        { id: 3, color: 'red', position: -4, stepCount: 0 },
      ],
      hasFinished: false,
      level: 58,
      title: 'Trishul Master',
    },
    {
      id: 'p2',
      name: 'Princess Balqis',
      color: 'green',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80',
      avatarFrame: 'frame-purple-empress',
      isBot: true,
      tokens: [
        { id: 0, color: 'green', position: -1, stepCount: 0 },
        { id: 1, color: 'green', position: -2, stepCount: 0 },
        { id: 2, color: 'green', position: -3, stepCount: 0 },
        { id: 3, color: 'green', position: -4, stepCount: 0 },
      ],
      hasFinished: false,
      level: 42,
      title: 'Amethyst Queen',
    },
    {
      id: 'p3',
      name: 'Sovereign Aryan',
      color: 'yellow',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      avatarFrame: 'frame-lion-crest',
      isBot: true,
      tokens: [
        { id: 0, color: 'yellow', position: -1, stepCount: 0 },
        { id: 1, color: 'yellow', position: -2, stepCount: 0 },
        { id: 2, color: 'yellow', position: -3, stepCount: 0 },
        { id: 3, color: 'yellow', position: -4, stepCount: 0 },
      ],
      hasFinished: false,
      level: 70,
      title: 'Lion of Ayodhya',
    },
    {
      id: 'p4',
      name: 'Danisya Nag',
      color: 'blue',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      avatarFrame: 'frame-neon-heart',
      isBot: true,
      tokens: [
        { id: 0, color: 'blue', position: -1, stepCount: 0 },
        { id: 1, color: 'blue', position: -2, stepCount: 0 },
        { id: 2, color: 'blue', position: -3, stepCount: 0 },
        { id: 3, color: 'blue', position: -4, stepCount: 0 },
      ],
      hasFinished: false,
      level: 35,
      title: 'Serpent Princess',
    },
  ]);

  const [activePlayerIndex, setActivePlayerIndex] = useState<number>(0);
  const [diceValue, setDiceValue] = useState<number>(6);
  const [isRolling, setIsRolling] = useState<boolean>(false);
  const [canRoll, setCanRoll] = useState<boolean>(true);
  const [bonusRoll, setBonusRoll] = useState<boolean>(false);
  const [selectableTokenIds, setSelectableTokenIds] = useState<number[]>([]);

  const activePlayer = players[activePlayerIndex];

  // Helper: Next Turn
  const passTurn = (isBonus: boolean = false) => {
    if (isBonus) {
      setCanRoll(true);
      setSelectableTokenIds([]);
      return;
    }

    setBonusRoll(false);
    setSelectableTokenIds([]);

    // Decrement Vajra Shield turns
    if (shieldTurnsRemaining > 0) {
      if (shieldTurnsRemaining <= 1) {
        setShieldTurnsRemaining(0);
        setIsVajraShieldActive(false);
      } else {
        setShieldTurnsRemaining((prev) => prev - 1);
      }
    }

    setActivePlayerIndex((prev) => (prev + 1) % players.length);
    setCanRoll(true);
  };

  // Bot Turn Automation (runs in arena)
  useEffect(() => {
    if (currentView === 'arena' && activePlayer.isBot && canRoll && !isRolling) {
      const delay = botSpeed === 'fast' ? 500 : 1200;
      const timer = setTimeout(() => {
        handleDiceRoll();
      }, delay);
      return () => clearTimeout(timer);
    }
  }, [currentView, activePlayerIndex, canRoll, isRolling]);

  // Dice Roll Handler
  const handleDiceRoll = () => {
    if (!canRoll || isRolling) return;
    setIsRolling(true);
    setCanRoll(false);

    setTimeout(() => {
      // Determine final roll (support forced dice from Admin)
      const rolled = forcedDiceVal || Math.floor(Math.random() * 6) + 1;
      setDiceValue(rolled);
      setIsRolling(false);

      // Check legal moves
      const legalTokens: number[] = [];
      activePlayer.tokens.forEach((t) => {
        // In base: only 6 can deploy
        if (t.position < 0) {
          if (rolled === 6) legalTokens.push(t.id);
        } else if (t.position !== 999) {
          // On main path or home stretch
          if (t.stepCount + rolled <= 57) {
            legalTokens.push(t.id);
          }
        }
      });

      // Announce roll in chat feed
      setMessages((prev) => [
        {
          id: `roll-${Date.now()}`,
          sender: activePlayer.name,
          avatar: activePlayer.avatar,
          text: `rolled a ${rolled}! 🎲`,
          type: 'roll',
          timestamp: 'Just now',
          badge: `Lv.${activePlayer.level}`,
        },
        ...prev.slice(0, 40),
      ]);

      if (legalTokens.length === 0) {
        // No legal move: pass turn after short pause
        setTimeout(() => passTurn(false), 900);
      } else if (activePlayer.isBot) {
        // Bot auto picks best legal token
        setSelectableTokenIds(legalTokens);
        setTimeout(() => {
          // Priority: 1. Deploy base if 6, 2. Move furthest token
          let chosen = legalTokens[0];
          const baseToken = legalTokens.find((id) => activePlayer.tokens[id].position < 0);
          if (baseToken !== undefined) {
            chosen = baseToken;
          }
          handleTokenClick(chosen);
        }, 800);
      } else {
        // Human player selection
        setSelectableTokenIds(legalTokens);
      }
    }, 750);
  };

  // Move Token Handler
  const handleTokenClick = (tokenId: number) => {
    if (!selectableTokenIds.includes(tokenId)) return;

    sound.playTokenHop();
    const token = activePlayer.tokens[tokenId];
    let nextPos = token.position;
    let nextStepCount = token.stepCount;
    let isCapture = false;
    let isFinishedHome = false;

    // Case 1: Deploy from base
    if (token.position < 0) {
      nextPos = PLAYER_START_CELLS[token.color];
      nextStepCount = 1;
    } else {
      // Case 2: Advance on track
      nextStepCount += diceValue;

      if (nextStepCount === 57) {
        // Finished inside victory triangle!
        nextPos = 999;
        isFinishedHome = true;
        sound.playFanfare();
        confetti({ particleCount: 70, spread: 60 });
      } else if (nextStepCount > 51) {
        // Home runway
        const offset = nextStepCount - 52;
        nextPos = 100 + offset;
      } else {
        // Main circular 52-cell track
        nextPos = (token.position + diceValue) % 52;
      }
    }

    // Check Capture on Main Track
    if (nextPos >= 0 && nextPos < 52 && !SAFE_CELL_INDICES.includes(nextPos)) {
      players.forEach((p) => {
        if (p.color !== token.color) {
          p.tokens.forEach((otherT) => {
            if (otherT.position === nextPos) {
              if (p.color === 'red' && isVajraShieldActive) {
                // Shielded! Cannot be captured!
                sound.playSafeCell();
                setMessages((prev) => [
                  {
                    id: `shield-${Date.now()}`,
                    sender: 'Indra Vajra Shield',
                    avatar: '',
                    text: `🛡️ DEFLECTED: Indra's Vajra Shield protected VikingKing's token from capture at cell #${nextPos}!`,
                    type: 'astra',
                    timestamp: 'Just now',
                    badge: 'INVULNERABLE',
                  },
                  ...prev.slice(0, 40),
                ]);
                return;
              }

              // Capture opponent token!
              isCapture = true;
              otherT.position = -(otherT.id + 1); // Send back to base
              otherT.stepCount = 0;
              sound.playCapture();
              confetti({ particleCount: 50, spread: 50 });

              // Bible Section 1 & 7: 5 diamonds per qualifying cut, max 40 diamonds/day cap
              let rewardText = `💥 CAPTURED ${p.name}'s token at cell #${nextPos}!`;
              if (!activePlayer.isBot) {
                const currentDaily = dailyCutDiamondsEarned;
                if (currentDaily < 40) {
                  const cutReward = Math.min(5, 40 - currentDaily);
                  const updatedDaily = currentDaily + cutReward;
                  setDailyCutDiamondsEarned(updatedDaily);
                  setUserDiamonds((d) => d + cutReward);
                  rewardText = `💥 CUT MASTER: Captured ${p.name}'s token! +${cutReward} 💎 Reward (Daily Cap: ${updatedDaily}/40 💎)`;
                } else {
                  rewardText = `💥 CAPTURED ${p.name}'s token! (Daily 40/40 💎 Cut Cap Reached)`;
                }
              }

              // Announce capture in chat
              setMessages((prev) => [
                {
                  id: `cap-${Date.now()}`,
                  sender: activePlayer.name,
                  avatar: activePlayer.avatar,
                  text: rewardText,
                  type: 'capture',
                  timestamp: 'Just now',
                  badge: 'CUT MASTER',
                },
                ...prev.slice(0, 40),
              ]);
            }
          });
        }
      });
    }

    // Update tokens state
    setPlayers((prev) =>
      prev.map((p, idx) => {
        if (idx !== activePlayerIndex) return p;
        return {
          ...p,
          tokens: p.tokens.map((t) =>
            t.id === tokenId
              ? { ...t, position: nextPos, stepCount: nextStepCount }
              : t
          ),
        };
      })
    );

    setSelectableTokenIds([]);

    // Check Win Condition (all 4 tokens finished)
    const updatedTokens = activePlayer.tokens.map((t) =>
      t.id === tokenId ? { ...t, position: nextPos, stepCount: nextStepCount } : t
    );
    const hasWon = updatedTokens.every((t) => t.position === 999);

    if (hasWon) {
      const isUser = activePlayer.id === 'p1' || !activePlayer.isBot;
      const nextStreak = isUser ? userWinStreak + 1 : 1;
      if (isUser) {
        setUserWinStreak(nextStreak);
      }
      setMatchWinner({ ...activePlayer, winStreak: isUser ? nextStreak : 1 });
      setIsVictoryModalOpen(true);
      sound.playFanfare();
      confetti({ particleCount: 200, spread: 100 });
      setMessages((prev) => [
        {
          id: `win-${Date.now()}`,
          sender: 'Cosmic Arena Arbiter',
          avatar: '',
          text: `👑 CHAMPION VICTORY: ${activePlayer.name} has finished all 4 tokens! 🏆`,
          type: 'astra',
          timestamp: 'Just now',
          badge: 'VICTORY',
        },
        ...prev,
      ]);
      return;
    }

    // Bonus roll rule: roll of 6, capture, or home run grants extra turn!
    const earnedBonus = diceValue === 6 || isCapture || isFinishedHome;
    setBonusRoll(earnedBonus);
    setTimeout(() => passTurn(earnedBonus), 600);
  };

  // Toggle Seat Mic
  const handleToggleSeatMic = (seatId: number) => {
    sound.playMicBeep(true);
    setSeats((prev) =>
      prev.map((s) => (s.id === seatId ? { ...s, isMuted: !s.isMuted } : s))
    );
  };

  // Trigger Send Gift in Live Room
  const handleSendGift = (gift: GiftItem, recipient: Seat, quantity: number) => {
    const totalCost = gift.cost * quantity;

    if (gift.currency === 'diamonds') {
      if (userDiamonds < totalCost) {
        alert('Insufficient Diamonds! Use Admin Center to boost diamonds instantly.');
        return;
      }
      setUserDiamonds((prev) => prev - totalCost);
    } else {
      if (userCoins < totalCost) {
        alert('Insufficient Coins!');
        return;
      }
      setUserCoins((prev) => prev - totalCost);
    }

    sound.playGiftChime();

    // Trigger Hypercar Entry cinematic for Supercar gifts
    if (gift.id === 'gift-racing-car' || gift.id === 'gift-hypercar-fleet') {
      setActiveEntryCinematic({
        type: 'hypercar',
        name: 'VikingKing (You)',
        title: gift.name,
      });
    } else if (gift.id === 'gift-sudarshan-blessing') {
      setActiveEntryCinematic({
        type: 'sudarshan',
        name: 'VikingKing (You)',
        title: '79 Billion 💎 Sudarshan Om Vortex',
      });
    } else {
      confetti({ particleCount: 80, spread: 70 });
    }

    // Add message
    setMessages((prev) => [
      {
        id: `gift-${Date.now()}`,
        sender: 'VikingKing (You)',
        avatar: seats[0].avatar,
        text: `sent ${gift.icon} ${quantity}x ${gift.name} to ${recipient.playerName}!`,
        type: 'gift',
        timestamp: 'Just now',
        badge: 'VIP GIFT',
      },
      ...prev.slice(0, 40),
    ]);
  };

  // Equip Frame Handler
  const handleEquipFrame = (frameId: FrameStyleId) => {
    setEquippedFrame(frameId);
    // Update player and seat representation
    setSeats((prev) =>
      prev.map((s) => (s.id === 1 ? { ...s, frameStyle: frameId } : s))
    );
    setPlayers((prev) =>
      prev.map((p) =>
        p.id === 'p1' ? { ...p, avatarFrame: `frame-${frameId}` } : p
      )
    );
  };

  // Trigger Astra Activation on Board with Unique Cinematic Sound Effect
  const handleActivateAstra = (astra: AstraItem) => {
    if (astraCooldown > 0) return; // Prevent spamming divine abilities!

    setAstraCooldown(ASTRA_COOLDOWN_TOTAL);

    // Play unique cinematic sound effect based on Astra type
    if (astra.id === 'gada-entry' || astra.id.includes('gada') || astra.cinematicEffect === 'gada-smash') {
      sound.playGadaSlam();
    } else if (
      astra.id === 'sudarshan-entry' ||
      astra.id.includes('sudarshan') ||
      astra.cinematicEffect === 'sudarshan-spin'
    ) {
      sound.playSudarshanSpin();
    } else if (astra.id === 'indra-vajra' || astra.cinematicEffect === 'lightning-vajra') {
      sound.playVajraLightning();
    } else if (astra.id === 'surya-rath') {
      sound.playSolarRath();
    } else if (astra.id === 'varun-vortex') {
      sound.playOceanVortex();
    } else if (astra.id === 'brahmastra-apex') {
      sound.playBrahmastraApex();
    } else {
      sound.playTrishulThunder();
    }

    setActiveAstraEffect(astra.cinematicEffect);

    setActiveEntryCinematic({
      type:
        astra.id === 'trishul-aura' || astra.cinematicEffect === 'tandav'
          ? 'trishul'
          : astra.id === 'gada-entry' || astra.cinematicEffect === 'gada-smash'
          ? 'gada'
          : 'sudarshan',
      name: 'VikingKing',
      title: astra.name,
    });

    // Custom deity title
    const deityPrefix =
      astra.id === 'gada-entry' || astra.cinematicEffect === 'gada-smash'
        ? '🔨 Hanuman Mahabali Gada Slam Awakened'
        : astra.id === 'sudarshan-entry' || astra.cinematicEffect === 'sudarshan-spin'
        ? '☀️ Vishnu Sudarshan Chakra Awakened'
        : astra.id === 'indra-vajra' || astra.cinematicEffect === 'lightning-vajra'
        ? '⚡ Indra Deva Vajra Storm Awakened'
        : astra.id === 'surya-rath'
        ? '🏹 Surya Deva Radiant Kodanda Awakened'
        : astra.id === 'varun-vortex'
        ? '🌊 Varuna Deva Ocean Deluge Awakened'
        : astra.id === 'brahmastra-apex'
        ? '🪐 Brahmastra Cosmic Singularity Awakened'
        : '🔱 Mahadev Tandav Awakened';

    setMessages((prev) => [
      {
        id: `astra-${Date.now()}`,
        sender: 'Divine Astra Arbiter',
        avatar: '',
        text: `${deityPrefix}: ${astra.name} active across all 8 live seats!`,
        type: 'astra',
        timestamp: 'Just now',
        badge: astra.tier.toUpperCase(),
      },
      ...prev,
    ]);

    setTimeout(() => setActiveAstraEffect(null), 8000);
  };

  // Real Interactive Astra Weapon Cast Handler (True in-game gameplay impact)
  const handleCastAstraWeapon = (weaponId: 'gada' | 'trishul' | 'sudarshan' | 'vajra' | 'dhanush' | 'brahmastra') => {
    if (weaponCooldowns[weaponId] > 0) return;

    // Set weapon cooldown
    setWeaponCooldowns((prev) => ({ ...prev, [weaponId]: 15 }));

    if (weaponId === 'gada') {
      // 1. Hanuman Gada Slam: Seismic Earthquake + Guarantees Lucky 6
      sound.playGadaSlam();
      setIsEarthquakeActive(true);
      setActiveAstraEffect('gada-smash');
      setTimeout(() => setIsEarthquakeActive(false), 1400);
      setTimeout(() => setActiveAstraEffect(null), 3000);

      // Force lucky 6 on dice
      setForcedDiceVal(6);
      setDiceValue(6);
      setCanRoll(true);

      // If user has active tokens, check legal moves for 6
      const legalTokens: number[] = [];
      players[0].tokens.forEach((t) => {
        if (t.position < 0) legalTokens.push(t.id);
        else if (t.position !== 999 && t.stepCount + 6 <= 57) legalTokens.push(t.id);
      });
      setSelectableTokenIds(legalTokens);

      setMessages((prev) => [
        {
          id: `gada-${Date.now()}`,
          sender: 'Hanuman Gada Mahabali',
          avatar: '',
          text: '🔨 GADA EARTHQUAKE SLAM: Shook the cosmic board! Guaranteed Lucky 6 activated!',
          type: 'astra',
          timestamp: 'Just now',
          badge: 'GADA SLAM',
        },
        ...prev.slice(0, 40),
      ]);
    } else if (weaponId === 'trishul') {
      // 2. Mahadev Trishul Tandav: Strikes leading opponent token and banishes it back to yard!
      sound.playTrishulThunder();
      setActiveAstraEffect('tandav');
      setTimeout(() => setActiveAstraEffect(null), 3500);

      // Find leading opponent token
      let targetPlayerIdx = -1;
      let targetTokenId = -1;
      let highestSteps = -1;

      players.forEach((p, pIdx) => {
        if (pIdx !== 0) {
          p.tokens.forEach((t) => {
            if (t.position >= 0 && t.position !== 999 && t.stepCount > highestSteps) {
              highestSteps = t.stepCount;
              targetPlayerIdx = pIdx;
              targetTokenId = t.id;
            }
          });
        }
      });

      if (targetPlayerIdx !== -1 && targetTokenId !== -1) {
        // Banish to yard
        setPlayers((prev) =>
          prev.map((p, idx) => {
            if (idx !== targetPlayerIdx) return p;
            return {
              ...p,
              tokens: p.tokens.map((t) =>
                t.id === targetTokenId
                  ? { ...t, position: -(t.id + 1), stepCount: 0 }
                  : t
              ),
            };
          })
        );
        sound.playTokenCapture();
        confetti({ particleCount: 100, spread: 80 });

        setMessages((prev) => [
          {
            id: `trishul-${Date.now()}`,
            sender: 'Mahadev Trishul Tandav',
            avatar: '',
            text: `🔱 CELESTIAL STRIKE: Trishul lightning banished ${players[targetPlayerIdx].name}'s leading pawn back to the yard!`,
            type: 'astra',
            timestamp: 'Just now',
            badge: 'TRISHUL STRIKE',
          },
          ...prev.slice(0, 40),
        ]);
      } else {
        // If no opponent on field: deploy player's base pawn for free!
        const baseToken = players[0].tokens.find((t) => t.position < 0);
        if (baseToken) {
          setPlayers((prev) =>
            prev.map((p, idx) => {
              if (idx !== 0) return p;
              return {
                ...p,
                tokens: p.tokens.map((t) =>
                  t.id === baseToken.id ? { ...t, position: 0, stepCount: 0 } : t
                ),
              };
            })
          );
          sound.playSafeCell();
          confetti({ particleCount: 60, spread: 60 });
          setMessages((prev) => [
            {
              id: `trishul-${Date.now()}`,
              sender: 'Mahadev Trishul Tandav',
              avatar: '',
              text: '🔱 TRISHUL BLESSING: Free divine pawn deployment from the base yard onto start cell #0!',
              type: 'astra',
              timestamp: 'Just now',
              badge: 'FREE DEPLOY',
            },
            ...prev.slice(0, 40),
          ]);
        }
      }
    } else if (weaponId === 'sudarshan') {
      // 3. Vishnu Sudarshan Warp: Advances leading active token by +4 steps & grants extra roll!
      sound.playSudarshanSpin();
      setActiveAstraEffect('sudarshan-spin');
      setTimeout(() => setActiveAstraEffect(null), 3500);

      // Advance leading token
      const activePawn = players[0].tokens
        .filter((t) => t.position >= 0 && t.position !== 999)
        .sort((a, b) => b.stepCount - a.stepCount)[0];

      if (activePawn) {
        const nextStepCount = activePawn.stepCount + 4;
        let nextPos = (activePawn.position + 4) % 52;
        if (nextStepCount >= 57) {
          nextPos = 999;
          sound.playFanfare();
          confetti({ particleCount: 100, spread: 80 });
        } else if (nextStepCount > 51) {
          nextPos = 100 + (nextStepCount - 52);
        }

        setPlayers((prev) =>
          prev.map((p, idx) => {
            if (idx !== 0) return p;
            return {
              ...p,
              tokens: p.tokens.map((t) =>
                t.id === activePawn.id
                  ? { ...t, position: nextPos, stepCount: nextStepCount }
                  : t
              ),
            };
          })
        );
      } else {
        // If none on board, deploy first token
        const baseToken = players[0].tokens.find((t) => t.position < 0);
        if (baseToken) {
          setPlayers((prev) =>
            prev.map((p, idx) => {
              if (idx !== 0) return p;
              return {
                ...p,
                tokens: p.tokens.map((t) =>
                  t.id === baseToken.id ? { ...t, position: 0, stepCount: 0 } : t
                ),
              };
            })
          );
        }
      }

      // Grants extra roll
      setCanRoll(true);
      setDiceValue(6);
      confetti({ particleCount: 75, spread: 70 });

      setMessages((prev) => [
        {
          id: `sudarshan-${Date.now()}`,
          sender: 'Vishnu Sudarshan Chakra',
          avatar: '',
          text: '☀️ SUDARSHAN HYPER WARP: Warped champion forward +4 spaces and unlocked an instant extra roll!',
          type: 'astra',
          timestamp: 'Just now',
          badge: 'HYPER WARP',
        },
        ...prev.slice(0, 40),
      ]);
    } else if (weaponId === 'vajra') {
      // 4. Indra Vajra Shield: Invulnerability shield on all player's pawns for 3 turns!
      sound.playVajraLightning();
      setActiveAstraEffect('lightning-vajra');
      setTimeout(() => setActiveAstraEffect(null), 3000);

      setIsVajraShieldActive(true);
      setShieldTurnsRemaining(3);
      confetti({ particleCount: 60, spread: 60 });

      setMessages((prev) => [
        {
          id: `vajra-${Date.now()}`,
          sender: "Indra's Vajra",
          avatar: '',
          text: '⚡ VAJRA CELESTIAL SHIELD: Impenetrable plasma shield activated! Tokens cannot be captured for 3 turns!',
          type: 'astra',
          timestamp: 'Just now',
          badge: 'GODMODE SHIELD',
        },
        ...prev.slice(0, 40),
      ]);
    } else if (weaponId === 'dhanush') {
      // 5. Gandiva Dhanush: Fires celestial energy arrow advancing player token +2 steps safely!
      sound.playTrishulThunder();
      setActiveAstraEffect('solar-rath');
      setTimeout(() => setActiveAstraEffect(null), 3000);

      // Advance leading pawn +2
      const activePawn = players[0].tokens
        .filter((t) => t.position >= 0 && t.position !== 999)
        .sort((a, b) => b.stepCount - a.stepCount)[0];

      if (activePawn && activePawn.stepCount + 2 <= 57) {
        setPlayers((prev) =>
          prev.map((p, idx) => {
            if (idx !== 0) return p;
            return {
              ...p,
              tokens: p.tokens.map((t) =>
                t.id === activePawn.id
                  ? {
                      ...t,
                      position: (t.position + 2) % 52,
                      stepCount: t.stepCount + 2,
                    }
                  : t
              ),
            };
          })
        );
        sound.playSafeCell();
      }

      setMessages((prev) => [
        {
          id: `dhanush-${Date.now()}`,
          sender: 'Gandiva Dhanush Arrow Volley',
          avatar: '',
          text: '🏹 GANDIVA VOLLEY: Golden cosmic arrows propelled your champion +2 steps forward!',
          type: 'astra',
          timestamp: 'Just now',
          badge: 'ARROW VOLLEY',
        },
        ...prev.slice(0, 40),
      ]);
    } else if (weaponId === 'brahmastra') {
      // 6. Brahmastra Universe Core: Temporary board hold (Bible Item 18: 10 uses hold)
      sound.playTrishulTandav();
      setActiveAstraEffect('tandav');
      setTimeout(() => setActiveAstraEffect(null), 4000);
      confetti({ particleCount: 90, spread: 80 });

      setMessages((prev) => [
        {
          id: `brahmastra-${Date.now()}`,
          sender: 'Brahmastra Universe Core',
          avatar: '',
          text: '🔱 BRAHMASTRA APEX STRIKE: Summoned cosmic creator rings of fire! Opponents immobilized for 1 round!',
          type: 'astra',
          timestamp: 'Just now',
          badge: 'BRAHMASTRA APEX',
        },
        ...prev.slice(0, 40),
      ]);
    }
  };

  // Astra Forge Handler (Combines 3 identical lower-tier Astras into a random higher-tier one)
  const handleForgeAstra = (sourceAstra: AstraItem): AstraItem | null => {
    const currentCount = astraInventory[sourceAstra.id] || 0;
    if (currentCount < 3) return null;

    const nextTier = NEXT_TIER[sourceAstra.tier];
    if (!nextTier) return null;

    const candidates = ASTRA_ITEMS.filter((a) => a.tier === nextTier);
    if (candidates.length === 0) return null;

    const reward = candidates[Math.floor(Math.random() * candidates.length)];

    // State Management: Destroy 3 copies of source Astra, create 1 copy of higher-tier reward Astra
    setAstraInventory((prev) => {
      const next = { ...prev };
      const remaining = (next[sourceAstra.id] || 0) - 3;
      if (remaining <= 0) {
        delete next[sourceAstra.id];
      } else {
        next[sourceAstra.id] = remaining;
      }
      next[reward.id] = (next[reward.id] || 0) + 1;
      return next;
    });

    // If equipped Astra was the one destroyed and now drops to 0, auto-equip the new reward
    if (equippedAstraId === sourceAstra.id && currentCount <= 3) {
      setEquippedAstraId(reward.id);
    }

    // Live Feed announcement
    setMessages((prev) => [
      {
        id: `forge-${Date.now()}`,
        sender: 'Astra Forge Altar',
        avatar: '',
        text: `⚡ Transmuted 3x ${sourceAstra.name} in the Astra Forge and crafted ${nextTier} artifact: ${reward.name} (${reward.hindiName})!`,
        type: 'astra',
        timestamp: 'Just now',
        badge: 'FORGE CRAFTED',
      },
      ...prev,
    ]);

    return reward;
  };

  // Helper to add test copies of any Astra
  const handleAddTestAstraCopies = (astraId: string, count: number) => {
    setAstraInventory((prev) => ({
      ...prev,
      [astraId]: (prev[astraId] || 0) + count,
    }));
  };

  // Launch Game from Lobby
  const handleStartGame = (mode: 'quick' | 'astra' | 'bot') => {
    setActivePrivateRoom(null);
    setCurrentView('arena');
    if (mode === 'astra') {
      handleActivateAstra(ASTRA_ITEMS[0]);
    }
  };

  // Start Private Match from PrivateRoomModal
  const handleStartPrivateMatch = (config: {
    roomCode: string;
    mode: 'classic' | 'quick' | 'team';
    stakeAmount: number;
    currency: 'coins' | 'diamonds';
  }) => {
    setActivePrivateRoom(config);
    if (config.currency === 'coins') {
      setUserCoins((prev) => Math.max(0, prev - config.stakeAmount));
    } else {
      setUserDiamonds((prev) => Math.max(0, prev - config.stakeAmount));
    }

    setCurrentView('arena');
    setMessages((prev) => [
      {
        id: `priv-${Date.now()}`,
        sender: 'Private Match Arbiter',
        avatar: '',
        text: `🎮 Private Room [${config.roomCode}] match started! Mode: ${config.mode.toUpperCase()} · Pot: ${config.currency === 'coins' ? '🪙' : '💎'} ${(config.stakeAmount * 4).toLocaleString()}`,
        type: 'chat',
        timestamp: 'Just now',
        badge: 'PRIVATE ROOM',
      },
      ...prev,
    ]);
  };

  // Rematch / Play Again Handler
  const handlePlayAgain = () => {
    setPlayers((prev) =>
      prev.map((player) => ({
        ...player,
        hasFinished: false,
        tokens: [
          { id: 0, color: player.color, position: -1, stepCount: 0 },
          { id: 1, color: player.color, position: -2, stepCount: 0 },
          { id: 2, color: player.color, position: -3, stepCount: 0 },
          { id: 3, color: player.color, position: -4, stepCount: 0 },
        ],
      }))
    );
    setActivePlayerIndex(0);
    setDiceValue(6);
    setCanRoll(true);
    setIsRolling(false);
    setSelectableTokenIds([]);
    setIsVictoryModalOpen(false);
    setMatchWinner(null);
    setMessages((prev) => [
      {
        id: `rematch-${Date.now()}`,
        sender: 'Cosmic Arena Arbiter',
        avatar: '',
        text: '⚔️ REMATCH INITIATED: All 16 tokens reset to yards. Red rolls first!',
        type: 'astra',
        timestamp: 'Just now',
        badge: 'REMATCH',
      },
      ...prev,
    ]);
  };

  // Claim Victory Rewards Handler
  const handleClaimVictoryRewards = (coins: number, diamonds: number) => {
    setUserCoins((prev) => prev + coins);
    setUserDiamonds((prev) => prev + diamonds);
  };

  // Enter Room from Directory
  const handleEnterRoom = (room: LiveRoom) => {
    setCurrentView('arena');
    setActiveEntryCinematic({
      type: 'hypercar',
      name: 'Akshay (VikingKing)',
      title: `Joined ${room.title}`,
    });
    setMessages((prev) => [
      {
        id: `entry-${Date.now()}`,
        sender: 'Live Room Gateway',
        avatar: '',
        text: `🚀 Akshay is onboard: Joined ${room.title} with Neon Hypercar arrival!`,
        type: 'entry',
        timestamp: 'Just now',
        badge: 'VIP ENTRY',
      },
      ...prev,
    ]);
  };

  // Toggle Audio
  const handleToggleAudio = () => {
    const next = !isAudioMuted;
    setIsAudioMuted(next);
    sound.toggleMute(next);
  };

  // Handle In-Match Throwables (Tomatoes, Bombs, Roses, Water, Punch, Eggs)
  const handleThrowReaction = (item: ThrowableReaction) => {
    if (item.type === 'tomato') sound.playTomatoSplat();
    else if (item.type === 'bomb') sound.playBombExplosion();
    else if (item.type === 'rose') sound.playRoseChime();
    else if (item.type === 'water') sound.playWaterSplash();
    else if (item.type === 'punch') sound.playPunch();
    else if (item.type === 'egg') sound.playTomatoSplat();
    else sound.playTrophy();

    const randomX = 40 + Math.random() * 20;
    const randomY = 35 + Math.random() * 25;

    const newImpact: ActiveImpact = {
      id: `impact-${Date.now()}-${Math.random()}`,
      type: item.type,
      emoji: item.emoji,
      senderName: 'VikingKing (You)',
      x: randomX,
      y: randomY,
    };

    setActiveImpacts((prev) => [...prev, newImpact]);

    setMessages((prev) => [
      {
        id: `react-${Date.now()}`,
        sender: 'VikingKing (You)',
        avatar: seats[0].avatar,
        text: `threw a ${item.name} ${item.emoji} across the board!`,
        type: 'chat',
        timestamp: 'Just now',
        badge: 'VIP 10',
      },
      ...prev,
    ]);
  };

  // Handle Voice Taunts
  const handleVoiceTaunt = (text: string) => {
    sound.speakTaunt(text);

    const newImpact: ActiveImpact = {
      id: `taunt-${Date.now()}-${Math.random()}`,
      type: 'taunt',
      tauntText: text,
      senderName: 'VikingKing (You)',
      x: 50,
      y: 45,
    };

    setActiveImpacts((prev) => [...prev, newImpact]);

    setMessages((prev) => [
      {
        id: `taunt-${Date.now()}`,
        sender: 'VikingKing (You)',
        avatar: seats[0].avatar,
        text: `🗣️ "${text}"`,
        type: 'chat',
        timestamp: 'Just now',
        badge: 'VIP 10',
      },
      ...prev,
    ]);
  };

  return (
    <div className="relative min-h-screen bg-[#070510] text-slate-100 flex flex-col font-sans overflow-x-hidden selection:bg-amber-500 selection:text-slate-950">
      {/* Background radial celestial glows */}
      <div className="fixed top-0 left-1/4 w-[600px] h-[600px] bg-purple-950/25 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed bottom-0 right-1/4 w-[600px] h-[600px] bg-indigo-950/25 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed top-1/3 right-10 w-[350px] h-[350px] bg-amber-500/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Dropdown Quick-Jump Launcher (Bible Section 4: ~10 visible + More/+) */}
      <TopDropdownLauncher
        onOpenModal={(modal) => setActiveModal(modal)}
        onNavigate={(view) => setCurrentView(view)}
        onOpenMuseum={() => setIsMuseumOpen(true)}
      />

      {/* ========================================================
          1. TOP APP BAR (Profile, Balances, Settings)
         ======================================================== */}
      <header className="sticky top-0 z-40 w-full glass-panel border-b border-white/10 px-3 sm:px-6 py-2.5 flex items-center justify-between">
        {/* Left: User Profile Pill */}
        <div
          onClick={() => {
            sound.playClick();
            setCurrentView('profile');
          }}
          className="flex items-center gap-2.5 p-1 sm:pr-3 rounded-full glass-card hover:border-amber-400/40 cursor-pointer transition group"
        >
          {/* Avatar with equipped frame */}
          <div
            className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full overflow-hidden bg-slate-800 frame-${equippedFrame}`}
          >
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="hidden sm:block text-left">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white group-hover:text-amber-300 transition">
                VikingKing
              </span>
              <span className="px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 text-[9px] font-black">
                VIP 10
              </span>
            </div>
            <p className="text-[10px] text-amber-400 font-semibold">Lv.58 · Trishul Master</p>
          </div>
        </div>

        {/* Center / Right: Currency Balances & Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Android APK Download Quick Pill */}
          <button
            onClick={() => {
              sound.playFanfare();
              setActiveModal('apk');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-emerald-600/40 via-teal-700/40 to-emerald-600/40 border border-emerald-400/60 hover:border-emerald-300 cursor-pointer transition text-xs font-black text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)] hover:scale-105 active:scale-95"
            title="Download Android APK / Install App"
          >
            <span className="text-xs">📲</span>
            <span className="text-[10px] uppercase font-black tracking-wider">APK</span>
          </button>

          {/* Season Pass Quick Pill */}
          <div
            onClick={() => {
              sound.playGrandVictory();
              setActiveModal('pass');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-600/40 via-purple-700/40 to-amber-600/40 border border-amber-400/60 hover:border-amber-300 cursor-pointer transition text-xs font-black text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)] hover:scale-105 active:scale-95"
            title="Season 1 Cosmic Pass · Level 4 (Tap to open)"
          >
            <Crown size={13} className="text-yellow-400 animate-pulse" />
            <span className="hidden sm:inline">PASS</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-black">
              LV.4
            </span>
          </div>

          {/* Butterfly Egg Hatchery Quick Pill */}
          <button
            onClick={() => {
              sound.playFanfare();
              setActiveModal('butterfly');
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-emerald-600/40 via-teal-700/40 to-emerald-600/40 border border-emerald-400/60 hover:border-emerald-300 cursor-pointer transition text-xs font-black text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)] hover:scale-105 active:scale-95"
            title="Mystic Butterfly Eggs & Hatchery"
          >
            <span className="text-xs">🦋</span>
            <span className="hidden md:inline uppercase text-[10px] tracking-wider">Hatchery</span>
          </button>

          {/* Game Niyam (Rules) Quick Pill */}
          <button
            onClick={() => {
              sound.playClick();
              setActiveModal('rules');
            }}
            className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-900 border border-amber-400/40 hover:border-amber-300 cursor-pointer transition text-xs font-black text-amber-300 hover:scale-105 active:scale-95"
            title="Game Niyam (खेल के नियम)"
          >
            <span className="text-xs">📜</span>
            <span className="hidden sm:inline uppercase text-[10px] tracking-wider">Niyam</span>
          </button>

          {/* Game Bible Reference Quick Pill */}
          <button
            onClick={() => {
              sound.playGrandVictory();
              setActiveModal('bible');
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-600/40 via-yellow-600/40 to-amber-600/40 border border-amber-400/60 hover:border-yellow-300 cursor-pointer transition text-xs font-black text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)] hover:scale-105 active:scale-95 animate-pulse"
            title="Ludo Master Game Bible (Page 2 Concept Reference)"
          >
            <span className="text-xs">📖</span>
            <span className="uppercase text-[10px] tracking-wider">Bible</span>
          </button>

          {/* Diamonds Counter */}
          <div
            onClick={() => {
              sound.playClick();
              setCurrentView('store');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full glass-card hover:border-amber-400/40 cursor-pointer transition text-xs font-bold"
            title="Diamonds Balance · Click to open Store"
          >
            <span className="text-sm">💎</span>
            <span className="text-amber-300 font-black">
              {userDiamonds >= 1000000
                ? `${(userDiamonds / 1000000).toFixed(1)}M`
                : userDiamonds.toLocaleString()}
            </span>
            <span className="w-4 h-4 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-black">
              +
            </span>
          </div>

          {/* Coins Counter */}
          <div
            onClick={() => {
              sound.playClick();
              setCurrentView('store');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full glass-card hover:border-amber-400/40 cursor-pointer transition text-xs font-bold hidden xs:flex"
            title="Coins Balance"
          >
            <span className="text-sm">🪙</span>
            <span className="text-yellow-300 font-black">
              {userCoins >= 1000000
                ? `${(userCoins / 1000000).toFixed(1)}M`
                : userCoins.toLocaleString()}
            </span>
          </div>

          {/* Stars Counter */}
          <div className="flex items-center gap-1 px-2 py-1 rounded-full glass-card text-xs font-bold hidden md:flex text-emerald-300">
            <span>⭐</span>
            <span>{userStars.toLocaleString()}</span>
          </div>

          {/* Audio Mute Toggle */}
          <button
            onClick={handleToggleAudio}
            className="p-2 rounded-full glass-card hover:border-white/20 text-slate-300 hover:text-white transition"
            title={isAudioMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isAudioMuted ? (
              <VolumeX size={17} className="text-rose-400" />
            ) : (
              <Volume2 size={17} className="text-amber-400" />
            )}
          </button>

          {/* Unique Player ID / Login Board Button (Bible Item 26) */}
          <button
            onClick={() => {
              sound.playClick();
              setActiveModal('auth');
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-amber-400/50 text-amber-300 hover:border-amber-300 transition text-xs font-black shadow-sm"
            title="Click to view Player ID or Login with Email (Bible Item 26)"
          >
            <span>{currentUser.role === 'owner' ? '👑' : '🆔'}</span>
            <span className="font-mono font-bold">#{currentUser.id}</span>
          </button>

          {/* Admin / Dev Controls Button */}
          <button
            onClick={() => {
              sound.playClick();
              setActiveModal('admin');
            }}
            className="p-2 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-300 hover:bg-rose-500/40 transition"
            title="Admin & Testing Controls"
          >
            <ShieldCheck size={17} />
          </button>
        </div>
      </header>

      {/* ========================================================
          2. MAIN CONTENT VIEW SWITCHER
         ======================================================== */}
      <main className="flex-1 w-full pt-4 sm:pt-6">
        {/* VIEW 1: LOBBY */}
        {currentView === 'lobby' && (
          <LobbyView
            onStartGame={handleStartGame}
            onNavigate={(view) => setCurrentView(view)}
            onOpenModal={(modal) => setActiveModal(modal)}
            onOpenWheel={() => setIsWheelOpen(true)}
            onOpenDrawer={() => setIsDrawerOpen(true)}
            userDiamonds={userDiamonds}
            userCoins={userCoins}
            equippedAstra={equippedAstraId}
          />
        )}

        {/* VIEW 2: LIVE ROOMS DIRECTORY */}
        {currentView === 'rooms' && (
          <LiveRoomsDirectoryView
            onEnterRoom={handleEnterRoom}
            onNavigate={(view) => setCurrentView(view)}
          />
        )}

        {/* VIEW 3: LIVE ROOM STAGE & 3D LUDO PLAY ARENA */}
        {currentView === 'arena' && (
          <div className="w-full max-w-5xl mx-auto space-y-4 px-2 sm:px-4 pb-24 animate-fade-in">
            {/* Top Stage Header with Astra Summon Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-2xl glass-panel border border-amber-500/20">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
                  <Flame size={18} className="animate-pulse" />
                </span>
                <div>
                  {activePrivateRoom ? (
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                          <span>🎮 Private Room:</span>
                          <span className="font-mono text-amber-300 font-black">{activePrivateRoom.roomCode}</span>
                        </h2>
                        <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                          {activePrivateRoom.mode.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[11px] text-amber-300 font-mono font-bold">
                        Prize Pot: {activePrivateRoom.currency === 'coins' ? '🪙' : '💎'} {(activePrivateRoom.stakeAmount * 4).toLocaleString()}
                      </p>
                    </div>
                  ) : (
                    <div>
                      <h2 className="text-sm font-bold text-white">
                        Royal Dubai Penthouse · Ludo Royale 4P
                      </h2>
                      <p className="text-[11px] text-amber-300">
                        Astra Active · 8-Seat Live Audio Broadcasting
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 self-stretch sm:self-auto flex-wrap justify-center sm:justify-end">
                {/* Grand Victory Ceremony & Podium Button */}
                <button
                  onClick={() => {
                    sound.playClick();
                    setMatchWinner({ ...players[0], winStreak: userWinStreak });
                    setIsVictoryModalOpen(true);
                  }}
                  className="font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 shadow active:scale-95 transition"
                  title="View Grand Victory Podium & Ceremony"
                >
                  <Trophy size={14} className="text-yellow-400" />
                  <span>Victory Podium</span>
                  {userWinStreak > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-red-600 text-white font-black border border-amber-300 shadow">
                      🔥{userWinStreak}
                    </span>
                  )}
                </button>

                {/* Quick Astra Trigger Button with Visual Cooldown Timer */}
                <button
                  onClick={() => handleActivateAstra(ASTRA_ITEMS[0])}
                  disabled={astraCooldown > 0}
                  className={`relative overflow-hidden font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 justify-center transition-all ${
                    astraCooldown > 0
                      ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-not-allowed shadow-inner'
                      : isAstraGleam
                      ? 'liquid-btn-gold text-slate-950 shadow-[0_0_30px_rgba(251,191,36,0.9)] scale-105 border-2 border-yellow-200 animate-pulse'
                      : 'liquid-btn-gold text-slate-950 shadow-[0_0_20px_rgba(245,158,11,0.5)] hover:brightness-110 active:scale-95'
                  }`}
                  title={
                    astraCooldown > 0
                      ? `Astra recharging... ${astraCooldown}s remaining`
                      : 'Summon Trishul Tandav Divine Ability!'
                  }
                >
                  {/* Sweeping Visual Cooldown Progress Bar Overlay */}
                  {astraCooldown > 0 && (
                    <div
                      className="absolute inset-0 bg-black/65 pointer-events-none transition-all duration-1000 ease-linear flex items-center justify-end"
                      style={{
                        width: `${(astraCooldown / ASTRA_COOLDOWN_TOTAL) * 100}%`,
                      }}
                    >
                      <div className="w-1.5 h-full bg-amber-400/90 shadow-[0_0_10px_#f59e0b]" />
                    </div>
                  )}

                  <div className="relative z-10 flex items-center gap-1.5">
                    {astraCooldown > 0 ? (
                      <>
                        <span className="text-xs">⏳</span>
                        <span className="font-mono font-bold tracking-wider text-amber-300">
                          RECHARGING ({astraCooldown}s)
                        </span>
                      </>
                    ) : (
                      <>
                        <Zap
                          size={14}
                          className={`text-amber-950 fill-amber-950 ${
                            isAstraGleam ? 'animate-bounce text-slate-950' : 'animate-pulse'
                          }`}
                        />
                        <span>SUMMON TRISHUL TANDAV</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold border ${
                            isAstraGleam
                              ? 'bg-yellow-300 text-slate-950 font-black border-white shadow-[0_0_10px_#fde047]'
                              : 'bg-amber-950/80 text-amber-300 border-amber-400/40'
                          }`}
                        >
                          {isAstraGleam ? '✨ READY!' : 'READY'}
                        </span>
                      </>
                    )}
                  </div>
                </button>
              </div>
            </div>

            {/* 8-Seat VIP Live Audio Room with Immersion Minimizer */}
            <div className="w-full">
              <div className="flex items-center justify-between px-2 mb-1.5 text-xs text-slate-400">
                <span className="font-bold flex items-center gap-1.5 text-amber-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  VIP 8-Seat Live Audio Stage
                </span>
                <button
                  onClick={() => {
                    sound.playClick();
                    setIsSeatsExpanded(!isSeatsExpanded);
                  }}
                  className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-all font-semibold"
                >
                  {isSeatsExpanded ? 'Minimize Stage ▲' : 'Expand 8 Seats ▼'}
                </button>
              </div>

              {isSeatsExpanded && (
                <LiveRoomSeats
                  seats={seats}
                  currentUserId={1}
                  onSeatClick={(seat) => {
                    setGiftTargetSeat(seat);
                    setActiveModal('gifts');
                  }}
                  onSendGiftClick={(seat) => {
                    setGiftTargetSeat(seat);
                    setActiveModal('gifts');
                  }}
                  onToggleMic={handleToggleSeatMic}
                  onOpenBalloons={(seat) => {
                    setGiftTargetSeat(seat);
                    setActiveModal('balloons');
                  }}
                />
              )}
            </div>

            {/* Arena Main Split: 3D Ludo Board & Live Chat Feed */}
            <div className={`grid gap-4 items-start ${
              isImmersionMode
                ? 'grid-cols-1 w-full max-w-4xl mx-auto'
                : 'grid-cols-1 lg:grid-cols-3'
            }`}>
              {/* Left / Center: 3D Board & Physical 3D Dice Controls */}
              <div className={`${isImmersionMode ? 'w-full' : 'lg:col-span-2'} flex flex-col items-center space-y-4`}>
                <Ludo3DBoard
                  players={players}
                  activeColor={activePlayer.color}
                  diceValue={diceValue}
                  canRoll={canRoll}
                  selectableTokenIds={selectableTokenIds}
                  onSelectToken={(token) => handleTokenClick(token.id)}
                  activeAstraEffect={activeAstraEffect}
                  onDismissAstraEffect={() => setActiveAstraEffect(null)}
                  boardTheme={boardTheme}
                  onChangeTheme={(t) => setBoardTheme(t)}
                  onDiceRoll={handleDiceRoll}
                  isRollingDice={isRolling}
                  isImmersionMode={isImmersionMode}
                  onToggleImmersion={() => setIsImmersionMode((prev) => !prev)}
                  onThrowAtPlayer={() => handleThrowReaction(THROWABLE_LIST[0])}
                  isEarthquakeActive={isEarthquakeActive}
                  isShieldActive={isVajraShieldActive}
                  visual4D={visual4D}
                  onOpenVisualsModal={() => setActiveModal('visuals')}
                />

                {/* Real-Time Interactive Astra Weapons Bar (True In-Game Powers) */}
                <AstraWeaponsBar
                  onCastWeapon={handleCastAstraWeapon}
                  isShieldActive={isVajraShieldActive}
                  shieldTurnsRemaining={shieldTurnsRemaining}
                  cooldowns={weaponCooldowns}
                  disabled={isRolling}
                />

                {/* Active Butterfly Companion & In-Game Rules Bar */}
                {(() => {
                  const activeBf =
                    BUTTERFLY_SPECIES.find((b) => b.id === equippedButterflyId) ||
                    BUTTERFLY_SPECIES[2];
                  return (
                    <div className="w-full max-w-md px-3.5 py-2 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-amber-950/40 border border-emerald-500/30 flex items-center justify-between shadow-md">
                      <div className="flex items-center gap-2.5">
                        <div
                          onClick={() => setActiveModal('butterfly')}
                          className="w-8 h-8 rounded-xl flex items-center justify-center text-xl cursor-pointer hover:scale-110 transition shadow-inner border border-white/10"
                          style={{
                            background: `radial-gradient(circle, ${activeBf.glowColor}40 20%, #020617 80%)`,
                          }}
                          title="Click to view Butterfly Sanctuary"
                        >
                          <span className="animate-bounce">🦋</span>
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p className="text-[11px] font-black text-white">{activeBf.name}</p>
                            <span className="text-[8px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                              BUFF ACTIVE
                            </span>
                          </div>
                          <p className="text-[9px] text-amber-300 font-bold truncate max-w-[210px]">
                            ✨ {activeBf.buffTitle}: {activeBf.passivePerk}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          sound.playClick();
                          setActiveModal('rules');
                        }}
                        className="px-2 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 text-[10px] font-black flex items-center gap-1 transition cursor-pointer"
                        title="View Official Game Niyam (खेल के नियम)"
                      >
                        <span>📜</span>
                        <span>Niyam</span>
                      </button>
                    </div>
                  );
                })()}

                {/* Physical 3D Dice */}
                <div className="w-full max-w-md p-4 rounded-3xl glass-panel border border-amber-500/20 flex items-center justify-around">
                  <div className="text-left">
                    <p className="text-xs text-slate-400">Turn to Roll</p>
                    <p
                      className="text-base font-black capitalize"
                      style={{ color: activePlayer.color }}
                    >
                      {activePlayer.name} {activePlayer.isBot && '(Bot)'}
                    </p>
                    {bonusRoll && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 animate-bounce inline-block mt-0.5">
                        ⭐ BONUS ROLL!
                      </span>
                    )}
                  </div>

                  <Dice3D
                    value={diceValue}
                    isRolling={isRolling}
                    onRoll={handleDiceRoll}
                    canRoll={canRoll && !activePlayer.isBot}
                    activeColor={activePlayer.color}
                    bonusRoll={bonusRoll}
                    isHolographic={visual4D.holographicDice}
                  />
                </div>

                {/* Real-Time Board Throwables & Voice Taunts */}
                <BoardReactionsBar
                  onThrow={handleThrowReaction}
                  onTaunt={handleVoiceTaunt}
                />
              </div>

              {/* Right: Live Chat, Gifts & System Activity Feed */}
              <div className={`${isImmersionMode ? 'w-full max-w-xl mx-auto' : 'lg:col-span-1'} h-[480px] sm:h-[560px] w-full`}>
                <LiveChatFeed
                  messages={messages}
                  onSendMessage={(text) => {
                    sound.playClick();
                    setMessages((prev) => [
                      {
                        id: `msg-${Date.now()}`,
                        sender: 'VikingKing (You)',
                        avatar: seats[0].avatar,
                        text,
                        type: 'chat',
                        timestamp: 'Just now',
                        badge: 'VIP 10',
                      },
                      ...prev,
                    ]);
                  }}
                  isMicOn={isMicOn}
                  onToggleMic={() => {
                    sound.playMicBeep(!isMicOn);
                    setIsMicOn(!isMicOn);
                  }}
                  voiceEffect={voiceEffect}
                  onChangeVoiceEffect={setVoiceEffect}
                />
              </div>
            </div>
          </div>
        )}

        {/* VIEW 4: LEADERBOARDS & HALL OF FAME */}
        {currentView === 'leaderboard' && <LeaderboardView />}

        {/* VIEW 5: STORE & TREASURY */}
        {currentView === 'store' && (
          <StoreView
            userDiamonds={userDiamonds}
            userCoins={userCoins}
            onAddDiamonds={(amt) => setUserDiamonds((d) => d + amt)}
            onAddCoins={(amt) => setUserCoins((c) => c + amt)}
            onOpenModal={(modal) => setActiveModal(modal)}
          />
        )}

        {/* VIEW 6: USER PROFILE & FRAME ATELIER */}
        {currentView === 'profile' && (
          <ProfileView
            userDiamonds={userDiamonds}
            userCoins={userCoins}
            userStars={userStars}
            equippedFrame={equippedFrame}
            onEquipFrame={handleEquipFrame}
            equippedAstraId={equippedAstraId}
            equippedPetId={equippedPetId}
            onOpenModal={(modal) => setActiveModal(modal)}
            currentUser={currentUser}
            onOpenAuthModal={() => setActiveModal('auth')}
          />
        )}

        {/* VIEW 7: 3D CELESTIAL WORLD MAP */}
        {currentView === 'map' && (
          <WorldMapView
            onNavigate={(view) => setCurrentView(view)}
            onOpenModal={(modal) => setActiveModal(modal)}
            onOpenMuseum={() => setIsMuseumOpen(true)}
          />
        )}
      </main>

      {/* ========================================================
          3. FIXED BOTTOM DOCK (Mobile & Desktop Navigation)
         ======================================================== */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 glass-panel border-t border-white/10 px-2 sm:px-6 py-2">
        <div className="max-w-md sm:max-w-lg mx-auto flex items-center justify-around">
          {/* 1. Lobby */}
          <button
            onClick={() => {
              sound.playClick();
              setCurrentView('lobby');
            }}
            className={`flex flex-col items-center py-1 px-3 rounded-xl transition ${
              currentView === 'lobby'
                ? 'text-amber-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home size={20} />
            <span className="text-[10px] mt-0.5">Lobby</span>
          </button>

          {/* 2. Live Rooms */}
          <button
            onClick={() => {
              sound.playClick();
              setCurrentView('rooms');
            }}
            className={`flex flex-col items-center py-1 px-3 rounded-xl transition ${
              currentView === 'rooms'
                ? 'text-purple-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio size={20} className={currentView === 'rooms' ? 'animate-pulse' : ''} />
            <span className="text-[10px] mt-0.5">Live Rooms</span>
          </button>

          {/* 3. Play Arena (Elevated Center Button) */}
          <button
            onClick={() => {
              sound.playDiceRoll();
              setCurrentView('arena');
            }}
            className="flex flex-col items-center -translate-y-2 py-1 px-3 group"
          >
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl shadow-2xl transition duration-300 ${
                currentView === 'arena'
                  ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 scale-110 shadow-[0_0_20px_rgba(255,215,0,0.6)]'
                  : 'bg-gradient-to-tr from-purple-600 to-amber-500 text-white group-hover:scale-105'
              }`}
            >
              🎲
            </div>
            <span
              className={`text-[10px] mt-0.5 font-bold ${
                currentView === 'arena' ? 'text-amber-400' : 'text-slate-300'
              }`}
            >
              Arena
            </span>
          </button>

          {/* 4. Leaderboard */}
          <button
            onClick={() => {
              sound.playClick();
              setCurrentView('leaderboard');
            }}
            className={`flex flex-col items-center py-1 px-3 rounded-xl transition ${
              currentView === 'leaderboard'
                ? 'text-yellow-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy size={20} />
            <span className="text-[10px] mt-0.5">Rankings</span>
          </button>

          {/* 5. Store */}
          <button
            onClick={() => {
              sound.playClick();
              setCurrentView('store');
            }}
            className={`flex flex-col items-center py-1 px-3 rounded-xl transition ${
              currentView === 'store'
                ? 'text-cyan-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Coins size={20} />
            <span className="text-[10px] mt-0.5">Store</span>
          </button>

          {/* 6. Profile */}
          <button
            onClick={() => {
              sound.playClick();
              setCurrentView('profile');
            }}
            className={`flex flex-col items-center py-1 px-3 rounded-xl transition ${
              currentView === 'profile'
                ? 'text-pink-400 font-bold scale-105'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User size={20} />
            <span className="text-[10px] mt-0.5">Profile</span>
          </button>
        </div>
      </nav>

      {/* ========================================================
          4. MODALS & SLIDE-OUT DRAWERS
         ======================================================== */}
      {/* Smooth Side Drawer for +More Features */}
      <ModalFadeWrapper isClosing={closingModal === 'drawer'}>
        <SideDrawer
          isOpen={isDrawerOpen || closingModal === 'drawer'}
          onClose={() => handleCloseWithExitAnimation('drawer')}
          onOpenModal={(modal) => setActiveModal(modal)}
          onNavigate={(view) => setCurrentView(view)}
          onOpenMuseum={() => setIsMuseumOpen(true)}
          isAudioMuted={isAudioMuted}
          onToggleAudio={handleToggleAudio}
        />
      </ModalFadeWrapper>

      {/* 3D Player Museum Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'museum'}>
        <PlayerMuseumModal
          isOpen={isMuseumOpen || closingModal === 'museum'}
          onClose={() => handleCloseWithExitAnimation('museum')}
          equippedPetId={equippedPetId}
          equippedAstraId={equippedAstraId}
          userFame={42500}
        />
      </ModalFadeWrapper>

      {/* Daily Lucky Spin Wheel */}
      <ModalFadeWrapper isClosing={closingModal === 'wheel'}>
        <DailyWheelModal
          isOpen={isWheelOpen || closingModal === 'wheel'}
          onClose={() => handleCloseWithExitAnimation('wheel')}
          onClaimReward={(type, amount) => {
            if (type === 'diamonds') setUserDiamonds((d) => d + amount);
            else if (type === 'coins') setUserCoins((c) => c + amount);
            else setUserStars((s) => s + amount);
          }}
        />
      </ModalFadeWrapper>

      {/* Astra Universe & Astra Forge */}
      <ModalFadeWrapper isClosing={closingModal === 'astra'}>
        <AstraUniverseModal
          isOpen={activeModal === 'astra' || closingModal === 'astra'}
          onClose={() => handleCloseWithExitAnimation('astra')}
          userDiamonds={userDiamonds}
          unlockedAstraIds={unlockedAstraIds}
          equippedAstraId={equippedAstraId}
          astraInventory={astraInventory}
          onEquipAstra={(astra) => setEquippedAstraId(astra.id)}
          onBuyAstra={(astra) => {
            setUserDiamonds((d) => d - astra.permanentDiamondCost);
            setAstraInventory((prev) => ({
              ...prev,
              [astra.id]: (prev[astra.id] || 0) + 1,
            }));
          }}
          onTestAstraFX={(astra) => handleActivateAstra(astra)}
          onForgeAstra={handleForgeAstra}
          onAddTestAstraCopies={handleAddTestAstraCopies}
          onTriggerCombo={(comboName, desc) => {
            setActiveCombo({
              name: comboName,
              count: comboName.includes('Tandav') ? 4 : 3,
              description: desc,
              petReactionEmoji: '🐉',
            });
          }}
        />
      </ModalFadeWrapper>

      {/* 30 Rare Pets Universe */}
      <ModalFadeWrapper isClosing={closingModal === 'pets'}>
        <PetUniverseModal
          isOpen={activeModal === 'pets' || closingModal === 'pets'}
          onClose={() => handleCloseWithExitAnimation('pets')}
          pets={pets}
          equippedPetId={equippedPetId}
          onEquipPet={(pet) => setEquippedPetId(pet.id)}
          onFeedPet={(id) => {
            setPets((prev) =>
              prev.map((p) =>
                p.id === id ? { ...p, affection: Math.min(100, p.affection + 5) } : p
              )
            );
          }}
        />
      </ModalFadeWrapper>

      {/* 3D Gift Store Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'gifts'}>
        <GiftStoreModal
          isOpen={activeModal === 'gifts' || closingModal === 'gifts'}
          onClose={() => handleCloseWithExitAnimation('gifts')}
          seats={seats}
          targetSeat={giftTargetSeat}
          userDiamonds={userDiamonds}
          userCoins={userCoins}
          onSendGift={handleSendGift}
        />
      </ModalFadeWrapper>

      {/* Cosmic Codex & 14 Lokas */}
      <ModalFadeWrapper isClosing={closingModal === 'codex'}>
        <CosmicCodexModal
          isOpen={activeModal === 'codex' || closingModal === 'codex'}
          onClose={() => handleCloseWithExitAnimation('codex')}
          onClaimBlessing={(c, d) => {
            setUserCoins((prev) => prev + c);
            setUserDiamonds((prev) => prev + d);
            setHasClaimedCodex(true);
          }}
          hasClaimedBlessing={hasClaimedCodex}
        />
      </ModalFadeWrapper>

      {/* Mini-Games Hub */}
      <ModalFadeWrapper isClosing={closingModal === 'minigames'}>
        <MiniGamesModal
          isOpen={activeModal === 'minigames' || closingModal === 'minigames'}
          onClose={() => handleCloseWithExitAnimation('minigames')}
          onEarnReward={(c, d, msg) => {
            setUserCoins((prev) => prev + c);
            setUserDiamonds((prev) => prev + d);
            setUserChillies((prev) => prev + 10);
            setMessages((prev) => [
              {
                id: `mg-${Date.now()}`,
                sender: 'Mini-Game Hub',
                avatar: '',
                text: `🎯 ${msg} (+${c.toLocaleString()} 🪙 Coins & +${d.toLocaleString()} 💎 Diamonds & +10 🌶️ Chillies)`,
                type: 'gift',
                timestamp: 'Just now',
              },
              ...prev,
            ]);
          }}
          onOpenModels={() => setActiveModal('models')}
        />
      </ModalFadeWrapper>

      {/* Crates & Mystery Chests */}
      <ModalFadeWrapper isClosing={closingModal === 'crates'}>
        <CratesModal
          isOpen={activeModal === 'crates' || closingModal === 'crates'}
          onClose={() => handleCloseWithExitAnimation('crates')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onOpenCrate={(c, d, title) => {
            setUserCoins((prev) => prev + c);
            setUserDiamonds((prev) => prev + d);
          }}
        />
      </ModalFadeWrapper>

      {/* Admin Center & Sandbox Testing Controls */}
      <ModalFadeWrapper isClosing={closingModal === 'admin'}>
        <AdminCenterModal
          isOpen={activeModal === 'admin' || closingModal === 'admin'}
          onClose={() => handleCloseWithExitAnimation('admin')}
          onAddDiamonds={(amt) => setUserDiamonds((d) => d + amt)}
          onAddCoins={(amt) => setUserCoins((c) => c + amt)}
          onSetForcedDice={setForcedDiceVal}
          forcedDiceVal={forcedDiceVal}
          onTriggerEntryTest={(type) => {
            setActiveEntryCinematic({
              type,
              name: 'VikingKing',
              title:
                type === 'signature-photo'
                  ? '5,000 Star Signature Photo Entrance'
                  : type === 'cyber-dragon'
                  ? 'Cyber-Dragon Royal Cosmic Flight'
                  : type === 'hypercar'
                  ? 'Neon Bugatti Supercar Entry'
                  : type === 'sudarshan'
                  ? '79 Billion 💎 Sudarshan Om Vortex'
                  : type === 'gada'
                  ? '59 Million 💎 Hanuman Gada Strike'
                  : '19.9 Million 💎 Nataraja Tandav Aura',
            });
          }}
          boardTheme={boardTheme}
          onChangeBoardTheme={setBoardTheme}
          botSpeed={botSpeed}
          onChangeBotSpeed={setBotSpeed}
          isGhostMode={isGhostMode}
          onToggleGhostMode={() => {
            const next = !isGhostMode;
            setIsGhostMode(next);
            setSeats((prev) =>
              prev.map((s) =>
                s.id === 1
                  ? {
                      ...s,
                      title: next ? '👻 Ghost Admin (Invisible)' : 'Trishul Master',
                      playerName: next ? '👻 Ghost Admin' : 'VikingKing (You)',
                    }
                  : s
              )
            );
          }}
          onTriggerMiracleArrival={() => setIsMiracleActive(true)}
          onTriggerTakshakNag={() => setIsTakshakActive(true)}
          onTriggerVictoryTest={() => setIsVictoryModalOpen(true)}
        />
      </ModalFadeWrapper>

      {/* Miracle Arrival: Tiny Character sprint, velvet curtain & 10s funny dialogue */}
      <ModalFadeWrapper isClosing={closingModal === 'miracle'}>
        <MiracleArrivalOverlay
          isOpen={isMiracleActive || closingModal === 'miracle'}
          onClose={() => handleCloseWithExitAnimation('miracle')}
          senderName="VikingKing"
          targetName="Princess Balqis"
          targetAvatar="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&auto=format&fit=crop&q=80"
        />
      </ModalFadeWrapper>

      {/* Takshak Nag Board Masti Harmless Cosmetic Effect */}
      <ModalFadeWrapper isClosing={closingModal === 'takshak'}>
        <TakshakNagOverlay
          isActive={isTakshakActive || closingModal === 'takshak'}
          onFinish={() => handleCloseWithExitAnimation('takshak')}
          targetPetName="Princess Balqis's Amethyst Kitty"
        />
      </ModalFadeWrapper>

      {/* Full-Screen Cinematic Entry Overlay (Bible Item 21) */}
      <ModalFadeWrapper isClosing={closingModal === 'cinematic'}>
        <EntryCinematicOverlay
          entryType={activeEntryCinematic.type}
          playerName={activeEntryCinematic.name}
          title={activeEntryCinematic.title}
          playerAvatar={seats[0].avatar}
          onFinish={() => handleCloseWithExitAnimation('cinematic')}
        />
      </ModalFadeWrapper>

      {/* 3D Glamour Models Cinematic Arrival Overlay (Bible Item 17: 5s reveal, 10s funny dialogues) */}
      <ModalFadeWrapper isClosing={closingModal === 'model-presentation'}>
        <ModelPresentationOverlay
          model={selectedModelArrival}
          onClose={() => handleCloseWithExitAnimation('model-presentation')}
        />
      </ModalFadeWrapper>

      {/* Astra Combo & Masti Sequence Overlay (Bible Item 19: Cosmetic counter & pet reaction) */}
      <ModalFadeWrapper isClosing={closingModal === 'combo'}>
        {activeCombo && (
          <AstraComboOverlay
            comboName={activeCombo.name}
            comboCount={activeCombo.count}
            comboDescription={activeCombo.description}
            petReactionEmoji={activeCombo.petReactionEmoji}
            onFinish={() => handleCloseWithExitAnimation('combo')}
          />
        )}
      </ModalFadeWrapper>

      {/* 3D Glamour Models Atelier Modal (Bible Item 17) */}
      <ModalFadeWrapper isClosing={closingModal === 'models'}>
        <ModelGalleryModal
          isOpen={activeModal === 'models' || closingModal === 'models'}
          onClose={() => handleCloseWithExitAnimation('models')}
          userChillies={userChillies}
          onSpendChillies={(amount) =>
            setUserChillies((prev) => Math.max(0, prev - amount))
          }
          onTriggerModelArrival={(model) => {
            sound.playTrophy();
            setSelectedModelArrival(model);
            setMessages((prev) => [
              {
                id: `model-${Date.now()}`,
                sender: model.name,
                avatar: model.image,
                text: `👑 "${model.dialogue}"`,
                type: 'chat',
                timestamp: 'Just now',
                badge: model.title,
              },
              ...prev,
            ]);
          }}
        />
      </ModalFadeWrapper>

      {/* Private Custom Room Modal (Play with Friends) */}
      <ModalFadeWrapper isClosing={closingModal === 'private-room'}>
        <PrivateRoomModal
          isOpen={activeModal === 'private-room' || closingModal === 'private-room'}
          onClose={() => handleCloseWithExitAnimation('private-room')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onStartPrivateMatch={handleStartPrivateMatch}
        />
      </ModalFadeWrapper>

      {/* Royal Grand Victory Ceremony & Podium Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'victory'}>
        <MatchVictoryModal
          isOpen={isVictoryModalOpen || closingModal === 'victory'}
          onClose={() => handleCloseWithExitAnimation('victory')}
          winner={matchWinner}
          players={players}
          winStreak={userWinStreak}
          onStreakChange={(s) => setUserWinStreak(s)}
          onPlayAgain={handlePlayAgain}
          onReturnToLobby={() => {
            setCurrentView('lobby');
            handleCloseWithExitAnimation('victory');
          }}
          onClaimRewards={handleClaimVictoryRewards}
        />
      </ModalFadeWrapper>

      {/* Season 1: Kurukshetra Cosmic Pass & Quests Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'pass'}>
        <SeasonPassModal
          isOpen={activeModal === 'pass' || closingModal === 'pass'}
          onClose={() => handleCloseWithExitAnimation('pass')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onAddCoins={(amt) => setUserCoins((c) => Math.max(0, c + amt))}
          onAddDiamonds={(amt) => setUserDiamonds((d) => Math.max(0, d + amt))}
        />
      </ModalFadeWrapper>

      {/* Grand Collections Vault (Unified 8-Category Showcase Hub) */}
      <ModalFadeWrapper isClosing={closingModal === 'collections'}>
        <GrandCollectionsModal
          isOpen={activeModal === 'collections' || closingModal === 'collections'}
          onClose={() => handleCloseWithExitAnimation('collections')}
          userDiamonds={userDiamonds}
          userCoins={userCoins}
          equippedAstraId={equippedAstraId}
          onEquipAstra={(id) => setEquippedAstraId(id)}
          equippedPetId={equippedPetId}
          onEquipPet={(id) => setEquippedPetId(id)}
          equippedButterflyId={equippedButterflyId}
          onEquipButterfly={(id) => setEquippedButterflyId(id)}
          onOpenButterflyModal={() => setActiveModal('butterfly')}
          onTestAstraFX={(astra) => handleActivateAstra(astra)}
          onOpenStore={() => {
            handleCloseWithExitAnimation('collections');
            setCurrentView('store');
          }}
        />
      </ModalFadeWrapper>

      {/* Mystic Butterfly Egg & Hatchery Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'butterfly'}>
        <ButterflyEggModal
          isOpen={activeModal === 'butterfly' || closingModal === 'butterfly'}
          onClose={() => handleCloseWithExitAnimation('butterfly')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onDeductCoins={(amt) => setUserCoins((c) => Math.max(0, c - amt))}
          onDeductDiamonds={(amt) => setUserDiamonds((d) => Math.max(0, d - amt))}
          equippedButterflyId={equippedButterflyId}
          onEquipButterfly={(id) => setEquippedButterflyId(id)}
          onOpenRules={() => setActiveModal('rules')}
        />
      </ModalFadeWrapper>

      {/* Official Game Niyam (खेल के नियम) Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'rules'}>
        <GameNiyamModal
          isOpen={activeModal === 'rules' || closingModal === 'rules'}
          onClose={() => handleCloseWithExitAnimation('rules')}
          onOpenButterflyModal={() => setActiveModal('butterfly')}
          onOpenAstraModal={() => setActiveModal('astra')}
        />
      </ModalFadeWrapper>

      {/* Android APK & Mobile App Download Center */}
      <ModalFadeWrapper isClosing={closingModal === 'apk'}>
        <ApkDownloadModal
          isOpen={activeModal === 'apk' || closingModal === 'apk'}
          onClose={() => handleCloseWithExitAnimation('apk')}
        />
      </ModalFadeWrapper>

      {/* 7-Day Daily Login Streak Calendar Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'streak'}>
        <DailyStreakModal
          isOpen={activeModal === 'streak' || closingModal === 'streak'}
          onClose={() => handleCloseWithExitAnimation('streak')}
          onClaimReward={(reward) => {
            if (reward.type === 'coins') {
              setUserCoins((c) => c + reward.amount);
            } else if (reward.type === 'diamonds') {
              setUserDiamonds((d) => d + reward.amount);
            } else if (reward.type === 'egg') {
              // Player claimed a rare/emerald butterfly egg!
              sound.playGrandVictory();
              setActiveModal('butterfly');
            }
          }}
          onOpenButterflyHatchery={() => {
            setActiveModal('butterfly');
          }}
        />
      </ModalFadeWrapper>

      {/* Celestial 3D Dice Forge & Enchantment Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'forge'}>
        <DiceForgeModal
          isOpen={activeModal === 'forge' || closingModal === 'forge'}
          onClose={() => handleCloseWithExitAnimation('forge')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onDeductCoins={(amt) => setUserCoins((c) => Math.max(0, c - amt))}
          onDeductDiamonds={(amt) => setUserDiamonds((d) => Math.max(0, d - amt))}
        />
      </ModalFadeWrapper>

      {/* Royal Clans & Guilds War Sanctuary Modal */}
      <ModalFadeWrapper isClosing={closingModal === 'clan'}>
        <ClanWarModal
          isOpen={activeModal === 'clan' || closingModal === 'clan'}
          onClose={() => handleCloseWithExitAnimation('clan')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onStartClanMatch={() => {
            handleStartGame('astra');
          }}
        />
      </ModalFadeWrapper>

      {/* LUDO MASTER GAME BIBLE (Page 2 Concept Reference & 10 Systems Audit) */}
      <ModalFadeWrapper isClosing={closingModal === 'bible'}>
        <GameBibleModal
          isOpen={activeModal === 'bible' || closingModal === 'bible'}
          onClose={() => handleCloseWithExitAnimation('bible')}
          onNavigate={(view) => setCurrentView(view)}
          onOpenModal={(modal) => setActiveModal(modal)}
          userDiamonds={userDiamonds}
          userCoins={userCoins}
          userStars={userStars}
        />
      </ModalFadeWrapper>

      {/* Interactive Game Tutorial Modal (Bible Item 40: Watch or Skip) */}
      <ModalFadeWrapper isClosing={closingModal === 'tutorial'}>
        <InteractiveTutorialModal
          isOpen={activeModal === 'tutorial' || closingModal === 'tutorial'}
          onClose={() => handleCloseWithExitAnimation('tutorial')}
          onNavigateToArena={() => {
            handleCloseWithExitAnimation('tutorial');
            setCurrentView('arena');
          }}
        />
      </ModalFadeWrapper>

      {/* Official Mission & Quest Board Modal (Bible Section 19) */}
      <ModalFadeWrapper isClosing={closingModal === 'missions'}>
        <MissionQuestBoardModal
          isOpen={activeModal === 'missions' || closingModal === 'missions'}
          onClose={() => handleCloseWithExitAnimation('missions')}
          onClaimReward={(type, amount) => {
            if (type === 'coins') setUserCoins((c) => c + amount);
            else if (type === 'diamonds') {
              const currentEarned = dailyCutDiamondsEarned;
              const add = Math.min(amount, Math.max(0, 40 - currentEarned));
              setDailyCutDiamondsEarned((d) => d + add);
              setUserDiamonds((d) => d + add);
            } else if (type === 'stars') setUserStars((s) => s + amount);
          }}
          onNavigateToGame={(target) => {
            handleCloseWithExitAnimation('missions');
            if (target === 'arena') setCurrentView('arena');
            else if (target === 'rooms') setCurrentView('rooms');
            else if (target === 'minigames') setActiveModal('minigames');
            else if (target === 'astra') setActiveModal('astra');
            else if (target === 'forge') setActiveModal('forge');
            else if (target === 'balloons') setActiveModal('balloons');
          }}
          userDiamonds={userDiamonds}
          userCoins={userCoins}
        />
      </ModalFadeWrapper>

      {/* Balloons & Splash Interaction Modal (Bible Item 11: 20+ variants, 2💎 splash) */}
      <ModalFadeWrapper isClosing={closingModal === 'balloons'}>
        <BalloonsModal
          isOpen={activeModal === 'balloons' || closingModal === 'balloons'}
          onClose={() => handleCloseWithExitAnimation('balloons')}
          userDiamonds={userDiamonds}
          onThrowBalloon={(balloon, targetSeatName) => {
            setUserDiamonds((d) => Math.max(0, d - balloon.diamondCost));
            setActiveImpacts((prev) => [
              {
                id: `bal-${Date.now()}`,
                type: balloon.effectType === 'bomb' ? 'bomb' : 'water',
                emoji: balloon.icon,
                senderName: 'VikingKing',
                tauntText: balloon.splatDecal,
                x: 50 + (Math.random() - 0.5) * 40,
                y: 50 + (Math.random() - 0.5) * 40,
              },
              ...prev,
            ]);
            setMessages((prev) => [
              {
                id: `bal-msg-${Date.now()}`,
                sender: 'Balloon Splash',
                avatar: '',
                text: `🎈 ${balloon.icon} ${balloon.name} splashed on ${targetSeatName}! (-2 💎)`,
                type: 'chat',
                timestamp: 'Just now',
              },
              ...prev,
            ]);
          }}
        />
      </ModalFadeWrapper>

      {/* Couple & Social Sanctuary Modal (Bible Item 14: 10 double-hearts, 50 birthday hearts) */}
      <ModalFadeWrapper isClosing={closingModal === 'couple'}>
        <CoupleSocialModal
          isOpen={activeModal === 'couple' || closingModal === 'couple'}
          onClose={() => handleCloseWithExitAnimation('couple')}
          userCoins={userCoins}
          userDiamonds={userDiamonds}
          onAddHearts={(hearts) => {
            setUserStars((s) => s + hearts);
          }}
        />
      </ModalFadeWrapper>

      {/* Flute Tiny Character Collection Modal (Bible Item 20) */}
      <ModalFadeWrapper isClosing={closingModal === 'flute'}>
        <FluteCollectionModal
          isOpen={activeModal === 'flute' || closingModal === 'flute'}
          onClose={() => handleCloseWithExitAnimation('flute')}
          selectedTinyId={selectedTinyId}
          onSelectTiny={(tiny) => setSelectedTinyId(tiny.id)}
          privacyMode={tinyPrivacyMode}
          onChangePrivacyMode={setTinyPrivacyMode}
          onTestMiracleArrival={() => {
            setIsMiracleActive(true);
          }}
        />
      </ModalFadeWrapper>

      {/* 4D & Neon-Liquid Family Suite Modal (Bible Item 22) */}
      <ModalFadeWrapper isClosing={closingModal === 'visuals'}>
        <NeonLiquidVisualsModal
          isOpen={activeModal === 'visuals' || closingModal === 'visuals'}
          onClose={() => handleCloseWithExitAnimation('visuals')}
          visuals={visual4D}
          onToggleVisual={(key, val) => {
            setVisual4D((prev) => ({
              ...prev,
              [key]: val !== undefined ? val : !prev[key],
            }));
          }}
        />
      </ModalFadeWrapper>

      {/* Player Login / Unique ID Auth Board Modal (Bible Item 26) */}
      <ModalFadeWrapper isClosing={closingModal === 'auth'}>
        <LoginAuthModal
          isOpen={activeModal === 'auth' || closingModal === 'auth'}
          onClose={() => handleCloseWithExitAnimation('auth')}
          currentUser={currentUser}
          onUserChange={(newUser) => {
            setCurrentUser(newUser);
            if (newUser.role === 'owner') {
              setUserDiamonds((d) => Math.max(d, 100000000));
              setUserCoins((c) => Math.max(c, 2500000));
            }
            setSeats((prev) =>
              prev.map((s) =>
                s.id === 1
                  ? {
                      ...s,
                      playerName: newUser.name,
                      avatar: newUser.avatar,
                      title: newUser.role === 'owner' ? 'Sovereign Owner' : newUser.tag,
                    }
                  : s
              )
            );
          }}
        />
      </ModalFadeWrapper>

      {/* Floating In-Game Reaction & Throwable Impacts Overlay */}
      <ReactionImpactOverlay
        impacts={activeImpacts}
        onRemoveImpact={(id) =>
          setActiveImpacts((prev) => prev.filter((i) => i.id !== id))
        }
      />
    </div>
  );
}
