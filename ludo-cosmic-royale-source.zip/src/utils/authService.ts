// Authentication & Player Unique ID Management Service
// Bible Point 26:
// Owner ID: 777777 with verified akvikings05@gmail.com
// Other players: Sequential IDs starting from 100002 onwards

export interface PlayerUser {
  id: string; // e.g. "777777" or "100002"
  email: string;
  name: string;
  role: 'owner' | 'admin' | 'player';
  isVerified: boolean;
  diamonds: number;
  coins: number;
  stars: number;
  tag: string;
  avatar: string;
  frameStyle: string;
  createdAt: string;
}

const STORAGE_KEY_USER = 'ludo_auth_current_user';
const STORAGE_KEY_USERS_DB = 'ludo_auth_users_database';
const STORAGE_KEY_NEXT_ID = 'ludo_auth_next_user_id';

// Default Owner profile
export const OWNER_USER: PlayerUser = {
  id: '777777',
  email: 'akvikings05@gmail.com',
  name: 'VikingKing (Owner)',
  role: 'owner',
  isVerified: true,
  diamonds: 100000000,
  coins: 2500000,
  stars: 5200,
  tag: 'President 👑',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
  frameStyle: 'frame-gold-wings',
  createdAt: '2026-01-01',
};

// Initial Seed Users
const INITIAL_USERS: PlayerUser[] = [
  OWNER_USER,
  {
    id: '100002',
    email: 'aditi.royal@gmail.com',
    name: 'Aditi Sharma',
    role: 'player',
    isVerified: true,
    diamonds: 11245,
    coins: 200000000,
    stars: 3800,
    tag: 'Diamond Mafia 💎',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=140&auto=format&fit=crop&q=80',
    frameStyle: 'frame-purple-empress',
    createdAt: '2026-02-10',
  },
  {
    id: '100003',
    email: 'karan.singh@gmail.com',
    name: 'Karan Singh',
    role: 'player',
    isVerified: true,
    diamonds: 7240,
    coins: 80000000,
    stars: 1950,
    tag: 'Egg Hunter 🥚',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=140&auto=format&fit=crop&q=80',
    frameStyle: 'frame-lion-crest',
    createdAt: '2026-03-01',
  },
  {
    id: '100004',
    email: 'zoya.diva@gmail.com',
    name: 'Zoya Khan',
    role: 'player',
    isVerified: true,
    diamonds: 5128,
    coins: 45000000,
    stars: 2800,
    tag: 'Matrix Master ⚡',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=140&auto=format&fit=crop&q=80',
    frameStyle: 'frame-neon-heart',
    createdAt: '2026-03-15',
  },
];

class AuthService {
  private users: PlayerUser[] = [];
  private currentUser: PlayerUser = OWNER_USER;
  private nextSequentialId: number = 100005;

  constructor() {
    this.loadState();
  }

  private safeGetItem(key: string): string | null {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        return window.localStorage.getItem(key);
      }
    } catch {
      // In restricted webviews or incognito, localStorage may throw SecurityError
    }
    return null;
  }

  private safeSetItem(key: string, value: string): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, value);
      }
    } catch {
      // Graceful fallback to memory
    }
  }

  private loadState() {
    try {
      // Load users
      const storedUsers = this.safeGetItem(STORAGE_KEY_USERS_DB);
      if (storedUsers) {
        this.users = JSON.parse(storedUsers);
      } else {
        this.users = [...INITIAL_USERS];
        this.saveUsers();
      }

      // Load next ID
      const storedNextId = this.safeGetItem(STORAGE_KEY_NEXT_ID);
      if (storedNextId) {
        this.nextSequentialId = parseInt(storedNextId, 10);
      } else {
        this.nextSequentialId = 100005;
        this.safeSetItem(STORAGE_KEY_NEXT_ID, '100005');
      }

      // Load current user
      const storedCurrent = this.safeGetItem(STORAGE_KEY_USER);
      if (storedCurrent) {
        this.currentUser = JSON.parse(storedCurrent);
      } else {
        // Default to Owner on first run
        this.currentUser = OWNER_USER;
        this.saveCurrentUser();
      }
    } catch {
      this.currentUser = OWNER_USER;
      this.users = [...INITIAL_USERS];
    }
  }

  private saveUsers() {
    this.safeSetItem(STORAGE_KEY_USERS_DB, JSON.stringify(this.users));
  }

  private saveCurrentUser() {
    this.safeSetItem(STORAGE_KEY_USER, JSON.stringify(this.currentUser));
  }

  public getCurrentUser(): PlayerUser {
    return this.currentUser;
  }

  public getAllUsers(): PlayerUser[] {
    return [...this.users];
  }

  public isOwner(): boolean {
    return this.currentUser.email === 'akvikings05@gmail.com' || this.currentUser.id === '777777';
  }

  // Login via Email
  public loginWithEmail(emailInput: string): { user: PlayerUser; isNew: boolean; message: string } {
    const cleanEmail = emailInput.trim().toLowerCase();

    // Check if logging in as Sovereign Owner
    if (cleanEmail === 'akvikings05@gmail.com') {
      this.currentUser = OWNER_USER;
      // ensure owner is in users list
      if (!this.users.some((u) => u.id === '777777')) {
        this.users.unshift(OWNER_USER);
        this.saveUsers();
      }
      this.saveCurrentUser();
      return {
        user: OWNER_USER,
        isNew: false,
        message: '🔱 Welcome back, Sovereign Owner! Logged in with ID #777777 and Super Admin privileges.',
      };
    }

    // Check existing registered user
    const existing = this.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (existing) {
      this.currentUser = existing;
      this.saveCurrentUser();
      return {
        user: existing,
        isNew: false,
        message: `Welcome back, ${existing.name}! Logged in with ID #${existing.id}.`,
      };
    }

    // Register new user with sequential ID starting from 100002+
    const newId = this.nextSequentialId.toString();
    this.nextSequentialId += 1;
    this.safeSetItem(STORAGE_KEY_NEXT_ID, this.nextSequentialId.toString());

    const username = cleanEmail.split('@')[0];
    const capitalizedName = username.charAt(0).toUpperCase() + username.slice(1);

    const newUser: PlayerUser = {
      id: newId,
      email: cleanEmail,
      name: capitalizedName,
      role: 'player',
      isVerified: true,
      diamonds: 5000,
      coins: 100000,
      stars: 100,
      tag: 'Egg Hunter 🥚',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
      frameStyle: 'frame-gold-wings',
      createdAt: new Date().toISOString().split('T')[0],
    };

    this.users.push(newUser);
    this.saveUsers();
    this.currentUser = newUser;
    this.saveCurrentUser();

    return {
      user: newUser,
      isNew: true,
      message: `🎉 Account Created! Your permanent Player ID is #${newId}. A confirmation email has been dispatched to ${cleanEmail}. You can login anytime with your Email or ID #${newId}!`,
    };
  }

  // Login via User ID
  public loginWithId(idInput: string): { user: PlayerUser | null; message: string } {
    const cleanId = idInput.trim();

    if (cleanId === '777777') {
      this.currentUser = OWNER_USER;
      this.saveCurrentUser();
      return {
        user: OWNER_USER,
        message: '🔱 Sovereign Owner verified! Logged in with ID #777777.',
      };
    }

    const found = this.users.find((u) => u.id === cleanId);
    if (found) {
      this.currentUser = found;
      this.saveCurrentUser();
      return {
        user: found,
        message: `Welcome back! Logged in with ID #${found.id}.`,
      };
    }

    return {
      user: null,
      message: `Player ID #${cleanId} not found. Please check your ID or sign in with your email address.`,
    };
  }

  // Update current user profile
  public updateProfile(updates: Partial<PlayerUser>) {
    this.currentUser = { ...this.currentUser, ...updates };
    this.users = this.users.map((u) => (u.id === this.currentUser.id ? this.currentUser : u));
    this.saveCurrentUser();
    this.saveUsers();
  }

  // Logout / Switch
  public logout() {
    this.currentUser = OWNER_USER;
    this.saveCurrentUser();
  }
}

export const authService = new AuthService();
