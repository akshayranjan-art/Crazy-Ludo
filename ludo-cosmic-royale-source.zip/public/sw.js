const CACHE_NAME = 'ludo-cosmic-royale-v3';

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((key) => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});

// Robust pass-through fetch handler that never returns undefined or causes network errors
self.addEventListener('fetch', (event) => {
  // Only handle GET requests
  if (event.request.method !== 'GET') return;

  // Let browser natively handle Vite dev modules, extensions, and web-sockets
  const url = event.request.url;
  if (!url.startsWith('http')) return;
  if (url.includes('/@vite') || url.includes('/__') || url.includes('sockjs')) return;

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Cache valid responses for offline resilience
        if (response && response.status === 200 && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone).catch(() => {});
          });
        }
        return response;
      })
      .catch(async () => {
        // Fallback to cache on network failure
        const cached = await caches.match(event.request);
        if (cached) return cached;
        // If navigating to page, fallback to root
        if (event.request.mode === 'navigate') {
          const cachedHome = await caches.match('/');
          if (cachedHome) return cachedHome;
        }
        // Return a valid Response so the browser never crashes with ERR_FAILED
        return new Response('Network offline. Reconnecting...', {
          status: 200,
          headers: { 'Content-Type': 'text/plain' },
        });
      })
  );
});
