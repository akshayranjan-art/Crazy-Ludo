JARVIS BRAIN — NEXTGEN ALPHA ECLIPSE v1.0.7

• Har Excel file = ek topic (sheet ka naam = topic).
• Column A = Question, B = Answer, C = Keywords (comma se alag, optional).
• Nayi file = naya topic. Nayi row = naya gyaan.
• Save karke HTML mein ⇄ SYNC (ya Jarvis → Files → Sync) dabao.
• My_Notes.json / SOPs.json = jo aap chat se Teach karte ho (apne aap).
