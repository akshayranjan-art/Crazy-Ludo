NEXTGEN ALPHA ECLIPSE v1.0.7 - PPT TEMPLATES
============================================

KAHAN DAALNA HAI
  Is poore folder ki saari files apne server folder me daalo:
  Eclipse_Tracker\PPT_Templates\
  Phir Tracker > Presentations > Templates > "Reload folder" dabao.
  Templates "Mere templates" me aa jayenge.

NAYA TEMPLATE KAISE BANAYE (1000 tak jitne chaho)
  1. Koi bhi .json file copy karo (jaise NGE_T01_Flower_Bloom.json).
  2. Naya naam do, jaise NGE_T51_My_Design.json.
  3. Notepad me kholo aur badlo:
       "name"     = template ka naam
       "palette"  = bg (background), ink (text ka rang), a (6 shape colours)
       "layouts"  = kis slide par kaunsa design
       "rotate"   = aapki extra slides par designs baari-baari se
       "background" = (optional) usi folder me rakhi PNG/JPG pic ka naam
  4. Save karo aur Reload dabao. Bas.

SLIDE TYPES (layouts me use karo)
  Title, Agenda, Problem, AS-IS, Solution, TO-BE, Before-After,
  Benefits, Team, Timeline, Next Steps, Thank You

DESIGN NAMES (layouts / rotate me likho)
  cards steps classify venn hexa timeline arrows cycle pyramid kpi compare
  flower puzzle origami pipeline isostack stairs chevcards wave cyclearrows
  ribbon target donut gear gantt kpihub insights spath arrowtarget layers3d
  yeararrow trophy topicstar halfarc sunburst speech agenda8 twist milestones
  ladder perspective radial5 pillcols bubbles quad pillars coins pdca octring
  rocket houses
  Covers: cover cover2 cover3

SIRF PIC SE TEMPLATE
  Koi bhi PNG/JPG (bina json) is folder me daalo, wo background wala
  template ban jayega.

DHYAAN
  - Galat design naam likha to wahan normal "cards" design aa jayega.
  - Json me comma / quotes sahi rakhna, warna wo file skip ho jayegi.
